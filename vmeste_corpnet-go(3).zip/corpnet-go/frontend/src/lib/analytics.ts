// Сбор аналитики: fetch keepalive не блокирует навигацию и переживает закрытие страницы (sendBeacon не умеет заголовок CSRF). Ошибки игнорируются.
import { csrfHeaders } from './api';
let lastPath = '';

function beacon(url: string, body: unknown) {
  try {
    const s = JSON.stringify(body);
    fetch(url, { method: 'POST', body: s, headers: csrfHeaders({ 'Content-Type': 'application/json' }), keepalive: true, credentials: 'same-origin' }).catch(() => {});
  } catch {}
}

/** Просмотр страницы (раздел определяет сервер по префиксу маршрута; id и query не отправляются). Один раз на смену path. */
export function trackPageview(path: string) {
  if (path === lastPath) return;
  lastPath = path;
  beacon('/api/analytics/pv', { p: path });
}
export function resetPageview() { lastPath = ''; }

/** Переход по результату поиска: запрос, раздел и объект (например news:12). */
export function trackSearchClick(q: string, scope: string, entity: string) {
  if (q.trim().length < 2) return;
  beacon('/api/analytics/search-click', { q, scope, entity });
}

/** Чтение новости: максимальная глубина прокрутки (0..100) и приращение активного времени в секундах. */
export function trackNewsRead(id: number, depth: number, seconds: number) {
  beacon(`/api/news-track/${id}/read`, { depth: Math.round(depth), seconds: Math.round(seconds) });
}
/** Показы карточек в ленте и переход по карточке. */
export function trackNewsImpressions(ids: number[], clicked = 0) {
  if (!ids.length && !clicked) return;
  beacon('/api/news-track/impressions', { ids, clicked });
}
/** Переход по категории ленты (0 — «Все»). */
export function trackNewsCategory(categoryId: number) {
  beacon('/api/news-track/category', { category_id: categoryId });
}
