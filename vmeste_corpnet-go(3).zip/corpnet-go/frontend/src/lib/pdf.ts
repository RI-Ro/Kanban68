// Мини-генератор PDF без внешних библиотек: страницы A4, векторная графика, TrueType-шрифты с кириллицей (Type0 / Identity-H),
// ToUnicode (текст выделяется и ищется), ссылки. Шрифты — подмножества Liberation Sans (public/fonts, лицензия OFL).
// Координаты — в пунктах от ЛЕВОГО ВЕРХНЕГО угла страницы (как в вёрстке); внутри переводятся в систему PDF.

export const A4 = { w: 595.28, h: 841.89 };
export type RGB = [number, number, number];
export const hex = (s: string): RGB => [parseInt(s.slice(1, 3), 16) / 255, parseInt(s.slice(3, 5), 16) / 255, parseInt(s.slice(5, 7), 16) / 255];

// ---------------------------------------------------------------- разбор TrueType

export class Ttf {
  readonly upm: number;
  readonly ascent: number;
  readonly descent: number;
  readonly capHeight: number;
  readonly bbox: [number, number, number, number];
  private numGlyphs: number;
  private hm: number;
  private dv: DataView;
  private hmtx = 0;
  private cmap = new Map<number, number>();
  constructor(readonly data: Uint8Array, readonly name: string) {
    const dv = (this.dv = new DataView(data.buffer, data.byteOffset, data.byteLength));
    const n = dv.getUint16(4);
    const tab: Record<string, number> = {};
    for (let i = 0; i < n; i++) {
      const o = 12 + i * 16;
      tab[String.fromCharCode(dv.getUint8(o), dv.getUint8(o + 1), dv.getUint8(o + 2), dv.getUint8(o + 3))] = dv.getUint32(o + 8);
    }
    for (const t of ['head', 'hhea', 'hmtx', 'maxp', 'cmap']) if (tab[t] === undefined) throw new Error('TTF: нет таблицы ' + t);
    const head = tab.head;
    this.upm = dv.getUint16(head + 18);
    this.bbox = [dv.getInt16(head + 36), dv.getInt16(head + 38), dv.getInt16(head + 40), dv.getInt16(head + 42)];
    this.ascent = dv.getInt16(tab.hhea + 4);
    this.descent = dv.getInt16(tab.hhea + 6);
    this.hm = dv.getUint16(tab.hhea + 34);
    this.hmtx = tab.hmtx;
    this.numGlyphs = dv.getUint16(tab.maxp + 4);
    this.capHeight = tab['OS/2'] !== undefined && dv.getUint16(tab['OS/2']) >= 2 ? dv.getInt16(tab['OS/2'] + 88) : Math.round(this.upm * 0.7);
    this.readCmap(tab.cmap);
  }
  private readCmap(base: number) {
    const dv = this.dv;
    const n = dv.getUint16(base + 2);
    let best = -1, bestScore = -1;
    for (let i = 0; i < n; i++) {
      const pid = dv.getUint16(base + 4 + i * 8), eid = dv.getUint16(base + 6 + i * 8), off = dv.getUint32(base + 8 + i * 8);
      const fmt = dv.getUint16(base + off);
      const score = (pid === 3 && eid === 10 && fmt === 12 ? 4 : 0) + (pid === 3 && eid === 1 && fmt === 4 ? 3 : 0) + (pid === 0 && (fmt === 4 || fmt === 12) ? 2 : 0);
      if (score > bestScore) { bestScore = score; best = base + off; }
    }
    if (best < 0 || bestScore <= 0) throw new Error('TTF: нет юникодной cmap');
    const fmt = dv.getUint16(best);
    if (fmt === 4) {
      const segX2 = dv.getUint16(best + 6), seg = segX2 / 2;
      const endO = best + 14, startO = endO + segX2 + 2, deltaO = startO + segX2, rangeO = deltaO + segX2;
      for (let s = 0; s < seg; s++) {
        const end = dv.getUint16(endO + s * 2), start = dv.getUint16(startO + s * 2), delta = dv.getInt16(deltaO + s * 2), ro = dv.getUint16(rangeO + s * 2);
        for (let c = start; c <= end && c !== 0xffff; c++) {
          let g: number;
          if (ro === 0) g = (c + delta) & 0xffff;
          else {
            const p = rangeO + s * 2 + ro + (c - start) * 2;
            if (p + 2 > dv.byteLength) continue;
            g = dv.getUint16(p);
            if (g) g = (g + delta) & 0xffff;
          }
          if (g) this.cmap.set(c, g);
        }
      }
    } else if (fmt === 12) {
      const ng = dv.getUint32(best + 12);
      for (let i = 0; i < ng; i++) {
        const o = best + 16 + i * 12, s = dv.getUint32(o), e = dv.getUint32(o + 4), g = dv.getUint32(o + 8);
        for (let c = s; c <= e; c++) this.cmap.set(c, g + (c - s));
      }
    } else throw new Error('TTF: неподдерживаемый формат cmap ' + fmt);
  }
  gid(cp: number): number { return this.cmap.get(cp) ?? this.cmap.get(0x3f) ?? 0; }
  has(cp: number): boolean { return this.cmap.has(cp); }
  /** Ширина глyфа в единицах шрифта. */
  adv(gid: number): number {
    const i = Math.min(gid, this.hm - 1);
    return this.dv.getUint16(this.hmtx + i * 4);
  }
}

// ---------------------------------------------------------------- шрифт документа

export class PdfFont {
  readonly used = new Map<number, number>(); // gid → code point
  constructor(readonly ttf: Ttf, readonly key: string) {}
  /** Ширина строки в пунктах. */
  width(s: string, size: number): number {
    let w = 0;
    for (const ch of s) w += this.ttf.adv(this.ttf.gid(ch.codePointAt(0)!));
    return (w * size) / this.ttf.upm;
  }
  hexStr(s: string): string {
    let out = '';
    for (const ch of s) {
      const cp = ch.codePointAt(0)!;
      const g = this.ttf.gid(cp);
      if (!this.used.has(g)) this.used.set(g, this.ttf.has(cp) ? cp : 0x3f);
      out += g.toString(16).padStart(4, '0');
    }
    return out;
  }
}

// ---------------------------------------------------------------- страница

export interface TextOpt { font?: PdfFont; size?: number; color?: RGB }
export interface BoxOpt { fill?: RGB; stroke?: RGB; lw?: number; r?: number; dash?: [number, number] }

const f2 = (n: number) => (Math.round(n * 100) / 100).toString();
const col = (c: RGB) => `${c[0].toFixed(3)} ${c[1].toFixed(3)} ${c[2].toFixed(3)}`;

export class PdfPage {
  ops: string[] = [];
  links: { x: number; y: number; w: number; h: number; url: string }[] = [];
  constructor(private doc: PdfDoc) {}
  private Y(y: number) { return A4.h - y; }
  rect(x: number, y: number, w: number, h: number, o: BoxOpt = {}) {
    const ops = this.ops;
    ops.push('q');
    if (o.fill) ops.push(col(o.fill) + ' rg');
    if (o.stroke) ops.push(col(o.stroke) + ' RG ' + f2(o.lw ?? 0.75) + ' w');
    if (o.dash) ops.push(`[${o.dash[0]} ${o.dash[1]}] 0 d`);
    const r = Math.min(o.r ?? 0, w / 2, h / 2), Y = this.Y(y + h);
    if (r <= 0) ops.push(`${f2(x)} ${f2(Y)} ${f2(w)} ${f2(h)} re`);
    else {
      const k = r * 0.5523;
      ops.push(`${f2(x + r)} ${f2(Y)} m ${f2(x + w - r)} ${f2(Y)} l ${f2(x + w - r + k)} ${f2(Y)} ${f2(x + w)} ${f2(Y + r - k)} ${f2(x + w)} ${f2(Y + r)} c`);
      ops.push(`${f2(x + w)} ${f2(Y + h - r)} l ${f2(x + w)} ${f2(Y + h - r + k)} ${f2(x + w - r + k)} ${f2(Y + h)} ${f2(x + w - r)} ${f2(Y + h)} c`);
      ops.push(`${f2(x + r)} ${f2(Y + h)} l ${f2(x + r - k)} ${f2(Y + h)} ${f2(x)} ${f2(Y + h - r + k)} ${f2(x)} ${f2(Y + h - r)} c`);
      ops.push(`${f2(x)} ${f2(Y + r)} l ${f2(x)} ${f2(Y + r - k)} ${f2(x + r - k)} ${f2(Y)} ${f2(x + r)} ${f2(Y)} c h`);
    }
    ops.push(o.fill && o.stroke ? 'B' : o.fill ? 'f' : 'S');
    ops.push('Q');
  }
  circle(cx: number, cy: number, r: number, o: BoxOpt = {}) { this.rect(cx - r, cy - r, r * 2, r * 2, { ...o, r }); }
  line(x1: number, y1: number, x2: number, y2: number, color: RGB, lw = 0.75, dash?: [number, number]) {
    this.ops.push(`q ${col(color)} RG ${f2(lw)} w ${dash ? `[${dash[0]} ${dash[1]}] 0 d ` : ''}${f2(x1)} ${f2(this.Y(y1))} m ${f2(x2)} ${f2(this.Y(y2))} l S Q`);
  }
  /** Текст по базовой линии (y — верх строки: базовая линия = y + ascent·size). */
  text(s: string, x: number, y: number, o: TextOpt = {}) {
    if (!s) return;
    const font = o.font || this.doc.regular, size = o.size ?? 10;
    const base = y + (font.ttf.ascent / font.ttf.upm) * size;
    this.ops.push(`BT ${col(o.color || [0.1, 0.12, 0.16])} rg /${font.key} ${f2(size)} Tf ${f2(x)} ${f2(this.Y(base))} Td <${font.hexStr(s)}> Tj ET`);
  }
  link(x: number, y: number, w: number, h: number, url: string) { this.links.push({ x, y, w, h, url }); }
}

// ---------------------------------------------------------------- документ

async function deflate(data: Uint8Array): Promise<Uint8Array | null> {
  if (typeof CompressionStream === 'undefined') return null;
  try {
    const cs = new CompressionStream('deflate');
    const w = cs.writable.getWriter();
    w.write(data as unknown as BufferSource); w.close();
    return new Uint8Array(await new Response(cs.readable).arrayBuffer());
  } catch { return null; }
}

const enc = new TextEncoder();
const pdfStr = (s: string) => '(' + s.replace(/[\\()]/g, (c) => '\\' + c).replace(/[^\x20-\x7e]/g, '?') + ')';
const utf16hex = (s: string) => 'FEFF' + Array.from(s).map((c) => c.codePointAt(0)!.toString(16).padStart(4, '0')).join('');

export class PdfDoc {
  pages: PdfPage[] = [];
  regular!: PdfFont;
  bold!: PdfFont;
  info: { title?: string; author?: string; subject?: string } = {};
  addPage(): PdfPage { const p = new PdfPage(this); this.pages.push(p); return p; }
  setFonts(regular: Ttf, bold: Ttf) { this.regular = new PdfFont(regular, 'F1'); this.bold = new PdfFont(bold, 'F2'); }

  async build(): Promise<Blob> {
    const parts: (string | Uint8Array)[] = [];
    const offsets: number[] = [];
    let pos = 0;
    const push = (x: string | Uint8Array) => { parts.push(x); pos += typeof x === 'string' ? x.length : x.length; };
    // всё, кроме потоков, ASCII (кириллица — только hex-строки), поэтому длина строки = длина в байтах
    const obj = (id: number, body: string | (string | Uint8Array)[]) => {
      offsets[id] = pos;
      push(`${id} 0 obj\n`);
      for (const b of Array.isArray(body) ? body : [body]) push(b);
      push('\nendobj\n');
    };
    const stream = async (dict: string, data: Uint8Array, compress = true): Promise<(string | Uint8Array)[]> => {
      const z = compress ? await deflate(data) : null;
      const body = z || data;
      return [`<< ${dict} ${z ? '/Filter /FlateDecode ' : ''}/Length ${body.length} >>\nstream\n`, body, '\nendstream'];
    };
    const fonts = [this.regular, this.bold];
    const N = this.pages.length;
    // нумерация: 1 каталог, 2 страницы, 3.. шрифты (по 5 объектов), затем страницы (по 2 + аннотации)
    const fontBase = 3, perFont = 5;
    const pageBase = fontBase + fonts.length * perFont;
    const linkIds: number[][] = [];
    let next = pageBase + N * 2;
    for (const pg of this.pages) { linkIds.push(pg.links.map(() => next++)); }
    const infoId = next++;
    const total = next;

    push('%PDF-1.5\n%\xE2\xE3\xCF\xD3\n');
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    obj(2, `<< /Type /Pages /Count ${N} /Kids [${this.pages.map((_, i) => `${pageBase + i * 2} 0 R`).join(' ')}] >>`);

    for (let fi = 0; fi < fonts.length; fi++) {
      const f = fonts[fi], t = f.ttf, id = fontBase + fi * perFont;
      const u = (n: number) => Math.round((n * 1000) / t.upm);
      const gids = [...f.used.keys()].sort((a, b) => a - b);
      const psName = 'AAAAAA+' + t.name.replace(/[^A-Za-z0-9-]/g, '');
      obj(id, `<< /Type /Font /Subtype /Type0 /BaseFont /${psName} /Encoding /Identity-H /DescendantFonts [${id + 1} 0 R] /ToUnicode ${id + 4} 0 R >>`);
      obj(id + 1, `<< /Type /Font /Subtype /CIDFontType2 /BaseFont /${psName} /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> /FontDescriptor ${id + 2} 0 R /DW 1000 /W [${gids.map((g) => `${g} [${u(t.adv(g))}]`).join(' ')}] /CIDToGIDMap /Identity >>`);
      obj(id + 2, `<< /Type /FontDescriptor /FontName /${psName} /Flags 32 /FontBBox [${t.bbox.map(u).join(' ')}] /ItalicAngle 0 /Ascent ${u(t.ascent)} /Descent ${u(t.descent)} /CapHeight ${u(t.capHeight)} /StemV 80 /FontFile2 ${id + 3} 0 R >>`);
      obj(id + 3, await stream(`/Length1 ${t.data.length}`, t.data));
      const bf = gids.map((g) => `<${g.toString(16).padStart(4, '0')}> <${(f.used.get(g) || 0x3f).toString(16).padStart(4, '0')}>`);
      let cm = '/CIDInit /ProcSet findresource begin 12 dict begin begincmap /CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def /CMapName /Adobe-Identity-UCS def /CMapType 2 def 1 begincodespacerange <0000> <FFFF> endcodespacerange\n';
      for (let i = 0; i < bf.length; i += 100) cm += `${Math.min(100, bf.length - i)} beginbfchar\n${bf.slice(i, i + 100).join('\n')}\nendbfchar\n`;
      cm += 'endcmap CMapName currentdict /CMap defineresource pop end end';
      obj(id + 4, await stream('', enc.encode(cm)));
    }
    const res = `<< /Font << ${fonts.map((f, i) => `/${f.key} ${fontBase + i * perFont} 0 R`).join(' ')} >> >>`;
    for (let i = 0; i < N; i++) {
      const pg = this.pages[i], pid = pageBase + i * 2;
      const annots = linkIds[i].length ? ` /Annots [${linkIds[i].map((x) => x + ' 0 R').join(' ')}]` : '';
      obj(pid, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f2(A4.w)} ${f2(A4.h)}] /Resources ${res} /Contents ${pid + 1} 0 R${annots} >>`);
      obj(pid + 1, await stream('', enc.encode(pg.ops.join('\n'))));
      pg.links.forEach((l, k) => {
        const y2 = A4.h - l.y, y1 = y2 - l.h;
        obj(linkIds[i][k], `<< /Type /Annot /Subtype /Link /Rect [${f2(l.x)} ${f2(y1)} ${f2(l.x + l.w)} ${f2(y2)}] /Border [0 0 0] /A << /S /URI /URI ${pdfStr(l.url)} >> >>`);
      });
    }
    const d = new Date();
    const pd = `D:${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}${String(d.getSeconds()).padStart(2, '0')}`;
    obj(infoId, `<< /Title <${utf16hex(this.info.title || '')}> /Author <${utf16hex(this.info.author || '')}> /Subject <${utf16hex(this.info.subject || '')}> /Producer (Vmeste) /CreationDate (${pd}) >>`);
    const xref = pos;
    push(`xref\n0 ${total}\n0000000000 65535 f \n`);
    for (let i = 1; i < total; i++) push(String(offsets[i]).padStart(10, '0') + ' 00000 n \n');
    push(`trailer\n<< /Size ${total} /Root 1 0 R /Info ${infoId} 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
    // строки превращаем в байты (все символы ≤ 0xFF → latin1)
    const chunks = parts.map((p) => (typeof p === 'string' ? Uint8Array.from(p, (c) => c.charCodeAt(0) & 0xff) : p));
    return new Blob(chunks as BlobPart[], { type: 'application/pdf' });
  }
}

let fontCache: Promise<[Ttf, Ttf]> | null = null;
/** Загружает шрифты (один раз за сессию). */
export function loadFonts(): Promise<[Ttf, Ttf]> {
  fontCache ??= (async () => {
    const get = async (n: string, name: string) => {
      const r = await fetch('/fonts/' + n, { credentials: 'same-origin' });
      if (!r.ok) throw new Error('Не удалось загрузить шрифт ' + n);
      return new Ttf(new Uint8Array(await r.arrayBuffer()), name);
    };
    return Promise.all([get('LiberationSans-Regular.subset.ttf', 'LiberationSans'), get('LiberationSans-Bold.subset.ttf', 'LiberationSans-Bold')]) as Promise<[Ttf, Ttf]>;
  })().catch((e) => { fontCache = null; throw e; });
  return fontCache;
}

export function saveBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}
