// Страницы подгружаются отдельными небольшими файлами (code splitting): главный бандл содержит только оболочку и ленту
// новостей, остальное — по требованию. Чтобы переход не ждал сети, чанки заранее подтягиваются:
//   1) при наведении/фокусе/касании на ссылку (lib/router.tsx → registerPrefetch);
//   2) в простое браузера после загрузки (idlePrefetch) — самые частые разделы, если связь не «экономная».
import { lazy, type ComponentType } from 'react';

const named = <T extends Record<string, any>>(load: () => Promise<T>, k: keyof T) =>
  lazy(() => load().then((m) => ({ default: m[k] as ComponentType<any> })));

export const loaders = {
  people: () => import('./pages/people'),
  groups: () => import('./pages/groups'),
  ideas: () => import('./pages/ideas'),
  vacations: () => import('./pages/vacations'),
  learning: () => import('./pages/learning'),
  certs: () => import('./pages/learning/lms-certs'),
  bookmarks: () => import('./pages/bookmarks'),
  messenger: () => import('./pages/messenger'),
  calendar: () => import('./pages/calendar'),
  files: () => import('./pages/files'),
  requests: () => import('./pages/requests'),
  tz: () => import('./pages/tz'),
  tzhome: () => import('./pages/tz/home'),
  wiki: () => import('./pages/wiki/home'),
  admin: () => import('./admin'),
};

export const WikiPage = named(loaders.wiki, 'WikiPage');
export const PeoplePage = named(loaders.people, 'PeoplePage');
export const ProfilePage = named(loaders.people, 'ProfilePage');
export const DepartmentsPage = named(loaders.people, 'DepartmentsPage');
export const DepartmentPage = named(loaders.people, 'DepartmentPage');
export const DirectionsPage = named(loaders.people, 'DirectionsPage');
export const CompanyPage = named(loaders.people, 'CompanyPage');
export const ResourcesPage = named(loaders.people, 'ResourcesPage');
export const SearchPage = named(loaders.people, 'SearchPage');
export const SettingsPage = named(loaders.people, 'SettingsPage');
export const GroupsPage = named(loaders.groups, 'GroupsPage');
export const GroupPage = named(loaders.groups, 'GroupPage');
export const IdeasPage = named(loaders.ideas, 'IdeasPage');
export const IdeaView = named(loaders.ideas, 'IdeaView');
export const VacationsPage = named(loaders.vacations, 'VacationsPage');
export const LearningPage = named(loaders.learning, 'LearningPage');
export const VerifyPage = named(loaders.certs, 'VerifyPage');
export const BookmarksPage = named(loaders.bookmarks, 'BookmarksPage');
export const MessengerPage = named(loaders.messenger, 'MessengerPage');
export const CalendarPage = named(loaders.calendar, 'CalendarPage');
export const FilesPage = named(loaders.files, 'FilesPage');
export const RequestsPage = named(loaders.requests, 'RequestsPage');
export const RewardsPage = named(loaders.tz, 'RewardsPage');
export const OnboardingPage = named(loaders.tz, 'OnboardingPage');
export const SurveysPage = named(loaders.tz, 'SurveysPage');
export const AskPage = named(loaders.tz, 'AskPage');
export const FeedbackPage = named(loaders.tz, 'FeedbackPage');
export const EditorialPage = named(loaders.tz, 'EditorialPage');
export const HomeWidgets = lazy(loaders.tzhome);
export const Admin = lazy(loaders.admin);

/** Какой чанк нужен для пути. */
const PREFIX: [string, keyof typeof loaders][] = [
  ['/people', 'people'], ['/departments', 'people'], ['/directions', 'people'], ['/company', 'people'], ['/resources', 'people'], ['/search', 'people'], ['/settings', 'people'],
  ['/groups', 'groups'], ['/ideas', 'ideas'], ['/vacations', 'vacations'], ['/learning', 'learning'], ['/bookmarks', 'bookmarks'],
  ['/messages', 'messenger'], ['/calendar', 'calendar'], ['/documents', 'files'], ['/photos', 'files'], ['/videos', 'files'],
  ['/requests', 'requests'], ['/admin', 'admin'],
  ['/rewards', 'tz'], ['/onboarding', 'tz'], ['/surveys', 'tz'], ['/ask', 'tz'], ['/feedback', 'tz'], ['/editorial', 'tz'],
];

const done = new Set<string>();
export function prefetchRoute(to: string) {
  const p = to.split(/[?#]/)[0];
  const hit = PREFIX.find(([x]) => p === x || p.startsWith(x + '/'));
  if (!hit || done.has(hit[1])) return;
  done.add(hit[1]);
  loaders[hit[1]]().catch(() => done.delete(hit[1])); // сбой сети — попробуем в следующий раз
}

/** После первой отрисовки, в простое, по одному подтягиваем самые частые разделы (не при «экономии трафика» и не на слабых ПК). */
export function idlePrefetch(order = ['/calendar', '/requests', '/people', '/vacations', '/messages', '/groups', '/documents', '/learning']) {
  const nav = navigator as any;
  if (nav.connection?.saveData || /(^|-)2g$/.test(nav.connection?.effectiveType || '') || document.documentElement.dataset.perf === 'lite') return;
  const ric: (cb: () => void, o?: { timeout: number }) => void = (window as any).requestIdleCallback || ((cb: () => void) => setTimeout(cb, 1500));
  let i = 0;
  const next = () => { if (i >= order.length) return; prefetchRoute(order[i++]); ric(next, { timeout: 4000 }); };
  ric(next, { timeout: 5000 });
}
