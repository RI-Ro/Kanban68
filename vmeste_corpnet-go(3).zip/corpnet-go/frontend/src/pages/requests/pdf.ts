// PDF заявки: реквизиты, данные, ход согласования (в том числе параллельные ветки), подписи и журнал.
// Автор заявки получает документ, из которого видно, на каком этапе заявка, кто и когда решил, кто ещё должен решить
// и как с ним связаться, чтобы напомнить вручную.

import { A4, PdfDoc, PdfPage, RGB, Ttf, hex, loadFonts, saveBlob } from '../../lib/pdf';
import { dmy, isEmpty, isDisplay, evalCond, plural, MODE_LABEL, STEP_KIND, STATUS } from './model';
import type { Field, Schema } from './model';

const C = {
  brand: hex('#0961d0'), navy: hex('#0b2a5b'), ink: hex('#14161c'), muted: hex('#5b6473'), faint: hex('#8a93a3'), line: hex('#dfe3ea'), bg: hex('#f3f6fb'), white: [1, 1, 1] as RGB,
  ok: hex('#17722d'), okBg: hex('#e2f4e7'), warn: hex('#8f4a00'), warnBg: hex('#fdebd2'), dng: hex('#b3182f'), dngBg: hex('#fbe1e5'), acc: hex('#0961d0'), accBg: hex('#e0ecfb'), grey: hex('#5b6473'), greyBg: hex('#e9ecf1'),
};
type Tone = { fg: RGB; bg: RGB };
const TONE: Record<string, Tone> = { ok: { fg: C.ok, bg: C.okBg }, warn: { fg: C.warn, bg: C.warnBg }, dng: { fg: C.dng, bg: C.dngBg }, acc: { fg: C.acc, bg: C.accBg }, grey: { fg: C.grey, bg: C.greyBg } };

const ML = 40, MR = 40, W = A4.w - ML - MR, TOP = 52, BOT = A4.h - 58;
const RAIL = ML + 9; // ось «рельса» маршрута

const p2 = (n: number) => String(n).padStart(2, '0');
const dt = (s?: string | null) => { if (!s) return ''; const d = new Date(s); return isNaN(+d) ? '' : `${p2(d.getDate())}.${p2(d.getMonth() + 1)}.${d.getFullYear()} ${p2(d.getHours())}:${p2(d.getMinutes())}`; };
const dd = (s?: string | null) => dt(s).slice(0, 10);
const daysAgo = (s?: string | null) => (s ? Math.max(0, Math.floor((Date.now() - +new Date(s)) / 864e5)) : 0);

const ASG: Record<string, { t: string; tone: string }> = {
  pending: { t: 'Ожидает решения', tone: 'acc' }, approved: { t: 'Согласовано', tone: 'ok' }, rejected: { t: 'Отклонено', tone: 'dng' }, done: { t: 'Выполнено', tone: 'ok' },
  acked: { t: 'Ознакомлен(а)', tone: 'ok' }, returned: { t: 'На доработку', tone: 'warn' }, skipped: { t: 'Не требуется', tone: 'grey' }, delegated: { t: 'Передано другому', tone: 'grey' },
};
const VIA: Record<string, string> = { deputy: 'замещает', fallback: 'запасной согласующий', delegate: 'делегировано', escalation: 'эскалация', assigned: 'назначен' };
const MODE_LONG: Record<string, string> = { any: 'достаточно решения одного', all: 'требуется решение всех', majority: 'требуется большинство' };
const EVT: Record<string, string> = {
  created: 'создал(а) черновик', edited: 'изменил(а) заявку', submitted: 'подал(а) заявку', resubmitted: 'отправил(а) заявку повторно', step_started: 'начат этап', step_skipped: 'этап пропущен',
  approved: 'согласовал(а)', executed: 'выполнил(а)', acked: 'ознакомился(ась)', rejected: 'отклонил(а)', returned: 'вернул(а) на доработку', question: 'задал(а) вопрос заявителю',
  answer: 'ответил(а) на вопрос', delegated: 'передал(а) решение', assigned: 'назначил(а) исполнителя', escalated: 'эскалация по сроку', cancelled: 'отозвал(а) заявку', comment: 'комментарий',
  status: 'статус изменён', overdue: 'просрочка', rework: 'заявка возвращена на доработку',
};

interface Block { h: number; paint: (pg: PdfPage, y: number) => void; keep?: boolean }

class Layout {
  doc = new PdfDoc();
  pg!: PdfPage;
  y = 0;
  first = true;
  constructor(fonts: [Ttf, Ttf], private head: string) { this.doc.setFonts(fonts[0], fonts[1]); this.newPage(); }
  get R() { return this.doc.regular; }
  get B() { return this.doc.bold; }
  newPage() {
    this.pg = this.doc.addPage();
    if (this.doc.pages.length > 1) {
      this.pg.rect(0, 0, A4.w, 6, { fill: C.brand });
      this.pg.text(this.head, ML, 20, { font: this.B, size: 9, color: C.muted });
      this.pg.line(ML, 36, A4.w - MR, 36, C.line, 0.75);
      this.y = TOP;
    }
  }
  wrap(s: string, size: number, w: number, bold = false): string[] {
    const f = bold ? this.B : this.R, out: string[] = [];
    for (const para of String(s).split(/\r?\n/)) {
      let line = '';
      for (const word of para.split(/\s+/).filter(Boolean)) {
        let cand = line ? line + ' ' + word : word;
        if (f.width(cand, size) <= w) { line = cand; continue; }
        if (line) { out.push(line); line = ''; }
        cand = word;
        while (f.width(cand, size) > w && cand.length > 1) { // длинное слово режем по символам
          let k = cand.length - 1;
          while (k > 1 && f.width(cand.slice(0, k), size) > w) k--;
          out.push(cand.slice(0, k)); cand = cand.slice(k);
        }
        line = cand;
      }
      out.push(line);
    }
    return out;
  }
  /** Ставит блоки подряд; группа переносится на новую страницу целиком, если помещается на одной. */
  place(...bs: Block[]) {
    const total = bs.reduce((a, b) => a + b.h, 0);
    if (this.y + total > BOT && total <= BOT - TOP) { this.newPage(); this.y = TOP; }
    for (const b of bs) {
      if (this.y + b.h > BOT) { this.newPage(); this.y = TOP; }
      b.paint(this.pg, this.y);
      this.y += b.h;
    }
  }
  /** Последовательность блоков: блок с keep не отрывается от следующего (заголовок — от первой строки). */
  flow(bs: Block[]) {
    let i = 0;
    while (i < bs.length) {
      const g = [bs[i]];
      while (bs[i].keep && i + 1 < bs.length) { i++; g.push(bs[i]); }
      this.place(...g);
      i++;
    }
  }
  fit(s: string, size: number, w: number, bold = false): string {
    const f = bold ? this.B : this.R;
    if (f.width(s, size) <= w) return s;
    let t = s;
    while (t.length > 1 && f.width(t + '…', size) > w) t = t.slice(0, -1);
    return t.trimEnd() + '…';
  }
  gap(h: number) { this.y += h; }
}

function pill(L: Layout, pg: PdfPage, text: string, x: number, y: number, tone: Tone, size = 8): number {
  const w = L.B.width(text, size) + 14;
  pg.rect(x, y, w, size + 8, { fill: tone.bg, r: (size + 8) / 2 });
  pg.text(text, x + 7, y + 4, { font: L.B, size, color: tone.fg });
  return w;
}

function sectionTitle(L: Layout, title: string, sub?: string): Block {
  return { h: 34, keep: true, paint: (pg, y) => {
    pg.rect(ML, y + 6, 4, 17, { fill: C.brand, r: 2 });
    pg.text(title, ML + 12, y + 6, { font: L.B, size: 14, color: C.ink });
    if (sub) pg.text(sub, A4.w - MR - L.R.width(sub, 8.5), y + 10, { size: 8.5, color: C.faint });
  } };
}

// ---------------------------------------------------------------- значения полей

function valText(f: Field, v: any): string {
  if (isEmpty(v)) return '—';
  const label = (x: any) => f.options?.find((o) => o.value === String(x))?.label ?? String(x);
  switch (f.type) {
    case 'file': return (v as any[]).map((x) => x.name).join('\n');
    case 'period': return `${dmy(v.from)} — ${dmy(v.to)}${v.days ? ` · ${v.days} ${plural(v.days, ['календарный день', 'календарных дня', 'календарных дней'])}${v.workdays != null ? `, рабочих ${v.workdays}` : ''}` : ''}`;
    case 'user': return (Array.isArray(v) ? v : [v]).map((u: any) => u.name).join(', ');
    case 'date': return dmy(String(v));
    case 'select': case 'radio': return label(v);
    case 'checkboxes': return (v as any[]).map(label).join(', ');
    case 'switch': return v ? 'Да' : 'Нет';
    case 'department': return v.name;
    case 'money': return Number(v).toLocaleString('ru', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' руб.';
    case 'number': return Number(v).toLocaleString('ru') + (f.unit ? ' ' + f.unit : '');
  }
  return String(v);
}

function dataBlocks(L: Layout, d: any): Block[] {
  const schema: Schema = d.schema, out: Block[] = [];
  const LW = 150, VX = ML + LW + 12, VW = W - LW - 12, LH = 12.5;
  for (const s of schema.sections.filter((x) => evalCond(x.visible_if, d.data))) {
    const rows = s.fields.filter((f) => !isDisplay(f.type) && evalCond(f.visible_if, d.data) && !isEmpty(d.data[f.key]));
    if (!rows.length) continue;
    if (s.title) out.push({ h: 24, keep: true, paint: (pg, y) => pg.text(s.title!.toUpperCase(), ML, y + 8, { font: L.B, size: 8, color: C.brand }) });
    rows.forEach((f, i) => {
      const v = d.data[f.key];
      if (f.type === 'table' && Array.isArray(v) && f.columns?.length) {
        const cols = f.columns, cw = (W - 24) / (cols.length + 0.4), firstW = cw * 0.4;
        const head: Block = { h: 18 + LH + 8, keep: true, paint: (pg, y) => {
          pg.text(f.label, ML, y + 4, { font: L.B, size: 9.5, color: C.ink });
          pg.rect(ML, y + 20, W, 17, { fill: C.bg, r: 3 });
          pg.text('№', ML + 6, y + 24.5, { font: L.B, size: 8, color: C.muted });
          cols.forEach((c, k) => pg.text(c.label, ML + 12 + firstW + k * cw, y + 24.5, { font: L.B, size: 8, color: C.muted }));
        } };
        out.push(head);
        (v as any[]).forEach((r, ri) => {
          const cells = cols.map((c) => L.wrap(valText(c, r[c.key]), 9, cw - 8));
          const n = Math.max(...cells.map((x) => x.length));
          out.push({ h: n * LH + 6, paint: (pg, y) => {
            pg.text(String(ri + 1), ML + 6, y + 3, { size: 9, color: C.muted });
            cells.forEach((lines, k) => lines.forEach((ln, li) => pg.text(ln, ML + 12 + firstW + k * cw, y + 3 + li * LH, { size: 9 })));
            pg.line(ML, y + n * LH + 5, ML + W, y + n * LH + 5, C.line, 0.5);
          } });
        });
        return;
      }
      const lab = L.wrap(f.label, 9, LW), val = L.wrap(valText(f, v), 10, VW);
      const n = Math.max(lab.length, val.length);
      out.push({ h: n * LH + 9, paint: (pg, y) => {
        if (i % 2 === 0) pg.rect(ML - 6, y - 1, W + 12, n * LH + 8, { fill: C.bg, r: 4 });
        lab.forEach((ln, li) => pg.text(ln, ML, y + 3 + li * LH, { size: 9, color: C.muted }));
        val.forEach((ln, li) => pg.text(ln, VX, y + 2.5 + li * LH, { size: 10 }));
      } });
    });
    out.push({ h: 8, paint: () => {} });
  }
  return out;
}

// ---------------------------------------------------------------- маршрут

function check(pg: PdfPage, cx: number, cy: number, color: RGB, s = 3.2) {
  pg.ops.push(`q ${color.map((x) => x.toFixed(3)).join(' ')} RG 1.6 w 1 J 1 j ${(cx - s).toFixed(2)} ${(A4.h - (cy + 0.2)).toFixed(2)} m ${(cx - s * 0.3).toFixed(2)} ${(A4.h - (cy + s * 0.8)).toFixed(2)} l ${(cx + s).toFixed(2)} ${(A4.h - (cy - s * 0.8)).toFixed(2)} l S Q`);
}
function cross(pg: PdfPage, cx: number, cy: number, color: RGB, s = 2.8) {
  pg.ops.push(`q ${color.map((x) => x.toFixed(3)).join(' ')} RG 1.6 w 1 J ${(cx - s).toFixed(2)} ${(A4.h - (cy - s)).toFixed(2)} m ${(cx + s).toFixed(2)} ${(A4.h - (cy + s)).toFixed(2)} l ${(cx - s).toFixed(2)} ${(A4.h - (cy + s)).toFixed(2)} m ${(cx + s).toFixed(2)} ${(A4.h - (cy - s)).toFixed(2)} l S Q`);
}

function routeBlocks(L: Layout, d: any): Block[] {
  const steps: any[] = (d.steps as any[]).filter((s) => s.round === d.round);
  const asgOf = (sid: number) => (d.assignees as any[]).filter((a) => a.step_id === sid);
  const out: Block[] = [];
  const CX = RAIL + 20, CW = W - 20;
  const route: any[] = d.route || [];
  route.forEach((st, si) => {
    const real = steps.find((s) => s.idx === st.idx || s.key === st.id);
    const sk = real ? real.state : st.applies ? 'wait' : 'skip';
    const tone: Tone = sk === 'done' ? TONE.ok : sk === 'rejected' ? TONE.dng : sk === 'returned' ? TONE.warn : sk === 'active' ? TONE.acc : TONE.grey;
    const stateT = { done: 'Завершён', rejected: 'Отклонён', returned: 'Возвращён на доработку', active: 'Идёт сейчас', wait: 'Ожидает очереди', skip: 'Не требуется', skipped: 'Пропущен' }[sk as string] || sk;
    const asg = real ? asgOf(real.id) : [];
    const branches = [...new Set(asg.map((a) => a.branch))].sort((a, b) => a - b);
    const parallel = branches.length > 1;
    const lastStep = si === route.length - 1;
    const sub = `${STEP_KIND[st.kind] || ''}${parallel ? ` · параллельные ветки (${branches.length})` : st.mode && st.who?.length > 1 ? ` · ${MODE_LABEL[st.mode]}` : ''}`;
    const dates = real ? `${real.started_at ? 'начат ' + dt(real.started_at) : ''}${real.finished_at ? ' · завершён ' + dt(real.finished_at) : ''}` : '';
    const who = !real && st.applies && st.who?.length ? L.wrap('Кто: ' + st.who.join('; '), 8.5, CW - 130) : [];
    const hdrH = 30 + (dates ? 12 : 0) + who.length * 11 + 4;
    const hdr: Block = { h: hdrH, keep: true, paint: (pg, y) => {
      pg.line(RAIL, y + 9, RAIL, y + hdrH, C.line, 1.5);
      pg.circle(RAIL, y + 9, 7, { fill: tone.fg });
      if (sk === 'done') check(pg, RAIL, y + 9, C.white); else if (sk === 'rejected') cross(pg, RAIL, y + 9, C.white); else pg.circle(RAIL, y + 9, 2.4, { fill: C.white });
      pg.text(st.name, CX, y + 1, { font: L.B, size: 11.5, color: sk === 'skip' || sk === 'wait' ? C.muted : C.ink });
      pill(L, pg, stateT, A4.w - MR - (L.B.width(stateT, 7.5) + 14), y, tone, 7.5);
      pg.text(sub, CX, y + 16, { size: 8.5, color: C.muted });
      let yy = y + 28;
      if (dates) { pg.text(dates, CX, yy - 1, { size: 8, color: C.faint }); yy += 12; }
      who.forEach((ln, i) => pg.text(ln, CX, yy - 2 + i * 11, { size: 8.5, color: C.faint }));
    } };
    const rows: Block[] = [];
    let lastBranch = -1;
    asg.forEach((a) => {
      const meta = a.state === 'pending' && a.overdue ? { t: 'Просрочено', tone: 'dng' } : ASG[a.state] || { t: a.state, tone: 'grey' };
      const tn = TONE[meta.tone];
      const lines: { t: string; c: RGB; b?: boolean; s?: number }[] = [];
      const via = a.via !== 'direct' && VIA[a.via] ? `${VIA[a.via]}${a.orig_name ? ' — ' + a.orig_name : ''}` : '';
      lines.push({ t: a.name, c: C.ink, b: true, s: 10 });
      if (a.job_title || via) lines.push({ t: [a.job_title, via].filter(Boolean).join(' · '), c: C.muted, s: 8.5 });
      if (a.state === 'pending') {
        const since = real?.started_at ? `ожидает с ${dd(real.started_at)} (${daysAgo(real.started_at)} ${plural(daysAgo(real.started_at), ['день', 'дня', 'дней'])})` : 'ожидает решения';
        lines.push({ t: since + (a.due_at ? ` · срок до ${dt(a.due_at)}` : ''), c: a.overdue ? C.dng : C.warn, s: 8.5 });
        const contacts = [a.phone && 'тел. ' + a.phone, a.email].filter(Boolean).join(' · ');
        if (contacts) lines.push({ t: 'Напомнить: ' + contacts, c: C.brand, s: 8.5 });
      } else if (a.decided_at) lines.push({ t: `${meta.t.toLowerCase()} ${dt(a.decided_at)}`, c: C.muted, s: 8.5 });
      if (a.comment) for (const ln of L.wrap('«' + a.comment + '»', 8.5, CW - 160)) lines.push({ t: ln, c: C.muted, s: 8.5 });
      const h = lines.reduce((s, l) => s + (l.s || 9) * 1.4, 0) + 12;
      const tag = parallel && a.branch !== lastBranch ? `Ветка ${branches.indexOf(a.branch) + 1} · ${MODE_LONG[a.mode] || ''}` : '';
      lastBranch = a.branch;
      const th = tag ? 15 : 0;
      rows.push({ h: h + th + 6, paint: (pg, y) => {
        pg.line(RAIL, y, RAIL, y + h + th + 6 + (lastStep ? -(h + th + 6) : 0), C.line, 1.5);
        let yy = y;
        if (tag) { pg.text(tag.toUpperCase(), CX + 2, y + 1, { font: L.B, size: 7.5, color: C.brand }); yy += th; }
        pg.rect(CX, yy, CW, h, { fill: a.state === 'pending' ? hex('#f7faff') : C.white, stroke: a.state === 'pending' ? hex('#b9d3f5') : C.line, lw: 0.8, r: 6 });
        pg.rect(CX, yy + 6, 3, h - 12, { fill: tn.fg, r: 1.5 });
        let ty = yy + 6;
        for (const l of lines) { pg.text(l.t, CX + 12, ty, { font: l.b ? L.B : L.R, size: l.s, color: l.c }); ty += (l.s || 9) * 1.4; }
        pill(L, pg, meta.t, CX + CW - (L.B.width(meta.t, 7.5) + 14) - 8, yy + 8, tn, 7.5);
      } });
    });
    if (real && !asg.length) rows.push({ h: 22, paint: (pg, y) => { pg.line(RAIL, y, RAIL, y + 22, C.line, 1.5); pg.text('Исполнители не определены', CX, y + 3, { size: 9, color: C.warn }); } });
    if (!lastStep) rows.push({ h: 8, paint: (pg, y) => pg.line(RAIL, y, RAIL, y + 8, C.line, 1.5) });
    out.push(hdr, ...rows);
  });
  return out;
}

// ---------------------------------------------------------------- подписи

function signBlocks(L: Layout, d: any): Block[] {
  const r = d.request;
  const steps: any[] = (d.steps as any[]).filter((s) => s.round === d.round);
  const items: { role: string; name: string; job: string; at?: string | null; ok?: boolean; bad?: boolean; txt: string }[] = [];
  items.push({ role: 'Заявитель', name: r.author || '—', job: r.author_title || '', at: r.submitted_at, ok: !!r.submitted_at, txt: r.submitted_at ? 'Подал(а) заявку' : '' });
  for (const s of steps) {
    for (const a of (d.assignees as any[]).filter((x) => x.step_id === s.id && x.state !== 'skipped' && x.state !== 'delegated')) {
      const role = s.kind === 'approve' ? 'Согласующий' : s.kind === 'execute' ? 'Исполнитель' : 'Ознакомление';
      const done = ['approved', 'done', 'acked'].includes(a.state);
      items.push({ role: `${role} · ${s.name}`, name: a.name, job: a.job_title || '', at: a.decided_at, ok: done, bad: a.state === 'rejected' || a.state === 'returned', txt: ({ approved: 'Согласовано', done: 'Выполнено', acked: 'Ознакомлен(а)', rejected: 'Отклонено', returned: 'Возвращено на доработку' } as any)[a.state] || '' });
    }
  }
  const CWd = (W - 12) / 2, H = 78;
  const out: Block[] = [];
  for (let i = 0; i < items.length; i += 2) {
    out.push({ h: H + 10, paint: (pg, y) => {
      [items[i], items[i + 1]].forEach((it, k) => {
        if (!it) return;
        const x = ML + k * (CWd + 12);
        pg.rect(x, y, CWd, H, { stroke: C.line, lw: 0.8, r: 6 });
        const [r1, r2] = it.role.split(' · ');
        pg.text(r1.toUpperCase(), x + 10, y + 8, { font: L.B, size: 7, color: C.brand });
        if (r2) pg.text(L.fit(r2, 7, CWd - 20 - L.B.width(r1.toUpperCase() + '  ', 7)), x + 10 + L.B.width(r1.toUpperCase() + '  ', 7), y + 8, { size: 7, color: C.faint });
        pg.text(L.wrap(it.name, 10, CWd - 20, true)[0], x + 10, y + 20, { font: L.B, size: 10 });
        if (it.job) pg.text(L.wrap(it.job, 8, CWd - 20)[0], x + 10, y + 33, { size: 8, color: C.muted });
        if (it.ok || it.bad) {
          const tn = it.bad ? TONE.dng : TONE.ok;
          pg.rect(x + 10, y + 48, CWd - 20, 22, { fill: tn.bg, r: 4 });
          if (it.bad) cross(pg, x + 21, y + 59, tn.fg); else check(pg, x + 21, y + 59, tn.fg);
          pg.text(`${it.txt}${it.at ? ' · ' + dt(it.at) : ''}`, x + 32, y + 54.5, { font: L.B, size: 8.5, color: tn.fg });
        } else {
          pg.line(x + 10, y + 64, x + CWd * 0.6, y + 64, C.faint, 0.6);
          pg.text('подпись', x + 10, y + 66, { size: 7, color: C.faint });
          pg.line(x + CWd * 0.66, y + 64, x + CWd - 10, y + 64, C.faint, 0.6);
          pg.text('дата', x + CWd * 0.66, y + 66, { size: 7, color: C.faint });
        }
      });
    } });
  }
  return out;
}

// ---------------------------------------------------------------- журнал

function logBlocks(L: Layout, d: any): Block[] {
  const evs: any[] = (d.events as any[]).filter((e) => e.kind !== 'via' && (EVT[e.kind] || e.text)).slice(-40);
  const out: Block[] = [];
  evs.forEach((e, i) => {
    const act = EVT[e.kind] || '';
    const msg = ['comment', 'answer', 'question', 'approved', 'executed', 'acked', 'rejected', 'returned', 'delegated', 'rework'].includes(e.kind) || !e.actor_id;
    const text = e.kind === 'step_started' && e.text ? e.text : [e.actor ? e.actor + ' ' : '', act, e.text && e.text !== act ? (act ? ': ' : '') + e.text : ''].join('');
    const lines = L.wrap(text, 9, W - 100);
    const h = lines.length * 12.5 + 6;
    void msg;
    out.push({ h, paint: (pg, y) => {
      if (i % 2 === 0) pg.rect(ML - 6, y - 1, W + 12, h, { fill: C.bg, r: 3 });
      pg.text(dt(e.created_at), ML, y + 2.5, { size: 8.5, color: C.muted });
      lines.forEach((ln, li) => pg.text(ln, ML + 92, y + 2.5 + li * 12.5, { size: 9 }));
    } });
  });
  return out;
}

// ---------------------------------------------------------------- документ

export async function renderRequestPdf(d: any, fonts: [Ttf, Ttf], origin: string): Promise<Blob> {
  const r = d.request, can = d.can || {};
  const num = r.number || 'Черновик';
  const L = new Layout(fonts, `Заявка № ${num} · ${r.type_name}`);
  const doc = L.doc;
  doc.info = { title: `Заявка ${num} — ${r.type_name}`, author: r.author || '', subject: 'Заявка и ход согласования' };
  const url = `${origin}/requests/${r.id}`;
  const pg = L.pg;

  // шапка
  pg.rect(0, 0, A4.w, 92, { fill: C.navy });
  pg.circle(A4.w - 40, 10, 90, { fill: hex('#12408a') });
  pg.circle(A4.w - 120, 96, 46, { fill: hex('#0f3573') });
  pg.text('Вместе', ML, 26, { font: L.B, size: 22, color: C.white });
  pg.text('корпоративный портал', ML, 54, { size: 9, color: hex('#b9cdee') });
  const rt = 'ЗАЯВКА · ХОД СОГЛАСОВАНИЯ';
  pg.text(rt, A4.w - MR - L.B.width(rt, 9), 28, { font: L.B, size: 9, color: C.white });
  const gen = 'Сформировано ' + dt(new Date().toISOString());
  pg.text(gen, A4.w - MR - L.R.width(gen, 8.5), 44, { size: 8.5, color: hex('#b9cdee') });

  // заголовок
  let y = 112;
  pg.text(`${r.type_name}${r.version ? ' · версия формы ' + r.version : ''}`, ML, y, { size: 10, color: C.muted });
  pg.text(num, ML, y + 14, { font: L.B, size: 26, color: C.ink });
  const st: { label: string; kind?: string } = STATUS[r.status] || { label: r.status };
  const tone = ({ ok: TONE.ok, warn: TONE.warn, dng: TONE.dng, accent: TONE.acc } as any)[st.kind || ''] || TONE.grey;
  const stLabel = r.info_by ? 'Ожидается ответ заявителя' : st.label;
  const sw = L.B.width(stLabel, 10) + 22;
  pg.rect(A4.w - MR - sw, y + 18, sw, 24, { fill: tone.bg, r: 12 });
  pg.text(stLabel, A4.w - MR - sw + 11, y + 24, { font: L.B, size: 10, color: tone.fg });
  y += 56;
  if (r.title && r.title !== num) { for (const ln of L.wrap(r.title, 11, W)) { pg.text(ln, ML, y, { font: L.B, size: 11 }); y += 15; } y += 2; }

  // реквизиты
  const meta: [string, string][] = ([
    ['Заявитель', [r.author, r.author_title].filter(Boolean).join(', ')],
    ['Подразделение', r.department || ''],
    ['Контакты заявителя', [r.author_phone, r.author_email].filter(Boolean).join(' · ')],
    ['Подана', r.submitted_at ? dt(r.submitted_at) : 'не подана (черновик создан ' + dd(r.created_at) + ')'],
    ['Срок исполнения', r.due_at ? dt(r.due_at) : ''],
    ['Круг согласования', d.round > 1 ? String(d.round) : ''],
    ['Закрыта', r.closed_at ? dt(r.closed_at) : ''],
  ] as [string, string][]).filter((m) => m[1]);
  const colW = (W - 36) / 2;
  const mrows: number[] = [];
  const wrapped = meta.map((m) => L.wrap(m[1], 10, colW));
  for (let i = 0; i < meta.length; i += 2) mrows.push(Math.max(wrapped[i].length, wrapped[i + 1]?.length || 0) * 12.5 + 18);
  const mh = mrows.reduce((a, b) => a + b, 0) + 18;
  pg.rect(ML, y, W, mh, { fill: C.bg, r: 8 });
  let my = y + 12;
  for (let i = 0; i < meta.length; i += 2) {
    [i, i + 1].forEach((k, c) => {
      if (!meta[k]) return;
      const x = ML + 18 + c * (colW + 0);
      pg.text(meta[k][0].toUpperCase(), x, my, { font: L.B, size: 7, color: C.faint });
      wrapped[k].forEach((ln, li) => pg.text(ln, x, my + 11 + li * 12.5, { size: 10 }));
    });
    my += mrows[i / 2];
  }
  L.y = y + mh + 16;

  // «Где сейчас заявка»
  const active = (d.steps as any[]).find((s) => s.round === d.round && s.state === 'active');
  const pend = active ? (d.assignees as any[]).filter((a) => a.step_id === active.id && a.state === 'pending') : [];
  const box: { title: string; tone: Tone; lines: string[]; contacts: string[] } = { title: '', tone: TONE.acc, lines: [], contacts: [] };
  if (['pending', 'in_progress'].includes(r.status) && active) {
    box.title = pend.length ? 'Требуется решение: ' + (STEP_KIND[active.kind] || 'этап') + ' «' + active.name + '»' : 'Идёт этап «' + active.name + '»';
    box.tone = pend.some((a) => a.overdue) ? TONE.dng : TONE.warn;
    box.lines.push(`Этап начат ${dt(active.started_at)} (${daysAgo(active.started_at)} ${plural(daysAgo(active.started_at), ['день', 'дня', 'дней'])} назад).`);
    for (const a of pend) {
      box.lines.push(`• ${a.name}${a.job_title ? ', ' + a.job_title : ''}${a.due_at ? ' — срок до ' + dt(a.due_at) : ''}${a.overdue ? ' (ПРОСРОЧЕНО)' : ''}`);
      const c = [a.phone && 'тел. ' + a.phone, a.email].filter(Boolean).join(' · ');
      if (c) box.contacts.push(`${a.name}: ${c}`);
    }
  } else if (r.status === 'rework') { box.title = 'Заявка возвращена на доработку'; box.tone = TONE.warn; box.lines.push('Заявитель должен внести правки и отправить заявку повторно.'); }
  else if (r.info_by) { box.title = 'Согласующий запросил информацию'; box.tone = TONE.warn; box.lines.push(`${r.info_by_name || 'Согласующий'} ждёт ответа заявителя в комментариях к заявке.`); }
  else if (r.status === 'rejected') { box.title = 'Заявка отклонена'; box.tone = TONE.dng; if (r.closed_at) box.lines.push('Закрыта ' + dt(r.closed_at) + '.'); }
  else if (['approved', 'done'].includes(r.status)) { box.title = r.status === 'done' ? 'Заявка выполнена' : 'Заявка согласована'; box.tone = TONE.ok; if (r.closed_at) box.lines.push('Закрыта ' + dt(r.closed_at) + '.'); }
  else if (r.status === 'cancelled') { box.title = 'Заявка отозвана заявителем'; box.tone = TONE.grey; }
  else if (r.status === 'draft') { box.title = 'Черновик'; box.tone = TONE.grey; box.lines.push('Заявка ещё не подана на согласование.'); }
  void can;
  if (box.title) {
    const body = box.lines.flatMap((l) => L.wrap(l, 9.5, W - 40));
    const cont = box.contacts.length ? ['Как напомнить:', ...box.contacts.flatMap((c) => L.wrap(c, 9.5, W - 56))] : [];
    const tl = L.wrap(box.title, 11.5, W - 40, true), th = tl.length * 15;
    const h = 14 + th + 6 + body.length * 13 + (cont.length ? cont.length * 13 + 8 : 0) + 10;
    L.place({ h: h + 14, paint: (p, yy) => {
      p.rect(ML, yy, W, h, { fill: box.tone.bg, r: 8 });
      p.rect(ML, yy, 5, h, { fill: box.tone.fg, r: 2.5 });
      tl.forEach((ln, i) => p.text(ln, ML + 18, yy + 11 + i * 15, { font: L.B, size: 11.5, color: box.tone.fg }));
      const by = yy + 11 + th + 6;
      body.forEach((ln, i) => p.text(ln, ML + 18, by + i * 13, { size: 9.5, color: C.ink }));
      cont.forEach((ln, i) => p.text(ln, ML + (i ? 28 : 18), by + body.length * 13 + 8 + i * 13, { font: i ? L.R : L.B, size: 9.5, color: i ? C.brand : C.ink }));
    } });
  }

  // разделы
  const data = dataBlocks(L, d);
  if (data.length) { L.flow([sectionTitle(L, 'Данные заявки'), ...data]); L.gap(6); }
  const route = routeBlocks(L, d);
  if (route.length) { L.flow([sectionTitle(L, 'Ход согласования', d.round > 1 ? `круг ${d.round}` : undefined), ...route]); L.gap(6); }
  const sign = signBlocks(L, d);
  if (sign.length) { L.flow([sectionTitle(L, 'Подписи и визы', 'электронные отметки и поля для подписи'), ...sign]); L.gap(6); }
  const log = logBlocks(L, d);
  if (log.length) L.flow([sectionTitle(L, 'Журнал событий'), ...log]);

  // колонтитулы
  const N = doc.pages.length;
  doc.pages.forEach((p, i) => {
    p.line(ML, A4.h - 40, A4.w - MR, A4.h - 40, C.line, 0.75);
    p.text('Открыть заявку в системе: ' + url, ML, A4.h - 33, { size: 8, color: C.brand });
    p.link(ML, A4.h - 34, Math.min(W - 80, L.R.width('Открыть заявку в системе: ' + url, 8)), 12, url);
    const pn = `Стр. ${i + 1} из ${N}`;
    p.text(pn, A4.w - MR - L.R.width(pn, 8), A4.h - 33, { size: 8, color: C.muted });
  });
  return doc.build();
}

export async function downloadRequestPdf(d: any): Promise<void> {
  const fonts = await loadFonts();
  const blob = await renderRequestPdf(d, fonts, location.origin);
  // имя файла — латиницей: так оно одинаково открывается в любых браузерах и ОС
  const tr: Record<string, string> = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };
  const safe = String(d.request.number || 'draft').toLowerCase().split('').map((c) => tr[c] ?? c).join('').replace(/[^a-z0-9._-]+/g, '_').toUpperCase();
  saveBlob(blob, `Zayavka_${safe}.pdf`);
}
