import { useState } from 'react';
import './tz.css';
import { api } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { toast, useStore, isHR } from '../../lib/store';
import { Badge, Btn, Empty, Field, Input, Loading, Modal, Select, Switch, Tabs, Textarea } from '../../ui';
import { Link, navigate, useTitle } from '../../lib/router';
import { cx, fmtShort as fmtDate, plural } from '../../lib/util';
import * as I from '../../lib/icons';
import { errMsg, useAudiences } from './common';

const ANON: Record<string, string> = { open: 'Открытый (видно, кто ответил)', anonymous: 'Анонимный (срезы от N ответов)', guaranteed: 'Гарантированно анонимный (без срезов)' };
const KINDS: Record<string, string> = { poll: 'Опрос', pulse: 'Пульс-опрос', engagement: 'Вовлечённость', onboarding: 'Адаптация', course: 'После курса' };
const QK: Record<string, string> = { single: 'Один вариант', multi: 'Несколько вариантов', scale: 'Шкала 1–10', rating: 'Оценка 1–5', nps: 'NPS 0–10', text: 'Свободный текст', date: 'Дата' };

function Take({ id }: { id: number }) {
  useTitle('Опрос');
  const q = useQuery<any>('sv:' + id, () => api.get('/api/surveys/' + id), { stale: 0 });
  const [a, setA] = useState<Record<string, any>>({});
  const [busy, setBusy] = useState(false);
  if (!q.data) return <Loading />;
  const { survey: s, questions } = q.data;
  const set = (qid: number, v: any) => setA((x) => ({ ...x, [qid]: v }));
  async function send() {
    const miss = questions.find((x: any) => x.required && (a[x.id] == null || a[x.id] === '' || (Array.isArray(a[x.id]) && !a[x.id].length)));
    if (miss) return toast({ title: 'Ответьте на обязательный вопрос: ' + miss.title, kind: 'error' });
    setBusy(true);
    try { await api.post(`/api/surveys/${id}/respond`, { answers: a }); invalidate('sv'); invalidate('home'); invalidate('gf'); toast({ title: 'Спасибо за ответы!', kind: 'success' }); navigate('/surveys'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  if (s.answered) return <div className="card"><Empty icon={I.CheckCheck} title="Вы уже участвовали в этом опросе">Спасибо! <Link to="/surveys" className="btn" style={{ marginTop: 10 }}>К списку опросов</Link></Empty></div>;
  return (
    <div className="stack" style={{ maxWidth: 820 }}>
      <div className="crumbs"><Link to="/surveys"><I.ArrowLeft size={15} style={{ verticalAlign: -2 }} /> Опросы</Link></div>
      <div className="card pad stackS"><h1>{s.title}</h1><div className="muted">{s.description}</div>
        <Badge kind={s.anonymity === 'open' ? 'warn' : 'ok'}>{s.anonymity === 'open' ? 'Ответы не анонимны' : 'Ответы анонимны: автор не сохраняется'}</Badge></div>
      {questions.map((x: any, i: number) => (
        <div key={x.id} className="tzQ"><b>{i + 1}. {x.title}{x.required && <span style={{ color: 'var(--danger)' }}> *</span>}</b>
          {(x.kind === 'single' || x.kind === 'multi') && <div className="stackS">{x.options.map((o: string) => { const multi = x.kind === 'multi'; const cur = a[x.id]; const on = multi ? (cur || []).includes(o) : cur === o;
            return <label key={o} className="tzOpt"><input type={multi ? 'checkbox' : 'radio'} name={'q' + x.id} checked={!!on} onChange={() => set(x.id, multi ? (on ? (cur || []).filter((z: string) => z !== o) : [...(cur || []), o]) : o)} /> {o}</label>; })}</div>}
          {(x.kind === 'scale' || x.kind === 'rating' || x.kind === 'nps') && (() => { const lo = x.kind === 'nps' ? 0 : 1, hi = x.kind === 'rating' ? 5 : 10; return <div className="tzScale" role="radiogroup">{Array.from({ length: hi - lo + 1 }, (_, k) => lo + k).map((n) => <button key={n} role="radio" aria-checked={a[x.id] === n} className={cx(a[x.id] === n && 'on')} onClick={() => set(x.id, n)}>{n}</button>)}</div>; })()}
          {x.kind === 'text' && <Textarea rows={3} maxLength={4000} value={a[x.id] || ''} onChange={(e) => set(x.id, e.target.value)} />}
          {x.kind === 'date' && <Input type="date" value={a[x.id] || ''} onChange={(e) => set(x.id, e.target.value)} />}
        </div>
      ))}
      <div><Btn kind="pri" size="lg" busy={busy} onClick={send}><I.Send size={17} /> Отправить ответы</Btn></div>
    </div>
  );
}

/** Расширенная справка: паспорт, участие, динамика, итоги по вопросам, выводы. Печать и скачивание — из окна. */
function ReportModal({ id, onClose }: { id: number; onClose: () => void }) {
  const q = useQuery<any>('sv:rep:' + id, () => api.get(`/api/surveys/${id}/report`), { stale: 0 });
  const d = q.data;
  const esc = (t: any) => String(t ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c] as string));
  function html() {
    const m = d.meta, r = d.results;
    const bars = (o: Record<string, number>, n: number) => Object.entries(o).sort((a, b) => b[1] - a[1]).map(([k, v]) => `<tr><td>${esc(k)}</td><td style="width:50%"><div style="background:#4a7fd0;height:10px;width:${n ? Math.round((v * 100) / n) : 0}%"></div></td><td>${v} (${n ? Math.round((v * 100) / n) : 0}%)</td></tr>`).join('');
    return `<!doctype html><meta charset="utf-8"><title>${esc(m.title)}</title><style>body{font:14px/1.5 system-ui,sans-serif;max-width:860px;margin:24px auto;color:#222}h1{font-size:22px}h2{font-size:16px;margin-top:22px}table{border-collapse:collapse;width:100%}td,th{padding:4px 8px;border-bottom:1px solid #ddd;text-align:left}.k{color:#666}li{margin:3px 0}</style>
<h1>Справка по опросу «${esc(m.title)}»</h1><p class="k">Автор: ${esc(m.author || '—')} · аудитория: ${esc(m.audience)} · анонимность: ${esc(ANON[m.anonymity] || m.anonymity)} · сформирована ${new Date(d.generated_at).toLocaleString('ru-RU')}</p>
${m.description ? `<p>${esc(m.description)}</p>` : ''}<h2>Выводы</h2><ul>${d.findings.map((f: string) => `<li>${esc(f)}</li>`).join('')}</ul>
<h2>Участие</h2><p>Ответили ${r.responded} из ${r.invited}.</p>${d.by_day.length ? `<table><tr><th>День</th><th>Ответов</th></tr>${d.by_day.map((x: any) => `<tr><td>${esc(x.day)}</td><td>${x.n}</td></tr>`).join('')}</table>` : ''}
${d.by_dept.length ? `<h2>Ответили по подразделениям (от ${r.min_group})</h2><table>${d.by_dept.map((x: any) => `<tr><td>${esc(x.name)}</td><td>${x.n}</td></tr>`).join('')}</table>` : ''}
<h2>Итоги по вопросам</h2>${r.questions.map((x: any, i: number) => `<h3>${i + 1}. ${esc(x.title)}</h3><p class="k">Ответов: ${x.n}${x.avg ? ` · среднее ${x.avg}` : ''}${x.nps != null ? ` · NPS ${x.nps}` : ''}</p>${x.counts && Object.keys(x.counts).length ? `<table>${bars(x.counts, x.n)}</table>` : ''}${x.texts?.length ? `<ul>${x.texts.map((t: string) => `<li>${esc(t)}</li>`).join('')}</ul>` : ''}`).join('')}`;
  }
  function print() { const w = window.open('', '_blank'); if (!w) { toast({ title: 'Разрешите всплывающие окна', kind: 'error' }); return; } w.document.write(html()); w.document.close(); w.focus(); setTimeout(() => w.print(), 300); }
  function download() { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([html()], { type: 'text/html;charset=utf-8' })); a.download = `spravka-oprosa-${id}.html`; document.body.appendChild(a); a.click(); a.remove(); }
  return (
    <Modal title="Расширенная справка по опросу" size="lg" onClose={onClose} footer={<><Btn onClick={onClose}>Закрыть</Btn>{d && <><Btn onClick={download}><I.Download size={16} /> Скачать</Btn><Btn kind="pri" onClick={print}><I.File size={16} /> Печать / PDF</Btn></>}</>}>
      {!d ? <Loading /> : <div className="stack">
        <div className="small muted">Автор: {d.meta.author || '—'} · аудитория: {d.meta.audience} · {ANON[d.meta.anonymity]}</div>
        <div className="card pad stackS"><b>Выводы</b>{d.findings.map((f: string, i: number) => <div key={i} className="small">• {f}</div>)}</div>
        {d.by_day.length > 0 && <div className="stackS"><b>Динамика ответов</b>{d.by_day.map((x: any) => <div key={x.day} className="tzRes"><span>{x.day}</span><div className="tzBar"><i style={{ width: Math.min(100, x.n * 100 / Math.max(...d.by_day.map((y: any) => y.n))) + '%' }} /></div><span>{x.n}</span></div>)}</div>}
        {d.by_dept.length > 0 && <div className="stackS"><b>Ответили по подразделениям</b>{d.by_dept.map((x: any) => <div key={x.name} className="row small"><span className="sp clip">{x.name}</span><b>{x.n}</b></div>)}</div>}
        <div className="small muted">Итоги по каждому вопросу — в печатной версии и в файле справки.</div>
      </div>}
    </Modal>
  );
}

function Results({ id }: { id: number }) {
  const [rep, setRep] = useState(false);
  const q = useQuery<any>('sv:res:' + id, () => api.get(`/api/surveys/${id}/results`), { stale: 0 });
  const d = q.data;
  if (!d) return <Loading />;
  const pct = d.invited ? Math.round((d.responded * 100) / d.invited) : 0;
  return (
    <div className="stack">
      <div className="row"><div className="crumbs sp"><Link to="/surveys"><I.ArrowLeft size={15} style={{ verticalAlign: -2 }} /> Опросы</Link></div><Btn onClick={() => setRep(true)}><I.File size={16} /> Расширенная справка</Btn></div>
      {rep && <ReportModal id={id} onClose={() => setRep(false)} />}
      <div className="tzStats"><div className="tzStat"><span className="small muted">Ответили</span><b>{d.responded} / {d.invited}</b></div><div className="tzStat"><span className="small muted">Участие</span><b>{pct}%</b></div><div className="tzStat"><span className="small muted">Анонимность</span><b style={{ fontSize: 14 }}>{ANON[d.anonymity]}</b></div></div>
      {d.questions.map((x: any) => (
        <div key={x.id} className="card pad stack"><h3>{x.title}</h3><div className="tiny muted">Ответов: {x.n}{x.avg ? ` · среднее ${x.avg}` : ''}</div>
          {x.kind === 'nps' && x.nps != null && <div className="tzNps" style={{ color: x.nps >= 30 ? 'var(--ok)' : x.nps >= 0 ? 'var(--warn)' : 'var(--danger)' }}>NPS {x.nps}</div>}
          {x.counts && Object.keys(x.counts).length > 0 && <div className="stackS">{Object.entries(x.counts).sort((a: any, b: any) => (x.kind === 'single' || x.kind === 'multi' ? b[1] - a[1] : +a[0] - +b[0])).map(([k, v]: any) => <div key={k} className="tzRes"><span className="clip">{k}</span><div className="tzBar"><i style={{ width: `${x.n ? (v * 100) / x.n : 0}%` }} /></div><b>{v}</b></div>)}</div>}
          {x.by_dept && <div className="stackS"><div className="small bold">По подразделениям (от {d.min_group} ответов)</div>{Object.entries(x.by_dept).map(([k, v]: any) => <div key={k} className="tzRes"><span className="clip">{k}</span><div className="tzBar"><i style={{ width: `${(v[0] / (x.kind === 'rating' ? 5 : 10)) * 100}%` }} /></div><b>{v[0]}</b></div>)}</div>}
          {x.texts?.length > 0 && <div className="stackS">{x.texts.map((t: string, i: number) => <div key={i} className="it small" style={{ padding: '8px 12px', background: 'var(--surface2)', borderRadius: 'var(--r-sm)' }}>{t}</div>)}</div>}
        </div>
      ))}
    </div>
  );
}

function Builder({ id, onClose }: { id?: number; onClose: () => void }) {
  const aud = useAudiences();
  const ex = useQuery<any>(id ? 'sv:edit:' + id : null, () => api.get('/api/surveys/' + id), { stale: 0 });
  const [f, setF] = useState<any>(null);
  if (id && ex.data && !f) setF({ ...ex.data.survey, questions: ex.data.questions.map((x: any) => ({ ...x })) });
  if (!id && !f) setF({ title: '', description: '', kind: 'poll', anonymity: 'anonymous', audience_id: null, status: 'draft', min_group: 5, results_public: false, ends_at: null, questions: [{ kind: 'single', title: '', options: ['Да', 'Нет'], required: true }] });
  const [busy, setBusy] = useState(false);
  if (!f) return <Loading />;
  const set = (k: string, v: any) => setF((s: any) => ({ ...s, [k]: v }));
  const setQ = (i: number, p: any) => set('questions', f.questions.map((x: any, j: number) => (j === i ? { ...x, ...p } : x)));
  async function save(status: string) {
    setBusy(true);
    try { await (id ? api.put('/api/surveys/' + id, { ...f, status, ends_at: f.ends_at ? new Date(f.ends_at).toISOString() : null, starts_at: null }) : api.post('/api/surveys', { ...f, status, ends_at: f.ends_at ? new Date(f.ends_at).toISOString() : null, starts_at: null })); invalidate('sv'); toast({ title: status === 'active' ? 'Опрос запущен' : 'Сохранено', kind: 'success' }); onClose(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return (
    <div className="card pad stack">
      <h2>{id ? 'Редактирование опроса' : 'Новый опрос'}</h2>
      <div className="formGrid">
        <Field label="Название" className="full"><Input value={f.title} onChange={(e) => set('title', e.target.value)} /></Field>
        <Field label="Описание" className="full"><Textarea rows={2} value={f.description} onChange={(e) => set('description', e.target.value)} /></Field>
        <Field label="Тип"><Select value={f.kind} onChange={(e) => set('kind', e.target.value)}>{Object.entries(KINDS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
        <Field label="Анонимность"><Select value={f.anonymity} onChange={(e) => set('anonymity', e.target.value)}>{Object.entries(ANON).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
        <Field label="Аудитория"><Select value={f.audience_id ?? ''} onChange={(e) => set('audience_id', e.target.value ? +e.target.value : null)}><option value="">Все сотрудники</option>{(aud.data || []).map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</Select></Field>
        <Field label="Приём ответов до"><Input type="date" value={f.ends_at ? String(f.ends_at).slice(0, 10) : ''} onChange={(e) => set('ends_at', e.target.value || null)} /></Field>
        <Field label="Показать на N-й день работы (адаптационный опрос)"><Input type="number" min={0} value={f.onboarding_day ?? ''} onChange={(e) => set('onboarding_day', e.target.value === '' ? null : +e.target.value)} /></Field>
        <Field label="Минимум ответов для срезов"><Input type="number" min={3} value={f.min_group} onChange={(e) => set('min_group', +e.target.value)} /></Field>
      </div>
      <Switch checked={f.results_public} onChange={(v) => set('results_public', v)} label="Результаты видны всем участникам" />
      <h3>Вопросы</h3>
      {f.questions.map((x: any, i: number) => (
        <div key={i} className="tzQ">
          <div className="row" style={{ flexWrap: 'wrap' }}><Input style={{ flex: 1, minWidth: 220 }} placeholder={`Вопрос ${i + 1}`} value={x.title} onChange={(e) => setQ(i, { title: e.target.value })} />
            <Select style={{ width: 200 }} value={x.kind} onChange={(e) => setQ(i, { kind: e.target.value })}>{Object.entries(QK).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select>
            <label className="row small" style={{ gap: 4 }}><input type="checkbox" checked={x.required} onChange={(e) => setQ(i, { required: e.target.checked })} /> обязательный</label>
            <button className="btn ghost sm" onClick={() => set('questions', f.questions.filter((_: any, j: number) => j !== i))} aria-label="Удалить вопрос"><I.Trash size={15} /></button></div>
          {(x.kind === 'single' || x.kind === 'multi') && <Textarea rows={3} placeholder="Варианты ответов — каждый с новой строки" value={(x.options || []).join('\n')} onChange={(e) => setQ(i, { options: e.target.value.split('\n').map((z) => z.trim()).filter(Boolean) })} />}
        </div>
      ))}
      <div><button className="btn" onClick={() => set('questions', [...f.questions, { kind: 'scale', title: '', options: [], required: false }])}><I.Plus size={16} /> Добавить вопрос</button></div>
      <div className="row" style={{ justifyContent: 'flex-end', flexWrap: 'wrap' }}><button className="btn" onClick={onClose}>Отмена</button><Btn busy={busy} onClick={() => save('draft')}>Сохранить черновик</Btn><Btn kind="pri" busy={busy} onClick={() => save('active')}><I.Play size={16} /> Запустить</Btn></div>
    </div>
  );
}

export function SurveysPage({ id, results }: { id?: number; results?: boolean }) {
  useTitle('Опросы');
  const me = useStore((s) => s.me)!;
  const manager = me.role === 'admin' || isHR(me) || !!me.survey_manager;
  const [tab, setTab] = useState<'my' | 'manage'>('my');
  const [edit, setEdit] = useState<number | 'new' | null>(null);
  const my = useQuery<any[]>('sv:my', () => api.get('/api/surveys'));
  const all = useQuery<any[]>(tab === 'manage' ? 'sv:all' : null, () => api.get('/api/surveys?manage=1'));
  if (id && results) return <Results id={id} />;
  if (id) return <Take id={id} />;
  if (edit != null) return <Builder id={edit === 'new' ? undefined : edit} onClose={() => setEdit(null)} />;
  async function remind(i: number) { try { const r = await api.post<{ sent: number }>(`/api/surveys/${i}/remind`); toast({ title: `Напоминание отправлено: ${r.sent}`, kind: 'success' }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  return (
    <div className="stack">
      <div className="pageH"><h1>Опросы</h1><div className="sp" />{manager && <button className="btn pri" onClick={() => setEdit('new')}><I.Plus size={17} /> Создать опрос</button>}</div>
      {manager && <Tabs value={tab} onChange={(v) => setTab(v as any)} items={[{ id: 'my', label: 'Для меня' }, { id: 'manage', label: 'Управление' }]} />}
      {tab === 'my' && (!my.data ? <Loading /> : my.data.length === 0 ? <div className="card"><Empty icon={I.Chart} title="Активных опросов нет">Когда появятся новые, вы получите уведомление.</Empty></div> :
        <div className="tzGrid">{my.data.map((s) => <Link key={s.id} to={`/surveys/${s.id}`} className="card tzW" style={{ color: 'inherit' }}><div className="row"><Badge>{KINDS[s.kind]}</Badge>{s.answered && <Badge kind="ok">Пройден</Badge>}</div><b>{s.title}</b><div className="small muted clamp2">{s.description}</div><div className="tiny muted">{plural(s.questions, ['вопрос', 'вопроса', 'вопросов'])}{s.ends_at ? ` · до ${fmtDate(s.ends_at)}` : ''}</div></Link>)}</div>)}
      {tab === 'manage' && (!all.data ? <Loading /> : <div className="stackS">{all.data.map((s) => <div key={s.id} className="card pad row" style={{ flexWrap: 'wrap' }}><div className="sp" style={{ minWidth: 220 }}><b>{s.title}</b><div className="tiny muted">{KINDS[s.kind]} · ответили {s.responses} из {s.audience_size}</div></div><Badge kind={s.status === 'active' ? 'ok' : undefined}>{s.status === 'active' ? 'Идёт' : s.status === 'draft' ? 'Черновик' : 'Закрыт'}</Badge><Link to={`/surveys/${s.id}/results`} className="btn sm">Результаты</Link>{s.status === 'active' && <button className="btn sm" onClick={() => remind(s.id)}>Напомнить</button>}{s.responses === 0 && <button className="btn sm" onClick={() => setEdit(s.id)}>Изменить</button>}</div>)}</div>)}
    </div>
  );
}
