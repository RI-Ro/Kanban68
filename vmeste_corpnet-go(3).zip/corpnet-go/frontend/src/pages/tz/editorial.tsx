import { useState } from 'react';
import './tz.css';
import { api } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { toast, useStore, isEditor } from '../../lib/store';
import { Badge, Btn, Empty, Loading, Modal, Textarea } from '../../ui';
import { Link, useTitle } from '../../lib/router';
import { fmtShort as fmtDate } from '../../lib/util';
import * as I from '../../lib/icons';
import { errMsg } from './common';

/** Редакционный процесс: очередь согласования для редакторов и «мои публикации» для авторов. */
export function EditorialPage() {
  useTitle('Редакция');
  const me = useStore((s) => s.me)!;
  const q = useQuery<any>('editorial', () => api.get('/api/news-review'), { stale: 0 });
  const [rej, setRej] = useState<any>(null);
  const [note, setNote] = useState('');
  if (!q.data) return <Loading />;
  async function approve(id: number) { try { await api.post(`/api/news/${id}/approve`, {}); invalidate('editorial'); invalidate('news'); toast({ title: 'Опубликовано', kind: 'success' }, 2500); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  async function reject() { try { await api.post(`/api/news/${rej.id}/reject`, { note }); setRej(null); setNote(''); invalidate('editorial'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  async function submit(id: number) { try { await api.post(`/api/news/${id}/submit`); invalidate('editorial'); toast({ title: 'Отправлено на согласование', kind: 'success' }, 2500); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  const { queue, mine } = q.data;
  const ST: Record<string, [string, any]> = { draft: ['Черновик', undefined], review: ['На согласовании', 'warn'], rejected: ['Возвращено', 'dng'] };
  return (
    <div className="stack" style={{ maxWidth: 960 }}>
      <div className="pageH"><h1>Редакция</h1><div className="sp" /><Link to="/news/new" className="btn pri"><I.Plus size={17} /> Новая публикация</Link></div>
      {isEditor(me) && <div className="stackS"><h3>На согласовании ({queue.length})</h3>
        {queue.length === 0 ? <div className="card"><Empty icon={I.CheckCheck} title="Очередь пуста">Новые публикации авторов появятся здесь.</Empty></div> : queue.map((n: any) => (
          <div key={n.id} className="card pad row" style={{ flexWrap: 'wrap' }}><div className="sp" style={{ minWidth: 240 }}><Link to={`/news/${n.id}`}><b>{n.title}</b></Link><div className="tiny muted">{n.author} · {n.department || 'вся компания'} · {fmtDate(n.submitted_at)}{n.must_read ? ' · обязательно к прочтению' : ''}</div></div>
            <Link to={`/news/${n.id}/edit`} className="btn sm">Править</Link><button className="btn sm" onClick={() => setRej(n)}>Вернуть</button><Btn kind="pri" size="sm" onClick={() => approve(n.id)}><I.Check size={15} /> Опубликовать</Btn></div>))}
      </div>}
      <div className="stackS"><h3>Мои материалы</h3>
        {mine.length === 0 ? <div className="small muted">Пока нет черновиков и материалов на согласовании.</div> : mine.map((n: any) => (
          <div key={n.id} className="card pad row" style={{ flexWrap: 'wrap' }}><div className="sp" style={{ minWidth: 240 }}><Link to={`/news/${n.id}/edit`}><b>{n.title}</b></Link>{n.review_note && <div className="small" style={{ color: 'var(--danger)' }}>Комментарий редактора: {n.review_note}</div>}</div>
            <Badge kind={ST[n.status][1]}>{ST[n.status][0]}</Badge>{(n.status === 'draft' || n.status === 'rejected') && <Btn size="sm" onClick={() => submit(n.id)}>На согласование</Btn>}</div>))}
      </div>
      {rej && <Modal title="Вернуть на доработку" onClose={() => setRej(null)} footer={<><button className="btn" onClick={() => setRej(null)}>Отмена</button><Btn kind="pri" disabled={!note.trim()} onClick={reject}>Вернуть автору</Btn></>}><Textarea rows={4} placeholder="Что нужно исправить?" value={note} onChange={(e) => setNote(e.target.value)} /></Modal>}
    </div>
  );
}
