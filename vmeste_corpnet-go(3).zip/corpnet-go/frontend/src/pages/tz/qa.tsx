import { useState } from 'react';
import './tz.css';
import { api } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { toast, useStore } from '../../lib/store';
import { Avatar, Badge, Btn, Empty, Field, Input, Loading, Modal, Select, Tabs, Textarea, useConfirm } from '../../ui';
import { useTitle } from '../../lib/router';
import { cx, fmtShort as fmtDate } from '../../lib/util';
import * as I from '../../lib/icons';
import { errMsg } from './common';

export function AskPage() {
  useTitle('Спросите директора');
  const q = useQuery<any>('qa', () => api.get('/api/qa'), { stale: 10000 });
  const [text, setText] = useState('');
  const [topic, setTopic] = useState('');
  const [anon, setAnon] = useState(false);
  const [busy, setBusy] = useState(false);
  const [ans, setAns] = useState<Record<number, string>>({});
  if (!q.data) return <Loading />;
  const { config: c, items, responder } = q.data;
  if (!c.enabled) return <div className="card"><Empty icon={I.Message} title="Раздел отключён" /></div>;
  async function ask() {
    setBusy(true);
    try { const r = await api.post<{ status: string }>('/api/qa', { question: text, topic, anonymous: anon }); setText(''); invalidate('qa'); toast({ title: r.status === 'new' ? 'Вопрос отправлен на проверку' : 'Вопрос опубликован', kind: 'success' }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  const vote = async (id: number) => { await api.post(`/api/qa/${id}/vote`).catch(() => {}); invalidate('qa'); };
  async function decide(id: number, status: string) {
    const reason = status === 'rejected' ? prompt('Причина отказа (увидит автор)') || '' : '';
    try { await api.post(`/api/qa/${id}/decide`, { status, answer: ans[id] || '', reason }); invalidate('qa'); invalidate('home'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <div className="stack" style={{ maxWidth: 900 }}>
      <div className="pageH"><h1>{c.title}</h1></div>
      <div className="card pad stack"><h3>Задать вопрос</h3>
        <div className="small muted">Вопросы читает руководство. {c.moderation ? 'Перед публикацией вопрос проверяет модератор.' : ''} Самые популярные получают ответ в первую очередь.</div>
        <Input placeholder="Тема (необязательно)" value={topic} onChange={(e) => setTopic(e.target.value)} />
        <Textarea rows={3} maxLength={1500} placeholder="Ваш вопрос…" value={text} onChange={(e) => setText(e.target.value)} />
        <div className="row" style={{ flexWrap: 'wrap' }}>{c.allow_anonymous && <label className="row small" style={{ gap: 6 }}><input type="checkbox" checked={anon} onChange={(e) => setAnon(e.target.checked)} /> Анонимно (имя не показывается никому)</label>}<span className="sp" /><Btn kind="pri" busy={busy} disabled={text.trim().length < 10} onClick={ask}><I.Send size={16} /> Отправить</Btn></div></div>
      {items.map((x: any) => (
        <div key={x.id} className="card pad stack">
          <div className="row" style={{ flexWrap: 'wrap' }}>{x.topic && <Badge kind="accent">{x.topic}</Badge>}{x.status === 'new' && <Badge kind="warn">На проверке</Badge>}{x.status === 'rejected' && <Badge kind="dng">Отклонён</Badge>}{x.mine && <Badge>Ваш вопрос</Badge>}<span className="sp" /><span className="tiny muted">{x.author || 'Аноним'} · {fmtDate(x.created_at)}</span></div>
          <div><b>{x.question}</b></div>
          {x.answer && <div className="card pad" style={{ background: 'var(--accent-soft)', boxShadow: 'none' }}><div className="tiny muted" style={{ marginBottom: 4 }}>Отвечает {x.answered_by} · {fmtDate(x.answered_at)}</div><div style={{ whiteSpace: 'pre-wrap' }}>{x.answer}</div></div>}
          <div className="row" style={{ flexWrap: 'wrap' }}>
            {(x.status === 'approved' || x.status === 'answered') && <button className={cx('chip', x.voted && 'on')} onClick={() => vote(x.id)}><I.Heart size={15} /> Поддерживаю · {x.votes}</button>}
            {responder && x.status !== 'rejected' && x.status !== 'answered' && <>
              <Textarea rows={2} style={{ flex: 1, minWidth: 220 }} placeholder="Ответ…" value={ans[x.id] || ''} onChange={(e) => setAns({ ...ans, [x.id]: e.target.value })} />
              {x.status === 'new' && <button className="btn sm" onClick={() => decide(x.id, 'approved')}>Опубликовать</button>}
              <Btn kind="pri" size="sm" disabled={!(ans[x.id] || '').trim()} onClick={() => decide(x.id, 'answered')}>Ответить</Btn><button className="btn sm" onClick={() => decide(x.id, 'rejected')}>Отклонить</button></>}
          </div>
        </div>
      ))}
    </div>
  );
}

const ST: Record<string, [string, any]> = { new: ['Новое', 'warn'], in_work: ['В работе', 'accent'], need_info: ['Нужны уточнения', 'warn'], resolved: ['Решено', 'ok'], rejected: ['Отклонено', 'dng'] };
const MODES: Record<string, string> = { named: 'Открыто, с моим именем', confidential: 'Конфиденциально (имя видит только HR)', anonymous: 'Анонимно (связь с автором не сохраняется)' };

function Thread({ id, onBack }: { id: number; onBack: () => void }) {
  const me = useStore((s) => s.me)!;
  const key = 'fb:t:' + id;
  const q = useQuery<any>(key, () => api.get('/api/feedback/' + id), { stale: 0 });
  const [body, setBody] = useState('');
  const [res, setRes] = useState('');
  const [edit, setEdit] = useState<{ subject: string; body: string } | null>(null);
  const [confirm, cnode] = useConfirm();
  if (!q.data) return <Loading />;
  const { report: r, messages, handler, editable } = q.data;
  async function send() {
    if (!body.trim()) return;
    try { await api.post('/api/feedback/message', { id, body }); setBody(''); invalidate('fb:t'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function status(s: string) { try { await api.post(`/api/feedback/${r.id}/status`, { status: s, result: res }); invalidate('fb'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  async function saveEdit() {
    try { await api.put('/api/feedback/' + id, edit); setEdit(null); invalidate('fb'); toast({ title: 'Обращение изменено', kind: 'success' }, 2000); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function del() {
    if (!(await confirm('Удалить обращение?', { text: 'Пока его не взяли в работу, обращение можно удалить без следа.', ok: 'Удалить' }))) return;
    try { await api.del('/api/feedback/' + id); invalidate('fb'); onBack(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <div className="stack" style={{ maxWidth: 860 }}>
      {cnode}
      <button className="btn ghost sm" style={{ justifySelf: 'start' }} onClick={onBack}><I.ArrowLeft size={15} /> Назад</button>
      <div className="card pad stack">
        <div className="row" style={{ flexWrap: 'wrap' }}><Badge>{r.topic}</Badge><Badge kind={ST[r.status][1]}>{ST[r.status][0]}</Badge>
          <span className="sp" />
          {editable && <><Btn size="sm" onClick={() => setEdit({ subject: r.subject, body: r.body })}><I.Edit size={14} /> Изменить</Btn><Btn size="sm" kind="dng" onClick={del}><I.Trash size={14} /> Удалить</Btn></>}
        </div>
        <h2>{r.subject}</h2>{r.author && <div className="small muted">Автор: {r.author}</div>}
        <div style={{ whiteSpace: 'pre-wrap' }}>{r.body}</div>
        {r.result && <div className="notice"><b>Результат:</b> {r.result}</div>}
      </div>
      <div className="card pad stack">
        <h3>Переписка {messages.length > 0 && <span className="muted">{messages.length}</span>}</h3>
        {messages.length === 0 && <div className="muted small">Сообщений пока нет.</div>}
        <div className="stack cmtList">
          {messages.map((m: any, i: number) => (
            <div key={i} className="cmtNode"><div className="cmt">
              <Avatar name={m.side === 'handler' ? 'Ответственный' : (r.author || me.name)} size={40} />
              <div style={{ minWidth: 0, flex: 1 }}>
                <div className="bubble">
                  <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
                    <span className="bold small">{m.side === 'handler' ? 'Ответственный' : (r.author || 'Автор обращения')}</span>
                    <span className="tiny faint cmtTime">{fmtDate(m.created_at)}</span>
                  </div>
                  <div className="body" style={{ whiteSpace: 'pre-wrap' }}>{m.body}</div>
                </div>
              </div>
            </div></div>
          ))}
        </div>
        <div className="cmtForm">
          <Avatar name={me.name} src={me.avatar} size={40} />
          <div className="cmtBox"><textarea className="txt" rows={1} value={body} maxLength={4000} placeholder="Написать сообщение… (Ctrl+Enter — отправить)" onChange={(e) => setBody(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); send(); } }} /></div>
          <Btn kind="pri" icon disabled={!body.trim()} onClick={send} aria-label="Отправить"><I.Send size={18} /></Btn>
        </div>
      </div>
      {handler && <div className="card pad stackS"><b>Обработка</b><Input placeholder="Итог / решение (увидит автор)" value={res} onChange={(e) => setRes(e.target.value)} /><div className="row" style={{ flexWrap: 'wrap' }}>{Object.entries(ST).map(([k, v]) => <button key={k} className={cx('chip', r.status === k && 'on')} onClick={() => status(k)}>{v[0]}</button>)}</div></div>}
      {edit && (
        <Modal title="Изменить обращение" onClose={() => setEdit(null)} footer={<><Btn onClick={() => setEdit(null)}>Отмена</Btn><Btn kind="pri" onClick={saveEdit} disabled={!edit.subject.trim() || edit.body.trim().length < 10}>Сохранить</Btn></>}>
          <div className="stack">
            <Field label="Кратко"><Input value={edit.subject} onChange={(e) => setEdit({ ...edit, subject: e.target.value })} /></Field>
            <Field label="Подробно" hint="Не короче 10 символов"><Textarea rows={6} value={edit.body} onChange={(e) => setEdit({ ...edit, body: e.target.value })} /></Field>
          </div>
        </Modal>
      )}
    </div>
  );
}

export function FeedbackPage() {
  useTitle('Обращения');
  const topics = useQuery<any[]>('fb:topics', () => api.get('/api/feedback/topics'));
  const list = useQuery<any>('fb:list', () => api.get('/api/feedback'), { stale: 10000 });
  const [tab, setTab] = useState<'new' | 'mine' | 'inbox'>('mine');
  const [f, setF] = useState({ topic_id: 0, mode: 'named', subject: '', body: '' });
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState('');
  const [open, setOpen] = useState<number | null>(null);
  const t = topics.data?.find((x) => x.id === f.topic_id);
  // тема по умолчанию — первая: форма сразу видна
  if (topics.data?.length && !f.topic_id) { const tt = topics.data[0]; setF({ ...f, topic_id: tt.id, mode: tt.modes.includes('named') ? 'named' : tt.modes[0] }); }
  if (open) return <Thread id={open} onBack={() => setOpen(null)} />;
  async function send() {
    setBusy(true);
    try { const r = await api.post<{ code: string; id: number }>('/api/feedback', f); setF({ ...f, subject: '', body: '' }); invalidate('fb'); if (f.mode === 'anonymous') setDone(r.code); else { toast({ title: 'Обращение отправлено', kind: 'success' }, 2500); setTab('mine'); } } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  const inbox = list.data?.inbox || [];
  const mine = list.data?.mine || [];
  const short = f.body.trim().length < 10;
  return (
    <div className="stack" style={{ maxWidth: 900 }}>
      <div className="pageH"><h1>Обращения</h1></div>
      <Tabs value={tab} onChange={(v) => setTab(v as any)} items={[{ id: 'mine', label: 'Мои обращения', count: mine.length || undefined }, { id: 'new', label: 'Новое обращение' }, ...(inbox.length ? [{ id: 'inbox' as const, label: 'Обработка', count: inbox.filter((x: any) => x.status === 'new').length }] : [])]} />
      {tab === 'new' && (done ? (
        <div className="card pad stack"><h3>Анонимное обращение принято</h3><div>Код обращения: <b style={{ fontSize: 22 }}>{done}</b></div>
          <div className="small muted">Связь с автором не сохраняется, поэтому обращение не появится в «Моих обращениях». Код восстановить нельзя.</div><div><button className="btn" onClick={() => { setDone(''); setTab('mine'); }}>Хорошо</button></div></div>
      ) : (
        <div className="card pad stack">
          <Field label="Тема"><Select value={f.topic_id} onChange={(e) => { const id = +e.target.value; const tt = topics.data?.find((x) => x.id === id); setF({ ...f, topic_id: id, mode: tt?.modes.includes(f.mode) ? f.mode : tt?.modes[0] || 'named' }); }}>{(topics.data || []).map((x) => <option key={x.id} value={x.id}>{x.title}</option>)}</Select></Field>
          {t && <><div className="small muted">{t.description} Срок реакции: {t.sla_hours} ч.</div>
            <Field label="Как подать"><Select value={f.mode} onChange={(e) => setF({ ...f, mode: e.target.value })}>{t.modes.map((m: string) => <option key={m} value={m}>{MODES[m]}</option>)}</Select></Field>
            <Field label="Кратко"><Input value={f.subject} maxLength={200} onChange={(e) => setF({ ...f, subject: e.target.value })} /></Field>
            <Field label="Подробно" hint={short && f.body ? 'Опишите подробнее — не короче 10 символов' : undefined}><Textarea rows={6} value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} /></Field>
            <div><Btn kind="pri" busy={busy} disabled={!f.subject.trim() || short} onClick={send}><I.Send size={16} /> Отправить</Btn></div></>}
        </div>
      ))}
      {tab === 'mine' && (mine.length === 0 ? <div className="card"><Empty icon={I.Shield} title="Обращений нет">Анонимные обращения здесь не показываются.</Empty></div> : <div className="stackS">{mine.map((r: any) => (
        <button key={r.id} className="card pad row" style={{ textAlign: 'left' }} onClick={() => setOpen(r.id)}><div className="sp"><b className="small">{r.subject}</b><div className="tiny muted">{r.topic} · {fmtDate(r.created_at)}</div></div><Badge kind={ST[r.status][1]}>{ST[r.status][0]}</Badge></button>))}</div>)}
      {tab === 'inbox' && <div className="stackS">{inbox.map((r: any) => <button key={r.id} className="card pad row" style={{ textAlign: 'left' }} onClick={() => setOpen(r.id)}><div className="sp"><b className="small">{r.subject}</b><div className="tiny muted">{r.topic}{r.author ? ' · ' + r.author : ''} · {fmtDate(r.created_at)}{r.overdue ? ' · просрочено' : ''}</div></div><Badge kind={ST[r.status][1]}>{ST[r.status][0]}</Badge></button>)}</div>}
    </div>
  );
}
