package kv

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

func backends(t *testing.T) map[string]*Client {
	m := map[string]*Client{"memory": New(NewMemory())}
	if u := os.Getenv("KV_TEST_PG_URL"); u != "" {
		p, err := pgxpool.New(context.Background(), u)
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(p.Close)
		b := NewPG(p)
		if err := b.Init(context.Background()); err != nil {
			t.Fatal(err)
		}
		_, _ = p.Exec(context.Background(), `TRUNCATE kv_store`)
		m["pg"] = New(b)
	}
	if u := os.Getenv("KV_TEST_REDIS_URL"); u != "" {
		r, err := NewRedis(u)
		if err != nil {
			t.Fatal(err)
		}
		r.C.FlushDB(context.Background())
		m["redis"] = New(r)
	}
	return m
}

func TestConformance(t *testing.T) {
	ctx := context.Background()
	for name, c := range backends(t) {
		t.Run(name, func(t *testing.T) {
			// строки, TTL, NX
			if err := c.Set(ctx, "s", "v", 0).Err(); err != nil {
				t.Fatal(err)
			}
			if v, err := c.Get(ctx, "s").Result(); err != nil || v != "v" {
				t.Fatalf("get %q %v", v, err)
			}
			if _, err := c.Get(ctx, "none").Result(); err != Nil {
				t.Fatalf("want Nil, got %v", err)
			}
			if !c.SetNX(ctx, "lock", "1", time.Minute).Val() {
				t.Fatal("setnx first")
			}
			if c.SetNX(ctx, "lock", "2", time.Minute).Val() {
				t.Fatal("setnx second must fail")
			}
			c.Set(ctx, "ttl", "x", 150*time.Millisecond)
			time.Sleep(300 * time.Millisecond)
			if _, err := c.Get(ctx, "ttl").Result(); err != Nil {
				t.Fatalf("expired key still there: %v", err)
			}
			if !c.SetNX(ctx, "ttl", "y", time.Minute).Val() {
				t.Fatal("setnx over expired")
			}
			if n := c.Del(ctx, "s", "none").Val(); n != 1 {
				t.Fatalf("del=%d", n)
			}
			// счётчик
			c.Incr(ctx, "n")
			if n := c.Incr(ctx, "n").Val(); n != 2 {
				t.Fatalf("incr=%d", n)
			}
			c.Expire(ctx, "n", 100*time.Millisecond)
			time.Sleep(250 * time.Millisecond)
			if n := c.Incr(ctx, "n").Val(); n != 1 {
				t.Fatalf("incr after expire=%d", n)
			}
			// хэш
			c.HSet(ctx, "h", "a", 1, "b", "x")
			c.HIncrBy(ctx, "h", "a", 4)
			h := c.HGetAll(ctx, "h").Val()
			if h["a"] != "5" || h["b"] != "x" || len(h) != 2 {
				t.Fatalf("hash %v", h)
			}
			if v, _ := c.HGet(ctx, "h", "b").Result(); v != "x" {
				t.Fatal("hget")
			}
			if _, err := c.HGet(ctx, "h", "zz").Result(); err != Nil {
				t.Fatal("hget miss")
			}
			if len(c.HGetAll(ctx, "nohash").Val()) != 0 {
				t.Fatal("hgetall empty")
			}
			// TTL ключа сохраняется при добавлении поля
			c.HSet(ctx, "ht", "a", "1")
			c.Expire(ctx, "ht", 200*time.Millisecond)
			c.HSet(ctx, "ht", "b", "2")
			time.Sleep(350 * time.Millisecond)
			if len(c.HGetAll(ctx, "ht").Val()) != 0 {
				t.Fatal("hash ttl must apply to new fields")
			}
			// множества, уникальные
			c.SAdd(ctx, "set", "a", "b", "a")
			if got := c.SMembers(ctx, "set").Val(); len(got) != 2 {
				t.Fatalf("smembers %v", got)
			}
			c.SRem(ctx, "set", "a")
			if got := c.SMembers(ctx, "set").Val(); len(got) != 1 || got[0] != "b" {
				t.Fatalf("srem %v", got)
			}
			c.PFAdd(ctx, "u", "x", "y", "x")
			if n := c.PFCount(ctx, "u").Val(); n != 2 {
				t.Fatalf("pfcount %d", n)
			}
			// упорядоченное множество
			c.ZAdd(ctx, "z", Z{Score: 1, Member: "a"}, Z{Score: 5, Member: "b"}, Z{Score: 9, Member: "c"})
			if n := c.ZCard(ctx, "z").Val(); n != 3 {
				t.Fatalf("zcard %d", n)
			}
			got := c.ZRangeByScore(ctx, "z", &ZRangeBy{Min: "2", Max: "+inf"}).Val()
			if len(got) != 2 || got[0] != "b" || got[1] != "c" {
				t.Fatalf("zrange %v", got)
			}
			got = c.ZRangeByScore(ctx, "z", &ZRangeBy{Min: "(1", Max: "9", Offset: 0, Count: 1}).Val()
			if len(got) != 1 || got[0] != "b" {
				t.Fatalf("zrange limit %v", got)
			}
			if n := c.ZRemRangeByScore(ctx, "z", "-inf", "(5").Val(); n != 1 {
				t.Fatalf("zremrange %d", n)
			}
			c.ZRem(ctx, "z", "c")
			if n := c.ZCard(ctx, "z").Val(); n != 1 {
				t.Fatalf("zcard after %d", n)
			}
			// RENAMENX
			c.Set(ctx, "r1", "1", 0)
			if !c.RenameNX(ctx, "r1", "r2").Val() {
				t.Fatal("renamenx")
			}
			if v, _ := c.Get(ctx, "r2").Result(); v != "1" {
				t.Fatal("renamed value")
			}
			// pipeline
			p := c.Pipeline()
			a := p.Incr(ctx, "pi")
			b := p.Incr(ctx, "pi")
			g := p.Get(ctx, "pmiss")
			if _, err := p.Exec(ctx); err != nil {
				t.Fatal(err)
			}
			if a.Val() != 1 || b.Val() != 2 || g.Err() != Nil {
				t.Fatalf("pipeline %d %d %v", a.Val(), b.Val(), g.Err())
			}
			if err := c.Ping(ctx).Err(); err != nil {
				t.Fatal(err)
			}
		})
	}
}
