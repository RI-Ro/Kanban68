package kv

import (
	"context"
	"errors"

	"github.com/redis/go-redis/v9"
)

// Redis — настоящий Redis; команды уходят как есть.
type Redis struct{ C *redis.Client }

func NewRedis(url string) (*Redis, error) {
	o, err := redis.ParseURL(url)
	if err != nil {
		return nil, err
	}
	o.PoolSize = 64
	o.Protocol = 2 // ответы как плоские списки: так их одинаково читают все реализации
	return &Redis{C: redis.NewClient(o)}, nil
}

func (r *Redis) Kind() string { return "redis" }
func (r *Redis) Close() error { return r.C.Close() }

func (r *Redis) Do(ctx context.Context, args ...any) (any, error) {
	v, err := r.C.Do(ctx, args...).Result()
	if errors.Is(err, redis.Nil) {
		return nil, nil
	}
	return v, err
}

func (r *Redis) Pipe(ctx context.Context, cmds [][]any) ([]any, []error) {
	p := r.C.Pipeline()
	cs := make([]*redis.Cmd, len(cmds))
	for i, c := range cmds {
		cs[i] = p.Do(ctx, c...)
	}
	_, _ = p.Exec(ctx)
	vals, errs := make([]any, len(cmds)), make([]error, len(cmds))
	for i, c := range cs {
		v, err := c.Result()
		if errors.Is(err, redis.Nil) {
			err = nil
			v = nil
		}
		vals[i], errs[i] = v, err
	}
	return vals, errs
}
