package kv

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// Schema — таблица для pg-реализации. UNLOGGED: не пишется в WAL и не реплицируется (это кэш/сессионные данные,
// после падения PostgreSQL они пусты — пользователям придётся войти заново, как и при перезапуске Redis).
const Schema = `
CREATE UNLOGGED TABLE IF NOT EXISTS kv_store (
  k     text NOT NULL,
  f     text NOT NULL DEFAULT '',
  v     text NOT NULL DEFAULT '',
  score double precision NOT NULL DEFAULT 0,
  exp   timestamptz,
  PRIMARY KEY (k, f)
);
CREATE INDEX IF NOT EXISTS kv_store_exp ON kv_store (exp) WHERE exp IS NOT NULL;
CREATE INDEX IF NOT EXISTS kv_store_score ON kv_store (k, score);`

// PG — хранилище в PostgreSQL. Работает для нескольких процессов и экземпляров, общих с одной БД.
// Просроченные строки фильтруются в запросах и удаляются фоновой очисткой (Sweep).
type PG struct{ P *pgxpool.Pool }

func NewPG(p *pgxpool.Pool) *PG { return &PG{P: p} }

func (p *PG) Kind() string { return "pg" }
func (p *PG) Close() error { return nil }

// Init создаёт таблицу, если её нет (миграции сделают это сами; это страховка).
func (p *PG) Init(ctx context.Context) error {
	_, err := p.P.Exec(ctx, Schema)
	return err
}

// Sweep удаляет просроченные строки; вызывать раз в минуту из одного процесса.
func (p *PG) Sweep(ctx context.Context) (int64, error) {
	t, err := p.P.Exec(ctx, `DELETE FROM kv_store WHERE exp IS NOT NULL AND exp <= now()`)
	return t.RowsAffected(), err
}

func (p *PG) Pipe(ctx context.Context, cmds [][]any) ([]any, []error) {
	vals, errs := make([]any, len(cmds)), make([]error, len(cmds))
	tx, err := p.P.Begin(ctx)
	if err != nil {
		for i := range errs {
			errs[i] = err
		}
		return vals, errs
	}
	defer tx.Rollback(ctx)
	for i, c := range cmds {
		vals[i], errs[i] = doTx(ctx, tx, c)
	}
	if err := tx.Commit(ctx); err != nil {
		for i := range errs {
			if errs[i] == nil {
				errs[i] = err
			}
		}
	}
	return vals, errs
}

func (p *PG) Do(ctx context.Context, args ...any) (any, error) {
	return doTx(ctx, p.P, args)
}

// live — условие «ключ не просрочен».
const live = `(exp IS NULL OR exp > now())`

type db interface {
	Query(ctx context.Context, sql string, args ...any) (pgx.Rows, error)
	QueryRow(ctx context.Context, sql string, args ...any) pgx.Row
}

// doTx выполняет одну команду на соединении/транзакции.
func doTx(ctx context.Context, d any, args []any) (any, error) {
	if len(args) == 0 {
		return nil, errors.New("kv: empty command")
	}
	cmd := strings.ToUpper(toStr(args[0]))
	a := make([]string, len(args)-1)
	for i, v := range args[1:] {
		a[i] = toStr(v)
	}
	var q db
	switch x := d.(type) {
	case *pgxpool.Pool:
		q = x
	case pgx.Tx:
		q = x
	default:
		return nil, errors.New("kv: bad executor")
	}
	if cmd == "PING" {
		var one int
		if err := q.QueryRow(ctx, `SELECT 1`).Scan(&one); err != nil {
			return nil, err
		}
		return "PONG", nil
	}
	if len(a) < 1 {
		return nil, errors.New("kv: wrong number of arguments for " + cmd)
	}
	k := a[0]
	// exec выполняет запрос и возвращает число затронутых строк.
	exec := func(sql string, params ...any) (int64, error) {
		rows, err := q.Query(ctx, sql, params...)
		if err != nil {
			return 0, err
		}
		rows.Close()
		return rows.CommandTag().RowsAffected(), rows.Err()
	}
	// inheritExp — срок жизни ключа сохраняется при добавлении полей (как в Redis).
	const inheritExp = `(SELECT exp FROM kv_store WHERE k=$1 AND exp IS NOT NULL LIMIT 1)`
	switch cmd {
	case "GET":
		var v string
		err := q.QueryRow(ctx, `SELECT v FROM kv_store WHERE k=$1 AND f='' AND `+live, k).Scan(&v)
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, nil
		}
		return v, err
	case "SET":
		if len(a) < 2 {
			return nil, errors.New("kv: wrong number of arguments for SET")
		}
		var nx bool
		var ttl time.Duration
		for i := 2; i < len(a); i++ {
			switch strings.ToUpper(a[i]) {
			case "NX":
				nx = true
			case "PX":
				i++
				n, _ := strconv.ParseInt(a[i], 10, 64)
				ttl = time.Duration(n) * time.Millisecond
			case "EX":
				i++
				n, _ := strconv.ParseInt(a[i], 10, 64)
				ttl = time.Duration(n) * time.Second
			}
		}
		var ttlArg any
		if ttl > 0 {
			ttlArg = float64(ttl) / float64(time.Second)
		}
		if nx {
			// сперва выбрасываем просроченное, затем пытаемся вставить: ON CONFLICT DO NOTHING
			if _, err := exec(`DELETE FROM kv_store WHERE k=$1 AND NOT `+live, k); err != nil {
				return nil, err
			}
			n, err := exec(`INSERT INTO kv_store (k,f,v,exp) VALUES ($1,'',$2, CASE WHEN $3::float8 IS NULL THEN NULL ELSE now() + make_interval(secs => $3::float8) END)
				ON CONFLICT (k,f) DO NOTHING`, k, a[1], ttlArg)
			if err != nil {
				return nil, err
			}
			if n == 0 {
				return nil, nil
			}
			return "OK", nil
		}
		if _, err := exec(`DELETE FROM kv_store WHERE k=$1`, k); err != nil {
			return nil, err
		}
		_, err := exec(`INSERT INTO kv_store (k,f,v,exp) VALUES ($1,'',$2, CASE WHEN $3::float8 IS NULL THEN NULL ELSE now() + make_interval(secs => $3::float8) END)`, k, a[1], ttlArg)
		return "OK", err
	case "DEL":
		var c int64
		err := q.QueryRow(ctx, `WITH d AS (DELETE FROM kv_store WHERE k = ANY($1) RETURNING k, exp)
			SELECT count(DISTINCT k) FROM d WHERE exp IS NULL OR exp > now()`, a).Scan(&c)
		return c, err
	case "PEXPIRE":
		if len(a) < 2 {
			return nil, errors.New("kv: wrong number of arguments for PEXPIRE")
		}
		n, _ := strconv.ParseInt(a[1], 10, 64)
		c, err := exec(`UPDATE kv_store SET exp = now() + make_interval(secs => $2::float8) WHERE k=$1 AND `+live, k, float64(n)/1000)
		if err != nil {
			return nil, err
		}
		if c > 0 {
			return int64(1), nil
		}
		return int64(0), nil
	case "INCR":
		var v string
		err := q.QueryRow(ctx, `INSERT INTO kv_store (k,f,v) VALUES ($1,'','1')
			ON CONFLICT (k,f) DO UPDATE SET
			  v = CASE WHEN `+strings.ReplaceAll(live, "exp", "kv_store.exp")+` THEN (kv_store.v::bigint + 1)::text ELSE '1' END,
			  exp = CASE WHEN `+strings.ReplaceAll(live, "exp", "kv_store.exp")+` THEN kv_store.exp ELSE NULL END
			RETURNING v`, k).Scan(&v)
		if err != nil {
			return nil, err
		}
		return toInt(v), nil
	case "HSET":
		if len(a) < 3 {
			return nil, errors.New("kv: wrong number of arguments for HSET")
		}
		var added int64
		for i := 1; i+1 < len(a); i += 2 {
			var ins bool
			err := q.QueryRow(ctx, `INSERT INTO kv_store (k,f,v,exp) VALUES ($1,$2,$3,`+inheritExp+`)
				ON CONFLICT (k,f) DO UPDATE SET v=EXCLUDED.v RETURNING (xmax = 0)`, k, a[i], a[i+1]).Scan(&ins)
			if err != nil {
				return nil, err
			}
			if ins {
				added++
			}
		}
		return added, nil
	case "HGET":
		if len(a) < 2 {
			return nil, errors.New("kv: wrong number of arguments for HGET")
		}
		var v string
		err := q.QueryRow(ctx, `SELECT v FROM kv_store WHERE k=$1 AND f=$2 AND `+live, k, a[1]).Scan(&v)
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, nil
		}
		return v, err
	case "HGETALL":
		rows, err := q.Query(ctx, `SELECT f, v FROM kv_store WHERE k=$1 AND `+live+` ORDER BY f`, k)
		if err != nil {
			return nil, err
		}
		defer rows.Close()
		out := []any{}
		for rows.Next() {
			var f, v string
			if err := rows.Scan(&f, &v); err != nil {
				return nil, err
			}
			out = append(out, f, v)
		}
		return out, rows.Err()
	case "HINCRBY":
		if len(a) < 3 {
			return nil, errors.New("kv: wrong number of arguments for HINCRBY")
		}
		d, _ := strconv.ParseInt(a[2], 10, 64)
		var v string
		err := q.QueryRow(ctx, `INSERT INTO kv_store (k,f,v,exp) VALUES ($1,$2,$3::bigint::text,`+inheritExp+`)
			ON CONFLICT (k,f) DO UPDATE SET v=(kv_store.v::bigint + $3::bigint)::text RETURNING v`, k, a[1], d).Scan(&v)
		if err != nil {
			return nil, err
		}
		return toInt(v), nil
	case "SADD", "PFADD":
		var added int64
		for _, m := range a[1:] {
			c, err := exec(`INSERT INTO kv_store (k,f,exp) VALUES ($1,$2,`+inheritExp+`) ON CONFLICT (k,f) DO NOTHING`, k, m)
			if err != nil {
				return nil, err
			}
			added += c
		}
		return added, nil
	case "SREM", "ZREM":
		c, err := exec(`DELETE FROM kv_store WHERE k=$1 AND f = ANY($2)`, k, a[1:])
		return c, err
	case "SMEMBERS":
		rows, err := q.Query(ctx, `SELECT f FROM kv_store WHERE k=$1 AND `+live+` ORDER BY f`, k)
		if err != nil {
			return nil, err
		}
		defer rows.Close()
		out := []any{}
		for rows.Next() {
			var f string
			if err := rows.Scan(&f); err != nil {
				return nil, err
			}
			out = append(out, f)
		}
		return out, rows.Err()
	case "PFCOUNT":
		var c int64
		err := q.QueryRow(ctx, `SELECT count(DISTINCT f) FROM kv_store WHERE k = ANY($1) AND `+live, a).Scan(&c)
		return c, err
	case "ZADD":
		var added int64
		for i := 1; i+1 < len(a); i += 2 {
			sc, _ := strconv.ParseFloat(a[i], 64)
			var ins bool
			err := q.QueryRow(ctx, `INSERT INTO kv_store (k,f,score,exp) VALUES ($1,$2,$3,`+inheritExp+`)
				ON CONFLICT (k,f) DO UPDATE SET score=EXCLUDED.score RETURNING (xmax = 0)`, k, a[i+1], sc).Scan(&ins)
			if err != nil {
				return nil, err
			}
			if ins {
				added++
			}
		}
		return added, nil
	case "ZCARD":
		var c int64
		err := q.QueryRow(ctx, `SELECT count(*) FROM kv_store WHERE k=$1 AND `+live, k).Scan(&c)
		return c, err
	case "ZRANGEBYSCORE", "ZREMRANGEBYSCORE":
		if len(a) < 3 {
			return nil, errors.New("kv: wrong number of arguments for " + cmd)
		}
		lo, loX, err := parseScore(a[1])
		if err != nil {
			return nil, err
		}
		hi, hiX, err := parseScore(a[2])
		if err != nil {
			return nil, err
		}
		cond := `k=$1 AND ` + live
		cond += ` AND score ` + map[bool]string{true: ">", false: ">="}[loX] + ` $2`
		cond += ` AND score ` + map[bool]string{true: "<", false: "<="}[hiX] + ` $3`
		if cmd == "ZREMRANGEBYSCORE" {
			return exec(`DELETE FROM kv_store WHERE `+cond, k, lo, hi)
		}
		sql := `SELECT f FROM kv_store WHERE ` + cond + ` ORDER BY score, f`
		if len(a) >= 6 && strings.EqualFold(a[3], "LIMIT") {
			off, _ := strconv.Atoi(a[4])
			cnt, _ := strconv.Atoi(a[5])
			if cnt >= 0 {
				sql += fmt.Sprintf(" LIMIT %d", cnt)
			}
			sql += fmt.Sprintf(" OFFSET %d", off)
		}
		rows, err := q.Query(ctx, sql, k, lo, hi)
		if err != nil {
			return nil, err
		}
		defer rows.Close()
		out := []any{}
		for rows.Next() {
			var f string
			if err := rows.Scan(&f); err != nil {
				return nil, err
			}
			out = append(out, f)
		}
		return out, rows.Err()
	case "RENAMENX":
		if len(a) < 2 {
			return nil, errors.New("kv: wrong number of arguments for RENAMENX")
		}
		var exists bool
		if err := q.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM kv_store WHERE k=$1 AND `+live+`)`, k).Scan(&exists); err != nil {
			return nil, err
		}
		if !exists {
			return nil, errors.New("ERR no such key")
		}
		if err := q.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM kv_store WHERE k=$1 AND `+live+`)`, a[1]).Scan(&exists); err != nil {
			return nil, err
		}
		if exists {
			return int64(0), nil
		}
		if _, err := exec(`DELETE FROM kv_store WHERE k=$1`, a[1]); err != nil {
			return nil, err
		}
		_, err := exec(`UPDATE kv_store SET k=$2 WHERE k=$1`, k, a[1])
		return int64(1), err
	}
	return nil, errors.New("kv: unsupported command " + cmd)
}
