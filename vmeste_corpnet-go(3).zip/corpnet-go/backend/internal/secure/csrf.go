package secure

import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/base64"
	"net/url"
	"strings"
)

// CSRF: «двойная отправка» (double submit cookie). Токен лежит в cookie cn_csrf (JS его читает) и обязан совпасть с
// заголовком X-CSRF-Token у небезопасных запросов, аутентифицированных cookie сессии. Чужой сайт не может ни прочитать
// cookie нашего домена, ни выставить заголовок X-CSRF-Token в кросс-доменном запросе без CORS-разрешения.
const (
	CookieName = "cn_csrf"
	HeaderName = "X-CSRF-Token"
)

// NewToken — 256 бит случайности в base64url.
func NewToken() string {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		panic("crypto/rand: " + err.Error())
	}
	return base64.RawURLEncoding.EncodeToString(b)
}

// ValidToken — оба значения непустые, нужной длины и совпадают (сравнение за постоянное время).
func ValidToken(cookie, header string) bool {
	if len(cookie) < 32 || len(cookie) > 128 || len(header) != len(cookie) {
		return false
	}
	return subtle.ConstantTimeCompare([]byte(cookie), []byte(header)) == 1
}

// Unsafe — методы, меняющие состояние.
func Unsafe(method string) bool {
	switch strings.ToUpper(method) {
	case "GET", "HEAD", "OPTIONS", "TRACE":
		return false
	}
	return true
}

// SameOrigin проверяет Origin (а при его отсутствии — Referer): хост должен совпасть с Host запроса либо входить в allowed
// (элементы вида «https://portal.example.com»). Нет ни Origin, ни Referer → true (не браузерный клиент; защиту даёт токен).
func SameOrigin(origin, referer, host string, allowed []string) bool {
	src := origin
	if src == "" {
		src = referer
	}
	if src == "" {
		return true
	}
	if src == "null" {
		return false
	}
	u, err := url.Parse(src)
	if err != nil || u.Host == "" {
		return false
	}
	if strings.EqualFold(u.Host, host) {
		return true
	}
	base := u.Scheme + "://" + u.Host
	for _, a := range allowed {
		if strings.EqualFold(strings.TrimRight(strings.TrimSpace(a), "/"), base) {
			return true
		}
	}
	return false
}
