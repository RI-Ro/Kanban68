package author

import "testing"

func TestVerify(t *testing.T) {
	name, sum = "", ""
	if Verify() == nil {
		t.Fatal("пустой автор должен отвергаться")
	}
	name, sum = "Автор", Checksum("Автор")
	if err := Verify(); err != nil {
		t.Fatal(err)
	}
	name = "Другой"
	if Verify() == nil {
		t.Fatal("подмена имени должна отвергаться")
	}
}
