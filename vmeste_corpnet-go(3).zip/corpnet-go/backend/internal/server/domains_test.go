package server

import (
	"context"

	"corpnet/internal/krb"
	"corpnet/internal/kv"
	"os"
	"testing"

	"github.com/go-ldap/ldap/v3"
	"github.com/jackc/pgx/v5/pgxpool"
)

func TestParseLoginInput(t *testing.T) {
	for _, c := range []struct{ in, sam, dom string }{
		{"ii-ivanov", "ii-ivanov", ""},
		{"ii-ivanov@DOMAIN1.LOCAL", "ii-ivanov", "domain1.local"},
		{`DOMAIN2\ii-ivanov`, "ii-ivanov", "domain2"},
		{" ivanov@corp.example ", "ivanov", "corp.example"},
		{"a@b@c.d", "a@b", "c.d"},
		{`\x`, `\x`, ""},
		{"@x", "@x", ""},
	} {
		sam, dom := parseLoginInput(c.in)
		if sam != c.sam || dom != c.dom {
			t.Errorf("%q → (%q,%q), want (%q,%q)", c.in, sam, dom, c.sam, c.dom)
		}
	}
}

func TestPrincipalAndFilter(t *testing.T) {
	l := &ldapSrv{Domain: "Domain1.Local", UserFilter: "(|(sAMAccountName=%s)(userPrincipalName=%u))"}
	if got := l.principal("II-Ivanov"); got != "ii-ivanov@domain1.local" {
		t.Fatal(got)
	}
	if got := l.principal("x@other.org"); got != "x@other.org" {
		t.Fatal(got)
	}
	if got := (&ldapSrv{}).principal("Plain"); got != "plain" {
		t.Fatal(got)
	}
	f := l.userFilterFor("a)(uid=*")
	if f != `(|(sAMAccountName=a\29\28uid=\2a)(userPrincipalName=a\29\28uid=\2a@domain1.local))` {
		t.Fatalf("injection not escaped: %s", f)
	}
	_ = ldap.EscapeFilter
}

func TestMentionRegexDomains(t *testing.T) {
	got := parseMentions("привет @ii-ivanov@domain1.local и @petrov, пишите на ivanov@mail.ru; @a@b.c.")
	want := []string{"ii-ivanov@domain1.local", "petrov", "a@b.c"}
	if len(got) != len(want) {
		t.Fatalf("%v", got)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("%v want %v", got, want)
		}
	}
}

// DB-тест: нужен KV_TEST_PG_URL (БД с применёнными миграциями). Два пользователя с одним sam в разных доменах.
func TestTwoDomainsAreDifferentUsers(t *testing.T) {
	url := os.Getenv("KV_TEST_PG_URL")
	if url == "" {
		t.Skip("KV_TEST_PG_URL не задан")
	}
	ctx := context.Background()
	db, err := pgxpool.New(ctx, url)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	s := &Server{db: &DB{Pool: db}, ro: db, rdb: kv.New(kv.NewMemory())}
	s.log = NewLogger(os.Stderr, Config{})
	cleanup := func() {
		db.Exec(ctx, `DELETE FROM users WHERE login IN ('ii-ivanov@domain1.local','ii-ivanov@domain2.local','ii-ivanov')`)
		db.Exec(ctx, `DELETE FROM ldap_servers WHERE name LIKE 'T-DOM%'`)
	}
	cleanup()
	defer cleanup()
	var ids [2]int64
	for i, d := range []string{"domain1.local", "domain2.local"} {
		if err := db.QueryRow(ctx, `INSERT INTO ldap_servers (name, enabled, url, base_dn, user_filter, auto_create, domain, netbios)
			VALUES ($1, true, 'ldap://x', 'dc=x', '(sAMAccountName=%s)', true, $2, $3) RETURNING id`, "T-DOM"+d, d, []string{"DOMAIN1", "DOMAIN2"}[i]).Scan(&ids[i]); err != nil {
			t.Fatal(err)
		}
	}
	// поиск каталога по домену: DNS, NetBIOS (регистр не важен), первая метка
	for _, q := range []struct {
		dom  string
		want int64
	}{{"domain1.local", ids[0]}, {"DOMAIN2", ids[1]}, {"domain2", ids[1]}, {"nope", 0}} {
		srv, err := s.findLDAPByDomain(ctx, q.dom)
		if err != nil {
			t.Fatal(err)
		}
		if (srv == nil && q.want != 0) || (srv != nil && srv.ID != q.want) {
			t.Fatalf("findLDAPByDomain(%q)=%v want %d", q.dom, srv, q.want)
		}
	}
	// два каталога, один и тот же sam, РАЗНЫЕ uid в каталогах — это два пользователя
	var users [2]int64
	for i, id := range ids {
		srv, err := s.loadLDAP(ctx, id)
		if err != nil {
			t.Fatal(err)
		}
		p := &ldapPerson{DN: "cn=ii,dc=x", UID: "guid-" + srv.Domain, Login: srv.principal("II-Ivanov"), Domain: srv.Domain,
			First: "Иван", Last: "Иванов", Email: ""}
		u, _, err := s.upsertLDAPUser(ctx, srv, p, true)
		if err != nil {
			t.Fatalf("upsert %s: %v", srv.Domain, err)
		}
		users[i] = u
	}
	if users[0] == users[1] || users[0] == 0 {
		t.Fatalf("users must differ: %v", users)
	}
	var l0, l1, d0 string
	db.QueryRow(ctx, `SELECT login, domain FROM users WHERE id=$1`, users[0]).Scan(&l0, &d0)
	db.QueryRow(ctx, `SELECT login FROM users WHERE id=$1`, users[1]).Scan(&l1)
	if l0 != "ii-ivanov@domain1.local" || l1 != "ii-ivanov@domain2.local" || d0 != "domain1.local" {
		t.Fatalf("logins: %q %q domain %q", l0, l1, d0)
	}
	// повторный вход тем же uid — тот же пользователь (не дубль)
	srv0, _ := s.loadLDAP(ctx, ids[0])
	again, _, err := s.upsertLDAPUser(ctx, srv0, &ldapPerson{DN: "cn=ii,dc=x", UID: "guid-domain1.local", Login: srv0.principal("ii-ivanov"), Domain: srv0.Domain, First: "Иван", Last: "Иванов"}, true)
	if err != nil || again != users[0] {
		t.Fatalf("relogin: %d %v", again, err)
	}
	// упоминания: полная форма — точно, короткая «@ii-ivanov» неоднозначна → не разрешается
	m, err := s.loginUsers(ctx, []string{"ii-ivanov@domain2.local", "ii-ivanov"}, false)
	if err != nil {
		t.Fatal(err)
	}
	if m["ii-ivanov@domain2.local"].ID != users[1] {
		t.Fatalf("full mention: %+v", m)
	}
	if _, ok := m["ii-ivanov"]; ok {
		t.Fatal("ambiguous short mention must not resolve")
	}
	// после удаления одного домена короткая форма становится однозначной
	db.Exec(ctx, `DELETE FROM users WHERE id=$1`, users[1])
	m, _ = s.loginUsers(ctx, []string{"ii-ivanov"}, false)
	if m["ii-ivanov"].ID != users[0] {
		t.Fatalf("unique short mention: %+v", m)
	}
}

// Kerberos: билет ii-ivanov@DOMAIN2.LOCAL — это пользователь домена 2, а не домена 1 и не локальный «ii-ivanov».
func TestKerberosResolvesPerDomain(t *testing.T) {
	url := os.Getenv("KV_TEST_PG_URL")
	if url == "" {
		t.Skip("KV_TEST_PG_URL не задан")
	}
	ctx := context.Background()
	db, err := pgxpool.New(ctx, url)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	s := &Server{db: &DB{Pool: db}, ro: db, rdb: kv.New(kv.NewMemory())}
	s.log = NewLogger(os.Stderr, Config{})
	clean := func() {
		db.Exec(ctx, `DELETE FROM users WHERE login IN ('ii-ivanov@domain1.local','ii-ivanov@domain2.local','ii-ivanov')`)
		db.Exec(ctx, `DELETE FROM ldap_servers WHERE name LIKE 'T-KRB%'`)
	}
	clean()
	defer clean()
	for _, d := range []string{"domain1.local", "domain2.local"} {
		db.Exec(ctx, `INSERT INTO ldap_servers (name, enabled, url, base_dn, user_filter, domain) VALUES ($1, true, 'ldap://x', 'dc=x', '(uid=%s)', $2)`, "T-KRB"+d, d)
	}
	var loc, u1, u2 int64
	ins := func(login string, out *int64) {
		if err := db.QueryRow(ctx, `INSERT INTO users (login, email, password_hash, first_name, last_name, role) VALUES ($1, '', 'x', 'И', 'И', 'user') RETURNING id`, login).Scan(out); err != nil {
			t.Fatal(err)
		}
	}
	ins("ii-ivanov", &loc)
	ins("ii-ivanov@domain1.local", &u1)
	ins("ii-ivanov@domain2.local", &u2)
	for _, mode := range []string{"upn", "auto", "short"} {
		cfg := krbCfg{UserMap: mode}
		for _, c := range []struct {
			realm string
			want  int64
		}{{"DOMAIN1.LOCAL", u1}, {"DOMAIN2.LOCAL", u2}} {
			got, err := s.krbResolveUser(ctx, cfg, &krb.Identity{User: "ii-ivanov", Realm: c.realm})
			if err != nil || got != c.want {
				t.Errorf("mode %s realm %s: got %d err %v, want %d", mode, c.realm, got, err, c.want)
			}
		}
	}
	// realm без каталога с таким доменом: прежнее поведение (локальный «ii-ivanov» в режиме short)
	got, err := s.krbResolveUser(ctx, krbCfg{UserMap: "short"}, &krb.Identity{User: "ii-ivanov", Realm: "OTHER.LOCAL"})
	if err != nil || got != loc {
		t.Errorf("unknown realm, short: %d %v", got, err)
	}
}
