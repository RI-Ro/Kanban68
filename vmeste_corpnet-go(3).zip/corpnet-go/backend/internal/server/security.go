package server

import (
	"net/http"
	"strings"

	"corpnet/internal/secure"
)

// Защита от CSRF для запросов, аутентифицированных cookie сессии (см. internal/secure).
//
//   - небезопасные методы (POST/PUT/PATCH/DELETE) на /api/ с cookie сессии требуют заголовок X-CSRF-Token = cookie cn_csrf;
//   - дополнительно проверяется Origin/Referer (должен совпасть с Host или входить в ALLOWED_ORIGINS);
//   - вход по паролю (/api/auth/login) токена не требует (сессии ещё нет), но Origin проверяется;
//   - cookie cn_csrf выставляется при входе и при любом запросе с сессией, если её нет (старые сессии подхватываются при загрузке приложения);
//   - запросы без cookie сессии (внутренний токен, мониторинг) CSRF-проверке не подлежат: уязвимости нет — нечем «ездить» от имени пользователя.
//
// Аварийное отключение — CSRF_DISABLE=1 (только на время расследования проблем).
func (s *Server) csrf(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !strings.HasPrefix(r.URL.Path, "/api/") {
			next.ServeHTTP(w, r)
			return
		}
		sess, _ := r.Cookie(cookieName)
		tok, _ := r.Cookie(secure.CookieName)
		if !s.cfg.CSRFOff && secure.Unsafe(r.Method) {
			isLogin := r.URL.Path == "/api/auth/login"
			if isLogin || sess != nil {
				if !secure.SameOrigin(r.Header.Get("Origin"), r.Header.Get("Referer"), r.Host, s.cfg.AllowedOrigins) {
					s.csrfDeny(w, r, "origin")
					return
				}
			}
			if sess != nil && !isLogin {
				got := r.Header.Get(secure.HeaderName)
				if tok == nil || !secure.ValidToken(tok.Value, got) {
					s.csrfDeny(w, r, "token")
					return
				}
			}
		}
		if sess != nil && (tok == nil || len(tok.Value) < 32) {
			s.setCSRFCookie(w, r)
		}
		next.ServeHTTP(w, r)
	})
}

func (s *Server) csrfDeny(w http.ResponseWriter, r *http.Request, why string) {
	s.log.Warn("csrf check failed", "why", why, "method", r.Method, "path", r.URL.Path, "origin", r.Header.Get("Origin"), "ip", s.clientIP(r))
	s.writeErr(w, r, &apiError{403, "Запрос отклонён проверкой безопасности (CSRF). Обновите страницу и повторите действие"})
}

// setCSRFCookie выставляет новый CSRF-токен (JS-читаемый: SPA копирует его в заголовок).
func (s *Server) setCSRFCookie(w http.ResponseWriter, r *http.Request) string {
	t := secure.NewToken()
	http.SetCookie(w, &http.Cookie{Name: secure.CookieName, Value: t, Path: "/", Secure: s.cfg.CookieSecure || s.isHTTPS(r),
		SameSite: http.SameSiteLaxMode, MaxAge: int(s.cfg.SessionTTL.Seconds())})
	return t
}

// isHTTPS — запрос пришёл по TLS (напрямую или через доверенный прокси с X-Forwarded-Proto).
func (s *Server) isHTTPS(r *http.Request) bool {
	return r.TLS != nil || (s.fromTrustedProxy(r) && strings.EqualFold(r.Header.Get("X-Forwarded-Proto"), "https")) || s.cfg.CookieSecure
}
