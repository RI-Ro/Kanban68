package server

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"

	"corpnet/internal/author"

	"corpnet/internal/kv"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"

	"corpnet/internal/secure"
)

// Server is completely stateless: sessions, caches, presence, pub/sub and
// locks live in Redis; durable data lives in PostgreSQL; uploaded files live on
// a shared volume. Any number of instances can run side by side.
type Server struct {
	cfg Config
	db  *DB           // основная БД (с RLS, см. dbrls.go) (запись и чтение, которому нужна свежесть)
	ro  *pgxpool.Pool // локальная реплика для тяжёлого чтения; если реплики нет — тот же пул, что и db
	rdb *kv.Client
	l1  *l1Cache // локальный кэш процесса (сессии и профили)
	hub *Hub
	log *slog.Logger
	mux *http.ServeMux
	up  time.Time
	an  *analytics // сбор аналитики (analytics.go)

	trusted      []*net.IPNet // TRUSTED_PROXIES
	internalNets []*net.IPNet // INTERNAL_ALLOW
}

func New(cfg Config, db, ro *pgxpool.Pool, rdb *kv.Client, log *slog.Logger) (*Server, error) {
	if ro == nil {
		ro = db
	}
	for _, d := range []string{"pub", "prv"} {
		if err := os.MkdirAll(filepath.Join(cfg.DataDir, d), 0o755); err != nil {
			return nil, err
		}
	}
	s := &Server{cfg: cfg, db: &DB{Pool: db, Off: cfg.RLSOff}, ro: ro, rdb: rdb, log: log, mux: http.NewServeMux(), up: time.Now(), l1: newL1(2000), an: newAnalytics(cfg.InstanceID, cfg.TZ)}
	s.trusted, s.internalNets = parseCIDRs(cfg.TrustedProxies), parseCIDRs(cfg.InternalAllow)
	s.hub = newHub(s)
	s.routes()
	return s, nil
}

// redisRaw — настоящий клиент Redis, если kv работает поверх Redis (нужен только для Pub/Sub в REALTIME_MODE=redis).
func (s *Server) redisRaw() *redis.Client {
	if r, ok := s.rdb.Backend().(*kv.Redis); ok {
		return r.C
	}
	return nil
}

func (s *Server) Handler() http.Handler {
	return s.monitor(s.headers(s.nodeRouter(s.gzipAPI(s.csrf(s.moduleGate(s.mux)))))) // request_id, JSON access-лог, метрики, recover (mon_access.go)
}

// ---------------------------------------------------------------- context

type Ctx struct {
	W  http.ResponseWriter
	R  *http.Request
	U  *User
	S  *Server
	T0 time.Time // начало обработки запроса (для замера времени поиска)

	reqID string
}

func (c *Ctx) Context() context.Context { return c.R.Context() }

func (c *Ctx) ID(name string) (int64, error) {
	v, err := strconv.ParseInt(c.R.PathValue(name), 10, 64)
	if err != nil || v <= 0 {
		return 0, badReq("Некорректный идентификатор")
	}
	return v, nil
}

func (c *Ctx) Q(name string) string { return strings.TrimSpace(c.R.URL.Query().Get(name)) }

func (c *Ctx) QInt(name string, def int) int {
	if v, err := strconv.Atoi(c.Q(name)); err == nil {
		return v
	}
	return def
}

func (c *Ctx) QInt64(name string) int64 {
	v, _ := strconv.ParseInt(c.Q(name), 10, 64)
	return v
}

// Page returns limit/offset from ?page=&per= with sane bounds.
func (c *Ctx) Page(defPer, maxPer int) (page, per, offset int) {
	page = max(c.QInt("page", 1), 1)
	per = min(max(c.QInt("per", defPer), 1), maxPer)
	return page, per, (page - 1) * per
}

func (c *Ctx) Decode(v any) error {
	c.R.Body = http.MaxBytesReader(c.W, c.R.Body, 2<<20)
	if err := json.NewDecoder(c.R.Body).Decode(v); err != nil {
		return badReq("Некорректный JSON")
	}
	return nil
}

func (c *Ctx) Raw(code int, b []byte) error {
	c.W.Header().Set("Content-Type", "application/json; charset=utf-8")
	c.W.WriteHeader(code)
	_, err := c.W.Write(b)
	return err
}

func (c *Ctx) JSON(code int, v any) error {
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	return c.Raw(code, b)
}

func (c *Ctx) OK() error { return c.Raw(200, []byte(`{"ok":true}`)) }

func (c *Ctx) IP() string { return c.S.clientIP(c.R) }

// ---------------------------------------------------------------- errors

type apiError struct {
	Code int
	Msg  string
}

func (e *apiError) Error() string { return e.Msg }

func badReq(m string) *apiError   { return &apiError{400, m} }
func conflict(m string) *apiError { return &apiError{409, m} }

var (
	errUnauth    = &apiError{401, "Требуется вход в систему"}
	errForbidden = &apiError{403, "Недостаточно прав"}
	errNotFound  = &apiError{404, "Не найдено"}
)

func (s *Server) writeErr(w http.ResponseWriter, r *http.Request, err error) {
	var ae *apiError
	var pe *pgconn.PgError
	switch {
	case errors.As(err, &ae):
	case errors.Is(err, pgx.ErrNoRows):
		ae = errNotFound
	case errors.As(err, &pe) && pe.Code == "23505":
		ae = conflict("Такая запись уже существует")
	case errors.As(err, &pe) && pe.Code == "23503":
		ae = badReq("Связанная запись не найдена или используется")
	case errors.As(err, &pe) && (pe.Code == "23514" || pe.Code == "22P02" || pe.Code == "22007" || pe.Code == "22008"):
		ae = badReq("Некорректные данные")
	case errors.Is(err, context.Canceled):
		return
	default:
		s.log.Error("request failed", "request_id", RequestID(r.Context()), "path", r.URL.Path, "err", err)
		ae = &apiError{500, "Внутренняя ошибка сервера"}
	}
	monSetErr(r, err)
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(ae.Code)
	b, _ := json.Marshal(map[string]string{"error": ae.Msg})
	w.Write(b)
}

// h adapts a handler; minRole "" means public, otherwise "user"|"editor"|"admin".
func (s *Server) h(minRole string, fn func(*Ctx) error) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		c := &Ctx{W: w, R: r, S: s, T0: time.Now()}
		if minRole != "" {
			u, err := s.authenticate(r)
			if err != nil {
				s.log.Error("auth backend failure", "request_id", RequestID(r.Context()), "err", err)
				s.writeErr(w, r, &apiError{503, "Сервис временно недоступен"})
				return
			}
			if u == nil {
				s.writeErr(w, r, errUnauth)
				return
			}
			if roleRank(minRole) > u.rank() {
				s.writeErr(w, r, errForbidden)
				return
			}
			c.U = u
			s.slideSession(w, r)
			c.R = r.WithContext(withRLS(r.Context(), u)) // запросы к БД с этого момента идут под RLS
			monSetUser(r, u)
		}
		if err := fn(c); err != nil {
			s.writeErr(w, r, err)
		}
	}
}

// ---------------------------------------------------------------- middleware

func (s *Server) headers(next http.Handler) http.Handler {
	csp := secure.CSP(secure.CSPOptions{Extra: s.cfg.CSPExtra})
	cspName := "Content-Security-Policy"
	if s.cfg.CSPReportOnly {
		cspName += "-Report-Only"
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("X-Instance", s.cfg.InstanceID)
		h.Set("X-Author", author.Name()) // зашит при сборке, изменить нельзя
		for k, v := range secure.Headers(s.isHTTPS(r)) {
			h.Set(k, v)
		}
		h.Set(cspName, csp) // отдача файлов (serveFile) ниже ставит собственную, более строгую политику с sandbox
		if strings.HasPrefix(r.URL.Path, "/api/") && !strings.HasPrefix(r.URL.Path, "/api/files/") {
			h.Set("Cache-Control", "no-store")
		}
		next.ServeHTTP(w, r)
	})
}

// ---------------------------------------------------------------- SQL helpers

// arr runs q and returns its rows as one JSON array, built by Postgres itself.
func (s *Server) arr(ctx context.Context, q string, args ...any) (json.RawMessage, error) {
	var b []byte
	err := s.db.QueryRow(ctx, "SELECT coalesce(json_agg(t), '[]'::json) FROM ("+q+") t", args...).Scan(&b)
	return b, err
}

// one runs q and returns the first row as a JSON object (404 if none).
func (s *Server) one(ctx context.Context, q string, args ...any) (json.RawMessage, error) {
	var b []byte
	err := s.db.QueryRow(ctx, "SELECT row_to_json(t) FROM ("+q+") t LIMIT 1", args...).Scan(&b)
	return b, err
}

func (s *Server) tx(ctx context.Context, fn func(tx pgx.Tx) error) error {
	tx, err := s.db.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	if err := fn(tx); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

// ReqID — идентификатор запроса для журнала: входящий X-Request-Id (если безопасный), иначе случайный; уходит и в ответ.
func (c *Ctx) ReqID() string {
	if c.reqID == "" {
		id := c.R.Header.Get("X-Request-Id")
		if !reqIDRe.MatchString(id) {
			b := make([]byte, 8)
			rand.Read(b)
			id = hex.EncodeToString(b)
		}
		c.reqID = id
		c.W.Header().Set("X-Request-Id", id)
	}
	return c.reqID
}

var reqIDRe = regexp.MustCompile(`^[A-Za-z0-9._-]{8,64}$`)

type execer interface {
	Exec(ctx context.Context, sql string, args ...any) (pgconn.CommandTag, error)
}

const auditSQL = `INSERT INTO audit_log (user_id, action, entity, entity_id, data, ip, request_id, actor_role)
	VALUES ($1, $2, $3, NULLIF($4::bigint, 0), $5::jsonb, $6, $7, $8)`

// auditTx пишет запись журнала в переданную транзакцию/соединение и возвращает ошибку (для действий, которые обязаны логироваться).
func (s *Server) auditTx(ctx context.Context, q execer, c *Ctx, action, entity string, id int64, data any) error {
	b, _ := json.Marshal(data)
	var uid any
	role := ""
	if c.U != nil {
		uid, role = c.U.ID, c.U.Role
	}
	_, err := q.Exec(ctx, auditSQL, uid, action, entity, id, string(b), c.IP(), c.ReqID(), role)
	return err
}

func (s *Server) audit(c *Ctx, action, entity string, id int64, data any) {
	if err := s.auditTx(c.Context(), s.db, c, action, entity, id, data); err != nil {
		s.log.Warn("audit failed", "err", err)
	}
}

// ---------------------------------------------------------------- routes

func (s *Server) routes() {
	m := s.mux
	const U, E, A = "user", "editor", "admin"

	m.HandleFunc("GET /healthz", s.healthz)
	m.HandleFunc("GET /api/about", s.about)
	m.HandleFunc("GET /api/admin/monitor", s.h(A, s.adminMonitor))
	m.HandleFunc("GET /metrics", s.metrics) // Prometheus; только внутренняя сеть или INTERNAL_TOKEN (mon_metrics.go)

	// auth & profile
	m.HandleFunc("GET /api/auth/sources", s.h("", s.authSources))
	m.HandleFunc("POST /api/auth/login", s.h("", s.login))
	m.HandleFunc("POST /api/auth/logout", s.h("", s.logout))
	m.HandleFunc("GET /api/bootstrap", s.h(U, s.bootstrap))
	m.HandleFunc("PUT /api/me", s.h(U, s.updateMe))
	m.HandleFunc("POST /api/me/password", s.h(U, s.changePassword))
	m.HandleFunc("POST /api/uploads/public", s.h(U, s.uploadPublic))

	// realtime
	m.HandleFunc("GET /api/presence", s.h(U, s.presence))

	// news
	m.HandleFunc("GET /api/news", s.h(U, s.listNews))
	m.HandleFunc("GET /api/news/{id}", s.h(U, s.getNews))
	m.HandleFunc("POST /api/news", s.h(U, s.saveNews))
	m.HandleFunc("PUT /api/news/{id}", s.h(U, s.saveNews))
	m.HandleFunc("POST /api/news/{id}/hidden", s.h(E, s.setNewsHidden))
	m.HandleFunc("DELETE /api/news/{id}", s.h(E, s.deleteNews))
	m.HandleFunc("POST /api/news/files", s.h(E, s.uploadNewsFile))
	m.HandleFunc("GET /api/news/{id}/versions", s.h(E, s.listNewsVersions))
	m.HandleFunc("GET /api/news/{id}/versions/{vid}", s.h(E, s.getNewsVersion))
	m.HandleFunc("POST /api/news/{id}/autosave", s.h(E, s.autosaveNews))
	m.HandleFunc("GET /api/news/{id}/analytics", s.h(E, s.newsAnalytics))
	m.HandleFunc("GET /api/news-versions/{vid}/comments", s.h(E, s.listVersionComments))
	m.HandleFunc("POST /api/news-versions/{vid}/comments", s.h(E, s.addVersionComment))
	m.HandleFunc("POST /api/news-track/{id}/read", s.h(U, s.trackRead))
	m.HandleFunc("POST /api/news-track/impressions", s.h(U, s.trackImpressions))
	m.HandleFunc("POST /api/news-track/category", s.h(U, s.trackCategory))
	m.HandleFunc("GET /api/news-track/categories", s.h(E, s.categoryAnalytics))
	m.HandleFunc("GET /api/comments", s.h(U, s.listComments))
	m.HandleFunc("POST /api/comments", s.h(U, s.addComment))
	m.HandleFunc("POST /api/comments/files", s.h(U, s.uploadCommentFile))
	m.HandleFunc("PUT /api/comments/{id}", s.h(U, s.editComment))
	m.HandleFunc("DELETE /api/comments/{id}/files/{fid}", s.h(U, s.deleteCommentFile))
	m.HandleFunc("DELETE /api/comments/{id}", s.h(U, s.deleteComment))
	m.HandleFunc("POST /api/likes", s.h(U, s.toggleLike))

	s.registerUserMgmt(m)    // управление пользователями редакторами + экспорт журнала (usermgmt.go)
	s.registerLearning(m)    // раздел «Обучение» (learning.go)
	s.registerLMS(m)         // LMS: курсы, назначения, сертификаты, статистика (lms.go)
	s.registerRequests(m)    // раздел «Заявки» (requests*.go)
	s.registerWiki(m)        // базы знаний в «Материалах» (wiki.go)
	s.registerSocial(m)      // реакции, закладки, упоминания (social_*.go)
	s.registerAnalytics(m)   // аналитика (analytics_api.go)
	s.registerFileSearch(m)  // поиск по содержимому файлов (filesearch.go)
	s.registerFilePreview(m) // серверный предпросмотр PDF (filepreview.go)
	s.registerFileOffice(m)  // просмотр doc/xls/ppt в браузере через LibreOffice (fileoffice.go)
	s.registerKerberos(m)    // вход через Kerberos/SPNEGO (krb_auth.go)
	s.registerTZ(m)          // модули ТЗ: ознакомление, аудитории, геймификация, адаптация, опросы (tz_routes.go)
	s.registerStatic(m)      // /media и SPA (static.go) — без nginx

	// ideas
	m.HandleFunc("GET /api/ideas", s.h(U, s.listIdeas))
	m.HandleFunc("POST /api/ideas", s.h(U, s.saveIdea))
	m.HandleFunc("GET /api/ideas/{id}", s.h(U, s.getIdea))
	m.HandleFunc("PUT /api/ideas/{id}", s.h(U, s.saveIdea))
	m.HandleFunc("GET /api/ideas/{id}/votes", s.h(U, s.ideaVotes))
	m.HandleFunc("POST /api/ideas/{id}/vote", s.h(U, s.ideaVote))
	m.HandleFunc("DELETE /api/ideas/{id}", s.h(U, s.deleteIdea))

	// banners & vacations
	m.HandleFunc("GET /api/banners", s.h(U, s.listBanners))
	m.HandleFunc("GET /api/vacations", s.h(U, s.listVacations))
	m.HandleFunc("POST /api/vacations", s.h(U, s.saveVacation))
	m.HandleFunc("PUT /api/vacations/{id}", s.h(U, s.saveVacation))
	m.HandleFunc("DELETE /api/vacations/{id}", s.h(U, s.deleteVacation))
	m.HandleFunc("GET /api/vacation-calendars", s.h(U, s.listVacCalendars))
	m.HandleFunc("POST /api/vacation-calendars", s.h(U, s.saveVacCalendar))
	m.HandleFunc("PUT /api/vacation-calendars/{id}", s.h(U, s.saveVacCalendar))
	m.HandleFunc("DELETE /api/vacation-calendars/{id}", s.h(U, s.deleteVacCalendar))
	m.HandleFunc("GET /api/vacation-calendars/{id}/access", s.h(U, s.getVacCalendarAccess))
	m.HandleFunc("PUT /api/vacation-calendars/{id}/access", s.h(U, s.putVacCalendarAccess))

	// people & structure
	m.HandleFunc("GET /api/users", s.h(U, s.listUsers))
	m.HandleFunc("GET /api/users/{id}", s.h(U, s.getUser))
	m.HandleFunc("GET /api/departments", s.h(U, s.listDepartments))
	m.HandleFunc("GET /api/departments/search", s.h(U, s.searchDepartments))
	m.HandleFunc("GET /api/admin/tree-check", s.h("admin", s.treeCheck))
	m.HandleFunc("GET /api/admin/ldap-map", s.h(A, s.adminLDAPMapGet))
	m.HandleFunc("PUT /api/admin/ldap-map", s.h(A, s.adminLDAPMapSet))
	m.HandleFunc("GET /api/departments/{id}", s.h(U, s.getDepartment))
	m.HandleFunc("POST /api/departments", s.h(E, s.saveDepartment))
	m.HandleFunc("PUT /api/departments/{id}", s.h(E, s.saveDepartment))
	m.HandleFunc("POST /api/departments/{id}/move", s.h(E, s.moveDepartment))
	m.HandleFunc("DELETE /api/departments/{id}", s.h(E, s.deleteDepartment))
	m.HandleFunc("GET /api/directions", s.h(U, s.listDirections))
	m.HandleFunc("POST /api/directions", s.h(E, s.saveDirection))
	m.HandleFunc("PUT /api/directions/{id}", s.h(E, s.saveDirection))
	m.HandleFunc("POST /api/directions/{id}/move", s.h(E, s.moveDirection))
	m.HandleFunc("DELETE /api/directions/{id}", s.h(E, s.deleteDirection))

	// groups
	m.HandleFunc("GET /api/groups", s.h(U, s.listGroups))
	m.HandleFunc("POST /api/groups", s.h(U, s.saveGroup))
	m.HandleFunc("GET /api/groups/{id}", s.h(U, s.getGroup))
	m.HandleFunc("PUT /api/groups/{id}", s.h(U, s.saveGroup))
	m.HandleFunc("DELETE /api/groups/{id}", s.h(U, s.deleteGroup))
	m.HandleFunc("POST /api/groups/{id}/join", s.h(U, s.joinGroup))
	m.HandleFunc("POST /api/groups/{id}/leave", s.h(U, s.leaveGroup))
	m.HandleFunc("POST /api/groups/{id}/members", s.h(U, s.addGroupMembers))
	m.HandleFunc("PUT /api/groups/{id}/members/{uid}", s.h(U, s.setMemberRole))
	m.HandleFunc("POST /api/groups/{id}/members/{uid}/approve", s.h(U, s.approveMember))
	m.HandleFunc("DELETE /api/groups/{id}/members/{uid}", s.h(U, s.removeMember))
	m.HandleFunc("GET /api/groups/{id}/posts", s.h(U, s.listPosts))
	m.HandleFunc("POST /api/groups/{id}/posts", s.h(U, s.addPost))
	m.HandleFunc("DELETE /api/posts/{id}", s.h(U, s.deletePost))

	// chats
	m.HandleFunc("GET /api/chats", s.h(U, s.listChats))
	m.HandleFunc("POST /api/chats", s.h(U, s.createChat))
	m.HandleFunc("GET /api/chats/{id}", s.h(U, s.getChat))
	m.HandleFunc("DELETE /api/chats/{id}", s.h(U, s.hideChat))
	m.HandleFunc("POST /api/chats/{id}/clear", s.h(U, s.clearChat))
	m.HandleFunc("POST /api/chats/{id}/members", s.h(U, s.addChatMembers))
	m.HandleFunc("POST /api/chats/{id}/leave", s.h(U, s.leaveChat))
	m.HandleFunc("GET /api/chats/{id}/messages", s.h(U, s.listMessages))
	m.HandleFunc("POST /api/chats/{id}/messages", s.h(U, s.sendMessage))
	m.HandleFunc("POST /api/chats/{id}/polls", s.h(U, s.createPoll))
	m.HandleFunc("POST /api/chats/{id}/read", s.h(U, s.markRead))
	m.HandleFunc("PUT /api/chats/{id}/pin", s.h(U, s.pinMessage))
	m.HandleFunc("POST /api/messages/forward", s.h(U, s.forwardMessages))
	m.HandleFunc("POST /api/chats/{id}/files", s.h(U, s.uploadChatFile))
	m.HandleFunc("POST /api/polls/{id}/vote", s.h(U, s.votePoll))
	m.HandleFunc("POST /api/polls/{id}/close", s.h(U, s.closePoll))
	m.HandleFunc("PUT /api/messages/{id}", s.h(U, s.editMessage))
	m.HandleFunc("DELETE /api/messages/{id}", s.h(U, s.deleteMessage))

	// calendar
	m.HandleFunc("GET /api/calendars", s.h(U, s.listCalendars))
	m.HandleFunc("POST /api/calendars", s.h(U, s.saveCalendar))
	m.HandleFunc("PUT /api/calendars/{id}", s.h(U, s.saveCalendar))
	m.HandleFunc("DELETE /api/calendars/{id}", s.h(U, s.deleteCalendar))
	m.HandleFunc("GET /api/events", s.h(U, s.listEvents))
	m.HandleFunc("GET /api/events/upcoming", s.h(U, s.upcomingEvents))
	m.HandleFunc("POST /api/events", s.h(U, s.saveEvent))
	m.HandleFunc("PUT /api/events/{id}", s.h(U, s.saveEvent))
	m.HandleFunc("DELETE /api/events/{id}", s.h(U, s.deleteEvent))
	m.HandleFunc("GET /api/acl/{type}/{id}", s.h(U, s.getACL))
	m.HandleFunc("PUT /api/acl/{type}/{id}", s.h(U, s.putACL))

	// documents / media
	m.HandleFunc("GET /api/folders", s.h(U, s.listFolders))
	m.HandleFunc("GET /api/folders/all", s.h(U, s.listAllFolders))
	m.HandleFunc("GET /api/folders/tree", s.h(U, s.folderTree))
	m.HandleFunc("POST /api/folders", s.h(U, s.saveFolder))
	m.HandleFunc("PUT /api/folders/{id}", s.h(U, s.saveFolder))
	m.HandleFunc("DELETE /api/folders/{id}", s.h(U, s.deleteFolder))
	m.HandleFunc("POST /api/folders/{id}/move", s.h(U, s.moveFolder))
	m.HandleFunc("POST /api/folders/{id}/files", s.h(U, s.uploadFolderFiles))
	m.HandleFunc("DELETE /api/files/{id}", s.h(U, s.deleteFile))
	m.HandleFunc("PUT /api/files/{id}", s.h(U, s.setFileDescription))
	m.HandleFunc("GET /api/files/{id}", s.h(U, s.serveFile))
	m.HandleFunc("GET /files/{id}", s.h(U, s.serveFile)) // путь, который использует интерфейс
	m.HandleFunc("GET /internal/blob/{kind}/{name}", s.internalBlob)
	m.HandleFunc("GET /internal/node/health", s.internalNodeHealth)
	m.HandleFunc("POST /internal/node/promote", s.internalNodePromote)
	m.HandleFunc("GET /api/admin/cluster", s.h(A, s.adminCluster))
	m.HandleFunc("POST /api/admin/nodes", s.h(A, s.adminNodeSave))
	m.HandleFunc("PUT /api/admin/nodes/{id}", s.h(A, s.adminNodeSave))
	m.HandleFunc("DELETE /api/admin/nodes/{id}", s.h(A, s.adminNodeDelete))
	m.HandleFunc("PUT /api/admin/cluster/settings", s.h(A, s.adminClusterSettings))
	m.HandleFunc("POST /api/admin/cluster/master", s.h(A, s.adminSwitchMaster))
	m.HandleFunc("GET /internal/manifest/{kind}", s.internalManifest) // список файлов для фоновой синхронизации площадок (filesync.go)

	// misc
	m.HandleFunc("GET /api/resources", s.h(U, s.listResources))
	m.HandleFunc("POST /api/resources", s.h(E, s.saveResource))
	m.HandleFunc("PUT /api/resources/{id}", s.h(E, s.saveResource))
	m.HandleFunc("DELETE /api/resources/{id}", s.h(E, s.deleteResource))
	m.HandleFunc("GET /api/company", s.h(U, s.getCompany))
	m.HandleFunc("PUT /api/company", s.h(A, s.putCompany))
	m.HandleFunc("GET /api/categories", s.h(U, s.listCategories))
	m.HandleFunc("POST /api/categories", s.h(E, s.saveCategory))
	m.HandleFunc("PUT /api/categories/{id}", s.h(E, s.saveCategory))
	m.HandleFunc("DELETE /api/categories/{id}", s.h(A, s.deleteCategory))
	m.HandleFunc("GET /api/notifications", s.h(U, s.listNotifications))
	m.HandleFunc("POST /api/notifications/read", s.h(U, s.readNotifications))
	m.HandleFunc("GET /api/search", s.h(U, s.search))

	// admin (редакторы видят только свою область; всё остальное — администраторы)
	m.HandleFunc("GET /api/admin/stats", s.h(A, s.adminStats))
	m.HandleFunc("GET /api/admin/audit", s.h(A, s.adminAudit))
	m.HandleFunc("GET /api/admin/news", s.h(E, s.adminListNews))
	m.HandleFunc("POST /api/admin/users/{id}/logout", s.h(A, s.adminLogoutUser))
	m.HandleFunc("GET /api/admin/comments", s.h(A, s.adminComments))
	m.HandleFunc("GET /api/admin/banners", s.h(A, s.adminListBanners))
	m.HandleFunc("POST /api/admin/banners", s.h(A, s.saveBanner))
	m.HandleFunc("PUT /api/admin/banners/{id}", s.h(A, s.saveBanner))
	m.HandleFunc("DELETE /api/admin/banners/{id}", s.h(A, s.deleteBanner))
	m.HandleFunc("GET /api/admin/ldap", s.h(A, s.adminListLDAP))
	m.HandleFunc("POST /api/admin/ldap", s.h(A, s.adminSaveLDAP))
	m.HandleFunc("PUT /api/admin/ldap/{id}", s.h(A, s.adminSaveLDAP))
	m.HandleFunc("DELETE /api/admin/ldap/{id}", s.h(A, s.adminDeleteLDAP))
	m.HandleFunc("POST /api/admin/ldap/{id}/test", s.h(A, s.adminTestLDAP))
	m.HandleFunc("POST /api/admin/ldap/{id}/sync", s.h(A, s.adminSyncLDAP))

	m.HandleFunc("/api/", func(w http.ResponseWriter, r *http.Request) {
		s.writeErr(w, r, errNotFound)
	})
}

func (s *Server) healthz(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 2*time.Second)
	defer cancel()
	status, code := "ok", 200
	if err := s.db.Ping(ctx); err != nil {
		status, code = "postgres: "+err.Error(), 503
	} else if err := s.rdb.Ping(ctx).Err(); err != nil {
		status, code = "kv: "+err.Error(), 503
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	fmt.Fprintf(w, `{"status":%q,"instance":%q}`, status, s.cfg.InstanceID)
}

// about: GET /api/about — сведения о проекте и авторе (публично, значения зашиты при сборке).
func (s *Server) about(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	fmt.Fprintf(w, `{"project":%q,"author":%q,"version":%q}`, author.Project, author.Name(), appVersion)
}

// ObservabilityHandler — только /metrics и /healthz: для отдельного порта процесса (METRICS_ADDR).
func (s *Server) ObservabilityHandler() http.Handler {
	m := http.NewServeMux()
	m.HandleFunc("GET /metrics", s.metrics)
	m.HandleFunc("GET /healthz", s.healthz)
	return m
}
