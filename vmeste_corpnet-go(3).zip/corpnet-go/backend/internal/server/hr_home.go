package server

import (
	"encoding/json"
	"strings"
	"time"
)

// Модуль предназначен для профиля сотрудника по ТЗ (раздел 11–12): конструктор дополнительных полей, навыки,
// замещение, поздравления, быстрые ссылки и агрегат главной страницы (/api/home).

// profileFields — поля, доступные мне (GET /api/profile-fields).
func (s *Server) profileFields(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT id, key, label, kind, options, help, required, in_list, filterable, visibility, editable_by, sort
		FROM profile_fields WHERE active AND (visibility IN ('all') OR ($1::boolean AND visibility IN ('managers','hr')) OR ($2::boolean AND visibility = 'managers')) ORDER BY sort, id`,
		c.U.IsAdmin() || c.U.HR, c.U.Head)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// setCustom — значения дополнительных полей (PUT /api/me/custom {values}); для чужого профиля — только HR (?user=ID).
func (s *Server) setCustom(c *Ctx) error {
	var in struct {
		Values map[string]any `json:"values"`
		Skills *[]string      `json:"skills"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	uid := c.U.ID
	hr := s.needHR(c) == nil
	if q := c.QInt64("user"); q > 0 && q != uid {
		if !hr {
			return errForbidden
		}
		uid = q
	}
	ctx := c.Context()
	rows, err := s.db.Query(ctx, `SELECT key, kind, options, editable_by FROM profile_fields WHERE active`)
	if err != nil {
		return err
	}
	allowed := map[string]string{}
	for rows.Next() {
		var k, kind, by string
		var opts []byte
		if rows.Scan(&k, &kind, &opts, &by) == nil && (by == "self" || hr) {
			allowed[k] = kind
		}
	}
	rows.Close()
	clean := map[string]any{}
	for k, v := range in.Values {
		kind, ok := allowed[k]
		if !ok {
			continue
		}
		if t, isStr := v.(string); isStr {
			v = strings.TrimSpace(t)
			if len([]rune(t)) > 2000 {
				return badReq("Значение поля «" + k + "» слишком длинное")
			}
		}
		if kind == "number" {
			if _, isNum := v.(float64); !isNum && v != "" && v != nil {
				return badReq("Поле «" + k + "» должно быть числом")
			}
		}
		clean[k] = v
	}
	b, _ := json.Marshal(clean)
	if _, err := s.db.Exec(ctx, `UPDATE users SET custom = custom || $2::jsonb WHERE id = $1`, uid, string(b)); err != nil {
		return err
	}
	if in.Skills != nil {
		var sk []string
		for _, t := range *in.Skills {
			if t = strings.TrimSpace(t); t != "" && len(sk) < 30 {
				sk = append(sk, t)
			}
		}
		if _, err := s.db.Exec(ctx, `UPDATE users SET skills = $2 WHERE id = $1`, uid, sk); err != nil {
			return err
		}
	}
	return c.JSON(200, map[string]any{"ok": true})
}

// setHRData — служебные данные сотрудника (PUT /api/users/{id}/hr): дата приёма, наставник, права автора/HR.
func (s *Server) setHRData(c *Ctx) error {
	if err := s.needHR(c); err != nil {
		return err
	}
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		HireDate  *string `json:"hire_date"`
		MentorID  *int64  `json:"mentor_id"`
		CanAuthor *bool   `json:"can_author"`
		HRAdmin   *bool   `json:"hr_admin"`
		Pollster  *bool   `json:"survey_manager"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if (in.HRAdmin != nil || in.Pollster != nil) && !c.U.IsAdmin() {
		return errForbidden
	}
	_, err = s.db.Exec(c.Context(), `UPDATE users SET hire_date = coalesce($2::date, hire_date), mentor_id = coalesce($3, mentor_id),
		can_author = coalesce($4, can_author), hr_admin = coalesce($5, hr_admin), survey_manager = coalesce($6, survey_manager) WHERE id = $1`, id, in.HireDate, in.MentorID, in.CanAuthor, in.HRAdmin, in.Pollster)
	if err != nil {
		return err
	}
	s.audit(c, "user.hr_data", "user", id, in)
	return c.JSON(200, map[string]any{"ok": true})
}

// ---------------------------------------------------------------- поздравления

// greetingsToday — именинники и годовщины на ближайшие дни (GET /api/greetings?days=7).
func (s *Server) greetingsToday(c *Ctx) error {
	days := int(c.QInt64("days"))
	if days <= 0 || days > 31 {
		days = 7
	}
	b, err := s.arr(c.Context(), `WITH x AS (
		SELECT u.id, u.full_name AS name, u.avatar, u.job_title, 'birthday' AS kind, u.birthday AS d, NULL::int AS years FROM users u WHERE u.birthday IS NOT NULL
		UNION ALL
		SELECT u.id, u.full_name, u.avatar, u.job_title, 'anniversary', u.hire_date, extract(year FROM age(current_date + $1::int, u.hire_date))::int FROM users u WHERE u.hire_date IS NOT NULL
	), y AS (
		SELECT x.*, make_date(extract(year FROM current_date)::int, extract(month FROM d)::int, least(extract(day FROM d)::int, 28)) AS this_year FROM x
		JOIN users u ON u.id = x.id AND NOT u.blocked AND u.deleted_at IS NULL)
	SELECT y.id, y.name, y.avatar, y.job_title, y.kind, y.years,
		CASE WHEN this_year < current_date THEN this_year + interval '1 year' ELSE this_year END::date AS on_date,
		(SELECT count(*) FROM greetings g WHERE g.to_id = y.id AND g.kind = y.kind AND g.year = extract(year FROM current_date)::int) AS greetings,
		EXISTS (SELECT 1 FROM greetings g WHERE g.to_id = y.id AND g.from_id = $2 AND g.kind = y.kind AND g.year = extract(year FROM current_date)::int) AS greeted
	FROM y WHERE CASE WHEN this_year < current_date THEN this_year + interval '1 year' ELSE this_year END::date BETWEEN current_date AND current_date + $1::int
		AND (y.kind = 'birthday' OR coalesce(y.years, 0) >= 1)
	ORDER BY on_date, name LIMIT 60`, days, c.U.ID)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) greetingSend(c *Ctx) error {
	var in struct {
		To      int64  `json:"to_id"`
		Kind    string `json:"kind"`
		Body    string `json:"body"`
		Sticker string `json:"sticker"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Body = strings.TrimSpace(in.Body)
	if in.To == c.U.ID || in.Body == "" || len([]rune(in.Body)) > 500 || !contains([]string{"birthday", "anniversary", "other"}, in.Kind) {
		return badReq("Проверьте текст поздравления")
	}
	if in.Sticker == "" {
		in.Sticker = "🎉"
	}
	ctx := c.Context()
	var n int
	s.db.QueryRow(ctx, `SELECT count(*) FROM greetings WHERE from_id = $1 AND to_id = $2 AND kind = $3 AND year = extract(year FROM now())::int`, c.U.ID, in.To, in.Kind).Scan(&n)
	if n > 0 {
		return conflict("Вы уже поздравили этого сотрудника")
	}
	if _, err := s.db.Exec(ctx, `INSERT INTO greetings (from_id, to_id, kind, body, sticker) VALUES ($1,$2,$3,$4,$5)`, c.U.ID, in.To, in.Kind, in.Body, in.Sticker); err != nil {
		return err
	}
	s.notify(ctx, []int64{in.To}, "greeting", c.U.Name+" поздравляет вас "+in.Sticker, in.Body, "/")
	s.award(ctx, c.U.ID, "greeting", "gr:"+i64s(in.To)+":"+in.Kind+":"+time.Now().Format("2006"), nil)
	return c.JSON(200, map[string]any{"ok": true})
}

// ---------------------------------------------------------------- быстрые ссылки

func (s *Server) linksList(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT id, title, url, sort FROM quick_links WHERE user_id = $1 ORDER BY sort, id`, c.U.ID)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) linkSave(c *Ctx) error {
	var in struct {
		Title string `json:"title"`
		URL   string `json:"url"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Title, in.URL = strings.TrimSpace(in.Title), strings.TrimSpace(in.URL)
	if in.Title == "" || !linkOrPathOK(in.URL) {
		return badReq("Нужны название и адрес (любая ссылка или путь портала)")
	}
	var n int
	s.db.QueryRow(c.Context(), `SELECT count(*) FROM quick_links WHERE user_id = $1`, c.U.ID).Scan(&n)
	if n >= 30 {
		return badReq("Не более 30 быстрых ссылок")
	}
	if _, err := s.db.Exec(c.Context(), `INSERT INTO quick_links (user_id, title, url, sort) VALUES ($1,$2,$3,$4)`, c.U.ID, in.Title, in.URL, n); err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true})
}

func (s *Server) linkDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	s.db.Exec(c.Context(), `DELETE FROM quick_links WHERE id = $1 AND user_id = $2`, id, c.U.ID)
	return c.JSON(200, map[string]any{"ok": true})
}

// ---------------------------------------------------------------- главная

// homeData — «Требует внимания» и сводка для главной (GET /api/home).
func (s *Server) homeData(c *Ctx) error {
	ctx := c.Context()
	go s.gfDaily(ctx, c.U.ID)
	uid := c.U.ID
	mustRead, err := s.arr(ctx, `SELECT n.id, n.title, n.must_read_due AS due, (n.must_read_due IS NOT NULL AND n.must_read_due < current_date) AS overdue
		FROM news n WHERE n.must_read AND `+visibleNow+` AND news_targeted(n.target_depts, n.target_users, n.audience_id, $1)
		AND NOT EXISTS (SELECT 1 FROM news_acks a WHERE a.news_id = n.id AND a.user_id = $1) ORDER BY n.must_read_due NULLS LAST, n.id DESC LIMIT 5`, uid)
	if err != nil {
		return err
	}
	onb, _ := s.arr(ctx, obPlanSQL+` WHERE p.user_id = $1 AND p.status = 'active'`, uid)
	surveys, _ := s.arr(ctx, `SELECT s.id, s.title, s.ends_at FROM sv_surveys s WHERE `+svVisible+`
		AND NOT EXISTS (SELECT 1 FROM sv_participation p WHERE p.survey_id = s.id AND p.user_id = $1) ORDER BY s.ends_at NULLS LAST LIMIT 5`, uid)
	newbies, _ := s.arr(ctx, `SELECT u.id, u.full_name AS name, u.avatar, u.job_title, to_char(u.hire_date,'YYYY-MM-DD') AS hire_date, d.name AS department
		FROM users u LEFT JOIN departments d ON d.id = u.department_id WHERE NOT u.blocked AND u.deleted_at IS NULL AND u.hire_date >= current_date - 30 AND u.hire_date <= current_date
		ORDER BY u.hire_date DESC LIMIT 8`)
	qa, _ := s.arr(ctx, `SELECT id, question, answer, answered_at FROM qa_questions WHERE status = 'answered' ORDER BY answered_at DESC LIMIT 2`)
	links, _ := s.arr(ctx, `SELECT id, title, url FROM quick_links WHERE user_id = $1 ORDER BY sort, id LIMIT 12`, uid)
	var gf json.RawMessage = []byte("null")
	if s.gfEnabled(ctx) {
		gf, _ = s.one(ctx, `SELECT coalesce(g.balance,0) AS balance, coalesce(g.xp,0) AS xp, coalesce(g.streak,0) AS streak FROM (SELECT 1) x LEFT JOIN gf_users g ON g.user_id = $1`, uid)
		var lv map[string]any
		cur, _, next := levelAt(s.gfLevels(ctx), gfXP(gf))
		lv = map[string]any{"level": cur, "next": next}
		b, _ := json.Marshal(lv)
		_ = b
		gf = mergeJSON(gf, lv)
	}
	return c.JSON(200, map[string]any{"must_read": mustRead, "onboarding": onb, "surveys": surveys, "newbies": newbies, "qa": qa, "links": links, "gf": gf})
}

func gfXP(b json.RawMessage) int {
	var v struct {
		XP int `json:"xp"`
	}
	json.Unmarshal(b, &v)
	return v.XP
}

func mergeJSON(a json.RawMessage, extra map[string]any) json.RawMessage {
	m := map[string]any{}
	json.Unmarshal(a, &m)
	for k, v := range extra {
		m[k] = v
	}
	b, _ := json.Marshal(m)
	return b
}

// setPrefs — личные настройки интерфейса на сервере (PUT /api/me/prefs {key, value}): дизайн, масштаб, шрифт, меню.
// Хранятся в users.settings; ключи ограничены списком, размер значения — 4 КБ.
func (s *Server) setPrefs(c *Ctx) error {
	var in struct {
		Key   string          `json:"key"`
		Value json.RawMessage `json:"value"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if !contains([]string{"ui", "home", "layout"}, in.Key) || len(in.Value) > 8192 || !json.Valid(in.Value) {
		return badReq("Недопустимая настройка")
	}
	_, err := s.db.Exec(c.Context(), `UPDATE users SET settings = jsonb_set(coalesce(settings, '{}'::jsonb), ARRAY[$2::text], $3::jsonb, true) WHERE id = $1`, c.U.ID, in.Key, string(in.Value))
	if err != nil {
		return err
	}
	s.dropUserCache(c.Context(), c.U.ID)
	return c.JSON(200, map[string]any{"ok": true})
}
