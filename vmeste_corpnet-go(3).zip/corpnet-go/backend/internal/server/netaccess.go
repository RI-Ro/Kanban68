package server

import (
	"net"
	"net/http"
	"strings"
)

// Приложение работает без nginx: само принимает TLS, само определяет адрес клиента и само ограничивает доступ
// к служебным адресам (/internal/*, /metrics) по спискам сетей.
//
//   TRUSTED_PROXIES — сети внешних балансировщиков (необязательно). Только от них принимаются X-Forwarded-For
//                     и X-Forwarded-Proto. Пусто — заголовки игнорируются, клиент = адрес TCP-соединения.
//   INTERNAL_ALLOW  — сети, которым разрешены /internal/* и /metrics (по умолчанию loopback и частные сети).

func parseCIDRs(list []string) []*net.IPNet {
	var out []*net.IPNet
	for _, s := range list {
		s = strings.TrimSpace(s)
		if s == "" {
			continue
		}
		if !strings.Contains(s, "/") {
			if ip := net.ParseIP(s); ip != nil {
				if ip.To4() != nil {
					s += "/32"
				} else {
					s += "/128"
				}
			}
		}
		if _, n, err := net.ParseCIDR(s); err == nil {
			out = append(out, n)
		}
	}
	return out
}

func inNets(ip net.IP, nets []*net.IPNet) bool {
	for _, n := range nets {
		if n.Contains(ip) {
			return true
		}
	}
	return false
}

func remoteIP(r *http.Request) net.IP {
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		h = r.RemoteAddr
	}
	return net.ParseIP(h)
}

// fromTrustedProxy — соединение пришло от доверенного балансировщика.
func (s *Server) fromTrustedProxy(r *http.Request) bool {
	if len(s.trusted) == 0 {
		return false
	}
	ip := remoteIP(r)
	return ip != nil && inNets(ip, s.trusted)
}

// clientIP — адрес клиента. X-Forwarded-For учитывается только от доверенных прокси; идём справа налево
// и берём первый адрес, не входящий в список доверенных (подделанные слева значения игнорируются).
func (s *Server) clientIP(r *http.Request) string {
	rip := remoteIP(r)
	if s.fromTrustedProxy(r) {
		parts := strings.Split(r.Header.Get("X-Forwarded-For"), ",")
		for i := len(parts) - 1; i >= 0; i-- {
			p := strings.TrimSpace(parts[i])
			if ip := net.ParseIP(p); ip != nil && !inNets(ip, s.trusted) {
				return ip.String()
			}
		}
	}
	if rip == nil {
		return ""
	}
	return rip.String()
}

// internalAllowed — запрос идёт из внутренней сети (и не через внешний прокси).
func (s *Server) internalAllowed(r *http.Request) bool {
	if !s.fromTrustedProxy(r) && (r.Header.Get("X-Forwarded-For") != "" || r.Header.Get("Forwarded") != "" || r.Header.Get("X-Real-IP") != "") {
		return false // за чужим прокси: источник неизвестен
	}
	ip := net.ParseIP(s.clientIP(r))
	if ip == nil {
		return false
	}
	if len(s.internalNets) > 0 {
		return inNets(ip, s.internalNets)
	}
	return ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast()
}

func splitList(v string) []string {
	return strings.FieldsFunc(v, func(r rune) bool { return r == ',' || r == ' ' || r == ';' })
}

// peerAllowed — адрес соседней площадки разрешён (PEER_ALLOW). Пусто — ограничения по адресу нет, защищает токен.
func (s *Server) peerAllowed(r *http.Request) bool {
	nets := parseCIDRs(s.cfg.PeerAllow)
	if len(nets) == 0 {
		return true
	}
	ip := net.ParseIP(s.clientIP(r))
	return ip != nil && inNets(ip, nets)
}
