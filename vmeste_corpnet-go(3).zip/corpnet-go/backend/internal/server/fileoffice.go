package server

import (
	"context"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"strings"
	"time"
)

// Просмотр офисных документов (doc/docx/xls/xlsx/ppt/pptx/odt/ods/odp/rtf/csv) прямо в браузере, без скачивания.
// Сервер конвертирует файл в PDF через LibreOffice (headless) и отдаёт PDF встроенному просмотрщику; результат кэшируется
// на диске (DATA_DIR/ovc, ключ — имя файла в хранилище). Права — те же, что у скачивания.
//
//	GET /api/files/{id}/office.pdf

var (
	ovSem     = make(chan struct{}, 2) // не более двух одновременных конверсий на экземпляр
	ovExt     = map[string]bool{".doc": true, ".docx": true, ".dotx": true, ".docm": true, ".xls": true, ".xlsx": true, ".xlsm": true, ".xltx": true, ".ppt": true, ".pptx": true, ".ppsx": true, ".potx": true, ".pptm": true, ".odt": true, ".ods": true, ".odp": true, ".ott": true, ".ots": true, ".otp": true, ".rtf": true, ".csv": true}
	ovTimeout = 120 * time.Second
)

func (s *Server) registerFileOffice(m *http.ServeMux) {
	m.HandleFunc("GET /api/files/{id}/office.pdf", s.h("user", s.officePDFAPI))
}

func (s *Server) officePDFAPI(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var storage, name string
	var base, viaNews bool
	if err := s.db.QueryRow(c.Context(), `SELECT f.storage, f.name, `+fileBaseOKSQL("f")+`, `+fileViaNewsSQL("f")+`
		FROM files f WHERE f.id = $1 AND f.external_url = ''`, id, c.U.ID, c.U.Dept, c.U.IsAdmin()).Scan(&storage, &name, &base, &viaNews); err != nil {
		return errNotFound
	}
	if !base && !viaNews {
		return errForbidden
	}
	ext := strings.ToLower(filepath.Ext(name))
	if !ovExt[ext] || storage == "" || filepath.Base(storage) != storage {
		return badReq("Этот формат нельзя открыть для просмотра")
	}
	if err := s.ensureLocal(c.Context(), false, storage); err != nil {
		return err
	}
	bin, err := exec.LookPath("soffice")
	if err != nil {
		if bin, err = exec.LookPath("libreoffice"); err != nil {
			return &apiError{503, "Просмотр документов недоступен: на сервере не установлен LibreOffice"}
		}
	}
	cdir := filepath.Join(s.cfg.DataDir, "ovc")
	if err := os.MkdirAll(cdir, 0o755); err != nil {
		return err
	}
	cached := filepath.Join(cdir, storage+".pdf")
	if _, err := os.Stat(cached); err != nil {
		select {
		case ovSem <- struct{}{}:
			defer func() { <-ovSem }()
		case <-c.Context().Done():
			return c.Context().Err()
		}
		if err := s.convertOffice(c.Context(), bin, filepath.Join(s.dir(false), path.Base(storage)), ext, cached); err != nil {
			return &apiError{422, "Не удалось подготовить документ к просмотру"}
		}
	}
	f, err := os.Open(cached)
	if err != nil {
		return err
	}
	defer f.Close()
	st, _ := f.Stat()
	h := c.W.Header()
	h.Set("Content-Type", "application/pdf")
	h.Set("Cache-Control", "private, max-age=86400")
	h.Set("Content-Security-Policy", "default-src 'none'; sandbox")
	h.Set("X-Content-Type-Options", "nosniff")
	http.ServeContent(c.W, c.R, "", st.ModTime(), f)
	return nil
}

// convertOffice копирует файл во временный каталог под «правильным» расширением (LibreOffice определяет формат по нему),
// конвертирует в PDF с отдельным профилем (параллельные запуски не конфликтуют) и атомарно кладёт результат в кэш.
func (s *Server) convertOffice(ctx context.Context, bin, src, ext, dst string) error {
	tmp, err := os.MkdirTemp("", "ov")
	if err != nil {
		return err
	}
	defer os.RemoveAll(tmp)
	in := filepath.Join(tmp, "doc"+ext)
	sf, err := os.Open(src)
	if err != nil {
		return err
	}
	df, err := os.Create(in)
	if err != nil {
		sf.Close()
		return err
	}
	_, err = io.Copy(df, sf)
	sf.Close()
	df.Close()
	if err != nil {
		return err
	}
	cctx, cancel := context.WithTimeout(ctx, ovTimeout)
	defer cancel()
	cmd := exec.CommandContext(cctx, bin, "--headless", "--norestore", "--nolockcheck", "--nodefault", "--nofirststartwizard",
		"-env:UserInstallation=file://"+filepath.Join(tmp, "profile"), "--convert-to", "pdf", "--outdir", tmp, in)
	cmd.Env = append(os.Environ(), "HOME="+tmp)
	if err := cmd.Run(); err != nil {
		return err
	}
	out := filepath.Join(tmp, "doc.pdf")
	if _, err := os.Stat(out); err != nil {
		return err
	}
	part := dst + "." + randName(4)
	if err := copyFile(out, part); err != nil {
		return err
	}
	return os.Rename(part, dst)
}

func copyFile(from, to string) error {
	a, err := os.Open(from)
	if err != nil {
		return err
	}
	defer a.Close()
	b, err := os.Create(to)
	if err != nil {
		return err
	}
	if _, err := io.Copy(b, a); err != nil {
		b.Close()
		os.Remove(to)
		return err
	}
	return b.Close()
}
