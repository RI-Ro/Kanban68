package server

import "encoding/json"

// Модуль предназначен для аудиторий (таргетинг, раздел 3.2 и 14.2 ТЗ): динамические выборки сотрудников по правилам.
// Сами правила вычисляет СУБД (audience_matches), здесь — справочник и предпросмотр «сколько человек и кто».

// audiencePreview — POST /api/audiences/preview {rules}: размер аудитории и первые участники.
func (s *Server) audiencePreview(c *Ctx) error {
	if err := s.needEditor(c); err != nil {
		return err
	}
	var in struct {
		Rules json.RawMessage `json:"rules"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if len(in.Rules) == 0 {
		in.Rules = []byte(`{}`)
	}
	ctx := c.Context()
	var total int
	if err := s.db.QueryRow(ctx, `SELECT count(*) FROM users u WHERE NOT u.blocked AND u.deleted_at IS NULL AND audience_matches($1::jsonb, u.id)`, string(in.Rules)).Scan(&total); err != nil {
		return err
	}
	sample, err := s.arr(ctx, `SELECT u.id, u.full_name AS name, u.avatar, u.job_title FROM users u WHERE NOT u.blocked AND u.deleted_at IS NULL
		AND audience_matches($1::jsonb, u.id) ORDER BY u.last_name, u.first_name LIMIT 8`, string(in.Rules))
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"total": total, "sample": sample})
}

// listAudiences — справочник для выбора (GET /api/audiences): с числом участников.
func (s *Server) listAudiences(c *Ctx) error {
	if err := s.needEditor(c); err != nil {
		return err
	}
	b, err := s.arr(c.Context(), `SELECT a.id, a.name, a.description, a.rules,
		(SELECT count(*) FROM audience_users(a.id)) AS size FROM audiences a ORDER BY a.name`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}
