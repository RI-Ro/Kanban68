package server

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
)

// Модуль предназначен для дополнительных действий с сообщениями чата: закрепление и пересылка.

// pinMessage закрепляет сообщение в чате (message_id = 0 или null — открепляет). Доступно любому участнику чата.
func (s *Server) pinMessage(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		MessageID *int64 `json:"message_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	if ok, err := s.isMember(ctx, id, c.U.ID); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	if in.MessageID != nil && *in.MessageID > 0 {
		var ok bool
		if err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM messages WHERE id = $1 AND chat_id = $2 AND deleted_at IS NULL)`, *in.MessageID, id).Scan(&ok); err != nil {
			return err
		}
		if !ok {
			return badReq("Сообщение не найдено")
		}
	} else {
		in.MessageID = nil
	}
	if _, err := s.db.Exec(ctx, `UPDATE chats SET pinned_message_id = $2 WHERE id = $1`, id, in.MessageID); err != nil {
		return err
	}
	members, _ := s.chatMembers(ctx, id)
	s.hub.EmitUsers(ctx, members, "chat.pin", map[string]any{"chat_id": id, "message_id": in.MessageID})
	return c.OK()
}

// forwardMessages пересылает сообщения (text и вложения) в другие чаты, где пользователь — участник.
// Тело: {message_ids: [..], chat_ids: [..]}. Сообщения берутся из чатов, где пользователь тоже участник; опросы не пересылаются.
func (s *Server) forwardMessages(c *Ctx) error {
	var in struct {
		MessageIDs []int64 `json:"message_ids"`
		ChatIDs    []int64 `json:"chat_ids"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if len(in.MessageIDs) == 0 || len(in.MessageIDs) > 50 || len(in.ChatIDs) == 0 || len(in.ChatIDs) > 10 {
		return badReq("Выберите до 50 сообщений и до 10 чатов")
	}
	ctx := c.Context()
	for _, cid := range in.ChatIDs {
		if ok, err := s.isMember(ctx, cid, c.U.ID); err != nil {
			return err
		} else if !ok {
			return errForbidden
		}
	}
	type src struct {
		ID     int64
		Body   string
		FileID *int64
		Author string
	}
	rows, err := s.db.Query(ctx, `SELECT m.id, m.body, m.file_id, coalesce(u.full_name, '') FROM messages m
		JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = $2 AND m.id > cm.cleared_before_id
		LEFT JOIN users u ON u.id = m.user_id
		WHERE m.id = ANY($1::bigint[]) AND m.deleted_at IS NULL AND m.kind = 'text' ORDER BY m.id`, in.MessageIDs, c.U.ID)
	if err != nil {
		return err
	}
	var list []src
	for rows.Next() {
		var m src
		if err := rows.Scan(&m.ID, &m.Body, &m.FileID, &m.Author); err != nil {
			rows.Close()
			return err
		}
		list = append(list, m)
	}
	rows.Close()
	if len(list) == 0 {
		return badReq("Нечего пересылать")
	}
	if !s.rateOK(ctx, fmt.Sprintf("fwd:%d", c.U.ID), 30, time.Minute) {
		return &apiError{429, "Слишком много пересылок. Подождите немного"}
	}
	sent := 0
	for _, cid := range in.ChatIDs {
		var ids []int64
		err := s.tx(ctx, func(tx pgx.Tx) error {
			for _, m := range list {
				body := m.Body
				if m.Author != "" {
					body = "↪ " + m.Author + ":\n" + body
				}
				if len(body) > 5000 {
					body = body[:5000]
				}
				var mid int64
				if err := tx.QueryRow(ctx, `INSERT INTO messages (chat_id, user_id, body, file_id) VALUES ($1, $2, $3, $4) RETURNING id`, cid, c.U.ID, body, m.FileID).Scan(&mid); err != nil {
					return err
				}
				ids = append(ids, mid)
			}
			if _, err := tx.Exec(ctx, `UPDATE chats SET last_message_id = $2, last_message_at = now() WHERE id = $1`, cid, ids[len(ids)-1]); err != nil {
				return err
			}
			if _, err := tx.Exec(ctx, `UPDATE chat_members SET last_read_id = $3 WHERE chat_id = $1 AND user_id = $2`, cid, c.U.ID, ids[len(ids)-1]); err != nil {
				return err
			}
			_, err := tx.Exec(ctx, `UPDATE chat_members SET hidden = false WHERE chat_id = $1 AND hidden`, cid)
			return err
		})
		if err != nil {
			return err
		}
		members, _ := s.chatMembers(ctx, cid)
		for _, mid := range ids {
			if msg, err := s.one(ctx, messageSelect+` WHERE m.id = $1`, mid); err == nil {
				s.hub.EmitUsers(ctx, members, "message", map[string]any{"chat_id": cid, "message": rawJSON(msg)})
			}
		}
		sent += len(ids)
	}
	return c.JSON(200, map[string]any{"sent": sent})
}

var _ = json.Marshal
