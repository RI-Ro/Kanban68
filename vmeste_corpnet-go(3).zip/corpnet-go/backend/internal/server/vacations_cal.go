package server

import (
	"context"
	"errors"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"
)

// Календари отпусков: у каждого календаря свой круг зрителей — «вся компания» либо перечисленные сотрудники, группы и
// подразделения (таблица vac_calendar_acl). Уровни: 1 просмотр, 2 ведение записей, 3 управление (владелец/админ).
// Расчёт уровня — SQL-функция vac_cal_level (миграция 018); для календаря по умолчанию ведущие график (users.can_vacations) получают 2.

// vacCalLevel возвращает уровень доступа текущего пользователя к календарю (0 — нет доступа / не существует).
func (s *Server) vacCalLevel(ctx context.Context, c *Ctx, cid int64) (lvl int, isDefault bool, err error) {
	err = s.db.QueryRow(ctx, `SELECT vac_cal_level(c.id, $2, $3), c.is_default FROM vac_calendars c WHERE c.id = $1`,
		cid, c.U.ID, c.U.IsAdmin()).Scan(&lvl, &isDefault)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, false, nil
	}
	if err == nil && isDefault && c.canVacations() && lvl < 2 {
		lvl = 2
	}
	return
}

// vacCalendarsFor — календари, доступные пользователю, с его уровнем доступа.
func (s *Server) vacCalendarsFor(c *Ctx) ([]byte, error) {
	b, err := s.arr2(c.Context(), `SELECT * FROM (
			SELECT cal.id, cal.name, cal.description, cal.color, cal.is_default, cal.visibility, cal.owner_id, u.full_name AS owner,
				greatest(vac_cal_level(cal.id, $1, $2), CASE WHEN cal.is_default AND $3 THEN 2 ELSE 0 END) AS level
			FROM vac_calendars cal LEFT JOIN users u ON u.id = cal.owner_id) x
		WHERE x.level > 0 ORDER BY x.is_default DESC, lower(x.name), x.id`, c.U.ID, c.U.IsAdmin(), c.canVacations())
	return b, err
}

func (s *Server) listVacCalendars(c *Ctx) error {
	b, err := s.vacCalendarsFor(c)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": rawJSON(b), "can_create": c.canVacations()})
}

type vacCalIn struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	Color       string `json:"color"`
	Visibility  string `json:"visibility"`
}

func (in *vacCalIn) clean() error {
	in.Name = strings.TrimSpace(in.Name)
	in.Description = strings.TrimSpace(in.Description)
	if n := len([]rune(in.Name)); n < 1 || n > 100 {
		return badReq("Название календаря — от 1 до 100 символов")
	}
	if len([]rune(in.Description)) > 500 {
		return badReq("Слишком длинное описание")
	}
	if !hexColorRe.MatchString(in.Color) {
		in.Color = "#3b82f6"
	}
	if in.Visibility != "company" {
		in.Visibility = "restricted"
	}
	return nil
}

func (s *Server) saveVacCalendar(c *Ctx) error {
	var in vacCalIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	if err := in.clean(); err != nil {
		return err
	}
	ctx := c.Context()
	var id int64
	if c.R.PathValue("id") != "" {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		lvl, isDef, err := s.vacCalLevel(ctx, c, id)
		if err != nil {
			return err
		}
		if lvl < 3 {
			return errForbidden
		}
		vis := in.Visibility
		if isDef {
			vis = "company" // общий график руководящего состава всегда виден всем
		}
		if _, err := s.db.Exec(ctx, `UPDATE vac_calendars SET name = $2, description = $3, color = $4, visibility = $5 WHERE id = $1`,
			id, in.Name, in.Description, in.Color, vis); err != nil {
			return err
		}
	} else {
		if !c.canVacations() {
			return &apiError{403, "Создавать календари отпусков могут администраторы и сотрудники, которым поручено вести график"}
		}
		var n int
		s.db.QueryRow(ctx, `SELECT count(*) FROM vac_calendars WHERE owner_id = $1`, c.U.ID).Scan(&n)
		if n >= 50 {
			return badReq("Слишком много календарей")
		}
		if err := s.db.QueryRow(ctx, `INSERT INTO vac_calendars (name, description, color, visibility, owner_id) VALUES ($1, $2, $3, $4, $5) RETURNING id`,
			in.Name, in.Description, in.Color, in.Visibility, c.U.ID).Scan(&id); err != nil {
			return err
		}
	}
	s.audit(c, "vac_calendar.save", "vac_calendar", id, map[string]string{"name": in.Name, "visibility": in.Visibility})
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) deleteVacCalendar(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	lvl, isDef, err := s.vacCalLevel(ctx, c, id)
	if err != nil {
		return err
	}
	if lvl < 3 {
		return errForbidden
	}
	if isDef {
		return badReq("Календарь по умолчанию удалить нельзя")
	}
	if _, err := s.db.Exec(ctx, `DELETE FROM vac_calendars WHERE id = $1`, id); err != nil {
		return err
	}
	s.audit(c, "vac_calendar.delete", "vac_calendar", id, nil)
	return c.OK()
}

func (s *Server) getVacCalendarAccess(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	if lvl, _, err := s.vacCalLevel(ctx, c, id); err != nil {
		return err
	} else if lvl < 3 {
		return errForbidden
	}
	entries, err := s.arr(ctx, `SELECT a.subject_type, a.subject_id, a.level,
		CASE a.subject_type WHEN 'user' THEN (SELECT full_name FROM users WHERE id = a.subject_id)
			WHEN 'group' THEN (SELECT name FROM user_groups WHERE id = a.subject_id)
			ELSE (SELECT name FROM departments WHERE id = a.subject_id) END AS name
		FROM vac_calendar_acl a WHERE a.calendar_id = $1 ORDER BY a.subject_type, 4`, id)
	if err != nil {
		return err
	}
	var vis string
	var isDef bool
	if err := s.db.QueryRow(ctx, `SELECT visibility, is_default FROM vac_calendars WHERE id = $1`, id).Scan(&vis, &isDef); err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"visibility": vis, "is_default": isDef, "entries": rawJSON(entries)})
}

func (s *Server) putVacCalendarAccess(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Visibility string `json:"visibility"`
		Entries    []struct {
			SubjectType string `json:"subject_type"`
			SubjectID   int64  `json:"subject_id"`
			Level       int    `json:"level"`
		} `json:"entries"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	lvl, isDef, err := s.vacCalLevel(ctx, c, id)
	if err != nil {
		return err
	}
	if lvl < 3 {
		return errForbidden
	}
	if in.Visibility != "company" && !isDef {
		in.Visibility = "restricted"
	} else {
		in.Visibility = "company" // общий график руководящего состава виден всем всегда
	}
	if len(in.Entries) > 500 {
		return badReq("Слишком много получателей доступа")
	}
	types, ids, lvls := []string{}, []int64{}, []int32{}
	seen := map[string]bool{}
	for _, e := range in.Entries {
		if (e.SubjectType != "user" && e.SubjectType != "group" && e.SubjectType != "department") || e.SubjectID <= 0 || (e.Level != 1 && e.Level != 2) {
			continue
		}
		k := e.SubjectType + ":" + strconv.FormatInt(e.SubjectID, 10)
		if seen[k] {
			continue
		}
		seen[k] = true
		types, ids, lvls = append(types, e.SubjectType), append(ids, e.SubjectID), append(lvls, int32(e.Level))
	}
	var name string
	var before []int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `SELECT name FROM vac_calendars WHERE id = $1 FOR UPDATE`, id).Scan(&name); err != nil {
			return err
		}
		rows, err := tx.Query(ctx, `SELECT subject_id FROM vac_calendar_acl WHERE calendar_id = $1 AND subject_type = 'user'`, id)
		if err != nil {
			return err
		}
		for rows.Next() {
			var u int64
			if err := rows.Scan(&u); err != nil {
				rows.Close()
				return err
			}
			before = append(before, u)
		}
		rows.Close()
		if _, err := tx.Exec(ctx, `UPDATE vac_calendars SET visibility = $2 WHERE id = $1`, id, in.Visibility); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `DELETE FROM vac_calendar_acl WHERE calendar_id = $1`, id); err != nil {
			return err
		}
		// только существующие субъекты
		_, err = tx.Exec(ctx, `INSERT INTO vac_calendar_acl (calendar_id, subject_type, subject_id, level)
			SELECT $1, t.st, t.sid, t.lv FROM unnest($2::text[], $3::bigint[], $4::int[]) AS t(st, sid, lv)
			WHERE (t.st = 'user' AND EXISTS (SELECT 1 FROM users WHERE id = t.sid))
			   OR (t.st = 'group' AND EXISTS (SELECT 1 FROM user_groups WHERE id = t.sid))
			   OR (t.st = 'department' AND EXISTS (SELECT 1 FROM departments WHERE id = t.sid))`, id, types, ids, lvls)
		return err
	})
	if err != nil {
		return err
	}
	// уведомляем тех сотрудников, кому доступ открыли только что
	was := map[int64]bool{}
	for _, u := range before {
		was[u] = true
	}
	var fresh []int64
	for i, t := range types {
		if t == "user" && !was[ids[i]] && ids[i] != c.U.ID {
			fresh = append(fresh, ids[i])
		}
	}
	s.notify(ctx, fresh, "vacation", "Вам открыт календарь отпусков: "+name, c.U.Name+" поделился(ась) календарём", "/vacations?calendar="+strconv.FormatInt(id, 10))
	s.audit(c, "vac_calendar.access", "vac_calendar", id, map[string]any{"visibility": in.Visibility, "entries": len(ids)})
	return c.OK()
}
