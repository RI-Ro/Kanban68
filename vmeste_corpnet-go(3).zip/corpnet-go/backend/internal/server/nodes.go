package server

import (
	"context"
	"crypto/subtle"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/jackc/pgx/v5"
)

// Территориально распределённый портал.
//
// Модель: в реестре nodes один узел помечен мастером (is_master) — на нём PostgreSQL принимает запись, остальные узлы
// держат реплики и отдают чтение. Запросы, меняющие данные, на неглавном узле прозрачно проксируются мастеру
// (после записи ещё несколько секунд проксируются и чтения — чтобы пользователь видел своё изменение, пока реплика
// догоняет). Файлы пишутся на мастер и расходятся по узлам штатной синхронизацией (filesync.go): пиры берутся из реестра.
// Балансировку пользователей между узлами выполняет DNS, портал в ней не участвует.
//
// Состояние узлов проверяет лидер фоновых задач каждого узла (HTTP /internal/node/health) и пишет снимок в
// DATA_DIR/.cluster-state.json — его читают остальные рабочие процессы prefork и админ-панель.

type nodeInfo struct {
	ID          int64     `json:"id"`
	Code        string    `json:"code"`
	Name        string    `json:"name"`
	Region      string    `json:"region"`
	PublicURL   string    `json:"public_url"`
	InternalURL string    `json:"internal_url"`
	Priority    int       `json:"priority"`
	Enabled     bool      `json:"enabled"`
	Maintenance bool      `json:"maintenance"`
	IsMaster    bool      `json:"is_master"`
	Note        string    `json:"note"`
	CreatedAt   time.Time `json:"created_at"`
}

// nodeState — результат последней проверки узла.
type nodeState struct {
	Code      string          `json:"code"`
	OK        bool            `json:"ok"`
	DBRole    string          `json:"db_role"` // primary | replica | ""
	LagSec    float64         `json:"lag_sec"`
	LatencyMS int64           `json:"latency_ms"`
	Fails     int             `json:"fails"`
	DownSince time.Time       `json:"down_since,omitempty"`
	CheckedAt time.Time       `json:"checked_at"`
	Err       string          `json:"err,omitempty"`
	Version   string          `json:"version,omitempty"`
	Sees      map[string]bool `json:"sees,omitempty"` // как этот узел видит остальных (для кворума при автопереключении)
}

type clusterSettings struct {
	AutoFailover bool `json:"auto_failover"`
	FailAfterSec int  `json:"fail_after_sec"`
	MaxLagSec    int  `json:"max_lag_sec"`
}

type clusterView struct {
	mu       sync.RWMutex
	nodes    []nodeInfo
	loadedAt time.Time
}

var (
	clusterCache  clusterView
	wroteRecently atomic.Int64
)

const nodeTokenHeader = "X-Internal-Token"

func (s *Server) nodeCode() string { return s.cfg.NodeCode }

// loadNodes читает реестр (кэш на 3 секунды; ошибка чтения — возвращаем прежний кэш).
func (s *Server) loadNodes(ctx context.Context) []nodeInfo {
	clusterCache.mu.RLock()
	if time.Since(clusterCache.loadedAt) < 3*time.Second {
		n := clusterCache.nodes
		clusterCache.mu.RUnlock()
		return n
	}
	clusterCache.mu.RUnlock()
	if s.db == nil {
		return nil
	}
	rows, err := s.db.Query(ctx, `SELECT id, code, name, region, public_url, internal_url, priority, enabled, maintenance, is_master, note, created_at FROM nodes ORDER BY priority, code`)
	if err != nil {
		clusterCache.mu.RLock()
		defer clusterCache.mu.RUnlock()
		return clusterCache.nodes
	}
	defer rows.Close()
	var out []nodeInfo
	for rows.Next() {
		var n nodeInfo
		if rows.Scan(&n.ID, &n.Code, &n.Name, &n.Region, &n.PublicURL, &n.InternalURL, &n.Priority, &n.Enabled, &n.Maintenance, &n.IsMaster, &n.Note, &n.CreatedAt) == nil {
			out = append(out, n)
		}
	}
	clusterCache.mu.Lock()
	clusterCache.nodes, clusterCache.loadedAt = out, time.Now()
	clusterCache.mu.Unlock()
	return out
}

func (n nodeInfo) base() string {
	u := n.InternalURL
	if u == "" {
		u = n.PublicURL
	}
	return strings.TrimRight(u, "/")
}

// masterNode — текущий мастер по реестру (nil, если реестр пуст или мастер не назначен).
func (s *Server) masterNode(ctx context.Context) *nodeInfo {
	for _, n := range s.loadNodes(ctx) {
		if n.IsMaster {
			m := n
			return &m
		}
	}
	return nil
}

// isMasterNode: этот узел может писать (реестра нет — одиночная установка, всегда да).
func (s *Server) isMasterNode(ctx context.Context) bool {
	nodes := s.loadNodes(ctx)
	if len(nodes) == 0 {
		return true
	}
	m := s.masterNode(ctx)
	return m == nil || m.Code == s.nodeCode()
}

// filePeerURLs — адреса соседей для синхронизации файлов: FILE_PEERS и узлы реестра (кроме себя и выведенных на обслуживание).
func (s *Server) filePeerURLs(ctx context.Context) []string {
	seen := map[string]bool{}
	var out []string
	add := func(u string) {
		u = strings.TrimRight(u, "/")
		if u != "" && !seen[u] {
			seen[u] = true
			out = append(out, u)
		}
	}
	for _, p := range s.cfg.FilePeers {
		add(p)
	}
	for _, n := range s.loadNodes(ctx) {
		if n.Code != s.nodeCode() && n.Enabled && !n.Maintenance {
			add(n.base())
		}
	}
	return out
}

// ---------------------------------------------------------------- маршрутизация записи

// nodeRouter: на неглавном узле запросы с записью уходят мастеру.
func (s *Server) nodeRouter(next http.Handler) http.Handler {
	proxies := map[string]*httputil.ReverseProxy{}
	var pmu sync.Mutex
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		p := r.URL.Path
		if s.db == nil || strings.HasPrefix(p, "/internal/") || !(strings.HasPrefix(p, "/api/") || strings.HasPrefix(p, "/files/")) {
			next.ServeHTTP(w, r)
			return
		}
		nodes := s.loadNodes(r.Context())
		if len(nodes) == 0 || s.isMasterNode(r.Context()) {
			next.ServeHTTP(w, r)
			return
		}
		write := r.Method != http.MethodGet && r.Method != http.MethodHead && r.Method != http.MethodOptions
		if !write {
			if c, err := r.Cookie("cn_wm"); err == nil && c.Value == "1" && !strings.HasPrefix(p, "/files/") && !strings.HasPrefix(p, "/api/files/") {
				write = true // read-your-writes: реплика могла не догнать
			}
		}
		if r.Header.Get("X-Node-Hop") != "" || !write {
			next.ServeHTTP(w, r)
			return
		}
		m := s.masterNode(r.Context())
		if m == nil || m.base() == "" {
			http.Error(w, `{"error":"Мастер-узел не доступен"}`, http.StatusServiceUnavailable)
			return
		}
		pmu.Lock()
		rp := proxies[m.base()]
		if rp == nil {
			tgt, err := url.Parse(m.base())
			if err != nil {
				pmu.Unlock()
				http.Error(w, `{"error":"Некорректный адрес мастера"}`, http.StatusBadGateway)
				return
			}
			rp = httputil.NewSingleHostReverseProxy(tgt)
			orig := rp.Director
			rp.Director = func(req *http.Request) {
				host := req.Host
				orig(req)
				req.Host = host // мастер видит исходное имя сайта (cookie, CSRF, проверка Origin)
				req.Header.Set("X-Node-Hop", s.nodeCode())
			}
			rp.FlushInterval = -1
			rp.ModifyResponse = func(resp *http.Response) error { // заголовки безопасности уже выставил этот узел: не дублируем мастерские
				for k := range resp.Header {
					if k != "Set-Cookie" && k != "Content-Type" && k != "Content-Length" && k != "Content-Encoding" && k != "Location" && k != "Content-Disposition" && k != "Etag" && k != "Last-Modified" && k != "Content-Range" && k != "Accept-Ranges" && k != "Vary" {
						resp.Header.Del(k)
					}
				}
				return nil
			}
			rp.ErrorHandler = func(w http.ResponseWriter, _ *http.Request, err error) {
				s.log.Warn("node: мастер не ответил", "err", err)
				http.Error(w, `{"error":"Мастер-узел не отвечает, повторите позже"}`, http.StatusBadGateway)
			}
			proxies[m.base()] = rp
		}
		pmu.Unlock()
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			http.SetCookie(w, &http.Cookie{Name: "cn_wm", Value: "1", Path: "/", MaxAge: 6, HttpOnly: true, SameSite: http.SameSiteLaxMode})
		}
		rp.ServeHTTP(w, r)
	})
}

// ---------------------------------------------------------------- проверка узлов

func (s *Server) localDBRole(ctx context.Context) (role string, lag float64) {
	var rec bool
	if s.db.QueryRow(ctx, `SELECT pg_is_in_recovery()`).Scan(&rec) != nil {
		return "", 0
	}
	if !rec {
		return "primary", 0
	}
	var l *float64
	_ = s.db.QueryRow(ctx, `SELECT extract(epoch FROM now() - pg_last_xact_replay_timestamp())`).Scan(&l)
	if l != nil {
		lag = *l
	}
	return "replica", lag
}

func (s *Server) tokenOK(r *http.Request) bool {
	t := s.cfg.InternalToken
	return t != "" && subtle.ConstantTimeCompare([]byte(r.Header.Get(nodeTokenHeader)), []byte(t)) == 1 && s.peerAllowed(r)
}

// internalNodeHealth: GET /internal/node/health — самоотчёт узла и его взгляд на остальных.
func (s *Server) internalNodeHealth(w http.ResponseWriter, r *http.Request) {
	if !s.tokenOK(r) {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	role, lag := s.localDBRole(r.Context())
	sees := map[string]bool{}
	for _, st := range s.readClusterState() {
		sees[st.Code] = st.OK
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"code": s.nodeCode(), "db_role": role, "lag_sec": lag, "version": "1", "sees": sees, "time": time.Now().UTC()})
}

// internalNodePromote: POST /internal/node/promote — перевести локальный PostgreSQL из реплики в основной (pg_promote).
func (s *Server) internalNodePromote(w http.ResponseWriter, r *http.Request) {
	if !s.tokenOK(r) {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	if err := s.promoteLocal(r.Context()); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	if r.URL.Query().Get("set") == "1" {
		if err := s.setMasterLocal(r.Context(), s.nodeCode(), "плановое переключение: "+r.URL.Query().Get("why")); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		s.runHook(s.nodeCode(), r.URL.Query().Get("why"))
	}
	w.Write([]byte(`{"ok":true}`))
}

func (s *Server) statePath() string { return filepath.Join(s.cfg.DataDir, ".cluster-state.json") }

func (s *Server) readClusterState() map[string]nodeState {
	out := map[string]nodeState{}
	b, err := os.ReadFile(s.statePath())
	if err != nil {
		return out
	}
	var arr []nodeState
	if json.Unmarshal(b, &arr) == nil {
		for _, st := range arr {
			out[st.Code] = st
		}
	}
	return out
}

func (s *Server) writeClusterState(m map[string]nodeState) {
	arr := make([]nodeState, 0, len(m))
	for _, v := range m {
		arr = append(arr, v)
	}
	sort.Slice(arr, func(i, j int) bool { return arr[i].Code < arr[j].Code })
	b, _ := json.Marshal(arr)
	tmp := s.statePath() + ".tmp"
	if os.WriteFile(tmp, b, 0o644) == nil {
		_ = os.Rename(tmp, s.statePath())
	}
}

func (s *Server) clusterSettings(ctx context.Context) clusterSettings {
	cs := clusterSettings{FailAfterSec: 30, MaxLagSec: 60}
	var raw []byte
	if s.db.QueryRow(ctx, `SELECT value FROM app_settings WHERE key = 'cluster'`).Scan(&raw) == nil {
		_ = json.Unmarshal(raw, &cs)
	}
	if cs.FailAfterSec < 5 {
		cs.FailAfterSec = 5
	}
	if cs.MaxLagSec < 1 {
		cs.MaxLagSec = 60
	}
	return cs
}

func (s *Server) probeNode(ctx context.Context, n nodeInfo) (st nodeState, peer map[string]bool) {
	st = nodeState{Code: n.Code, CheckedAt: time.Now()}
	if n.Code == s.nodeCode() {
		st.OK = true
		st.DBRole, st.LagSec = s.localDBRole(ctx)
		st.OK = st.DBRole != ""
		if !st.OK {
			st.Err = "нет связи с локальной БД"
		}
		return
	}
	if n.base() == "" {
		st.Err = "не задан адрес"
		return
	}
	cctx, cancel := context.WithTimeout(ctx, 4*time.Second)
	defer cancel()
	req, _ := http.NewRequestWithContext(cctx, "GET", n.base()+"/internal/node/health", nil)
	req.Header.Set(nodeTokenHeader, s.cfg.InternalToken)
	t0 := time.Now()
	resp, err := http.DefaultClient.Do(req)
	st.LatencyMS = time.Since(t0).Milliseconds()
	if err != nil {
		st.Err = "нет ответа"
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		st.Err = fmt.Sprintf("HTTP %d", resp.StatusCode)
		return
	}
	var h struct {
		Code string          `json:"code"`
		Role string          `json:"db_role"`
		Lag  float64         `json:"lag_sec"`
		Ver  string          `json:"version"`
		Sees map[string]bool `json:"sees"`
	}
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<16))
	if json.Unmarshal(b, &h) != nil || h.Code != n.Code {
		st.Err = "узел представился другим кодом"
		return
	}
	st.OK, st.DBRole, st.LagSec, st.Version = h.Role != "", h.Role, h.Lag, h.Ver
	if !st.OK {
		st.Err = "БД узла недоступна"
	}
	return st, h.Sees
}

// clusterLoop — цикл проверки; запускается в процессе-лидере.
func (s *Server) clusterLoop(ctx context.Context) {
	state := s.readClusterState()
	t := time.NewTicker(5 * time.Second)
	defer t.Stop()
	for {
		nodes := s.loadNodes(ctx)
		if len(nodes) > 0 {
			peerSees := map[string]map[string]bool{}
			for _, n := range nodes {
				if !n.Enabled {
					delete(state, n.Code)
					continue
				}
				prev := state[n.Code]
				st, ps := s.probeNode(ctx, n)
				if st.OK {
					if prev.Fails >= 3 {
						s.clusterEvent(ctx, "node_up", n.Code, "узел снова доступен")
					}
					st.Fails = 0
				} else {
					st.Fails = prev.Fails + 1
					st.DownSince = prev.DownSince
					if st.DownSince.IsZero() {
						st.DownSince = time.Now()
					}
					if st.Fails == 3 {
						s.clusterEvent(ctx, "node_down", n.Code, st.Err)
					}
				}
				state[n.Code] = st
				if ps != nil {
					peerSees[n.Code] = ps
				}
			}
			me := state[s.nodeCode()]
			me.Sees = map[string]bool{}
			for c, st := range state {
				me.Sees[c] = st.OK
			}
			state[s.nodeCode()] = me
			s.writeClusterState(state)
			s.fence(ctx)
			s.maybeFailover(ctx, nodes, state, peerSees)
		}
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
	}
}

func (s *Server) clusterEvent(ctx context.Context, kind, node, details string) {
	if s.isMasterNode(ctx) {
		_, _ = s.db.Exec(ctx, `INSERT INTO cluster_events (kind, node, details) VALUES ($1, $2, $3)`, kind, node, details)
	}
	s.log.Info("cluster", "kind", kind, "node", node, "details", details)
}

// fence (включается NODE_FENCE=1; нужны права суперпользователя БД): если по реестру мастер — другой узел, а локальная БД всё ещё принимает запись (старый мастер после переключения),
// пытаемся перевести её в режим «только чтение», чтобы не получить два пишущих узла.
func (s *Server) fenceOn() bool { return os.Getenv("NODE_FENCE") == "1" }

func (s *Server) fence(ctx context.Context) {
	if !s.fenceOn() || s.isMasterNode(ctx) {
		return
	}
	if role, _ := s.localDBRole(ctx); role != "primary" {
		return
	}
	if _, err := s.db.Exec(ctx, `ALTER SYSTEM SET default_transaction_read_only = on`); err == nil {
		_, _ = s.db.Exec(ctx, `SELECT pg_reload_conf()`)
		s.log.Warn("node: БД этого узла больше не мастер — включён default_transaction_read_only")
	} else {
		s.log.Warn("node: БД этого узла принимает запись, хотя мастер — другой узел; нужно перевести её в реплику", "err", err)
	}
}

func (s *Server) promoteLocal(ctx context.Context) error {
	role, _ := s.localDBRole(ctx)
	if role == "primary" {
		_, _ = s.db.Exec(ctx, `ALTER SYSTEM RESET default_transaction_read_only`)
		_, _ = s.db.Exec(ctx, `SELECT pg_reload_conf()`)
		return nil
	}
	var ok bool
	if err := s.db.QueryRow(ctx, `SELECT pg_promote(true, 60)`).Scan(&ok); err != nil {
		return fmt.Errorf("pg_promote: %w", err)
	}
	if !ok {
		return fmt.Errorf("pg_promote не завершился за 60 с")
	}
	return nil
}

// setMasterLocal фиксирует нового мастера в реестре; выполняется на узле, чья БД уже принимает запись.
func (s *Server) setMasterLocal(ctx context.Context, code, why string) error {
	err := s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `UPDATE nodes SET is_master = false, updated_at = now() WHERE is_master AND code <> $1`, code); err != nil {
			return err
		}
		tag, err := tx.Exec(ctx, `UPDATE nodes SET is_master = true, updated_at = now() WHERE code = $1`, code)
		if err != nil {
			return err
		}
		if tag.RowsAffected() == 0 {
			return fmt.Errorf("узел %s не найден", code)
		}
		_, err = tx.Exec(ctx, `INSERT INTO cluster_events (kind, node, details) VALUES ('master_change', $1, $2)`, code, why)
		return err
	})
	clusterCache.mu.Lock()
	clusterCache.loadedAt = time.Time{}
	clusterCache.mu.Unlock()
	return err
}

// runHook выполняет внешний сценарий (NODE_SWITCH_HOOK <новый_мастер> <причина>): перенастройка остальных реплик, DNS и т.п.
func (s *Server) runHook(code, why string) {
	h := strings.TrimSpace(os.Getenv("NODE_SWITCH_HOOK"))
	if h == "" {
		return
	}
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
		defer cancel()
		out, err := exec.CommandContext(ctx, h, code, why).CombinedOutput()
		s.log.Info("node: NODE_SWITCH_HOOK", "err", err, "out", strings.TrimSpace(string(out)))
	}()
}

// maybeFailover: автоматическое переключение. Условия: включено; мастер недоступен дольше fail_after_sec с точки зрения
// этого узла и большинства включённых узлов; этот узел — лучший кандидат (приоритет, затем меньшее отставание).
func (s *Server) maybeFailover(ctx context.Context, nodes []nodeInfo, state map[string]nodeState, peerSees map[string]map[string]bool) {
	cs := s.clusterSettings(ctx)
	if !cs.AutoFailover {
		return
	}
	var master *nodeInfo
	for i := range nodes {
		if nodes[i].IsMaster {
			master = &nodes[i]
		}
	}
	if master == nil || master.Code == s.nodeCode() {
		return
	}
	ms := state[master.Code]
	if ms.OK || ms.DownSince.IsZero() || time.Since(ms.DownSince) < time.Duration(cs.FailAfterSec)*time.Second {
		return
	}
	if !failoverQuorum(nodes, master.Code, s.nodeCode(), peerSees) {
		return // нет кворума: возможно, сеть разорвана у нас
	}
	var best *nodeInfo
	for i := range nodes {
		n := nodes[i]
		st := state[n.Code]
		if !n.Enabled || n.Maintenance || n.IsMaster || !st.OK || st.LagSec > float64(cs.MaxLagSec) {
			continue
		}
		if best == nil {
			best = &nodes[i]
			continue
		}
		bs := state[best.Code]
		if n.Priority < best.Priority || (n.Priority == best.Priority && (st.LagSec < bs.LagSec || (st.LagSec == bs.LagSec && n.Code < best.Code))) {
			best = &nodes[i]
		}
	}
	if best == nil || best.Code != s.nodeCode() {
		return
	}
	s.log.Warn("cluster: автопереключение мастера", "old", master.Code, "new", s.nodeCode())
	if err := s.promoteLocal(ctx); err != nil {
		s.log.Error("cluster: promote не удался", "err", err)
		return
	}
	why := "автопереключение: мастер " + master.Code + " недоступен"
	if err := s.setMasterLocal(ctx, s.nodeCode(), why); err != nil {
		s.log.Error("cluster: не записали мастера", "err", err)
		return
	}
	s.runHook(s.nodeCode(), why)
}

// failoverQuorum: большинство включённых узлов (считая сам мастер) не видит мастера. Голос этого узла — «не вижу».
// В кластере из двух узлов кворума нет никогда (защита от split-brain) — нужен третий узел или свидетель.
func failoverQuorum(nodes []nodeInfo, master, me string, peerSees map[string]map[string]bool) bool {
	enabled, down := 0, 0
	for _, n := range nodes {
		if !n.Enabled {
			continue
		}
		enabled++
		if n.Code == me {
			down++
		} else if sees, ok := peerSees[n.Code]; ok && !sees[master] {
			down++
		}
	}
	return down*2 > enabled
}

var errNotMaster = fmt.Errorf("узел не мастер")

// electLocalLeader выбирает одного лидера среди рабочих процессов узла по файловой блокировке (работает и на реплике,
// где job_locks в БД недоступен для записи). Блокировка живёт, пока жив процесс-лидер.
func (s *Server) electLocalLeader(ctx context.Context, start func()) {
	_ = os.MkdirAll(s.cfg.DataDir, 0o755)
	f, err := os.OpenFile(filepath.Join(s.cfg.DataDir, ".node-leader.lock"), os.O_CREATE|os.O_RDWR, 0o644)
	if err != nil {
		s.log.Warn("node: нет файла блокировки лидера", "err", err)
		return
	}
	t := time.NewTicker(5 * time.Second)
	defer t.Stop()
	for {
		if syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB) == nil {
			s.log.Info("узел: этот процесс — лидер узла (проверка узлов, синхронизация файлов)", "pid", os.Getpid())
			start()
			<-ctx.Done()
			return
		}
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
	}
}
