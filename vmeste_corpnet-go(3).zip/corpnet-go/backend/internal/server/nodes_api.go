package server

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"strings"
	"time"
)

var nodeCodeRe = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{0,39}$`)

// adminCluster: GET /api/admin/cluster — реестр, состояние, настройки, журнал событий.
func (s *Server) adminCluster(c *Ctx) error {
	ctx := c.Context()
	st := s.readClusterState()
	type row struct {
		nodeInfo
		State *nodeState `json:"state,omitempty"`
		Self  bool       `json:"self"`
	}
	var list []row
	for _, n := range s.loadNodes(ctx) {
		r := row{nodeInfo: n, Self: n.Code == s.nodeCode()}
		if v, ok := st[n.Code]; ok {
			vv := v
			r.State = &vv
		}
		list = append(list, r)
	}
	events, _ := s.arr(ctx, `SELECT id, at, kind, node, details FROM cluster_events ORDER BY id DESC LIMIT 40`)
	role, lag := s.localDBRole(ctx)
	return c.JSON(200, map[string]any{
		"self": s.nodeCode(), "nodes": list, "settings": s.clusterSettings(ctx), "events": json.RawMessage(events),
		"local_db": map[string]any{"role": role, "lag_sec": lag}, "can_write": s.isMasterNode(ctx),
		"sync": map[string]any{"enabled": s.cfg.FileSync || len(s.loadNodes(ctx)) > 1, "token_set": s.cfg.InternalToken != ""},
	})
}

type nodeIn struct {
	Code        string `json:"code"`
	Name        string `json:"name"`
	Region      string `json:"region"`
	PublicURL   string `json:"public_url"`
	InternalURL string `json:"internal_url"`
	Priority    int    `json:"priority"`
	Enabled     bool   `json:"enabled"`
	Maintenance bool   `json:"maintenance"`
	Note        string `json:"note"`
}

func (in *nodeIn) check() error {
	in.Code = strings.ToLower(strings.TrimSpace(in.Code))
	in.Name = strings.TrimSpace(in.Name)
	in.PublicURL = strings.TrimRight(strings.TrimSpace(in.PublicURL), "/")
	in.InternalURL = strings.TrimRight(strings.TrimSpace(in.InternalURL), "/")
	if !nodeCodeRe.MatchString(in.Code) {
		return badReq("Код узла: латиница, цифры, . _ - (до 40 символов)")
	}
	if in.Name == "" || len([]rune(in.Name)) > 80 {
		return badReq("Название — от 1 до 80 символов")
	}
	for _, u := range []string{in.PublicURL, in.InternalURL} {
		if u != "" && !strings.HasPrefix(u, "http://") && !strings.HasPrefix(u, "https://") {
			return badReq("Адрес узла должен начинаться с http:// или https://")
		}
	}
	if in.PublicURL == "" && in.InternalURL == "" {
		return badReq("Укажите адрес узла")
	}
	if in.Priority < 1 || in.Priority > 9999 {
		in.Priority = 100
	}
	return nil
}

func (s *Server) nodesRefresh() {
	clusterCache.mu.Lock()
	clusterCache.loadedAt = time.Time{}
	clusterCache.mu.Unlock()
}

// adminNodeSave: POST /api/admin/nodes, PUT /api/admin/nodes/{id}.
func (s *Server) adminNodeSave(c *Ctx) error {
	var in nodeIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	if err := in.check(); err != nil {
		return err
	}
	ctx := c.Context()
	if idStr := c.R.PathValue("id"); idStr != "" {
		id, err := c.ID("id")
		if err != nil {
			return err
		}
		var master bool
		if s.db.QueryRow(ctx, `SELECT is_master FROM nodes WHERE id = $1`, id).Scan(&master) != nil {
			return errNotFound
		}
		if master && (!in.Enabled || in.Maintenance) {
			return badReq("Сначала назначьте мастером другой узел")
		}
		if _, err := s.db.Exec(ctx, `UPDATE nodes SET code=$2, name=$3, region=$4, public_url=$5, internal_url=$6, priority=$7, enabled=$8, maintenance=$9, note=$10, updated_at=now() WHERE id=$1`,
			id, in.Code, in.Name, in.Region, in.PublicURL, in.InternalURL, in.Priority, in.Enabled, in.Maintenance, in.Note); err != nil {
			return badReq("Не удалось сохранить: код узла уже занят?")
		}
		s.audit(c, "node.update", "node", id, in)
	} else {
		var n int
		_ = s.db.QueryRow(ctx, `SELECT count(*) FROM nodes`).Scan(&n)
		var id int64
		if err := s.db.QueryRow(ctx, `INSERT INTO nodes (code, name, region, public_url, internal_url, priority, enabled, maintenance, note, is_master) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
			in.Code, in.Name, in.Region, in.PublicURL, in.InternalURL, in.Priority, in.Enabled, in.Maintenance, in.Note, n == 0).Scan(&id); err != nil {
			return badReq("Не удалось добавить: код узла уже занят?")
		}
		s.audit(c, "node.create", "node", id, in)
	}
	s.nodesRefresh()
	return c.JSON(200, map[string]any{"ok": true})
}

// adminNodeDelete: DELETE /api/admin/nodes/{id}.
func (s *Server) adminNodeDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var master bool
	if s.db.QueryRow(c.Context(), `SELECT is_master FROM nodes WHERE id = $1`, id).Scan(&master) != nil {
		return errNotFound
	}
	if master {
		return badReq("Мастер-узел удалить нельзя: сначала назначьте другого мастера")
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM nodes WHERE id = $1`, id); err != nil {
		return err
	}
	s.audit(c, "node.delete", "node", id, nil)
	s.nodesRefresh()
	return c.JSON(200, map[string]any{"ok": true})
}

// adminClusterSettings: PUT /api/admin/cluster/settings.
func (s *Server) adminClusterSettings(c *Ctx) error {
	var in clusterSettings
	if err := c.Decode(&in); err != nil {
		return err
	}
	if in.FailAfterSec < 10 || in.FailAfterSec > 3600 {
		return badReq("Время недоступности мастера — от 10 до 3600 секунд")
	}
	if in.MaxLagSec < 1 || in.MaxLagSec > 86400 {
		return badReq("Допустимое отставание — от 1 до 86400 секунд")
	}
	b, _ := json.Marshal(in)
	if _, err := s.db.Exec(c.Context(), `INSERT INTO app_settings (key, value) VALUES ('cluster', $1::jsonb) ON CONFLICT (key) DO UPDATE SET value = $1::jsonb, updated_at = now()`, string(b)); err != nil {
		return err
	}
	s.audit(c, "cluster.settings", "settings", 0, in)
	return c.JSON(200, map[string]any{"ok": true})
}

// adminSwitchMaster: POST /api/admin/cluster/master {code, reason} — плановое переключение мастера.
// Выполняется на текущем мастере (запись проксируется ему): запрещаем запись в старой БД, просим целевой узел
// выполнить pg_promote и записать себя мастером в реестре.
func (s *Server) adminSwitchMaster(c *Ctx) error {
	var in struct {
		Code   string `json:"code"`
		Reason string `json:"reason"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	cs := s.clusterSettings(ctx)
	var target *nodeInfo
	for _, n := range s.loadNodes(ctx) {
		if n.Code == in.Code {
			nn := n
			target = &nn
		}
	}
	if target == nil {
		return errNotFound
	}
	cur := s.masterNode(ctx)
	if cur != nil && cur.Code == target.Code {
		return badReq("Этот узел уже мастер")
	}
	if !target.Enabled || target.Maintenance {
		return badReq("Узел выключен или выведен на обслуживание")
	}
	if s.cfg.InternalToken == "" {
		return badReq("Не задан INTERNAL_TOKEN: узлы не могут общаться")
	}
	st := s.readClusterState()[target.Code]
	if !st.OK {
		return badReq("Узел сейчас недоступен: " + st.Err)
	}
	if st.LagSec > float64(cs.MaxLagSec) {
		return badReq(fmt.Sprintf("Реплика отстаёт на %.0f с (допустимо %d)", st.LagSec, cs.MaxLagSec))
	}
	why := strings.TrimSpace(in.Reason)
	if why == "" {
		why = "по решению администратора"
	}
	// 1. запрет записи в старом мастере и ожидание, пока реплика дочитает журнал
	roErr := error(fmt.Errorf("NODE_FENCE выключен"))
	if !s.fenceOn() {
	} else if _, roErr = s.db.Exec(ctx, `ALTER SYSTEM SET default_transaction_read_only = on`); roErr == nil {
		_, _ = s.db.Exec(ctx, `SELECT pg_reload_conf()`)
		time.Sleep(3 * time.Second)
	}
	undo := func() {
		if roErr == nil {
			_, _ = s.db.Exec(context.Background(), `ALTER SYSTEM RESET default_transaction_read_only`)
			_, _ = s.db.Exec(context.Background(), `SELECT pg_reload_conf()`)
		}
	}
	// 2. promote на целевом узле + запись мастера в реестр
	rq, _ := http.NewRequestWithContext(ctx, "POST", target.base()+"/internal/node/promote?set=1&why="+urlQ(why), nil)
	rq.Header.Set(nodeTokenHeader, s.cfg.InternalToken)
	cl := &http.Client{Timeout: 90 * time.Second}
	resp, err := cl.Do(rq)
	if err != nil {
		undo()
		return badReq("Целевой узел не ответил: " + err.Error())
	}
	resp.Body.Close()
	if resp.StatusCode != 200 {
		undo()
		return badReq(fmt.Sprintf("Целевой узел отказал (HTTP %d): проверьте права pg_promote", resp.StatusCode))
	}
	s.nodesRefresh()
	s.audit(c, "cluster.switch", "node", target.ID, map[string]string{"to": target.Code, "why": why})
	note := ""
	if roErr != nil {
		note = "Старая БД не переведена в read-only автоматически (включите NODE_FENCE=1 и права суперпользователя БД либо сделайте это сценарием NODE_SWITCH_HOOK) — переведите её в реплику."
	}
	return c.JSON(200, map[string]any{"ok": true, "note": note})
}

func urlQ(s string) string {
	r := strings.NewReplacer(" ", "%20", "&", "%26", "?", "%3F", "#", "%23", "%", "%25")
	return r.Replace(s)
}
