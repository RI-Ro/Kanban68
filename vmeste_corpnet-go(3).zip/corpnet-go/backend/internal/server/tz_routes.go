package server

import (
	"net/http"
	"time"
)

// Модуль предназначен для регистрации маршрутов модулей ТЗ: согласование и ознакомление, аудитории, геймификация,
// адаптация, опросы, обращения, профиль и главная. Справочники администратора реализованы универсальным crud.

func (s *Server) registerTZ(m *http.ServeMux) {
	U, E, A := "user", "editor", "admin"
	_ = E
	// новости: ознакомление и согласование
	m.HandleFunc("POST /api/news/{id}/ack", s.h(U, s.ackNews))
	m.HandleFunc("GET /api/must-read", s.h(U, s.listMustRead))
	m.HandleFunc("GET /api/news/{id}/acks", s.h(E, s.newsAcks))
	m.HandleFunc("POST /api/news/{id}/acks/remind", s.h(E, s.remindNewsAcks))
	m.HandleFunc("GET /api/news-review", s.h(U, s.reviewQueue))
	m.HandleFunc("POST /api/news/{id}/submit", s.h(U, s.submitNews))
	m.HandleFunc("POST /api/news/{id}/approve", s.h(E, s.approveNews))
	m.HandleFunc("POST /api/news/{id}/reject", s.h(E, s.rejectNews))
	// аудитории
	m.HandleFunc("GET /api/audiences", s.h(U, s.listAudiences))
	m.HandleFunc("POST /api/audiences/preview", s.h(U, s.audiencePreview))
	hr := func(c *Ctx) error { return s.needHR(c) }
	crud{table: "audiences", cols: []string{"name", "description", "rules"}, order: "t.name", check: hr}.mountWrite(s, m, "audiences")
	// геймификация
	m.HandleFunc("GET /api/gf/me", s.h(U, s.gfMe))
	m.HandleFunc("GET /api/gf/leaderboard", s.h(U, s.gfLeaderboard))
	m.HandleFunc("PUT /api/gf/hidden", s.h(U, s.gfSetHidden))
	m.HandleFunc("GET /api/gf/thanks", s.h(U, s.gfThanksFeed))
	m.HandleFunc("POST /api/gf/thanks", s.h(U, s.gfThank))
	m.HandleFunc("GET /api/gf/rewards", s.h(U, s.gfRewards))
	m.HandleFunc("POST /api/gf/rewards/{id}/order", s.h(U, s.gfOrder))
	m.HandleFunc("GET /api/gf/orders", s.h(U, s.gfOrders))
	m.HandleFunc("POST /api/gf/orders/{id}/decide", s.h(U, s.gfDecide))
	m.HandleFunc("POST /api/gf/grant", s.h(U, s.gfGrant))
	m.HandleFunc("GET /api/gf/stats", s.h(U, s.gfStats))
	m.HandleFunc("PUT /api/gf/config", s.h(U, func(c *Ctx) error {
		if err := s.needHR(c); err != nil {
			return err
		}
		var in struct {
			Enabled       bool   `json:"enabled"`
			CurrencyName  string `json:"currency_name"`
			CurrencyIcon  string `json:"currency_icon"`
			Leaderboard   bool   `json:"leaderboard"`
			Style         string `json:"style"`
			ThanksPoints  int    `json:"thanks_points"`
			ThanksPerDay  int    `json:"thanks_per_day"`
			StreakEnabled bool   `json:"streak_enabled"`
		}
		if err := c.Decode(&in); err != nil {
			return err
		}
		if in.Style != "playful" {
			in.Style = "strict"
		}
		_, err := s.db.Exec(c.Context(), `UPDATE gf_config SET enabled=$1, currency_name=$2, currency_icon=$3, leaderboard=$4, style=$5, thanks_points=$6, thanks_per_day=$7, streak_enabled=$8 WHERE id=1`,
			in.Enabled, in.CurrencyName, in.CurrencyIcon, in.Leaderboard, in.Style, in.ThanksPoints, in.ThanksPerDay, in.StreakEnabled)
		if err != nil {
			return err
		}
		return c.JSON(200, map[string]any{"ok": true})
	}))
	crud{table: "gf_rules", cols: []string{"event", "title", "points", "xp", "day_limit", "total_limit", "audience_id", "starts_on", "ends_on", "active"}, order: "t.event, t.id", check: hr}.mount(s, m, "gf/rules")
	crud{table: "gf_levels", cols: []string{"xp_from", "title", "icon", "color"}, order: "t.xp_from", check: hr}.mount(s, m, "gf/levels")
	crud{table: "gf_badges", cols: []string{"title", "description", "icon", "color", "shape", "tier", "kind", "cond_event", "cond_count", "cond_xp", "cond_streak", "secret", "active"}, order: "t.id", check: hr}.mount(s, m, "gf/badges")
	crud{table: "gf_rewards", cols: []string{"title", "description", "image", "kind", "price", "stock", "per_user_limit", "audience_id", "approval", "active"}, order: "t.price, t.id", check: hr}.mount(s, m, "gf/rewards-admin")
	// адаптация
	m.HandleFunc("GET /api/onboarding/me", s.h(U, s.obMe))
	m.HandleFunc("GET /api/onboarding/team", s.h(U, s.obTeam))
	m.HandleFunc("POST /api/onboarding/items/{id}/done", s.h(U, s.obDone))
	m.HandleFunc("PUT /api/onboarding/intro", s.h(U, s.obIntro))
	m.HandleFunc("GET /api/onboarding/intros", s.h(U, s.obIntros))
	m.HandleFunc("POST /api/onboarding/assign", s.h(U, s.obStart))
	crud{table: "ob_templates", cols: []string{"name", "description", "audience_id", "auto_assign", "duration_days", "active"}, order: "t.id", check: hr}.mount(s, m, "onboarding/templates")
	crud{table: "ob_items", cols: []string{"template_id", "sort", "section", "title", "description", "link", "assignee", "due_day", "required", "auto_event"}, order: "t.sort, t.id", check: hr, where: "t.template_id = $1", whereQ: "template_id"}.mount(s, m, "onboarding/items")
	// опросы
	m.HandleFunc("GET /api/surveys", s.h(U, s.svList))
	m.HandleFunc("GET /api/surveys/{id}", s.h(U, s.svGet))
	m.HandleFunc("POST /api/surveys", s.h(U, s.svSave))
	m.HandleFunc("PUT /api/surveys/{id}", s.h(U, s.svSave))
	m.HandleFunc("POST /api/surveys/{id}/respond", s.h(U, s.svRespond))
	m.HandleFunc("GET /api/surveys/{id}/results", s.h(U, s.svResults))
	m.HandleFunc("GET /api/surveys/{id}/report", s.h(U, s.svReport))
	m.HandleFunc("POST /api/surveys/{id}/remind", s.h(U, s.svRemind))
	// «Спросите директора»
	m.HandleFunc("GET /api/qa", s.h(U, s.qaList))
	m.HandleFunc("POST /api/qa", s.h(U, s.qaAsk))
	m.HandleFunc("POST /api/qa/{id}/vote", s.h(U, s.qaVote))
	m.HandleFunc("POST /api/qa/{id}/decide", s.h(U, s.qaDecide))
	m.HandleFunc("PUT /api/qa/config", s.h(U, func(c *Ctx) error {
		if !c.U.IsAdmin() {
			return errForbidden
		}
		var in struct {
			Enabled     bool    `json:"enabled"`
			Title       string  `json:"title"`
			Responders  []int64 `json:"responder_ids"`
			Moderation  bool    `json:"moderation"`
			AllowAnonym bool    `json:"allow_anonymous"`
		}
		if err := c.Decode(&in); err != nil {
			return err
		}
		if in.Responders == nil {
			in.Responders = []int64{}
		}
		_, err := s.db.Exec(c.Context(), `UPDATE qa_config SET enabled=$1, title=$2, responder_ids=$3, moderation=$4, allow_anonymous=$5 WHERE id=1`, in.Enabled, in.Title, in.Responders, in.Moderation, in.AllowAnonym)
		if err != nil {
			return err
		}
		return c.JSON(200, map[string]any{"ok": true})
	}))
	// «Куда жаловаться»
	m.HandleFunc("GET /api/feedback/topics", s.h(U, s.fbTopics))
	m.HandleFunc("GET /api/feedback", s.h(U, s.fbMine))
	m.HandleFunc("POST /api/feedback", s.h(U, s.fbCreate))
	m.HandleFunc("GET /api/feedback/track", s.h(U, s.fbThread))
	m.HandleFunc("GET /api/feedback/{id}", s.h(U, s.fbThread))
	m.HandleFunc("POST /api/feedback/message", s.h(U, s.fbMessage))
	m.HandleFunc("PUT /api/feedback/{id}", s.h(U, s.fbEdit))
	m.HandleFunc("DELETE /api/feedback/{id}", s.h(U, s.fbDelete))
	m.HandleFunc("POST /api/feedback/{id}/status", s.h(U, s.fbStatus))
	crud{table: "fb_topics", cols: []string{"title", "description", "modes", "handler_ids", "sla_hours", "sort", "active"}, order: "t.sort, t.id", check: hr}.mount(s, m, "feedback-topics")
	// профиль, статус, поздравления, ссылки, главная
	m.HandleFunc("GET /api/profile-fields", s.h(U, s.profileFields))
	crud{table: "profile_fields", cols: []string{"key", "label", "kind", "options", "help", "required", "in_list", "filterable", "searchable", "visibility", "editable_by", "sort", "active"}, order: "t.sort, t.id", check: hr}.mount(s, m, "profile-fields-admin")
	m.HandleFunc("PUT /api/me/custom", s.h(U, s.setCustom))
	m.HandleFunc("PUT /api/me/prefs", s.h(U, s.setPrefs))
	m.HandleFunc("PUT /api/users/{id}/hr", s.h(U, s.setHRData))
	m.HandleFunc("GET /api/greetings", s.h(U, s.greetingsToday))
	m.HandleFunc("POST /api/greetings", s.h(U, s.greetingSend))
	m.HandleFunc("GET /api/quick-links", s.h(U, s.linksList))
	m.HandleFunc("POST /api/quick-links", s.h(U, s.linkSave))
	m.HandleFunc("DELETE /api/quick-links/{id}", s.h(U, s.linkDelete))
	m.HandleFunc("GET /api/home", s.h(U, s.homeData))
	m.HandleFunc("GET /api/modules", s.h(U, s.modulesList))
	m.HandleFunc("PUT /api/admin/modules/{key}", s.h(A, s.modulesSet))
	m.HandleFunc("GET /api/ui-defaults", s.h(U, s.uiDefaultsGet))
	m.HandleFunc("GET /api/site", s.h("", s.siteGet))
	m.HandleFunc("PUT /api/admin/site", s.h(A, s.siteSet))
	m.HandleFunc("PUT /api/ui-defaults", s.h(A, s.uiDefaultsSet))
	m.HandleFunc("GET /api/mail/settings", s.h(U, s.mailGet))
	m.HandleFunc("PUT /api/mail/settings", s.h(U, s.mailSave))
	m.HandleFunc("POST /api/mail/test", s.h(U, s.mailTest))
	m.HandleFunc("GET /api/mail/campaigns", s.h(U, s.campaignList))
	m.HandleFunc("POST /api/mail/campaigns", s.h(U, s.campaignSend))
	_ = time.Now
}
