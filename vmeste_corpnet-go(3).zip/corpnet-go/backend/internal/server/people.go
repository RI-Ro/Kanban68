package server

import (
	"context"
	"encoding/json"
	"fmt"
	"regexp"
	"strings"

	"github.com/jackc/pgx/v5"
)

// aclVisible builds a SQL predicate: is resource `alias` (of rtype) visible to the
// user? Parameter numbers: u = user id, d = department id, a = is-admin boolean.
func aclVisible(rtype, alias string, u, d, a int) string {
	return fmt.Sprintf(`(%[2]s.visibility = 'company' OR $%[5]d OR %[2]s.owner_id = $%[3]d OR EXISTS (
		SELECT 1 FROM acl x WHERE x.resource_type = '%[1]s' AND x.resource_id = %[2]s.id AND (
			(x.subject_type = 'user' AND x.subject_id = $%[3]d) OR (x.subject_type = 'department' AND x.subject_id = $%[4]d))))`,
		rtype, alias, u, d, a)
}

// ---------------------------------------------------------------- users

var loginRe = regexp.MustCompile(`^[a-z0-9][a-z0-9._@-]{1,63}$`)

// userSearch добавляет условия поиска сотрудников. От 3 символов — подстрока через триграммный индекс по
// search_text (ФИО, логин, почта, должность, телефоны); короче — префикс фамилии по btree-индексу.
func (s *Server) userSearch(ctx context.Context, w *whereBuilder, q string) {
	toks := searchTokens(q)
	if len(toks) == 0 {
		return
	}
	for _, t := range toks {
		if len([]rune(t)) >= 3 {
			// редкие совпадения берём целиком из триграммного индекса (см. candidates), частые — обычный обход
			if ids, ok := s.candidates(ctx, "users", `search_text LIKE $1 ESCAPE '\'`, "%"+likeEscape(t)+"%"); ok {
				w.add(`u.id = ANY(?::bigint[])`, ids)
				continue
			}
			w.add(`u.search_text LIKE ? ESCAPE '\'`, "%"+likeEscape(t)+"%")
		} else {
			w.add(`(lower(u.last_name) LIKE ? ESCAPE '\' OR u.search_text LIKE ? ESCAPE '\')`, likeEscape(t)+"%", "% "+likeEscape(t)+"%")
		}
	}
}

func (s *Server) listUsers(c *Ctx) error {
	ctx := c.Context()
	page, per, off := c.Page(50, 200)
	w := &whereBuilder{}
	w.raw("u.deleted_at IS NULL")
	admin := c.Q("all") == "1" && c.U.IsAdmin()
	if !admin {
		w.raw("NOT u.blocked")
	}
	s.userSearch(ctx, w, c.Q("q"))
	if v := c.QInt64("department"); v > 0 {
		if c.Q("direct") == "1" {
			w.add("u.department_id = ?", v)
		} else {
			w.add("u.department_id IN "+deptSubtree("?"), v)
		}
	}
	if c.Q("heads") == "1" {
		w.raw("u.is_head")
	}
	if r := c.Q("role"); admin && roleRank(r) > 0 {
		w.add("u.role = ?", r)
	}
	var total int
	if err := s.ro.QueryRow(ctx, "SELECT count(*) FROM users u WHERE "+w.String(), w.args...).Scan(&total); err != nil {
		return err
	}
	extra := ""
	if admin {
		extra = `, u.profile_source, (SELECT coalesce(json_agg(e.department_id), '[]') FROM editor_departments e WHERE e.user_id = u.id) AS editor_departments,
			(SELECT coalesce(json_agg(e.department_id), '[]') FROM learning_manager_departments e WHERE e.user_id = u.id) AS learning_departments`
	}
	n := w.n()
	items, err := s.arr2(ctx, `SELECT `+userCols+extra+userFrom+` WHERE `+w.String()+
		fmt.Sprintf(` ORDER BY `+userOrder+` LIMIT $%d OFFSET $%d`, n+1, n+2), append(w.args, per, off)...)
	if err != nil {
		return err
	}
	if page == 1 {
		s.logSearch(c, "people", c.Q("q"), total) // аналитика поиска
	}
	return c.Raw(200, []byte(fmt.Sprintf(`{"items":%s,"total":%d,"page":%d,"per":%d}`, items, total, page, per)))
}

func (s *Server) getUser(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	b, err := s.one(c.Context(), `SELECT `+userCols+userFrom+` WHERE u.id = $1 AND u.deleted_at IS NULL`, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

type userIn struct {
	profile
	Login             string   `json:"login"`
	Password          string   `json:"password"`
	DepartmentID      *int64   `json:"department_id"`
	Role              string   `json:"role"`
	IsHead            bool     `json:"is_head"`
	CanVacations      bool     `json:"can_vacations"`
	CompanyNews       bool     `json:"company_news"`
	LearningManager   *bool    `json:"learning_manager"`     // nil — не менять (LDAP и старые клиенты не затирают)
	LearningDepts     *[]int64 `json:"learning_departments"` // nil — не менять
	Blocked           *bool    `json:"blocked"`
	ProfileSource     *string  `json:"profile_source"` // ldap | local — только для LDAP-учёток
	EditorDepartments []int64  `json:"editor_departments"`
}

func (in *userIn) validate(create bool) error {
	in.trim()
	in.Login = strings.ToLower(strings.TrimSpace(in.Login))
	if !loginRe.MatchString(in.Login) {
		return badReq("Логин: 2–64 символа, латиница, цифры и . _ - @")
	}
	if err := in.profile.validate(); err != nil {
		return err
	}
	if roleRank(in.Role) == 0 {
		in.Role = "user"
	}
	if (create || in.Password != "") && len(in.Password) < 8 {
		return badReq("Пароль должен содержать не менее 8 символов")
	}
	return nil
}

func setEditorDepts(ctx context.Context, tx pgx.Tx, uid int64, role string, ids []int64) error {
	if _, err := tx.Exec(ctx, `DELETE FROM editor_departments WHERE user_id = $1`, uid); err != nil {
		return err
	}
	if role != "editor" || len(ids) == 0 {
		return nil
	}
	_, err := tx.Exec(ctx, `INSERT INTO editor_departments (user_id, department_id) SELECT $1, d.id FROM departments d WHERE d.id = ANY($2) ON CONFLICT DO NOTHING`, uid, ids)
	return err
}

func (s *Server) adminLogoutUser(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	s.killSessions(c.Context(), id)
	s.audit(c, "user.logout", "user", id, nil)
	return c.OK()
}

// ---------------------------------------------------------------- tree helpers

// moveNode переносит узел дерева (departments | directions) под нового родителя на позицию index и
// перенумеровывает sort у всех соседей (шаг 10), сохраняя порядок «индекс сортировки, затем алфавит».
func moveNode(ctx context.Context, tx pgx.Tx, table string, id int64, parent *int64, index int) error {
	rows, err := tx.Query(ctx, fmt.Sprintf(`SELECT id FROM %s WHERE parent_id IS NOT DISTINCT FROM $1::bigint AND id <> $2 ORDER BY sort, lower(name), id`, table), parent, id)
	if err != nil {
		return err
	}
	var sib []int64
	for rows.Next() {
		var x int64
		if err := rows.Scan(&x); err != nil {
			rows.Close()
			return err
		}
		sib = append(sib, x)
	}
	rows.Close()
	index = min(max(index, 0), len(sib))
	order := append(append(append([]int64{}, sib[:index]...), id), sib[index:]...)
	sorts := make([]int32, len(order))
	for i := range order {
		sorts[i] = int32((i + 1) * 10)
	}
	if _, err := tx.Exec(ctx, fmt.Sprintf(`UPDATE %s SET parent_id = $1::bigint WHERE id = $2`, table), parent, id); err != nil {
		return err
	}
	_, err = tx.Exec(ctx, fmt.Sprintf(`UPDATE %s t SET sort = x.s FROM unnest($1::bigint[], $2::int[]) AS x(id, s) WHERE t.id = x.id`, table), order, sorts)
	return err
}

func isDescendant(ctx context.Context, q interface {
	QueryRow(context.Context, string, ...any) pgx.Row
}, table string, root, node int64) (bool, error) {
	var ok bool
	err := q.QueryRow(ctx, fmt.Sprintf(`WITH RECURSIVE t AS (SELECT id FROM %s WHERE id = $1
		UNION ALL SELECT d.id FROM %s d JOIN t ON d.parent_id = t.id) SELECT EXISTS (SELECT 1 FROM t WHERE id = $2)`, table, table), root, node).Scan(&ok)
	return ok, err
}

// ---------------------------------------------------------------- departments

const deptSelect = `SELECT d.id, d.parent_id, d.name, d.image, d.head_id, d.sort,
	hu.full_name AS head,
	(SELECT count(*) FROM users u WHERE u.department_id = d.id AND NOT u.blocked) AS employees,
	(SELECT count(*) FROM departments x WHERE x.parent_id = d.id) AS children_count,
	(d.description <> '') AS has_description,
	(d.id = ANY($1::bigint[]) OR $2::boolean) AS can_manage
	FROM departments d LEFT JOIN users hu ON hu.id = d.head_id`

func (s *Server) listDepartments(c *Ctx) error {
	sc, err := s.scopeOf(c.Context(), c.U)
	if err != nil {
		return err
	}
	b, err := s.arr2(c.Context(), deptSelect+` ORDER BY d.sort, lower(d.name), d.id`, sc.IDs, sc.All)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// searchDepartments возвращает id подразделений, подходящих под запрос: по названию, описанию, руководителю и сотрудникам.
// Все слова запроса должны встретиться в совокупном тексте подразделения.
func (s *Server) searchDepartments(c *Ctx) error {
	toks := searchTokens(c.Q("q"))
	if len(toks) == 0 {
		return c.Raw(200, []byte(`[]`))
	}
	conds := make([]string, 0, len(toks))
	args := make([]any, 0, len(toks))
	for i, t := range toks {
		conds = append(conds, fmt.Sprintf(`(lower(d.name) LIKE $%[1]d ESCAPE '\' OR lower(d.description) LIKE $%[1]d ESCAPE '\'
			OR EXISTS (SELECT 1 FROM users u WHERE (u.id = d.head_id OR u.department_id = d.id) AND u.deleted_at IS NULL AND NOT u.blocked AND u.search_text LIKE $%[1]d ESCAPE '\'))`, i+1))
		args = append(args, "%"+likeEscape(t)+"%")
	}
	b, err := s.arr2(c.Context(), `SELECT d.id FROM departments d WHERE `+strings.Join(conds, " AND ")+` LIMIT 500`, args...)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) getDepartment(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	dep, err := s.one(ctx, `SELECT d.id, d.parent_id, d.name, d.description, d.image, d.head_id, d.deputy_id, du.full_name AS deputy, d.sort, hu.full_name AS head,
		(d.id = ANY($2::bigint[]) OR $3::boolean) AS can_manage,
		(SELECT count(*) FROM users u WHERE u.department_id IN `+deptSubtree("d.id")+` AND NOT u.blocked) AS employees_total
		FROM departments d LEFT JOIN users hu ON hu.id = d.head_id LEFT JOIN users du ON du.id = d.deputy_id WHERE d.id = $1`, id, sc.IDs, sc.All)
	if err != nil {
		return err
	}
	children, err := s.arr2(ctx, deptSelect+` WHERE d.parent_id = $3 ORDER BY d.sort, lower(d.name), d.id`, sc.IDs, sc.All, id)
	if err != nil {
		return err
	}
	crumbs, err := s.arr2(ctx, `WITH RECURSIVE t AS (SELECT id, parent_id, name, 0 AS depth FROM departments WHERE id = $1
		UNION ALL SELECT d.id, d.parent_id, d.name, t.depth + 1 FROM departments d JOIN t ON d.id = t.parent_id)
		SELECT id, name FROM t WHERE depth > 0 ORDER BY depth DESC`, id)
	if err != nil {
		return err
	}
	people, err := s.arr2(ctx, `SELECT `+userCols+userFrom+` WHERE u.department_id = $1 AND NOT u.blocked ORDER BY `+userOrder+` LIMIT 200`, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]json.RawMessage{"department": dep, "children": children, "employees": people, "breadcrumbs": crumbs})
}

func (s *Server) saveDepartment(c *Ctx) error {
	var in struct {
		Name        string `json:"name"`
		Description string `json:"description"`
		Image       string `json:"image"`
		ParentID    *int64 `json:"parent_id"`
		HeadID      *int64 `json:"head_id"`
		DeputyID    *int64 `json:"deputy_id"`
		Sort        int    `json:"sort"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" {
		return badReq("Укажите название")
	}
	if len(in.Name) > 200 {
		return badReq("Название слишком длинное")
	}
	if in.HeadID != nil && in.DeputyID != nil && *in.HeadID == *in.DeputyID {
		return badReq("Резервный руководитель должен отличаться от руководителя")
	}
	for _, uid := range []*int64{in.HeadID, in.DeputyID} {
		if uid == nil {
			continue
		}
		var ok bool
		if err := s.db.QueryRow(c.Context(), `SELECT EXISTS (SELECT 1 FROM users WHERE id = $1 AND deleted_at IS NULL AND NOT blocked)`, *uid).Scan(&ok); err != nil {
			return err
		}
		if !ok {
			return badReq("Руководитель или резервный руководитель не найден или заблокирован")
		}
	}
	if len(in.Description) > 100000 {
		return badReq("Описание слишком длинное")
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	var id int64
	if c.R.PathValue("id") != "" {
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if !sc.Has(id) {
			return &apiError{403, "Это подразделение вне вашей области управления"}
		}
		var oldParent *int64
		if err := s.db.QueryRow(ctx, `SELECT parent_id FROM departments WHERE id = $1`, id).Scan(&oldParent); err != nil {
			return err
		}
		if (in.ParentID == nil) != (oldParent == nil) || (in.ParentID != nil && *in.ParentID != *oldParent) { // перенос
			if in.ParentID == nil && !sc.All {
				return &apiError{403, "Корневые подразделения создаёт администратор"}
			}
			if in.ParentID != nil {
				if !sc.Has(*in.ParentID) {
					return &apiError{403, "Целевое подразделение вне вашей области управления"}
				}
				if cyc, err := isDescendant(ctx, s.db, "departments", id, *in.ParentID); err != nil {
					return err
				} else if cyc {
					return badReq("Подразделение не может входить само в себя")
				}
			}
		}
		if _, err := s.db.Exec(ctx, `UPDATE departments SET name = $2, description = $3, image = $4, parent_id = $5, head_id = $6, sort = $7, deputy_id = $8 WHERE id = $1`,
			id, in.Name, in.Description, in.Image, in.ParentID, in.HeadID, in.Sort, in.DeputyID); err != nil {
			return err
		}
		s.audit(c, "department.update", "department", id, map[string]string{"name": in.Name})
	} else {
		if in.ParentID == nil && !sc.All {
			return &apiError{403, "Корневые подразделения создаёт администратор"}
		}
		if in.ParentID != nil && !sc.Has(*in.ParentID) {
			return &apiError{403, "Родительское подразделение вне вашей области управления"}
		}
		if err := s.db.QueryRow(ctx, `INSERT INTO departments (name, description, image, parent_id, head_id, sort, deputy_id) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
			in.Name, in.Description, in.Image, in.ParentID, in.HeadID, in.Sort, in.DeputyID).Scan(&id); err != nil {
			return err
		}
		s.audit(c, "department.create", "department", id, map[string]string{"name": in.Name})
	}
	b, err := s.one(ctx, deptSelect+` WHERE d.id = $3`, sc.IDs, sc.All, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// moveDepartment — перенос мышью в дереве (drag & drop): новый родитель и позиция среди соседей.
func (s *Server) moveDepartment(c *Ctx) error { return s.moveTreeNode(c, "departments") }

func (s *Server) moveTreeNode(c *Ctx, table string) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		ParentID *int64 `json:"parent_id"`
		Index    int    `json:"index"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	var oldParent *int64
	if err := s.db.QueryRow(ctx, fmt.Sprintf(`SELECT parent_id FROM %s WHERE id = $1`, table), id).Scan(&oldParent); err != nil {
		return err
	}
	if in.ParentID != nil && *in.ParentID == id {
		return badReq("Нельзя вложить элемент в самого себя")
	}
	if in.ParentID != nil {
		if cyc, err := isDescendant(ctx, s.db, table, id, *in.ParentID); err != nil {
			return err
		} else if cyc {
			return badReq("Нельзя вложить элемент в собственный дочерний элемент")
		}
	}
	if table == "departments" {
		if !sc.Has(id) {
			return &apiError{403, "Это подразделение вне вашей области управления"}
		}
		if in.ParentID == nil && !sc.All {
			return &apiError{403, "Корневые подразделения может создавать и переносить только администратор"}
		}
		if in.ParentID != nil && !sc.Has(*in.ParentID) {
			return &apiError{403, "Целевое подразделение вне вашей области управления"}
		}
	} else {
		ok, err := s.canManageDirection(ctx, c.U, sc, id)
		if err != nil {
			return err
		}
		if !ok {
			return errForbidden
		}
		if in.ParentID == nil && !c.U.IsAdmin() {
			return &apiError{403, "Корневые направления создаёт администратор"}
		}
		if in.ParentID != nil {
			if ok, err := s.canManageDirection(ctx, c.U, sc, *in.ParentID); err != nil {
				return err
			} else if !ok {
				return &apiError{403, "Целевое направление вне вашей области управления"}
			}
		}
	}
	if err := s.tx(ctx, func(tx pgx.Tx) error { return moveNode(ctx, tx, table, id, in.ParentID, in.Index) }); err != nil {
		return err
	}
	s.bumpNews(ctx)
	s.audit(c, strings.TrimSuffix(table, "s")+".move", strings.TrimSuffix(table, "s"), id, in)
	return c.OK()
}

func (s *Server) deleteDepartment(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if !sc.Has(id) {
		return &apiError{403, "Это подразделение вне вашей области управления"}
	}
	if !sc.All {
		var parent *int64
		s.db.QueryRow(ctx, `SELECT parent_id FROM departments WHERE id = $1`, id).Scan(&parent)
		if parent == nil || !sc.Has(*parent) {
			return &apiError{403, "Удалить корень своей области может только администратор"}
		}
	}
	var emps, kids, dirs int
	if err := s.db.QueryRow(ctx, `SELECT (SELECT count(*) FROM users WHERE department_id = $1),
		(SELECT count(*) FROM departments WHERE parent_id = $1), (SELECT count(*) FROM directions WHERE department_id = $1)`, id).Scan(&emps, &kids, &dirs); err != nil {
		return err
	}
	switch {
	case emps > 0:
		return conflict(fmt.Sprintf("В подразделении есть сотрудники (%d). Переведите их в другое подразделение", emps))
	case kids > 0:
		return conflict(fmt.Sprintf("У подразделения есть дочерние подразделения (%d). Сначала удалите или перенесите их", kids))
	case dirs > 0:
		return conflict(fmt.Sprintf("К подразделению привязаны направления деятельности (%d)", dirs))
	}
	if _, err := s.db.Exec(ctx, `DELETE FROM departments WHERE id = $1`, id); err != nil {
		return err
	}
	s.audit(c, "department.delete", "department", id, nil)
	return c.OK()
}

// ---------------------------------------------------------------- directions (направления деятельности)

func (s *Server) listDirections(c *Ctx) error {
	sc, err := s.scopeOf(c.Context(), c.U)
	if err != nil {
		return err
	}
	b, err := s.arr2(c.Context(), dirTreeSQL+` SELECT d.id, d.parent_id, d.name, d.description, d.cover, d.sort, d.department_id, dp.name AS department,
		coalesce(m.ok, false) AS can_manage FROM directions d LEFT JOIN m ON m.id = d.id LEFT JOIN departments dp ON dp.id = d.department_id
		ORDER BY d.sort, lower(d.name), d.id`, sc.IDs, sc.All)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) saveDirection(c *Ctx) error {
	var in struct {
		Name         string `json:"name"`
		Description  string `json:"description"`
		Cover        string `json:"cover"`
		ParentID     *int64 `json:"parent_id"`
		DepartmentID *int64 `json:"department_id"`
		Sort         int    `json:"sort"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" {
		return badReq("Укажите название")
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if !c.U.IsAdmin() {
		if in.DepartmentID != nil && !sc.Has(*in.DepartmentID) {
			return &apiError{403, "Подразделение вне вашей области управления"}
		}
		if in.ParentID == nil && in.DepartmentID == nil {
			return &apiError{403, "Укажите подразделение, которому принадлежит направление"}
		}
		if in.ParentID != nil {
			if ok, err := s.canManageDirection(ctx, c.U, sc, *in.ParentID); err != nil {
				return err
			} else if !ok {
				return &apiError{403, "Родительское направление вне вашей области управления"}
			}
		}
	}
	var id int64
	if c.R.PathValue("id") != "" {
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if ok, err := s.canManageDirection(ctx, c.U, sc, id); err != nil {
			return err
		} else if !ok {
			return errForbidden
		}
		if in.ParentID != nil {
			if cyc, err := isDescendant(ctx, s.db, "directions", id, *in.ParentID); err != nil {
				return err
			} else if cyc {
				return badReq("Направление не может входить само в себя")
			}
		}
		if _, err := s.db.Exec(ctx, `UPDATE directions SET name = $2, description = $3, cover = $4, parent_id = $5, department_id = $6, sort = $7 WHERE id = $1`,
			id, in.Name, in.Description, in.Cover, in.ParentID, in.DepartmentID, in.Sort); err != nil {
			return err
		}
	} else if err := s.db.QueryRow(ctx, `INSERT INTO directions (name, description, cover, parent_id, department_id, sort) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
		in.Name, in.Description, in.Cover, in.ParentID, in.DepartmentID, in.Sort).Scan(&id); err != nil {
		return err
	}
	s.bumpNews(ctx)
	s.audit(c, "direction.save", "direction", id, map[string]string{"name": in.Name})
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) moveDirection(c *Ctx) error { return s.moveTreeNode(c, "directions") }

func (s *Server) deleteDirection(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if ok, err := s.canManageDirection(ctx, c.U, sc, id); err != nil {
		return err
	} else if !ok {
		return errForbidden
	}
	var kids int
	s.db.QueryRow(ctx, `SELECT count(*) FROM directions WHERE parent_id = $1`, id).Scan(&kids)
	if kids > 0 {
		return conflict(fmt.Sprintf("У направления есть вложенные направления (%d). Сначала удалите или перенесите их", kids))
	}
	if _, err := s.db.Exec(ctx, `DELETE FROM directions WHERE id = $1`, id); err != nil {
		return err
	}
	s.bumpNews(ctx)
	s.audit(c, "direction.delete", "direction", id, nil)
	return c.OK()
}

// treeCheck — проверка целостности оргструктуры (подразделения): циклы, «висячие» родители, одинаковые названия у соседей,
// руководители вне подразделения/заблокированные, резервный руководитель совпадает с руководителем, слишком глубокая вложенность.
// Только для администратора. Возвращает список замечаний {level, node_id, node, text}.
func (s *Server) treeCheck(c *Ctx) error {
	if !c.U.IsAdmin() {
		return errForbidden
	}
	ctx := c.Context()
	b, err := s.arr2(ctx, `
	WITH RECURSIVE t AS (
		SELECT id, parent_id, name, 1 AS depth, ARRAY[id] AS path FROM departments WHERE parent_id IS NULL
		UNION ALL
		SELECT d.id, d.parent_id, d.name, t.depth + 1, t.path || d.id FROM departments d JOIN t ON d.parent_id = t.id WHERE NOT d.id = ANY(t.path)
	), reach AS (SELECT id FROM t)
	SELECT 'error' AS level, d.id AS node_id, d.name AS node, 'Подразделение недостижимо от корня (цикл или разрыв в дереве)' AS text
		FROM departments d WHERE d.id NOT IN (SELECT id FROM reach)
	UNION ALL
	SELECT 'warn', t.id, t.name, 'Вложенность глубже 8 уровней (' || t.depth || ')' FROM t WHERE t.depth > 8
	UNION ALL
	SELECT 'warn', d.id, d.name, 'Есть подразделение с таким же названием на том же уровне'
		FROM departments d WHERE EXISTS (SELECT 1 FROM departments o WHERE o.id <> d.id AND o.parent_id IS NOT DISTINCT FROM d.parent_id AND lower(o.name) = lower(d.name))
	UNION ALL
	SELECT 'warn', d.id, d.name, 'Руководитель «' || u.full_name || '» заблокирован или удалён'
		FROM departments d JOIN users u ON u.id = d.head_id WHERE u.blocked OR u.deleted_at IS NOT NULL
	UNION ALL
	SELECT 'info', d.id, d.name, 'Руководитель «' || u.full_name || '» числится в другом подразделении'
		FROM departments d JOIN users u ON u.id = d.head_id WHERE u.department_id IS DISTINCT FROM d.id AND u.deleted_at IS NULL
	UNION ALL
	SELECT 'warn', d.id, d.name, 'Резервный руководитель «' || u.full_name || '» заблокирован или удалён'
		FROM departments d JOIN users u ON u.id = d.deputy_id WHERE u.blocked OR u.deleted_at IS NOT NULL
	UNION ALL
	SELECT 'error', d.id, d.name, 'Резервный руководитель совпадает с руководителем' FROM departments d WHERE d.deputy_id IS NOT NULL AND d.deputy_id = d.head_id
	UNION ALL
	SELECT 'info', d.id, d.name, 'Нет руководителя' FROM departments d WHERE d.head_id IS NULL
	UNION ALL
	SELECT 'info', d.id, d.name, 'Пустое подразделение: нет сотрудников и вложенных подразделений'
		FROM departments d WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.department_id = d.id AND u.deleted_at IS NULL)
			AND NOT EXISTS (SELECT 1 FROM departments k WHERE k.parent_id = d.id)
	UNION ALL
	SELECT 'error', u.id, u.full_name, 'Сотрудник привязан к несуществующему подразделению'
		FROM users u WHERE u.department_id IS NOT NULL AND u.deleted_at IS NULL AND NOT EXISTS (SELECT 1 FROM departments d WHERE d.id = u.department_id)
	ORDER BY 1, 4, 3`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}
