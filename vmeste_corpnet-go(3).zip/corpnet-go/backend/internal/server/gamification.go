package server

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// Модуль предназначен для геймификации (раздел 10 ТЗ): баллы и опыт по правилам администратора, уровни, достижения,
// серии, рейтинги, благодарности и магазин наград. Начисляет только award(): все лимиты и защита от накрутки — в нём.

type gfLevel struct {
	Title string `json:"title"`
	Icon  string `json:"icon"`
	Color string `json:"color"`
	From  int    `json:"xp_from"`
}

// gfLevels — уровни по возрастанию опыта.
func (s *Server) gfLevels(ctx context.Context) []gfLevel {
	rows, err := s.db.Query(ctx, `SELECT title, icon, color, xp_from FROM gf_levels ORDER BY xp_from`)
	if err != nil {
		return nil
	}
	defer rows.Close()
	var out []gfLevel
	for rows.Next() {
		var l gfLevel
		if rows.Scan(&l.Title, &l.Icon, &l.Color, &l.From) == nil {
			out = append(out, l)
		}
	}
	return out
}

func levelAt(ls []gfLevel, xp int) (cur gfLevel, idx int, next *gfLevel) {
	for i, l := range ls {
		if xp >= l.From {
			cur, idx = l, i
		}
	}
	if idx+1 < len(ls) {
		n := ls[idx+1]
		next = &n
	}
	return
}

func (s *Server) gfEnabled(ctx context.Context) bool {
	var on bool
	if s.db.QueryRow(ctx, `SELECT enabled FROM gf_config WHERE id = 1`).Scan(&on) != nil {
		return false
	}
	return on
}

// award начисляет баллы по всем действующим правилам события. ref делает начисление однократным для объекта
// (например, "course:12"); пустой ref — начисление на каждое действие в пределах суточного лимита правила.
func (s *Server) award(ctx context.Context, uid int64, event, ref string, by *int64) {
	if uid == 0 || !s.gfEnabled(ctx) {
		return
	}
	ctx = context.WithoutCancel(ctx)
	var gained, xpGained int
	var titles []string
	var before int
	err := s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `INSERT INTO gf_users (user_id) VALUES ($1) ON CONFLICT DO NOTHING`, uid); err != nil {
			return err
		}
		if err := tx.QueryRow(ctx, `SELECT xp FROM gf_users WHERE user_id = $1 FOR UPDATE`, uid).Scan(&before); err != nil {
			return err
		}
		rows, err := tx.Query(ctx, `SELECT r.id, r.title, r.points, r.xp, r.day_limit, r.total_limit,
				(SELECT count(*) FROM gf_ledger l WHERE l.user_id = $2 AND l.rule_id = r.id AND l.created_at >= current_date) AS today,
				(SELECT count(*) FROM gf_ledger l WHERE l.user_id = $2 AND l.rule_id = r.id) AS total
			FROM gf_rules r WHERE r.event = $1 AND r.active AND (r.starts_on IS NULL OR r.starts_on <= current_date)
			AND (r.ends_on IS NULL OR r.ends_on >= current_date) AND audience_has(r.audience_id, $2)`, event, uid)
		if err != nil {
			return err
		}
		type rule struct {
			id                       int
			title                    string
			pts, xp, dl, tl, td, tot int
		}
		var rs []rule
		for rows.Next() {
			var r rule
			if err := rows.Scan(&r.id, &r.title, &r.pts, &r.xp, &r.dl, &r.tl, &r.td, &r.tot); err != nil {
				rows.Close()
				return err
			}
			rs = append(rs, r)
		}
		rows.Close()
		for _, r := range rs {
			if (r.dl > 0 && r.td >= r.dl) || (r.tl > 0 && r.tot >= r.tl) || (r.pts == 0 && r.xp == 0) {
				continue
			}
			tag, err := tx.Exec(ctx, `INSERT INTO gf_ledger (user_id, rule_id, event, ref, points, xp, reason, created_by)
				VALUES ($1, $2, $3, $4, $5, $6, $7, $8) ON CONFLICT DO NOTHING`, uid, r.id, event, ref, r.pts, r.xp, r.title, by)
			if err != nil {
				return err
			}
			if tag.RowsAffected() > 0 {
				gained += r.pts
				xpGained += r.xp
				titles = append(titles, r.title)
			}
		}
		if gained+xpGained == 0 {
			return nil
		}
		_, err = tx.Exec(ctx, `UPDATE gf_users SET balance = balance + $2, xp = xp + $3 WHERE user_id = $1`, uid, gained, xpGained)
		return err
	})
	if err != nil {
		s.log.Warn("gamification award", "event", event, "err", err)
		return
	}
	if gained+xpGained == 0 {
		return
	}
	ls := s.gfLevels(ctx)
	_, i0, _ := levelAt(ls, before)
	cur, i1, _ := levelAt(ls, before+xpGained)
	newBadges := s.gfCheckBadges(ctx, uid)
	switch {
	case i1 > i0:
		s.notify(ctx, []int64{uid}, "gamification", "Новый уровень: "+cur.Title, fmt.Sprintf("+%d опыта", xpGained), "/rewards")
	case len(newBadges) > 0:
		s.notify(ctx, []int64{uid}, "gamification", "Новое достижение: "+strings.Join(newBadges, ", "), "", "/rewards")
	case gained >= 10:
		s.notify(ctx, []int64{uid}, "gamification", fmt.Sprintf("+%d баллов: %s", gained, strings.Join(titles, ", ")), "", "/rewards")
	}
}

// gfCheckBadges выдаёт автоматические достижения, условия которых выполнены; возвращает названия новых.
func (s *Server) gfCheckBadges(ctx context.Context, uid int64) []string {
	rows, err := s.db.Query(ctx, `INSERT INTO gf_user_badges (user_id, badge_id)
		SELECT $1, b.id FROM gf_badges b, gf_users g WHERE g.user_id = $1 AND b.active AND b.kind = 'auto'
		  AND (b.cond_event <> '' OR b.cond_xp > 0 OR b.cond_streak > 0)
		  AND (b.cond_event = '' OR (SELECT count(*) FROM gf_ledger l WHERE l.user_id = $1 AND l.event = b.cond_event) >= b.cond_count)
		  AND (b.cond_xp = 0 OR g.xp >= b.cond_xp) AND (b.cond_streak = 0 OR g.best_streak >= b.cond_streak)
		ON CONFLICT DO NOTHING RETURNING badge_id`, uid)
	if err != nil {
		return nil
	}
	var ids []int
	for rows.Next() {
		var id int
		if rows.Scan(&id) == nil {
			ids = append(ids, id)
		}
	}
	rows.Close()
	var names []string
	if len(ids) > 0 {
		r2, err := s.db.Query(ctx, `SELECT title FROM gf_badges WHERE id = ANY($1)`, ids)
		if err == nil {
			for r2.Next() {
				var t string
				if r2.Scan(&t) == nil {
					names = append(names, t)
				}
			}
			r2.Close()
		}
	}
	return names
}

// gfDaily — раз в сутки на пользователя: серия дней и «заполненный профиль» (вызывается при входе в портал).
func (s *Server) gfDaily(ctx context.Context, uid int64) {
	day := time.Now().Format("2006-01-02")
	if !s.rdb.SetNX(ctx, "gf:daily:"+strconv.FormatInt(uid, 10)+":"+day, 1, 30*time.Hour).Val() || !s.gfEnabled(ctx) {
		return
	}
	var streak int
	err := s.db.QueryRow(ctx, `INSERT INTO gf_users (user_id, streak, best_streak, last_active) VALUES ($1, 1, 1, current_date)
		ON CONFLICT (user_id) DO UPDATE SET
			streak = CASE WHEN gf_users.last_active = current_date THEN gf_users.streak
			              WHEN gf_users.last_active = current_date - 1 THEN gf_users.streak + 1 ELSE 1 END,
			best_streak = greatest(gf_users.best_streak, CASE WHEN gf_users.last_active = current_date THEN gf_users.streak
			              WHEN gf_users.last_active = current_date - 1 THEN gf_users.streak + 1 ELSE 1 END),
			last_active = current_date RETURNING streak`, uid).Scan(&streak)
	if err == nil && streak > 0 && streak%5 == 0 {
		s.award(ctx, uid, "login_streak", "streak:"+day, nil)
	}
	var filled bool
	if s.db.QueryRow(ctx, `SELECT avatar <> '' AND phone1 <> '' AND birthday IS NOT NULL AND job_title <> '' FROM users WHERE id = $1`, uid).Scan(&filled) == nil && filled {
		s.award(ctx, uid, "profile_fill", "profile", nil)
	}
	s.gfCheckBadges(ctx, uid)
}

// ---------------------------------------------------------------- API сотрудника

func (s *Server) gfConfig(ctx context.Context) (json.RawMessage, error) {
	return s.one(ctx, `SELECT enabled, currency_name, currency_icon, leaderboard, style, thanks_points, thanks_per_day, streak_enabled FROM gf_config WHERE id = 1`)
}

// gfMe — всё о моём прогрессе (GET /api/gf/me).
func (s *Server) gfMe(c *Ctx) error {
	ctx := c.Context()
	cfg, err := s.gfConfig(ctx)
	if err != nil {
		return err
	}
	uid := c.U.ID
	if q := c.QInt64("user"); q > 0 && q != uid {
		uid = q
	}
	var balance, xp, streak, best int
	var hidden bool
	err = s.db.QueryRow(ctx, `SELECT balance, xp, streak, best_streak, hidden FROM gf_users WHERE user_id = $1`, uid).Scan(&balance, &xp, &streak, &best, &hidden)
	if err != nil && err != pgx.ErrNoRows {
		return err
	}
	ls := s.gfLevels(ctx)
	cur, idx, next := levelAt(ls, xp)
	pct := 100
	if next != nil {
		pct = (xp - cur.From) * 100 / max(next.From-cur.From, 1)
	}
	badges, err := s.arr(ctx, `SELECT b.id, b.title, b.description, b.icon, b.color, b.shape, b.tier, b.secret, ub.awarded_at, ub.note,
			(ub.user_id IS NOT NULL) AS earned
		FROM gf_badges b LEFT JOIN gf_user_badges ub ON ub.badge_id = b.id AND ub.user_id = $1
		WHERE b.active AND (ub.user_id IS NOT NULL OR (NOT b.secret AND $1 = $2)) ORDER BY (ub.user_id IS NULL), b.tier DESC, b.id`, uid, c.U.ID)
	if err != nil {
		return err
	}
	var ledger json.RawMessage = []byte("[]")
	var orders json.RawMessage = []byte("[]")
	if uid == c.U.ID {
		if ledger, err = s.arr(ctx, `SELECT id, event, reason, points, xp, created_at FROM gf_ledger WHERE user_id = $1 ORDER BY id DESC LIMIT 30`, uid); err != nil {
			return err
		}
		if orders, err = s.arr(ctx, `SELECT o.id, o.status, o.price, o.created_at, o.comment, r.title FROM gf_orders o JOIN gf_rewards r ON r.id = o.reward_id
			WHERE o.user_id = $1 ORDER BY o.id DESC LIMIT 20`, uid); err != nil {
			return err
		}
	}
	var rank, total int
	s.db.QueryRow(ctx, `SELECT (SELECT count(*) + 1 FROM gf_users g JOIN users u ON u.id = g.user_id WHERE NOT u.blocked AND NOT g.hidden AND g.xp > $2), (SELECT count(*) FROM gf_users g WHERE NOT g.hidden)`, uid, xp).Scan(&rank, &total)
	var thanksLeft int
	s.db.QueryRow(ctx, `SELECT greatest(0, (SELECT thanks_per_day FROM gf_config WHERE id = 1) - count(*)) FROM gf_thanks WHERE from_id = $1 AND created_at >= current_date`, c.U.ID).Scan(&thanksLeft)
	var rules json.RawMessage
	if rules, err = s.arr(ctx, `SELECT id, event, title, points, xp, day_limit FROM gf_rules WHERE active AND (audience_id IS NULL OR audience_has(audience_id, $1)) ORDER BY points DESC, id`, c.U.ID); err != nil {
		return err
	}
	if hidden && uid != c.U.ID {
		rank = 0
	}
	return c.JSON(200, map[string]any{"config": cfg, "balance": balance, "xp": xp, "streak": streak, "best_streak": best, "hidden": hidden,
		"level": cur, "level_index": idx, "next_level": next, "percent": pct, "levels": ls, "badges": badges, "ledger": ledger, "orders": orders,
		"rank": rank, "participants": total, "thanks_left": thanksLeft, "rules": rules})
}

// gfLeaderboard — рейтинг (GET /api/gf/leaderboard?scope=company|dept|teams&period=week|month|quarter|all&metric=xp|points).
// Показывает топ и окрестности пользователя, а не весь список: отстающим не нужно видеть себя в хвосте.
func (s *Server) gfLeaderboard(c *Ctx) error {
	ctx := c.Context()
	var on bool
	s.db.QueryRow(ctx, `SELECT leaderboard FROM gf_config WHERE id = 1`).Scan(&on)
	if !on {
		return c.JSON(200, map[string]any{"enabled": false, "top": []any{}, "around": []any{}})
	}
	since := map[string]string{"week": "7 days", "month": "1 month", "quarter": "3 months"}[c.Q("period")]
	col := "l.xp"
	if c.Q("metric") == "points" {
		col = "l.points"
	}
	cond := `$1::bigint > 0 AND l.points >= 0`
	if since != "" {
		cond += ` AND l.created_at >= now() - interval '` + since + `'`
	}
	if c.Q("scope") == "teams" {
		b, err := s.arr(ctx, `SELECT d.id, d.name, round(sum(x.v)::numeric / count(DISTINCT u.id), 1) AS avg, count(DISTINCT u.id) AS members, sum(x.v) AS total
			FROM departments d JOIN users u ON u.department_id = d.id AND NOT u.blocked
			JOIN gf_users g ON g.user_id = u.id AND NOT g.hidden
			LEFT JOIN LATERAL (SELECT coalesce(sum(`+col+`), 0) AS v FROM gf_ledger l WHERE l.user_id = u.id AND `+cond+`) x ON true
			GROUP BY d.id HAVING count(DISTINCT u.id) >= 3 ORDER BY avg DESC LIMIT 20`, c.U.ID)
		if err != nil {
			return err
		}
		return c.JSON(200, map[string]any{"enabled": true, "teams": b})
	}
	scope := ""
	args := []any{c.U.ID}
	if c.Q("scope") == "dept" {
		dept := c.QInt64("dept")
		if dept == 0 {
			dept = c.U.Dept
		}
		scope = ` AND u.department_id IN (SELECT id FROM dept_subtree(ARRAY[$2::int]))`
		args = append(args, dept)
	}
	q := `WITH r AS (
			SELECT u.id, u.full_name AS name, u.avatar, u.job_title, sum(` + col + `)::int AS score, g.xp,
			       dense_rank() OVER (ORDER BY sum(` + col + `) DESC) AS rank
			FROM gf_ledger l JOIN users u ON u.id = l.user_id AND NOT u.blocked AND u.deleted_at IS NULL
			JOIN gf_users g ON g.user_id = u.id AND NOT g.hidden WHERE ` + cond + scope + ` GROUP BY u.id, g.xp HAVING sum(` + col + `) > 0)
		SELECT * FROM r `
	top, err := s.arr(ctx, q+`ORDER BY rank, name LIMIT 10`, args...)
	if err != nil {
		return err
	}
	ls := s.gfLevels(ctx)
	_ = ls
	around, err := s.arr(ctx, q+`WHERE rank BETWEEN (SELECT coalesce(min(rank), 0) FROM r WHERE id = $1) - 2 AND (SELECT coalesce(min(rank), 0) FROM r WHERE id = $1) + 2
		AND EXISTS (SELECT 1 FROM r WHERE id = $1) ORDER BY rank, name`, args...)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"enabled": true, "top": top, "around": around})
}

// gfSetHidden — скрыть себя в рейтингах (PUT /api/gf/hidden).
func (s *Server) gfSetHidden(c *Ctx) error {
	var in struct {
		Hidden bool `json:"hidden"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	_, err := s.db.Exec(c.Context(), `INSERT INTO gf_users (user_id, hidden) VALUES ($1, $2) ON CONFLICT (user_id) DO UPDATE SET hidden = $2`, c.U.ID, in.Hidden)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true})
}

// ---------------------------------------------------------------- благодарности

func (s *Server) gfThanksFeed(c *Ctx) error {
	where, args := ``, []any{}
	if u := c.QInt64("user"); u > 0 {
		where, args = ` WHERE t.to_id = $1 OR t.from_id = $1`, append(args, u)
	}
	b, err := s.arr(c.Context(), `SELECT t.id, t.message, t.value_tag, t.created_at, t.from_id, f.full_name AS from_name, f.avatar AS from_avatar,
		t.to_id, r.full_name AS to_name, r.avatar AS to_avatar FROM gf_thanks t JOIN users f ON f.id = t.from_id JOIN users r ON r.id = t.to_id`+where+` ORDER BY t.id DESC LIMIT 30`, args...)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// gfThank — «Спасибо коллеге» (POST /api/gf/thanks). Защита: не себе, суточный лимит, баллы получают оба — по правилам.
func (s *Server) gfThank(c *Ctx) error {
	var in struct {
		To      int64  `json:"to_id"`
		Message string `json:"message"`
		Tag     string `json:"value_tag"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Message = strings.TrimSpace(in.Message)
	if in.To == c.U.ID {
		return badReq("Благодарность самому себе не засчитывается")
	}
	if n := len([]rune(in.Message)); n < 5 || n > 600 {
		return badReq("Напишите, за что благодарите (5–600 символов)")
	}
	ctx := c.Context()
	var exists bool
	if err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM users WHERE id = $1 AND NOT blocked AND deleted_at IS NULL)`, in.To).Scan(&exists); err != nil || !exists {
		return badReq("Сотрудник не найден")
	}
	var left int
	s.db.QueryRow(ctx, `SELECT (SELECT thanks_per_day FROM gf_config WHERE id = 1) - count(*) FROM gf_thanks WHERE from_id = $1 AND created_at >= current_date`, c.U.ID).Scan(&left)
	if left <= 0 {
		return &apiError{429, "Лимит благодарностей на сегодня исчерпан — попробуйте завтра"}
	}
	var pair int
	s.db.QueryRow(ctx, `SELECT count(*) FROM gf_thanks WHERE from_id = $1 AND to_id = $2 AND created_at >= now() - interval '7 days'`, c.U.ID, in.To).Scan(&pair)
	var id int64
	if err := s.db.QueryRow(ctx, `INSERT INTO gf_thanks (from_id, to_id, message, value_tag) VALUES ($1, $2, $3, $4) RETURNING id`, c.U.ID, in.To, in.Message, strings.TrimSpace(in.Tag)).Scan(&id); err != nil {
		return err
	}
	if pair < 2 { // взаимная «накрутка» между двумя людьми: баллы только за первые две благодарности в неделю
		s.award(ctx, in.To, "thanks_received", "thanks:"+strconv.FormatInt(id, 10), &c.U.ID)
		s.award(ctx, c.U.ID, "thanks_sent", "thanks:"+strconv.FormatInt(id, 10)+":s", nil)
	}
	s.notify(ctx, []int64{in.To}, "thanks", c.U.Name+" благодарит вас", in.Message, "/rewards")
	return c.JSON(200, map[string]any{"ok": true, "id": id})
}

// ---------------------------------------------------------------- магазин

func (s *Server) gfRewards(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT r.id, r.title, r.description, r.image, r.kind, r.price, r.stock, r.per_user_limit, r.approval,
			(SELECT count(*) FROM gf_orders o WHERE o.reward_id = r.id AND o.user_id = $1 AND o.status <> 'cancelled' AND o.status <> 'rejected') AS mine
		FROM gf_rewards r WHERE r.active AND (r.audience_id IS NULL OR audience_has(r.audience_id, $1)) ORDER BY r.price, r.id`, c.U.ID)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// gfOrder — обмен баллов на награду (POST /api/gf/rewards/{id}/order): баллы резервируются до решения.
func (s *Server) gfOrder(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var oid int64
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var price, per int
		var stock *int
		var approval bool
		if err := tx.QueryRow(ctx, `SELECT price, stock, per_user_limit, approval FROM gf_rewards
			WHERE id = $1 AND active AND (audience_id IS NULL OR audience_has(audience_id, $2)) FOR UPDATE`, id, c.U.ID).Scan(&price, &stock, &per, &approval); err != nil {
			return errNotFound
		}
		if stock != nil && *stock <= 0 {
			return conflict("Награда закончилась")
		}
		var mine int
		tx.QueryRow(ctx, `SELECT count(*) FROM gf_orders WHERE user_id = $1 AND reward_id = $2 AND status NOT IN ('cancelled','rejected')`, c.U.ID, id).Scan(&mine)
		if per > 0 && mine >= per {
			return conflict("Вы уже получили максимум этой награды")
		}
		if _, err := tx.Exec(ctx, `INSERT INTO gf_users (user_id) VALUES ($1) ON CONFLICT DO NOTHING`, c.U.ID); err != nil {
			return err
		}
		var bal int
		if err := tx.QueryRow(ctx, `SELECT balance FROM gf_users WHERE user_id = $1 FOR UPDATE`, c.U.ID).Scan(&bal); err != nil {
			return err
		}
		if bal < price {
			return conflict(fmt.Sprintf("Не хватает баллов: нужно %d, у вас %d", price, bal))
		}
		status := "pending"
		if !approval {
			status = "issued"
		}
		if err := tx.QueryRow(ctx, `INSERT INTO gf_orders (user_id, reward_id, price, status) VALUES ($1, $2, $3, $4) RETURNING id`, c.U.ID, id, price, status).Scan(&oid); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE gf_users SET balance = balance - $2 WHERE user_id = $1`, c.U.ID, price); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO gf_ledger (user_id, event, ref, points, reason) VALUES ($1, 'reward', $2, $3, 'Обмен на награду')`, c.U.ID, "order:"+strconv.FormatInt(oid, 10), -price); err != nil {
			return err
		}
		if stock != nil {
			_, err := tx.Exec(ctx, `UPDATE gf_rewards SET stock = stock - 1 WHERE id = $1`, id)
			return err
		}
		return nil
	})
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true, "id": oid})
}

// gfOrders — заказы (GET /api/gf/orders?status=): для администратора все, у сотрудника — свои.
func (s *Server) gfOrders(c *Ctx) error {
	all := s.needHR(c) == nil && c.Q("all") == "1"
	st := c.Q("status")
	b, err := s.arr(c.Context(), `SELECT o.id, o.status, o.price, o.created_at, o.comment, r.title, o.user_id, u.full_name AS user_name, u.avatar
		FROM gf_orders o JOIN gf_rewards r ON r.id = o.reward_id JOIN users u ON u.id = o.user_id
		WHERE ($1::boolean OR o.user_id = $2) AND ($3 = '' OR o.status = $3) ORDER BY o.id DESC LIMIT 200`, all, c.U.ID, st)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// gfDecide — решение по заказу (POST /api/gf/orders/{id}/decide {status, comment}); отказ возвращает баллы и остаток.
func (s *Server) gfDecide(c *Ctx) error {
	if err := s.needHR(c); err != nil {
		return err
	}
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Status  string `json:"status"`
		Comment string `json:"comment"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if in.Status != "approved" && in.Status != "issued" && in.Status != "rejected" {
		return badReq("Недопустимое решение")
	}
	ctx := c.Context()
	var uid int64
	var title string
	err = s.tx(ctx, func(tx pgx.Tx) error {
		var price, rid int
		var cur string
		if err := tx.QueryRow(ctx, `SELECT user_id, price, reward_id, status FROM gf_orders WHERE id = $1 FOR UPDATE`, id).Scan(&uid, &price, &rid, &cur); err != nil {
			return err
		}
		if cur == "rejected" || cur == "cancelled" {
			return conflict("Заказ уже закрыт")
		}
		if _, err := tx.Exec(ctx, `UPDATE gf_orders SET status = $2, comment = $3, decided_by = $4, decided_at = now() WHERE id = $1`, id, in.Status, in.Comment, c.U.ID); err != nil {
			return err
		}
		tx.QueryRow(ctx, `SELECT title FROM gf_rewards WHERE id = $1`, rid).Scan(&title)
		if in.Status == "rejected" {
			if _, err := tx.Exec(ctx, `UPDATE gf_users SET balance = balance + $2 WHERE user_id = $1`, uid, price); err != nil {
				return err
			}
			if _, err := tx.Exec(ctx, `UPDATE gf_rewards SET stock = stock + 1 WHERE id = $1 AND stock IS NOT NULL`, rid); err != nil {
				return err
			}
			_, err := tx.Exec(ctx, `INSERT INTO gf_ledger (user_id, event, ref, points, reason) VALUES ($1, 'reward_refund', $2, $3, 'Возврат баллов: заказ отклонён')`, uid, "order:"+strconv.FormatInt(id, 10)+":r", price)
			return err
		}
		return nil
	})
	if err != nil {
		return err
	}
	msg := map[string]string{"approved": "Заказ одобрен", "issued": "Награда выдана", "rejected": "Заказ отклонён, баллы возвращены"}[in.Status]
	s.notify(ctx, []int64{uid}, "gamification", msg, title, "/rewards")
	s.audit(c, "gf.order."+in.Status, "gf_order", id, nil)
	return c.JSON(200, map[string]any{"ok": true})
}

// gfGrant — ручное начисление/списание администратором с обязательным комментарием (POST /api/gf/grant).
func (s *Server) gfGrant(c *Ctx) error {
	if err := s.needHR(c); err != nil {
		return err
	}
	var in struct {
		UserID  int64  `json:"user_id"`
		Points  int    `json:"points"`
		XP      int    `json:"xp"`
		Comment string `json:"comment"`
		BadgeID int    `json:"badge_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Comment = strings.TrimSpace(in.Comment)
	if in.Comment == "" {
		return badReq("Укажите причину — запись попадёт в журнал")
	}
	ctx := c.Context()
	err := s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `INSERT INTO gf_users (user_id) VALUES ($1) ON CONFLICT DO NOTHING`, in.UserID); err != nil {
			return err
		}
		if in.Points != 0 || in.XP != 0 {
			if _, err := tx.Exec(ctx, `INSERT INTO gf_ledger (user_id, event, points, xp, reason, created_by) VALUES ($1, 'manual', $2, $3, $4, $5)`, in.UserID, in.Points, in.XP, in.Comment, c.U.ID); err != nil {
				return err
			}
			if _, err := tx.Exec(ctx, `UPDATE gf_users SET balance = greatest(0, balance + $2), xp = greatest(0, xp + $3) WHERE user_id = $1`, in.UserID, in.Points, in.XP); err != nil {
				return err
			}
		}
		if in.BadgeID > 0 {
			if _, err := tx.Exec(ctx, `INSERT INTO gf_user_badges (user_id, badge_id, awarded_by, note) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING`, in.UserID, in.BadgeID, c.U.ID, in.Comment); err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return err
	}
	s.audit(c, "gf.grant", "user", in.UserID, in)
	s.notify(ctx, []int64{in.UserID}, "gamification", "Вам начислены баллы вручную", in.Comment, "/rewards")
	return c.JSON(200, map[string]any{"ok": true})
}

// gfStats — бюджет и отчёт (GET /api/gf/stats): начислено/потрачено, доля активных, популярные награды.
func (s *Server) gfStats(c *Ctx) error {
	if err := s.needHR(c); err != nil {
		return err
	}
	ctx := c.Context()
	var earned, spent, active, users int
	s.db.QueryRow(ctx, `SELECT coalesce(sum(points) FILTER (WHERE points > 0), 0), coalesce(-sum(points) FILTER (WHERE points < 0), 0) FROM gf_ledger`).Scan(&earned, &spent)
	s.db.QueryRow(ctx, `SELECT count(DISTINCT user_id) FROM gf_ledger WHERE created_at >= now() - interval '30 days' AND points > 0`).Scan(&active)
	s.db.QueryRow(ctx, `SELECT count(*) FROM users WHERE NOT blocked AND deleted_at IS NULL`).Scan(&users)
	pop, err := s.arr(ctx, `SELECT r.title, count(*) AS orders, coalesce(sum(o.price), 0) AS points FROM gf_orders o JOIN gf_rewards r ON r.id = o.reward_id
		WHERE o.status NOT IN ('cancelled','rejected') GROUP BY r.title ORDER BY count(*) DESC LIMIT 10`)
	if err != nil {
		return err
	}
	byEvent, err := s.arr(ctx, `SELECT event, count(*) AS n, sum(points) AS points FROM gf_ledger WHERE points > 0 AND created_at >= now() - interval '30 days' GROUP BY event ORDER BY sum(points) DESC`)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"earned": earned, "spent": spent, "active_30d": active, "users": users, "popular": pop, "by_event": byEvent})
}
