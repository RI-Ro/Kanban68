package server

// Голосование по идеям: «нравится» (1), «нейтрально» (0), «не нравится» (-1). Один голос на пользователя, повторный клик снимает его.

func (s *Server) ideaVotes(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	return c.JSON(200, s.ideaVoteSummary(c, id))
}

func (s *Server) ideaVoteSummary(c *Ctx, id int64) map[string]any {
	var up, down, neutral int
	s.db.QueryRow(c.Context(), `SELECT count(*) FILTER (WHERE vote = 1), count(*) FILTER (WHERE vote = -1), count(*) FILTER (WHERE vote = 0) FROM idea_votes WHERE idea_id = $1`, id).Scan(&up, &down, &neutral)
	var mine *int
	_ = s.db.QueryRow(c.Context(), `SELECT vote FROM idea_votes WHERE idea_id = $1 AND user_id = $2`, id, c.U.ID).Scan(&mine)
	return map[string]any{"up": up, "down": down, "neutral": neutral, "mine": mine}
}

func (s *Server) ideaVote(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Vote *int `json:"vote"` // 1 / 0 / -1; null — снять голос
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	var exists bool
	if s.db.QueryRow(c.Context(), `SELECT true FROM ideas WHERE id = $1`, id).Scan(&exists) != nil {
		return errNotFound
	}
	if in.Vote == nil {
		_, err = s.db.Exec(c.Context(), `DELETE FROM idea_votes WHERE idea_id = $1 AND user_id = $2`, id, c.U.ID)
	} else {
		if *in.Vote < -1 || *in.Vote > 1 {
			return badReq("Недопустимый голос")
		}
		_, err = s.db.Exec(c.Context(), `INSERT INTO idea_votes (idea_id, user_id, vote) VALUES ($1, $2, $3) ON CONFLICT (idea_id, user_id) DO UPDATE SET vote = $3, at = now()`, id, c.U.ID, *in.Vote)
	}
	if err != nil {
		return err
	}
	return c.JSON(200, s.ideaVoteSummary(c, id))
}
