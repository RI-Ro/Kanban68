package server

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

// Модуль предназначен для чтения config.yaml: разделы server/database/storage/auth/logging/kerberos/files.
// Приоритет значений: переменная окружения > config.yaml > значение по умолчанию. Для этого каждое значение файла
// превращается в переменную окружения, если она ещё не задана (пустая переменная окружения не переопределяет файл).
// Поддерживается подмножество YAML, достаточное для конфигурации: два уровня «раздел → ключ: значение», комментарии,
// строки в кавычках, списки в [a, b] и в виде «- элемент». Внешних зависимостей нет (закрытый контур).

// configKeys связывает «раздел.ключ» файла с переменной окружения.
var configKeys = map[string]string{
	"server.addr": "HTTP_ADDR", "server.tls_cert": "TLS_CERT", "server.tls_key": "TLS_KEY", "server.http_redirect": "HTTP_REDIRECT_ADDR",
	"server.trusted_proxies": "TRUSTED_PROXIES", "server.allowed_origins": "ALLOWED_ORIGINS", "server.static_dir": "STATIC_DIR",
	"server.data_dir": "DATA_DIR", "server.max_upload_mb": "MAX_UPLOAD_MB", "server.cookie_secure": "COOKIE_SECURE",
	"server.session_ttl_hours": "SESSION_TTL_HOURS", "server.instance_id": "INSTANCE_ID", "server.dc_id": "DC_ID", "server.tz": "TZ",
	"server.prefork": "PREFORK", "server.internal_allow": "INTERNAL_ALLOW", "server.metrics_addr": "METRICS_ADDR",
	"database.url": "DATABASE_URL", "database.replica_url": "DATABASE_REPLICA_URL", "database.pool_size": "PG_POOL_MAX",
	"storage.redis_url": "REDIS_URL", "storage.kv_backend": "KV_BACKEND", "storage.session_store": "SESSION_STORE", "storage.realtime": "REALTIME_MODE",
	"auth.secret_key": "SECRET_KEY", "auth.internal_token": "INTERNAL_TOKEN",
	"logging.access_log": "ACCESS_LOG", "logging.error_log": "ERROR_LOG", "logging.console": "LOG_CONSOLE",
	"logging.slow_request_ms": "SLOW_REQUEST_MS", "logging.slow_sql_ms": "SLOW_SQL_MS",
	"kerberos.enabled": "KRB5_ENABLED", "kerberos.service_principal": "KRB5_SERVICE_PRINCIPAL", "kerberos.keytab": "KRB5_KEYTAB",
	"kerberos.realm": "KRB5_REALM", "kerberos.conf": "KRB5_CONF", "kerberos.clock_skew_sec": "KRB5_CLOCK_SKEW_SEC",
	"kerberos.user_map": "KRB5_USER_MAP", "kerberos.auto_create": "KRB5_AUTO_CREATE",
	"files.media_workers": "MEDIA_WORKERS", "files.ffmpeg": "FFMPEG_BIN", "files.peers": "FILE_PEERS", "files.sync": "FILE_SYNC",
	"mail.host": "SMTP_HOST", "mail.port": "SMTP_PORT", "mail.user": "SMTP_USER", "mail.password": "SMTP_PASSWORD", "mail.from": "SMTP_FROM",
}

// ApplyConfigFile читает файл и выставляет не заданные переменные окружения. Отсутствие файла не ошибка, если путь не был указан явно.
func ApplyConfigFile(path string, explicit bool) error {
	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) && !explicit {
			return nil
		}
		return err
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	section := ""
	var listKey string
	var list []string
	flush := func() {
		if listKey != "" {
			setEnvIfEmpty(section+"."+listKey, strings.Join(list, ","))
			listKey, list = "", nil
		}
	}
	ln := 0
	for sc.Scan() {
		ln++
		raw := sc.Text()
		line := stripComment(raw)
		if strings.TrimSpace(line) == "" {
			continue
		}
		indent := len(line) - len(strings.TrimLeft(line, " "))
		t := strings.TrimSpace(line)
		if strings.HasPrefix(t, "- ") && listKey != "" {
			list = append(list, unquote(strings.TrimSpace(t[2:])))
			continue
		}
		flush()
		k, v, ok := strings.Cut(t, ":")
		if !ok {
			return fmt.Errorf("%s:%d: ожидалось «ключ: значение»", path, ln)
		}
		k, v = strings.TrimSpace(k), strings.TrimSpace(v)
		if indent == 0 {
			if v != "" {
				return fmt.Errorf("%s:%d: раздел «%s» не должен иметь значения", path, ln, k)
			}
			section = k
			continue
		}
		switch {
		case v == "":
			listKey = k
		case strings.HasPrefix(v, "[") && strings.HasSuffix(v, "]"):
			var parts []string
			for _, p := range strings.Split(v[1:len(v)-1], ",") {
				if p = unquote(strings.TrimSpace(p)); p != "" {
					parts = append(parts, p)
				}
			}
			setEnvIfEmpty(section+"."+k, strings.Join(parts, ","))
		default:
			setEnvIfEmpty(section+"."+k, unquote(v))
		}
	}
	flush()
	return sc.Err()
}

func setEnvIfEmpty(key, val string) {
	name, ok := configKeys[key]
	if !ok {
		fmt.Fprintf(os.Stderr, "config.yaml: неизвестный параметр %q — пропущен\n", key)
		return
	}
	if os.Getenv(name) == "" { // пустая переменная окружения не переопределяет файл
		os.Setenv(name, val)
	}
}

func stripComment(s string) string {
	inQ := byte(0)
	for i := 0; i < len(s); i++ {
		c := s[i]
		switch {
		case inQ != 0:
			if c == inQ {
				inQ = 0
			}
		case c == '"' || c == '\'':
			inQ = c
		case c == '#' && (i == 0 || s[i-1] == ' '):
			return s[:i]
		}
	}
	return s
}

func unquote(v string) string {
	if len(v) >= 2 && (v[0] == '"' && v[len(v)-1] == '"' || v[0] == '\'' && v[len(v)-1] == '\'') {
		return v[1 : len(v)-1]
	}
	return v
}
