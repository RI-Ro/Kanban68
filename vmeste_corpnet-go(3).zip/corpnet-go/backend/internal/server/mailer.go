package server

import (
	"context"
	"crypto/tls"
	"encoding/base64"
	"fmt"
	"html"
	"net"
	"net/smtp"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// Модуль предназначен для email-рассылок (раздел 7 ТЗ): настройки SMTP, кампании по аудитории, очередь с ограничением
// скорости (письма в минуту), журнал доставки. Пароль SMTP хранится в БД в зашифрованном виде (SECRET_KEY).

// mailGet — настройки SMTP (GET /api/mail/settings). Пароль не возвращается.
func (s *Server) mailGet(c *Ctx) error {
	if !c.U.IsAdmin() {
		return errForbidden
	}
	b, err := s.one(c.Context(), `SELECT enabled, host, port, security, username, from_addr, from_name, per_minute, (password <> '') AS has_password FROM mail_settings WHERE id = 1`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

func (s *Server) mailSave(c *Ctx) error {
	if !c.U.IsAdmin() {
		return errForbidden
	}
	var in struct {
		Enabled   bool    `json:"enabled"`
		Host      string  `json:"host"`
		Port      int     `json:"port"`
		Security  string  `json:"security"`
		Username  string  `json:"username"`
		Password  *string `json:"password"`
		FromAddr  string  `json:"from_addr"`
		FromName  string  `json:"from_name"`
		PerMinute int     `json:"per_minute"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if !contains([]string{"none", "starttls", "tls"}, in.Security) || in.Port < 1 || in.Port > 65535 {
		return badReq("Проверьте порт и тип защиты")
	}
	if in.PerMinute < 1 || in.PerMinute > 1000 {
		in.PerMinute = 60
	}
	ctx := c.Context()
	if in.Password != nil && *in.Password != "" {
		enc, err := s.encrypt(*in.Password)
		if err != nil {
			return err
		}
		if _, err := s.db.Exec(ctx, `UPDATE mail_settings SET password = $1 WHERE id = 1`, enc); err != nil {
			return err
		}
	}
	_, err := s.db.Exec(ctx, `UPDATE mail_settings SET enabled=$1, host=$2, port=$3, security=$4, username=$5, from_addr=$6, from_name=$7, per_minute=$8 WHERE id = 1`,
		in.Enabled, strings.TrimSpace(in.Host), in.Port, in.Security, in.Username, strings.TrimSpace(in.FromAddr), in.FromName, in.PerMinute)
	if err != nil {
		return err
	}
	s.audit(c, "mail.settings", "mail", 1, nil)
	return c.JSON(200, map[string]any{"ok": true})
}

// mailTest — тестовое письмо себе (POST /api/mail/test).
func (s *Server) mailTest(c *Ctx) error {
	if !c.U.IsAdmin() {
		return errForbidden
	}
	var email string
	s.db.QueryRow(c.Context(), `SELECT email FROM users WHERE id = $1`, c.U.ID).Scan(&email)
	if email == "" {
		return badReq("В вашем профиле не указан email")
	}
	if err := s.sendMail(c.Context(), email, "Вместе: проверка почты", "Это тестовое письмо корпоративного портала. Если вы его читаете — SMTP настроен верно."); err != nil {
		return badReq("Не удалось отправить: " + err.Error())
	}
	return c.JSON(200, map[string]any{"ok": true})
}

type smtpCfg struct {
	host, security, user, pass, from, fromName string
	port, perMinute                            int
	enabled                                    bool
}

func (s *Server) smtpConfig(ctx context.Context) (smtpCfg, error) {
	var m smtpCfg
	var enc string
	err := s.db.QueryRow(ctx, `SELECT enabled, host, port, security, username, password, from_addr, from_name, per_minute FROM mail_settings WHERE id = 1`).
		Scan(&m.enabled, &m.host, &m.port, &m.security, &m.user, &enc, &m.from, &m.fromName, &m.perMinute)
	if err != nil {
		return m, err
	}
	if enc != "" {
		if m.pass, err = s.decrypt(enc); err != nil {
			return m, err
		}
	}
	return m, nil
}

// sendMail отправляет одно письмо (text/html + text), соединение — на каждое письмо (рассылка ограничена per_minute).
func (s *Server) sendMail(ctx context.Context, to, subject, body string) error {
	m, err := s.smtpConfig(ctx)
	if err != nil {
		return err
	}
	if m.host == "" || m.from == "" {
		return fmt.Errorf("SMTP не настроен")
	}
	if strings.ContainsAny(to+subject+m.from+m.fromName, "\r\n") { // защита от внедрения заголовков
		return fmt.Errorf("недопустимые символы в адресе или теме")
	}
	addr := net.JoinHostPort(m.host, fmt.Sprint(m.port))
	d := net.Dialer{Timeout: 15 * time.Second}
	var conn net.Conn
	if m.security == "tls" {
		conn, err = tls.DialWithDialer(&d, "tcp", addr, &tls.Config{ServerName: m.host})
	} else {
		conn, err = d.DialContext(ctx, "tcp", addr)
	}
	if err != nil {
		return err
	}
	conn.SetDeadline(time.Now().Add(60 * time.Second))
	cl, err := smtp.NewClient(conn, m.host)
	if err != nil {
		conn.Close()
		return err
	}
	defer cl.Close()
	if m.security == "starttls" {
		if err := cl.StartTLS(&tls.Config{ServerName: m.host}); err != nil {
			return err
		}
	}
	if m.user != "" {
		if err := cl.Auth(smtp.PlainAuth("", m.user, m.pass, m.host)); err != nil {
			return err
		}
	}
	if err := cl.Mail(m.from); err != nil {
		return err
	}
	if err := cl.Rcpt(to); err != nil {
		return err
	}
	w, err := cl.Data()
	if err != nil {
		return err
	}
	msg := fmt.Sprintf("From: =?UTF-8?B?%s?= <%s>\r\nTo: %s\r\nSubject: =?UTF-8?B?%s?=\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\nDate: %s\r\n\r\n%s\r\n",
		b64(m.fromName), m.from, to, b64(subject), time.Now().Format(time.RFC1123Z), htmlBody(body))
	if _, err := w.Write([]byte(msg)); err != nil {
		return err
	}
	if err := w.Close(); err != nil {
		return err
	}
	return cl.Quit()
}

func htmlBody(t string) string {
	return `<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.5">` + strings.ReplaceAll(html.EscapeString(t), "\n", "<br>") + `</div>`
}

// ---------------------------------------------------------------- кампании

func (s *Server) campaignList(c *Ctx) error {
	if !c.U.IsAdmin() && !c.U.HR {
		return errForbidden
	}
	b, err := s.arr(c.Context(), `SELECT m.id, m.subject, m.status, m.total, m.sent, m.failed, m.scheduled_at, m.created_at, a.name AS audience FROM mail_campaigns m LEFT JOIN audiences a ON a.id = m.audience_id ORDER BY m.id DESC LIMIT 100`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// campaignSend — создать и поставить в очередь (POST /api/mail/campaigns {subject, body, audience_id, scheduled_at}).
func (s *Server) campaignSend(c *Ctx) error {
	if !c.U.IsAdmin() && !c.U.HR {
		return errForbidden
	}
	var in struct {
		Subject     string  `json:"subject"`
		Body        string  `json:"body"`
		AudienceID  *int    `json:"audience_id"`
		ScheduledAt *string `json:"scheduled_at"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Subject, in.Body = strings.TrimSpace(in.Subject), strings.TrimSpace(in.Body)
	if in.Subject == "" || in.Body == "" || len(in.Subject) > 200 {
		return badReq("Заполните тему и текст письма")
	}
	ctx := c.Context()
	var on bool
	s.db.QueryRow(ctx, `SELECT enabled AND host <> '' FROM mail_settings WHERE id = 1`).Scan(&on)
	if !on {
		return badReq("Отправка почты не настроена: заполните параметры SMTP и включите её")
	}
	var id int64
	var total int
	err := s.tx(ctx, func(q pgx.Tx) error {
		if err := q.QueryRow(ctx, `INSERT INTO mail_campaigns (subject, body, audience_id, status, scheduled_at, created_by) VALUES ($1,$2,$3,'queued',$4::timestamptz,$5) RETURNING id`,
			in.Subject, in.Body, in.AudienceID, in.ScheduledAt, c.U.ID).Scan(&id); err != nil {
			return err
		}
		if err := q.QueryRow(ctx, `WITH ins AS (INSERT INTO mail_log (campaign_id, user_id, email)
			SELECT $1, au.id, u.email FROM audience_users($2) au JOIN users u ON u.id = au.id WHERE u.email <> '' AND NOT u.blocked RETURNING 1) SELECT count(*) FROM ins`, id, in.AudienceID).Scan(&total); err != nil {
			return err
		}
		_, err := q.Exec(ctx, `UPDATE mail_campaigns SET total = $2 WHERE id = $1`, id, total)
		return err
	})
	if err != nil {
		return err
	}
	s.audit(c, "mail.campaign", "mail_campaign", id, map[string]any{"total": total})
	return c.JSON(200, map[string]any{"id": id, "total": total})
}

// mailJob — рабочий цикл очереди (раз в минуту): не больше per_minute писем, кампании по расписанию ждут своего часа.
func (s *Server) mailJob(ctx context.Context) {
	m, err := s.smtpConfig(ctx)
	if err != nil || !m.enabled || m.host == "" {
		return
	}
	if !s.lock(ctx, "mail-job", 55*time.Second) {
		return
	}
	rows, err := s.db.Query(ctx, `SELECT l.id, l.campaign_id, l.email, coalesce(u.first_name, ''), coalesce(u.full_name, ''), c.subject, c.body
		FROM mail_log l JOIN mail_campaigns c ON c.id = l.campaign_id LEFT JOIN users u ON u.id = l.user_id
		WHERE l.status = 'queued' AND c.status IN ('queued','sending') AND (c.scheduled_at IS NULL OR c.scheduled_at <= now())
		ORDER BY l.id LIMIT $1`, m.perMinute)
	if err != nil {
		return
	}
	type job struct {
		id, camp                       int64
		email, first, name, subj, body string
	}
	var jobs []job
	for rows.Next() {
		var j job
		if rows.Scan(&j.id, &j.camp, &j.email, &j.first, &j.name, &j.subj, &j.body) == nil {
			jobs = append(jobs, j)
		}
	}
	rows.Close()
	camps := map[int64]bool{}
	for _, j := range jobs {
		if !camps[j.camp] {
			camps[j.camp] = true
			s.db.Exec(ctx, `UPDATE mail_campaigns SET status = 'sending', started_at = coalesce(started_at, now()) WHERE id = $1 AND status = 'queued'`, j.camp)
		}
		body := strings.NewReplacer("{{name}}", j.name, "{{first_name}}", j.first).Replace(j.body)
		if err := s.sendMail(ctx, j.email, j.subj, body); err != nil {
			s.db.Exec(ctx, `UPDATE mail_log SET status = 'failed', error = $2 WHERE id = $1`, j.id, trunc(err.Error(), 300))
		} else {
			s.db.Exec(ctx, `UPDATE mail_log SET status = 'sent', sent_at = now() WHERE id = $1`, j.id)
		}
	}
	s.db.Exec(ctx, `UPDATE mail_campaigns c SET sent = x.s, failed = x.f,
		status = CASE WHEN x.q = 0 THEN (CASE WHEN x.s = 0 AND x.f > 0 THEN 'failed' ELSE 'sent' END) ELSE c.status END,
		finished_at = CASE WHEN x.q = 0 THEN now() ELSE NULL END
		FROM (SELECT campaign_id, count(*) FILTER (WHERE status = 'sent') AS s, count(*) FILTER (WHERE status = 'failed') AS f, count(*) FILTER (WHERE status = 'queued') AS q
		      FROM mail_log GROUP BY campaign_id) x WHERE x.campaign_id = c.id AND c.status IN ('queued','sending')`)
}

func b64(t string) string { return base64.StdEncoding.EncodeToString([]byte(t)) }
