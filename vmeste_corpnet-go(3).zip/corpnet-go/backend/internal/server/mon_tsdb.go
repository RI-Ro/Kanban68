package server

// Встроенный мониторинг («как в Grafana»): процесс раз в monStep снимает показатели реестра mon (тот же, что отдаёт /metrics
// для Prometheus) и хранит их в кольцевом буфере в памяти — monKeep точек (6 часов при шаге 10 с). Панель администратора
// читает GET /api/admin/monitor. Это мониторинг одного экземпляра; сводные графики по всем экземплярам и ЦОДам, долгое
// хранение и алерты — через Prometheus + Grafana (deploy/monitoring), оба режима работают от одних и тех же счётчиков.

import (
	"context"
	"math"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

const (
	monStep = 10 * time.Second
	monKeep = 2160
)

// monSeriesNames — порядок и состав рядов во встроенном буфере.
var monSeriesNames = []string{
	"rps", "err5xx", "err4xx", "p50", "p95", "p99", "inflight", "ws", "goroutines", "heap_mb", "gc_ms",
	"db_acquired", "db_max", "db_p95", "db_err", "redis_p95", "slow", "panics",
}

type monTS struct {
	mu     sync.RWMutex
	times  []int64
	series map[string][]float64
}

var monStore = &monTS{series: map[string][]float64{}}

func (t *monTS) push(ts int64, vals map[string]float64) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.times = append(t.times, ts)
	for _, n := range monSeriesNames {
		v, ok := vals[n]
		if !ok {
			v = math.NaN()
		}
		t.series[n] = append(t.series[n], v)
	}
	if over := len(t.times) - monKeep; over > 0 {
		t.times = append([]int64(nil), t.times[over:]...)
		for n, s := range t.series {
			t.series[n] = append([]float64(nil), s[over:]...)
		}
	}
}

// slice возвращает последние n точек (NaN → nil, чтобы JSON получил null и график разорвал линию).
func (t *monTS) slice(n int) ([]int64, map[string][]*float64) {
	t.mu.RLock()
	defer t.mu.RUnlock()
	from := 0
	if len(t.times) > n {
		from = len(t.times) - n
	}
	times := append([]int64(nil), t.times[from:]...)
	out := make(map[string][]*float64, len(t.series))
	for name, s := range t.series {
		part := s[from:]
		cp := make([]*float64, len(part))
		for i := range part {
			if !math.IsNaN(part[i]) && !math.IsInf(part[i], 0) {
				v := part[i]
				cp[i] = &v
			}
		}
		out[name] = cp
	}
	return times, out
}

// monSnapshot копирует гистограмму: по-бакетные (не кумулятивные) счётчики, число наблюдений, сумма.
func (h *monHist) snapshot() ([]uint64, uint64, float64) {
	h.mu.Lock()
	defer h.mu.Unlock()
	return append([]uint64(nil), h.counts...), h.n, h.sum
}

// monAggHist суммирует все гистограммы набора (по всем лейблам).
func monAggHist(set *monSet[monHist]) ([]uint64, uint64, float64) {
	counts := make([]uint64, len(monBuckets))
	var n uint64
	var sum float64
	for _, k := range set.keys() {
		c, cn, cs := set.get(k, newHist).snapshot()
		for i := range counts {
			counts[i] += c[i]
		}
		n += cn
		sum += cs
	}
	return counts, n, sum
}

func monSumCounters(set *monSet[monCounter]) float64 {
	var t float64
	for _, k := range set.keys() {
		t += set.get(k, func() *monCounter { return &monCounter{} }).get()
	}
	return t
}

// monQuantile оценивает квантиль по дельте гистограммы линейной интерполяцией внутри корзины (как histogram_quantile).
// Значения за последней границей приравниваются к ней. Нет наблюдений — NaN.
func monQuantile(delta []uint64, q float64) float64 {
	var total uint64
	for _, c := range delta {
		total += c
	}
	if total == 0 {
		return math.NaN()
	}
	target := q * float64(total)
	var cum float64
	lo := 0.0
	for i, c := range delta {
		hi := monBuckets[i]
		if cum+float64(c) >= target && c > 0 {
			return lo + (hi-lo)*((target-cum)/float64(c))
		}
		cum += float64(c)
		lo = hi
	}
	return monBuckets[len(monBuckets)-1]
}

func monDelta(cur, prev []uint64) []uint64 {
	d := make([]uint64, len(cur))
	for i := range cur {
		if prev != nil && cur[i] >= prev[i] {
			d[i] = cur[i] - prev[i]
		} else {
			d[i] = cur[i]
		}
	}
	return d
}

// monPrev — предыдущие значения счётчиков для расчёта скоростей.
var monPrev struct {
	at                              time.Time
	req, r4, r5, slow, panics, dbEr float64
	reqH, dbH, redisH               []uint64
	gcNs                            uint64
}

// monSample — один замер; вызывается раз в monStep.
func (s *Server) monSample(ctx context.Context) {
	now := time.Now()
	var req, r4, r5 float64
	for _, k := range mon.reqs.keys() {
		p := strings.SplitN(k, "|", 3)
		v := mon.reqs.get(k, func() *monCounter { return &monCounter{} }).get()
		req += v
		if len(p) == 3 && len(p[2]) > 0 {
			switch p[2][0] {
			case '4':
				r4 += v
			case '5':
				r5 += v
			}
		}
	}
	reqH, _, _ := monAggHist(&mon.reqDur)
	dbH, _, _ := monAggHist(&mon.dbDur)
	redisH, _, _ := monAggHist(&mon.redisDur)
	slow, panics, dbEr := monSumCounters(&mon.slowReqs), mon.panics.get(), monSumCounters(&mon.dbErrs)
	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)

	prev := monPrev
	monPrev.at, monPrev.req, monPrev.r4, monPrev.r5, monPrev.slow, monPrev.panics, monPrev.dbEr = now, req, r4, r5, slow, panics, dbEr
	monPrev.reqH, monPrev.dbH, monPrev.redisH, monPrev.gcNs = reqH, dbH, redisH, ms.PauseTotalNs

	vals := map[string]float64{
		"inflight":   mon.inflight.get(),
		"ws":         float64(s.hub.conns.Load()),
		"goroutines": float64(runtime.NumGoroutine()),
		"heap_mb":    float64(ms.HeapAlloc) / (1 << 20),
	}
	st := s.db.Stat()
	vals["db_acquired"], vals["db_max"] = float64(st.AcquiredConns()), float64(st.MaxConns())
	if !prev.at.IsZero() {
		dt := now.Sub(prev.at).Seconds()
		if dt > 0 {
			rate := func(cur, old float64) float64 { return math.Max(cur-old, 0) / dt }
			vals["rps"], vals["err5xx"], vals["err4xx"] = rate(req, prev.req), rate(r5, prev.r5), rate(r4, prev.r4)
			vals["slow"], vals["panics"], vals["db_err"] = rate(slow, prev.slow), rate(panics, prev.panics), rate(dbEr, prev.dbEr)
			vals["gc_ms"] = float64(ms.PauseTotalNs-prev.gcNs) / 1e6 / dt
		}
		d := monDelta(reqH, prev.reqH)
		vals["p50"], vals["p95"], vals["p99"] = monQuantile(d, .5)*1000, monQuantile(d, .95)*1000, monQuantile(d, .99)*1000
		vals["db_p95"] = monQuantile(monDelta(dbH, prev.dbH), .95) * 1000
		vals["redis_p95"] = monQuantile(monDelta(redisH, prev.redisH), .95) * 1000
	}
	monStore.push(now.Unix(), vals)
}

type monRoute struct {
	Route  string  `json:"route"`
	Count  float64 `json:"count"`
	Errors float64 `json:"errors"`
	AvgMS  float64 `json:"avg_ms"`
	P95MS  float64 `json:"p95_ms"`
}

// monRoutes — сводка по маршрутам с начала работы процесса (топ по числу запросов).
func monRoutes(limit int) []monRoute {
	type acc struct {
		count, errs, sum float64
		n                uint64
		buckets          []uint64
	}
	by := map[string]*acc{}
	get := func(r string) *acc {
		a := by[r]
		if a == nil {
			a = &acc{buckets: make([]uint64, len(monBuckets))}
			by[r] = a
		}
		return a
	}
	for _, k := range mon.reqs.keys() {
		p := strings.SplitN(k, "|", 3)
		if len(p) < 3 {
			continue
		}
		v := mon.reqs.get(k, func() *monCounter { return &monCounter{} }).get()
		a := get(p[1])
		a.count += v
		if len(p[2]) > 0 && p[2][0] == '5' {
			a.errs += v
		}
	}
	for _, k := range mon.reqDur.keys() {
		p := strings.SplitN(k, "|", 2)
		if len(p) < 2 {
			continue
		}
		c, n, sum := mon.reqDur.get(k, newHist).snapshot()
		a := get(p[1])
		a.n += n
		a.sum += sum
		for i := range c {
			a.buckets[i] += c[i]
		}
	}
	out := make([]monRoute, 0, len(by))
	for r, a := range by {
		if r == "/metrics" || r == "/healthz" {
			continue
		}
		mr := monRoute{Route: r, Count: a.count, Errors: a.errs}
		if a.n > 0 {
			mr.AvgMS = a.sum / float64(a.n) * 1000
			if q := monQuantile(a.buckets, .95); !math.IsNaN(q) {
				mr.P95MS = q * 1000
			}
		}
		out = append(out, mr)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Count > out[j].Count })
	if len(out) > limit {
		out = out[:limit]
	}
	return out
}

// adminMonitor: GET /api/admin/monitor?minutes=15 — ряды для встроенных графиков.
func (s *Server) adminMonitor(c *Ctx) error {
	minutes := min(max(c.QInt("minutes", 15), 1), 360)
	times, series := monStore.slice(minutes * 60 / int(monStep.Seconds()))
	return c.JSON(200, map[string]any{
		"step":      int(monStep.Seconds()),
		"times":     times,
		"series":    series,
		"routes":    monRoutes(15),
		"instance":  s.cfg.InstanceID,
		"dc":        s.cfg.DCID,
		"version":   appVersion,
		"uptime":    int64(time.Since(s.up).Seconds()),
		"go":        runtime.Version(),
		"prom_path": "/metrics",
	})
}
