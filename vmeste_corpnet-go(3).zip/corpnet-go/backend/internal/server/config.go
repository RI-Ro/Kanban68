package server

import (
	"os"
	"runtime"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	Addr            string
	DatabaseURL     string
	RedisURL        string
	TLSCert, TLSKey string   // TLS_CERT / TLS_KEY: приложение отдаёт HTTPS само (HTTP/2 включается автоматически)
	RedirectAddr    string   // HTTP_REDIRECT_ADDR (например :80): редирект http → https
	TrustedProxies  []string // TRUSTED_PROXIES: сети внешних балансировщиков (X-Forwarded-*)
	InternalAllow   []string // INTERNAL_ALLOW: сети для /internal/* и /metrics (по умолчанию — частные)
	PeerAllow       []string // PEER_ALLOW: адреса соседних площадок для /internal/* (пусто — без ограничения, только токен)
	Prefork         int      // PREFORK: число рабочих процессов под одним мастером (0 — выключено, auto — по числу ядер)
	WorkerID        int      // номер рабочего процесса (задаёт мастер)
	Background      bool     // фоновые тяжёлые циклы (конвертация медиа, синхронизация и индексация файлов) — только в рабочем №0
	MetricsAddr     string   // METRICS_ADDR: отдельный порт /metrics каждого процесса (в prefork: порт + номер рабочего)
	KVBackend       string   // KV_BACKEND: auto | redis | pg | memory (auto: redis, если задан REDIS_URL, иначе pg)
	DataDir         string
	PGPoolMax       int
	MaxUploadMB     int64
	StaticDir       string // STATIC_DIR: каталог собранного фронтенда вместо встроенного (удобно при разработке)
	CookieSecure    bool
	SessionTTL      time.Duration
	AllowedOrigins  []string
	CSPReportOnly   bool   // CSP_REPORT_ONLY=1: политика только сообщает о нарушениях (для отладки внедрения)
	CSPExtra        string // CSP_EXTRA: дополнительные/переопределяющие директивы через «;»
	RLSOff          bool   // RLS_DISABLE=1: аварийное отключение построчной защиты (dbrls.go)
	CSRFOff         bool   // CSRF_DISABLE=1: аварийное отключение проверки CSRF (не рекомендуется)
	InstanceID      string
	NodeCode        string // NODE_CODE: код этого узла в реестре узлов (по умолчанию INSTANCE_ID)

	// --- несколько ЦОДов ---
	DCID          string   // имя ЦОДа (main, dc2 …): префикс локальных ключей Redis, владелец локальных очередей
	ReplicaURL    string   // DATABASE_REPLICA_URL: локальная read-реплика (читающие запросы), пусто = читаем с основной
	Realtime      string   // auto | redis | pg: чем доставлять события между экземплярами (pg — между ЦОДами)
	SessionStore  string   // kv | pg: где хранить сессии (kv — в хранилище kv, pg — таблица, общая для ЦОДов) (pg — общие для ЦОДов)
	SecretKey     string   // ключ шифрования паролей LDAP-подключений
	FilePeers     []string // базовые URL других ЦОДов для подтягивания файлов «по требованию»
	InternalToken string   // общий секрет для /internal/blob между ЦОДами
	TZ            string   // часовой пояс для повторяющихся событий

	// --- фоновые задачи с файлами
	MediaWorkers  int           // MEDIA_WORKERS: потоков фоновой конвертации фото/видео (0 — выключено)
	FFmpeg        string        // FFMPEG_BIN: путь к ffmpeg (пусто/off — видео и WebP не конвертируются)
	FFmpegTimeout time.Duration // MEDIA_FFMPEG_TIMEOUT_MIN: предел времени на один файл
	FileSync      bool          // FILE_SYNC: фоновая синхронизация файлов с FILE_PEERS (по умолчанию включена, если пиры заданы)
	FileSyncEvery time.Duration // FILE_SYNC_INTERVAL_SEC: период опроса соседа
	FileSyncJobs  int           // FILE_SYNC_WORKERS: параллельных загрузок

	// --- мониторинг (mon_*.go)
	SlowRequestMS int // порог «медленного» HTTP-запроса (флаг slow в access-логе), SLOW_REQUEST_MS
	SlowSQLMS     int // порог лога медленного SQL, SLOW_SQL_MS
}

func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func envInt(k string, def int) int {
	if v, err := strconv.Atoi(os.Getenv(k)); err == nil {
		return v
	}
	return def
}

func envBool(k string, def bool) bool {
	switch strings.ToLower(os.Getenv(k)) {
	case "1", "true", "yes", "on":
		return true
	case "0", "false", "no", "off":
		return false
	}
	return def
}

func LoadConfig() Config {
	host, _ := os.Hostname()
	c := Config{
		Addr:           env("HTTP_ADDR", ":8080"),
		DatabaseURL:    env("DATABASE_URL", "postgres://corpnet:corpnet@localhost:5432/corpnet?sslmode=disable"),
		RedisURL:       env("REDIS_URL", ""),
		TLSCert:        env("TLS_CERT", ""),
		TLSKey:         env("TLS_KEY", ""),
		RedirectAddr:   env("HTTP_REDIRECT_ADDR", ""),
		TrustedProxies: splitList(env("TRUSTED_PROXIES", "")),
		InternalAllow:  splitList(env("INTERNAL_ALLOW", "")),
		PeerAllow:      splitList(env("PEER_ALLOW", "")),
		Prefork:        preforkN(env("PREFORK", "auto")),
		WorkerID:       envInt("CORPNET_WORKER", 0),
		Background:     true,
		MetricsAddr:    env("METRICS_ADDR", ""),
		KVBackend:      strings.ToLower(env("KV_BACKEND", "auto")),
		DataDir:        env("DATA_DIR", "./data"),
		PGPoolMax:      envInt("PG_POOL_MAX", 12),
		MaxUploadMB:    int64(envInt("MAX_UPLOAD_MB", 200)),
		StaticDir:      env("STATIC_DIR", ""),
		CookieSecure:   envBool("COOKIE_SECURE", false),
		SessionTTL:     time.Duration(envInt("SESSION_TTL_HOURS", 24*14)) * time.Hour,
		InstanceID:     env("INSTANCE_ID", host),
		NodeCode:       strings.ToLower(env("NODE_CODE", env("INSTANCE_ID", host))),
		DCID:           env("DC_ID", "main"),
		ReplicaURL:     env("DATABASE_REPLICA_URL", ""),
		Realtime:       strings.ToLower(env("REALTIME_MODE", "auto")),
		SessionStore:   strings.ToLower(env("SESSION_STORE", "kv")),
		SecretKey:      env("SECRET_KEY", "change-me-corpnet-secret"),
		InternalToken:  env("INTERNAL_TOKEN", ""),
		TZ:             env("TZ", "Europe/Moscow"),
		MediaWorkers:   envInt("MEDIA_WORKERS", 1),
		FFmpeg:         env("FFMPEG_BIN", "ffmpeg"),
		FFmpegTimeout:  time.Duration(envInt("MEDIA_FFMPEG_TIMEOUT_MIN", 30)) * time.Minute,
		FileSyncEvery:  time.Duration(max(envInt("FILE_SYNC_INTERVAL_SEC", 30), 5)) * time.Second,
		FileSyncJobs:   max(envInt("FILE_SYNC_WORKERS", 2), 1),
		SlowRequestMS:  envInt("SLOW_REQUEST_MS", 1000),
		SlowSQLMS:      envInt("SLOW_SQL_MS", 200),
		CSPReportOnly:  envBool("CSP_REPORT_ONLY", false),
		CSPExtra:       env("CSP_EXTRA", ""),
		RLSOff:         envBool("RLS_DISABLE", false),
		CSRFOff:        envBool("CSRF_DISABLE", false),
	}
	if p := os.Getenv("FILE_PEERS"); p != "" {
		for _, x := range strings.Split(p, ",") {
			if x = strings.TrimRight(strings.TrimSpace(x), "/"); x != "" {
				c.FilePeers = append(c.FilePeers, x)
			}
		}
	}
	c.FileSync = envBool("FILE_SYNC", len(c.FilePeers) > 0) && len(c.FilePeers) > 0
	if o := os.Getenv("ALLOWED_ORIGINS"); o != "" {
		c.AllowedOrigins = strings.Split(o, ",")
	}
	return c
}

// preforkN разбирает PREFORK: число, "auto" (по ядрам) или пусто/0 (выключено).
func preforkN(v string) int {
	v = strings.ToLower(strings.TrimSpace(v))
	switch v {
	case "", "0", "off", "false", "no":
		return 0
	case "auto", "true", "yes", "on":
		return runtime.NumCPU()
	}
	n, err := strconv.Atoi(v)
	if err != nil || n < 0 {
		return 0
	}
	return n
}
