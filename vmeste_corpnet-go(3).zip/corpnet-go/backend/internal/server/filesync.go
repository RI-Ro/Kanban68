package server

import (
	"context"
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Фоновая синхронизация файлов между площадками (экземплярами портала).
//
// Каждая площадка хранит файлы на своём диске (DATA_DIR/pub, DATA_DIR/prv). Чтобы после загрузки на площадке A файл
// оказывался и на площадке B ДО того, как его откроют, B периодически спрашивает у A «манифест» — список файлов,
// изменённых после курсора, — и докачивает недостающие (pullFrom). Курсор (время изменения последнего принятого файла)
// хранится на диске: после перезапуска синхронизация продолжается с того же места, а раз в сутки идёт полная сверка.
// Если файла ещё нет, а его уже открыли, работает «подтягивание по требованию» (ensureLocal) — синхронизация лишь
// заранее заполняет диск. Связь односторонняя «B тянет у A»: для двух равноправных площадок каждая указывает соседа в
// FILE_PEERS и тянет у него. Третью площадку подключают тем же способом (см. руководство).
//
// Удаления синхронизируются через журнал file_tombstones (tombstone.go). Кроме того, приватные файлы (prv) сверяются с БД:
// если строки в files уже нет, файл не докачивается; для публичных (аватары, обложки) решает журнал удалений.

const (
	syncPage      = 1000
	syncYoungSkip = 2 * time.Minute // файл только что записан, а строки в БД ещё нет — повторим на следующем круге
)

type manifestItem struct {
	N string `json:"n"` // имя файла
	S int64  `json:"s"` // размер
	T int64  `json:"t"` // время изменения, unix-nano
}

type manifestResp struct {
	Items []manifestItem `json:"items"`
	More  bool           `json:"more"`
}

// internalManifest: GET /internal/manifest/{kind}?after=<unix-nano>&limit=N — список файлов с mtime >= after по возрастанию.
func (s *Server) internalManifest(w http.ResponseWriter, r *http.Request) {
	if s.cfg.InternalToken == "" || r.Header.Get("X-Internal-Token") != s.cfg.InternalToken || !s.peerAllowed(r) {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	kind := r.PathValue("kind")
	if kind != "pub" && kind != "prv" {
		http.NotFound(w, r)
		return
	}
	after, _ := strconv.ParseInt(r.URL.Query().Get("after"), 10, 64)
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if limit <= 0 || limit > 5000 {
		limit = syncPage
	}
	ents, err := os.ReadDir(s.dir(kind == "pub"))
	if err != nil {
		http.Error(w, "error", 500)
		return
	}
	items := make([]manifestItem, 0, 256)
	for _, e := range ents {
		n := e.Name()
		if e.IsDir() || strings.HasPrefix(n, ".") || strings.Contains(n, ".part.") {
			continue
		}
		fi, err := e.Info()
		if err != nil || fi.ModTime().UnixNano() < after {
			continue
		}
		items = append(items, manifestItem{N: n, S: fi.Size(), T: fi.ModTime().UnixNano()})
	}
	sort.Slice(items, func(i, j int) bool {
		if items[i].T != items[j].T {
			return items[i].T < items[j].T
		}
		return items[i].N < items[j].N
	})
	resp := manifestResp{Items: items}
	if len(items) > limit {
		resp.Items, resp.More = items[:limit], true
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(resp)
}

func (s *Server) fileSyncLoop(ctx context.Context) {
	if s.cfg.InternalToken == "" {
		s.log.Warn("filesync: INTERNAL_TOKEN не задан — синхронизация файлов отключена")
		return
	}
	// Список соседей динамический: FILE_PEERS + узлы реестра (nodes.go). Раз в 30 с сверяем и запускаем/останавливаем циклы.
	running := map[string]context.CancelFunc{}
	go func() {
		t := time.NewTicker(30 * time.Second)
		defer t.Stop()
		for {
			want := map[string]bool{}
			for _, peer := range s.filePeerURLs(ctx) {
				want[peer] = true
				if _, ok := running[peer]; !ok {
					pc, cancel := context.WithCancel(ctx)
					running[peer] = cancel
					for _, kind := range []string{"prv", "pub"} {
						go s.syncPeerKind(pc, peer, kind)
					}
					s.log.Info("filesync: сосед подключён", "peer", peer, "every", s.cfg.FileSyncEvery.String())
				}
			}
			for peer, cancel := range running {
				if !want[peer] {
					cancel()
					delete(running, peer)
					s.log.Info("filesync: сосед отключён", "peer", peer)
				}
			}
			select {
			case <-ctx.Done():
				return
			case <-t.C:
			}
		}
	}()
	s.tombstoneLoop(ctx)
}

func (s *Server) cursorPath(peer, kind string) string {
	h := sha1.Sum([]byte(peer))
	return filepath.Join(s.cfg.DataDir, ".sync-"+kind+"-"+hex.EncodeToString(h[:4]))
}

func (s *Server) syncPeerKind(ctx context.Context, peer, kind string) {
	cp := s.cursorPath(peer, kind)
	var cursor int64
	if b, err := os.ReadFile(cp); err == nil {
		cursor, _ = strconv.ParseInt(strings.TrimSpace(string(b)), 10, 64)
	}
	lastFull := time.Now()
	t := time.NewTicker(s.cfg.FileSyncEvery)
	defer t.Stop()
	for {
		if time.Since(lastFull) > 24*time.Hour { // суточная полная сверка: ловит всё, что курсор мог пропустить
			cursor, lastFull = 0, time.Now()
		}
		next, n, err := s.syncOnce(ctx, peer, kind, cursor)
		if err != nil {
			s.log.Warn("filesync: сбой круга", "peer", peer, "kind", kind, "err", err)
		}
		if next > cursor {
			cursor = next
			_ = os.WriteFile(cp, []byte(strconv.FormatInt(cursor, 10)), 0o644)
		}
		if n > 0 {
			s.log.Info("filesync: загружено файлов", "peer", peer, "kind", kind, "n", n)
		}
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
	}
}

// syncOnce проходит страницы манифеста с курсора; возвращает новый курсор и число докачанных файлов.
// Курсор не сдвигается дальше первого файла, который не удалось получить, — следующий круг повторит его.
func (s *Server) syncOnce(ctx context.Context, peer, kind string, cursor int64) (int64, int, error) {
	total := 0
	dir := s.dir(kind == "pub")
	cl := &http.Client{Timeout: 60 * time.Second}
	for ctx.Err() == nil {
		req, _ := http.NewRequestWithContext(ctx, "GET", fmt.Sprintf("%s/internal/manifest/%s?after=%d&limit=%d", peer, kind, cursor, syncPage), nil)
		req.Header.Set("X-Internal-Token", s.cfg.InternalToken)
		resp, err := cl.Do(req)
		if err != nil {
			return cursor, total, err
		}
		var m manifestResp
		err = json.NewDecoder(resp.Body).Decode(&m)
		resp.Body.Close()
		if resp.StatusCode != 200 || err != nil {
			return cursor, total, fmt.Errorf("манифест: HTTP %d %v", resp.StatusCode, err)
		}
		if len(m.Items) == 0 {
			return cursor, total, nil
		}
		var (
			mu     sync.Mutex
			failed = int64(-1) // mtime самого раннего неудавшегося файла
			wg     sync.WaitGroup
			sem    = make(chan struct{}, s.cfg.FileSyncJobs)
		)
		for _, it := range m.Items {
			if ctx.Err() != nil {
				break
			}
			it := it
			dst := filepath.Join(dir, it.N)
			if fi, err := os.Stat(dst); err == nil && fi.Size() == it.S {
				continue
			}
			if ok, young := s.syncWanted(ctx, kind, it); !ok {
				if young {
					mu.Lock()
					if failed < 0 || it.T < failed {
						failed = it.T
					}
					mu.Unlock()
				}
				continue
			}
			sem <- struct{}{}
			wg.Add(1)
			go func() {
				defer wg.Done()
				defer func() { <-sem }()
				err := s.pullFrom(ctx, peer, kind, it.N, dst)
				if err == errPeerMiss { // у соседа уже удалили — не ошибка
					return
				}
				if err != nil {
					mu.Lock()
					if failed < 0 || it.T < failed {
						failed = it.T
					}
					mu.Unlock()
					s.log.Debug("filesync: не удалось", "name", it.N, "err", err)
					return
				}
				mu.Lock()
				total++
				mu.Unlock()
			}()
		}
		wg.Wait()
		last := m.Items[len(m.Items)-1].T
		if failed >= 0 { // двигаем курсор только до первого сбоя (включительно: повторим его)
			return max(cursor, failed), total, nil
		}
		if last == cursor && !m.More {
			return cursor, total, nil
		}
		cursor = last
		if !m.More {
			return cursor, total, nil
		}
	}
	return cursor, total, ctx.Err()
}

// syncWanted: нужен ли файл этой площадке. Приватные — только если они ещё есть в БД (иначе удалённый на другой
// площадке файл «воскрес» бы). young — файл свежий, а строки пока нет (загрузка ещё не завершилась).
func (s *Server) syncWanted(ctx context.Context, kind string, it manifestItem) (ok, young bool) {
	if s.tombstoned(ctx, kind, it.N) { // файл удалили (журнал удалений) — не возвращаем
		return false, false
	}
	if kind != "prv" {
		return true, false
	}
	var exists bool
	if err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM files WHERE storage = $1 OR thumb = $1 OR view = $1)`, it.N).Scan(&exists); err != nil {
		return true, false // БД недоступна — лучше лишний файл, чем потерянный
	}
	if exists {
		return true, false
	}
	return false, time.Since(time.Unix(0, it.T)) < syncYoungSkip
}

var _ = url.PathEscape
