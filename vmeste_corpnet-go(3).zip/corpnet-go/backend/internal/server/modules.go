package server

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"sync"
	"time"
)

// Модуль предназначен для административного включения и выключения разделов портала для всех пользователей.
// Выключенный модуль исчезает из меню, а его API отвечает 403 (администратору остаётся доступным — для настройки и предпросмотра).
// Состояние читается из app_modules не чаще раза в 5 секунд, поэтому изменение быстро доходит до всех процессов и экземпляров.

var moduleAPI = map[string][]string{
	"news":       {"news", "news-track", "news-versions", "news-review", "must-read"},
	"calendar":   {"events", "calendars"},
	"messenger":  {"chats", "messages"},
	"groups":     {"groups", "posts"},
	"files":      {"folders"},
	"wiki":       {"wiki"},
	"ideas":      {"ideas"},
	"polls":      {"polls"},
	"surveys":    {"surveys"},
	"vacations":  {"vacations", "vacation-calendars"},
	"requests":   {"requests"},
	"learning":   {"learning", "lms"},
	"onboarding": {"onboarding"},
	"rewards":    {"gf"},
	"ask":        {"qa"},
	"feedback":   {"feedback"},
	"bookmarks":  {"bookmarks"},
}

type modState struct {
	mu   sync.RWMutex
	off  map[string]bool
	at   time.Time
	byPf map[string]string
}

var modCache = &modState{byPf: func() map[string]string {
	m := map[string]string{}
	for k, ps := range moduleAPI {
		for _, p := range ps {
			m[p] = k
		}
	}
	return m
}()}

func (s *Server) disabledModules() map[string]bool {
	modCache.mu.RLock()
	if time.Since(modCache.at) < 5*time.Second && modCache.off != nil {
		off := modCache.off
		modCache.mu.RUnlock()
		return off
	}
	modCache.mu.RUnlock()
	off := map[string]bool{}
	rows, err := s.db.Pool.Query(context.Background(), `SELECT key FROM app_modules WHERE NOT enabled`)
	if err == nil {
		for rows.Next() {
			var k string
			if rows.Scan(&k) == nil {
				off[k] = true
			}
		}
		rows.Close()
	} else {
		return map[string]bool{}
	}
	modCache.mu.Lock()
	modCache.off, modCache.at = off, time.Now()
	modCache.mu.Unlock()
	return off
}

// moduleGate — middleware: запросы к API выключенного модуля получают 403 (кроме администратора).
func (s *Server) moduleGate(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		p := r.URL.Path
		if strings.HasPrefix(p, "/api/") {
			seg := p[5:]
			if i := strings.IndexByte(seg, '/'); i >= 0 {
				seg = seg[:i]
			}
			if key, ok := modCache.byPf[seg]; ok && s.disabledModules()[key] {
				if u, _ := s.authenticate(r); u == nil || !u.IsAdmin() {
					s.writeErr(w, r, &apiError{403, "Раздел отключён администратором"})
					return
				}
			}
		}
		next.ServeHTTP(w, r)
	})
}

// modulesList — состояние модулей (GET /api/modules): нужно клиенту, чтобы скрыть пункты меню. Для администратора — с описаниями.
func (s *Server) modulesList(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT key, title, descr, enabled, sort, updated_at FROM app_modules ORDER BY sort, key`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// modulesSet — включить/выключить модуль (PUT /api/admin/modules/{key} {enabled}).
func (s *Server) modulesSet(c *Ctx) error {
	key := c.R.PathValue("key")
	var in struct {
		Enabled bool `json:"enabled"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	tag, err := s.db.Exec(c.Context(), `UPDATE app_modules SET enabled = $2, updated_at = now(), updated_by = $3 WHERE key = $1`, key, in.Enabled, c.U.ID)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return errNotFound
	}
	modCache.mu.Lock()
	modCache.at = time.Time{}
	modCache.mu.Unlock()
	s.audit(c, "module.set", "module", 0, map[string]any{"key": key, "enabled": in.Enabled})
	return c.JSON(200, map[string]any{"ok": true})
}

// uiDefaults — общие умолчания оформления (GET/PUT /api/ui-defaults).
func (s *Server) uiDefaultsGet(c *Ctx) error {
	var v []byte
	if err := s.db.QueryRow(c.Context(), `SELECT value FROM app_settings WHERE key = 'ui_defaults'`).Scan(&v); err != nil {
		v = []byte("{}")
	}
	return c.Raw(200, v)
}

func (s *Server) uiDefaultsSet(c *Ctx) error {
	var in map[string]any
	if err := c.Decode(&in); err != nil {
		return err
	}
	b, _ := json.Marshal(in)
	if _, err := s.db.Exec(c.Context(), `INSERT INTO app_settings (key, value) VALUES ('ui_defaults', $1::jsonb) ON CONFLICT (key) DO UPDATE SET value = $1::jsonb, updated_at = now()`, string(b)); err != nil {
		return err
	}
	s.audit(c, "ui.defaults", "settings", 0, in)
	return c.JSON(200, map[string]any{"ok": true})
}

// siteGet — название портала и логотип (GET /api/site, без авторизации: нужны экрану входа).
func (s *Server) siteGet(c *Ctx) error {
	var v []byte
	if err := s.db.QueryRow(c.Context(), `SELECT value FROM app_settings WHERE key = 'site'`).Scan(&v); err != nil {
		v = []byte(`{"name":"Вместе","logo":""}`)
	}
	return c.Raw(200, v)
}

// siteSet — изменить название и логотип (PUT /api/admin/site).
func (s *Server) siteSet(c *Ctx) error {
	var in struct {
		Name string `json:"name"`
		Logo string `json:"logo"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" || len([]rune(in.Name)) > 60 {
		return badReq("Название — от 1 до 60 символов")
	}
	if in.Logo != "" && !linkOrPathOK(in.Logo) {
		return badReq("Логотип: загрузите файл или укажите ссылку")
	}
	b, _ := json.Marshal(map[string]string{"name": in.Name, "logo": in.Logo})
	if _, err := s.db.Exec(c.Context(), `INSERT INTO app_settings (key, value) VALUES ('site', $1::jsonb) ON CONFLICT (key) DO UPDATE SET value = $1::jsonb, updated_at = now()`, string(b)); err != nil {
		return err
	}
	s.audit(c, "site.set", "settings", 0, map[string]string{"name": in.Name})
	return c.JSON(200, map[string]any{"ok": true})
}
