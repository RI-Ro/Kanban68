package server

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"
)

// Модуль предназначен для опросов (раздел 15 ТЗ): конструктор вопросов, адресная рассылка по аудитории, анонимность
// (открытый / анонимный со срезами / гарантированно анонимный без привязки к подразделению), NPS и отчёты.
// При анонимных опросах связь «человек — ответ» не хранится: участие записывается отдельно, без ссылки на ответ.

const svVisible = `s.status = 'active' AND (s.starts_at IS NULL OR s.starts_at <= now()) AND (s.ends_at IS NULL OR s.ends_at > now())
	AND audience_has(s.audience_id, $1)
	AND (s.onboarding_day IS NULL OR EXISTS (SELECT 1 FROM users u WHERE u.id = $1 AND u.hire_date IS NOT NULL AND current_date - u.hire_date >= s.onboarding_day))`

// svList — опросы, доступные мне (GET /api/surveys); managers=1 — все опросы для управления.
func (s *Server) svList(c *Ctx) error {
	ctx := c.Context()
	if c.Q("manage") == "1" {
		if err := s.needEditorOrHR(c); err != nil {
			return err
		}
		b, err := s.arr(ctx, `SELECT s.*, (SELECT count(*) FROM sv_participation p WHERE p.survey_id = s.id) AS responses,
			(SELECT count(*) FROM audience_users(s.audience_id)) AS audience_size FROM sv_surveys s
			WHERE $2::boolean OR s.created_by = $1 ORDER BY s.id DESC LIMIT 500`, c.U.ID, svAll(c))
		if err != nil {
			return err
		}
		return c.Raw(200, b)
	}
	b, err := s.arr(ctx, `SELECT s.id, s.title, s.description, s.kind, s.anonymity, s.ends_at,
			(SELECT count(*) FROM sv_questions q WHERE q.survey_id = s.id) AS questions,
			EXISTS (SELECT 1 FROM sv_participation p WHERE p.survey_id = s.id AND p.user_id = $1) AS answered
		FROM sv_surveys s WHERE `+svVisible+` ORDER BY answered, s.ends_at NULLS LAST, s.id DESC`, c.U.ID)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// needEditorOrHR — доступ к разделу управления опросами: администратор, HR-администратор или «проводящий опросы».
func (s *Server) needEditorOrHR(c *Ctx) error {
	if c.U.Pollster || c.U.HR || c.U.IsAdmin() {
		return nil
	}
	return errForbidden
}

// svAll — управляет ли пользователь всеми опросами (администратор и HR); остальные — только своими.
func svAll(c *Ctx) bool { return c.U.HR || c.U.IsAdmin() }

// svOwn проверяет право менять опрос: все — администратор и HR, иначе только автор опроса.
func (s *Server) svOwn(c *Ctx, id int64) error {
	if svAll(c) {
		return nil
	}
	var creator *int64
	if err := s.db.QueryRow(c.Context(), `SELECT created_by FROM sv_surveys WHERE id = $1`, id).Scan(&creator); err != nil {
		return errNotFound
	}
	if creator != nil && *creator == c.U.ID {
		return nil
	}
	return errForbidden
}

// svGet — опрос с вопросами (GET /api/surveys/{id}).
func (s *Server) svGet(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	manage := s.needEditorOrHR(c) == nil && s.svOwn(c, id) == nil
	sv, err := s.one(ctx, `SELECT s.*, EXISTS (SELECT 1 FROM sv_participation p WHERE p.survey_id = s.id AND p.user_id = $1) AS answered
		FROM sv_surveys s WHERE s.id = $2 AND ($3::boolean OR `+svVisible+`)`, c.U.ID, id, manage)
	if err != nil {
		return errNotFound
	}
	qs, err := s.arr(ctx, `SELECT id, sort, kind, title, options, required FROM sv_questions WHERE survey_id = $1 ORDER BY sort, id`, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"survey": sv, "questions": qs})
}

// svRespond — ответ на опрос (POST /api/surveys/{id}/respond {answers:{"<qid>": value}}).
func (s *Server) svRespond(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Answers map[string]json.RawMessage `json:"answers"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	var anon, kind string
	if err := s.db.QueryRow(ctx, `SELECT s.anonymity, s.kind FROM sv_surveys s WHERE s.id = $2 AND `+svVisible, c.U.ID, id).Scan(&anon, &kind); err != nil {
		return errNotFound
	}
	rows, err := s.db.Query(ctx, `SELECT id, kind, required, options FROM sv_questions WHERE survey_id = $1`, id)
	if err != nil {
		return err
	}
	type q struct {
		id   int64
		kind string
		req  bool
		opts []string
	}
	var qs []q
	for rows.Next() {
		var x q
		var raw []byte
		if rows.Scan(&x.id, &x.kind, &x.req, &raw) == nil {
			json.Unmarshal(raw, &x.opts)
			qs = append(qs, x)
		}
	}
	rows.Close()
	clean := map[int64]json.RawMessage{}
	for _, x := range qs {
		v, ok := in.Answers[i64s(x.id)]
		empty := !ok || string(v) == "null" || string(v) == `""` || string(v) == "[]"
		if empty {
			if x.req {
				return badReq("Ответьте на все обязательные вопросы")
			}
			continue
		}
		switch x.kind {
		case "scale", "rating", "nps":
			var n int
			if json.Unmarshal(v, &n) != nil {
				return badReq("Некорректный ответ")
			}
			hi := map[string]int{"scale": 10, "rating": 5, "nps": 10}[x.kind]
			lo := map[string]int{"scale": 1, "rating": 1, "nps": 0}[x.kind]
			if n < lo || n > hi {
				return badReq("Значение вне диапазона")
			}
		case "text":
			var t string
			if json.Unmarshal(v, &t) != nil || len([]rune(t)) > 4000 {
				return badReq("Текст слишком длинный")
			}
		case "single":
			var t string
			if json.Unmarshal(v, &t) != nil || !contains(x.opts, t) {
				return badReq("Недопустимый вариант")
			}
		case "multi":
			var ts []string
			if json.Unmarshal(v, &ts) != nil {
				return badReq("Некорректный ответ")
			}
			for _, t := range ts {
				if !contains(x.opts, t) {
					return badReq("Недопустимый вариант")
				}
			}
		}
		clean[x.id] = v
	}
	tx, err := s.db.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	tag, err := tx.Exec(ctx, `INSERT INTO sv_participation (survey_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`, id, c.U.ID)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return conflict("Вы уже участвовали в этом опросе")
	}
	var uid, dept any
	if anon == "open" {
		uid = c.U.ID
	}
	if anon != "guaranteed" && c.U.Dept != 0 {
		dept = c.U.Dept
	}
	var rid int64
	if err := tx.QueryRow(ctx, `INSERT INTO sv_responses (survey_id, user_id, dept_id) VALUES ($1, $2, $3) RETURNING id`, id, uid, dept).Scan(&rid); err != nil {
		return err
	}
	for qid, v := range clean {
		if _, err := tx.Exec(ctx, `INSERT INTO sv_answers (response_id, question_id, value) VALUES ($1, $2, $3)`, rid, qid, string(v)); err != nil {
			return err
		}
	}
	if err := tx.Commit(ctx); err != nil {
		return err
	}
	s.award(ctx, c.U.ID, "poll_answer", "survey:"+i64s(id), nil)
	return c.JSON(200, map[string]any{"ok": true})
}

func contains(a []string, v string) bool {
	for _, x := range a {
		if x == v {
			return true
		}
	}
	return false
}

// svResults — отчёт (GET /api/surveys/{id}/results). Срезы по подразделениям скрываются, если ответов меньше min_group.
func (s *Server) svResults(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	out, err := s.svResultsData(c, id)
	if err != nil {
		return err
	}
	return c.JSON(200, out)
}

func (s *Server) svResultsData(c *Ctx, id int64) (map[string]any, error) {
	ctx := c.Context()
	var minGroup int
	var anon string
	var public bool
	var creator *int64
	if err := s.db.QueryRow(ctx, `SELECT min_group, anonymity, results_public, created_by FROM sv_surveys WHERE id = $1`, id).Scan(&minGroup, &anon, &public, &creator); err != nil {
		return nil, errNotFound
	}
	if !(c.U.IsAdmin() || c.U.HR || (creator != nil && *creator == c.U.ID) || public) {
		return nil, errForbidden
	}
	var invited, responded int
	s.db.QueryRow(ctx, `SELECT (SELECT count(*) FROM audience_users(s.audience_id)), (SELECT count(*) FROM sv_participation p WHERE p.survey_id = s.id) FROM sv_surveys s WHERE s.id = $1`, id).Scan(&invited, &responded)
	rows, err := s.db.Query(ctx, `SELECT q.id, q.kind, q.title, q.options, a.value, coalesce(d.name, '') FROM sv_questions q
		LEFT JOIN sv_answers a ON a.question_id = q.id LEFT JOIN sv_responses r ON r.id = a.response_id LEFT JOIN departments d ON d.id = r.dept_id
		WHERE q.survey_id = $1 ORDER BY q.sort, q.id`, id)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	type agg struct {
		ID      int64                  `json:"id"`
		Kind    string                 `json:"kind"`
		Title   string                 `json:"title"`
		N       int                    `json:"n"`
		Avg     float64                `json:"avg,omitempty"`
		Counts  map[string]int         `json:"counts,omitempty"`
		NPS     *int                   `json:"nps,omitempty"`
		Texts   []string               `json:"texts,omitempty"`
		ByDept  map[string]*[2]float64 `json:"by_dept,omitempty"`
		sum     float64
		promo   int
		detr    int
		deptN   map[string]int
		deptSum map[string]float64
	}
	var order []int64
	m := map[int64]*agg{}
	for rows.Next() {
		var qid int64
		var kind, title, dept string
		var opts, val []byte
		if err := rows.Scan(&qid, &kind, &title, &opts, &val, &dept); err != nil {
			return nil, err
		}
		a := m[qid]
		if a == nil {
			a = &agg{ID: qid, Kind: kind, Title: title, Counts: map[string]int{}, deptN: map[string]int{}, deptSum: map[string]float64{}}
			m[qid] = a
			order = append(order, qid)
		}
		if val == nil {
			continue
		}
		a.N++
		switch kind {
		case "scale", "rating", "nps":
			var n float64
			json.Unmarshal(val, &n)
			a.sum += n
			a.Counts[strconv.Itoa(int(n))]++
			if kind == "nps" {
				if n >= 9 {
					a.promo++
				} else if n <= 6 {
					a.detr++
				}
			}
			if dept != "" && anon != "guaranteed" {
				a.deptN[dept]++
				a.deptSum[dept] += n
			}
		case "single":
			var t string
			json.Unmarshal(val, &t)
			a.Counts[t]++
		case "multi":
			var ts []string
			json.Unmarshal(val, &ts)
			for _, t := range ts {
				a.Counts[t]++
			}
		case "text", "date":
			var t string
			json.Unmarshal(val, &t)
			if t != "" && len(a.Texts) < 200 {
				a.Texts = append(a.Texts, t)
			}
		}
	}
	out := make([]*agg, 0, len(order))
	for _, qid := range order {
		a := m[qid]
		if a.N > 0 && (a.Kind == "scale" || a.Kind == "rating" || a.Kind == "nps") {
			a.Avg = float64(int(a.sum/float64(a.N)*100+0.5)) / 100
		}
		if a.Kind == "nps" && a.N > 0 {
			v := (a.promo - a.detr) * 100 / a.N
			a.NPS = &v
		}
		if len(a.deptN) > 0 {
			a.ByDept = map[string]*[2]float64{}
			keys := make([]string, 0, len(a.deptN))
			for k := range a.deptN {
				keys = append(keys, k)
			}
			sort.Strings(keys)
			for _, k := range keys {
				if a.deptN[k] >= minGroup { // защита анонимности малых групп
					a.ByDept[k] = &[2]float64{float64(int(a.deptSum[k]/float64(a.deptN[k])*100+0.5)) / 100, float64(a.deptN[k])}
				}
			}
		}
		if anon != "open" && len(a.Texts) > 0 && responded < minGroup {
			a.Texts = nil // при малом числе ответов свободный текст может выдать автора
		}
		out = append(out, a)
	}
	return map[string]any{"invited": invited, "responded": responded, "min_group": minGroup, "anonymity": anon, "questions": out}, nil
}

// svRemind — напоминание тем, кто не ответил (POST /api/surveys/{id}/remind): адресатам уходит уведомление, список не раскрывается.
func (s *Server) svRemind(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if err := s.svOwn(c, id); err != nil {
		return err
	}
	ctx := c.Context()
	if !s.lock(ctx, "svremind:"+i64s(id), 30*60*1e9) {
		return conflict("Напоминание уже отправлено недавно")
	}
	var uids []int64
	rows, err := s.db.Query(ctx, `SELECT au.id FROM sv_surveys s, audience_users(s.audience_id) au WHERE s.id = $1 AND s.status = 'active'
		AND NOT EXISTS (SELECT 1 FROM sv_participation p WHERE p.survey_id = s.id AND p.user_id = au.id)`, id)
	if err != nil {
		return err
	}
	for rows.Next() {
		var u int64
		if rows.Scan(&u) == nil {
			uids = append(uids, u)
		}
	}
	rows.Close()
	var title string
	s.db.QueryRow(ctx, `SELECT title FROM sv_surveys WHERE id = $1`, id).Scan(&title)
	s.notify(ctx, uids, "survey", "Пройдите опрос", title, "/surveys/"+i64s(id))
	return c.JSON(200, map[string]any{"sent": len(uids)})
}

// svSave — создание и изменение опроса вместе с вопросами (POST /api/surveys, PUT /api/surveys/{id}).
func (s *Server) svSave(c *Ctx) error {
	if err := s.needEditorOrHR(c); err != nil {
		return err
	}
	var in struct {
		Title         string  `json:"title"`
		Description   string  `json:"description"`
		Kind          string  `json:"kind"`
		Anonymity     string  `json:"anonymity"`
		AudienceID    *int    `json:"audience_id"`
		Status        string  `json:"status"`
		StartsAt      *string `json:"starts_at"`
		EndsAt        *string `json:"ends_at"`
		OnboardingDay *int    `json:"onboarding_day"`
		MinGroup      int     `json:"min_group"`
		ResultsPublic bool    `json:"results_public"`
		Questions     []struct {
			Kind     string   `json:"kind"`
			Title    string   `json:"title"`
			Options  []string `json:"options"`
			Required bool     `json:"required"`
		} `json:"questions"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Title = strings.TrimSpace(in.Title)
	if in.Title == "" || len(in.Questions) == 0 {
		return badReq("Нужны название и хотя бы один вопрос")
	}
	if in.MinGroup < 3 {
		in.MinGroup = 5
	}
	ctx := c.Context()
	tx, err := s.db.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	var id int64
	if v := c.R.PathValue("id"); v != "" {
		id, _ = strconv.ParseInt(v, 10, 64)
		if err := s.svOwn(c, id); err != nil {
			return err
		}
		var resp int
		tx.QueryRow(ctx, `SELECT count(*) FROM sv_participation WHERE survey_id = $1`, id).Scan(&resp)
		if resp > 0 {
			// вопросы опроса с ответами не меняем — только оформление и статус
			_, err = tx.Exec(ctx, `UPDATE sv_surveys SET title=$2, description=$3, status=$4, ends_at=$5::timestamptz, results_public=$6 WHERE id=$1`,
				id, in.Title, in.Description, in.Status, in.EndsAt, in.ResultsPublic)
			if err != nil {
				return err
			}
			if err := tx.Commit(ctx); err != nil {
				return err
			}
			return c.JSON(200, map[string]any{"id": id, "questions_locked": true})
		}
		_, err = tx.Exec(ctx, `UPDATE sv_surveys SET title=$2, description=$3, kind=$4, anonymity=$5, audience_id=$6, status=$7, starts_at=$8::timestamptz,
			ends_at=$9::timestamptz, onboarding_day=$10, min_group=$11, results_public=$12 WHERE id=$1`, id, in.Title, in.Description, in.Kind, in.Anonymity, in.AudienceID,
			in.Status, in.StartsAt, in.EndsAt, in.OnboardingDay, in.MinGroup, in.ResultsPublic)
		if err != nil {
			return err
		}
		tx.Exec(ctx, `DELETE FROM sv_questions WHERE survey_id = $1`, id)
	} else {
		err = tx.QueryRow(ctx, `INSERT INTO sv_surveys (title, description, kind, anonymity, audience_id, status, starts_at, ends_at, onboarding_day, min_group, results_public, created_by)
			VALUES ($1,$2,$3,$4,$5,$6,$7::timestamptz,$8::timestamptz,$9,$10,$11,$12) RETURNING id`, in.Title, in.Description, in.Kind, in.Anonymity, in.AudienceID,
			in.Status, in.StartsAt, in.EndsAt, in.OnboardingDay, in.MinGroup, in.ResultsPublic, c.U.ID).Scan(&id)
		if err != nil {
			return err
		}
	}
	for i, q := range in.Questions {
		opts, _ := json.Marshal(q.Options)
		if _, err := tx.Exec(ctx, `INSERT INTO sv_questions (survey_id, sort, kind, title, options, required) VALUES ($1,$2,$3,$4,$5,$6)`, id, i+1, q.Kind, strings.TrimSpace(q.Title), string(opts), q.Required); err != nil {
			return err
		}
	}
	if err := tx.Commit(ctx); err != nil {
		return err
	}
	if in.Status == "active" {
		s.svAnnounce(ctx, id)
	}
	s.audit(c, "survey.save", "survey", id, nil)
	return c.JSON(200, map[string]any{"id": id})
}

// svAnnounce уведомляет аудиторию об открытии опроса (однократно, для опросов не привязанных к дню адаптации).
func (s *Server) svAnnounce(ctx context.Context, id int64) {
	if !s.lock(ctx, "svannounce:"+i64s(id), 24*3600*1e9) {
		return
	}
	var title string
	var onb *int
	s.db.QueryRow(ctx, `SELECT title, onboarding_day FROM sv_surveys WHERE id = $1`, id).Scan(&title, &onb)
	if onb != nil {
		return
	}
	var uids []int64
	rows, err := s.db.Query(ctx, `SELECT au.id FROM sv_surveys s, audience_users(s.audience_id) au WHERE s.id = $1`, id)
	if err != nil {
		return
	}
	for rows.Next() {
		var u int64
		if rows.Scan(&u) == nil {
			uids = append(uids, u)
		}
	}
	rows.Close()
	s.notify(ctx, uids, "survey", "Новый опрос", title, "/surveys/"+i64s(id))
}

// svReport — расширенная справка по опросу (GET /api/surveys/{id}/report): паспорт, участие, динамика,
// итоги по вопросам и автоматические выводы. Доступна администратору, HR и автору опроса.
func (s *Server) svReport(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if err := s.svOwn(c, id); err != nil {
		return err
	}
	ctx := c.Context()
	res, err := s.svResultsData(c, id)
	if err != nil {
		return err
	}
	meta, err := s.one(ctx, `SELECT s.title, s.description, s.kind, s.anonymity, s.status, s.starts_at, s.ends_at, s.min_group, s.created_at,
		coalesce(u.full_name, '') AS author, (SELECT count(*) FROM sv_questions q WHERE q.survey_id = s.id) AS questions_count,
		coalesce(a.name, 'Все сотрудники') AS audience
		FROM sv_surveys s LEFT JOIN users u ON u.id = s.created_by LEFT JOIN audiences a ON a.id = s.audience_id WHERE s.id = $1`, id)
	if err != nil {
		return errNotFound
	}
	days, err := s.arr(ctx, `SELECT to_char(submitted_at AT TIME ZONE 'Europe/Moscow', 'YYYY-MM-DD') AS day, count(*) AS n
		FROM sv_responses WHERE survey_id = $1 GROUP BY 1 ORDER BY 1`, id)
	if err != nil {
		return err
	}
	var depts json.RawMessage = []byte("[]")
	if res["anonymity"] != "guaranteed" {
		minGroup, _ := res["min_group"].(int)
		if d, err := s.arr(ctx, `SELECT d.name, count(*) AS n FROM sv_responses r JOIN departments d ON d.id = r.dept_id
			WHERE r.survey_id = $1 GROUP BY d.name HAVING count(*) >= $2 ORDER BY n DESC, d.name LIMIT 50`, id, minGroup); err == nil {
			depts = d
		}
	}
	invited, _ := res["invited"].(int)
	responded, _ := res["responded"].(int)
	rate := 0
	if invited > 0 {
		rate = responded * 100 / invited
	}
	var findings []string
	findings = append(findings, fmt.Sprintf("Ответили %d из %d приглашённых — %d%%.", responded, invited, rate))
	b, _ := json.Marshal(res["questions"])
	var qlist []struct {
		Title  string         `json:"title"`
		Kind   string         `json:"kind"`
		N      int            `json:"n"`
		Avg    float64        `json:"avg"`
		Counts map[string]int `json:"counts"`
		NPS    *int           `json:"nps"`
	}
	json.Unmarshal(b, &qlist)
	var best, worst string
	bestV, worstV := -1.0, 1e9
	for _, q := range qlist {
		switch q.Kind {
		case "scale", "rating":
			if q.N > 0 {
				if q.Avg > bestV {
					bestV, best = q.Avg, q.Title
				}
				if q.Avg < worstV {
					worstV, worst = q.Avg, q.Title
				}
			}
		case "nps":
			if q.NPS != nil {
				findings = append(findings, fmt.Sprintf("NPS по вопросу «%s»: %d.", q.Title, *q.NPS))
			}
		case "single", "multi":
			top, topN := "", 0
			for k, v := range q.Counts {
				if v > topN || (v == topN && k < top) {
					top, topN = k, v
				}
			}
			if topN > 0 && q.N > 0 {
				findings = append(findings, fmt.Sprintf("«%s»: чаще всего выбирали «%s» — %d%% ответивших.", q.Title, top, topN*100/q.N))
			}
		}
	}
	if best != "" && best != worst {
		findings = append(findings, fmt.Sprintf("Самая высокая средняя оценка (%.2f) — «%s»; самая низкая (%.2f) — «%s».", bestV, best, worstV, worst))
	}
	if responded > 0 && responded < 5 {
		findings = append(findings, "Ответов мало — выводы ориентировочные.")
	}
	return c.JSON(200, map[string]any{"meta": meta, "results": res, "by_day": days, "by_dept": depts, "findings": findings, "generated_at": time.Now()})
}
