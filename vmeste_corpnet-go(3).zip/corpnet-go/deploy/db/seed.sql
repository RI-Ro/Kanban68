-- ============================================================================
-- CorpNet: начальные и тестовые данные. Приложение их не вставляет — выполняет deploy/db/migrate.sh:
--   DATABASE_URL=... deploy/db/migrate.sh --seed admin@corp.example 'Пароль' [--demo]
-- (скрипт сам считает bcrypt-хэш пароля и передаёт переменные admin_email, admin_hash, demo).
--   BASE — сведения о компании, категории, календари, общая папка, администратор (обязательный минимум).
--   DEMO — оргструктура, 35 сотрудников (пароль corpnet123), новости с версиями и аналитикой,
--          группы, события, отпуска, идеи. Только для стендов, в production не выполнять.
-- Выполняется один раз на пустой базе.
-- ============================================================================

-- @@BASE
UPDATE company SET about = 'Единое пространство для внутренних новостей, коммуникаций, документов, календарей и медиаматериалов компании.',
    address = 'Москва, Пресненская наб., 12 · Главный офис', phone = '+7 495 000-00-00', email = 'info@corpnet.local', founded = 2014 WHERE id = 1;

INSERT INTO categories (name, color, sort) VALUES
    ('Компания', '#286b9e', 0), ('IT', '#7c5cff', 1), ('Мероприятия', '#e8590c', 2), ('Проекты', '#2f9e44', 3), ('HR', '#d6336c', 4);

INSERT INTO calendars (name, description, kind, color, visibility, open_add) VALUES
    ('Дни рождения', 'Дни рождения сотрудников', 'birthdays', '#d6336c', 'company', false),
    ('Видеоконференции', 'Запланированные видеоконференции', 'conference', '#7c5cff', 'company', true),
    ('Мероприятия', 'Праздники, турниры и события компании (редакторы могут добавлять)', 'custom', '#e8590c', 'company', false);

INSERT INTO folders (kind, name, description, visibility) VALUES ('documents', 'Общие', 'Общие документы компании', 'company');

INSERT INTO users (login, email, password_hash, first_name, last_name, job_title, role)
    VALUES ('admin', :'admin_email', :'admin_hash', 'Администратор', 'Системы', 'Администратор портала', 'admin');
INSERT INTO calendars (name, kind, owner_id, visibility, color)
    SELECT 'Мой календарь', 'personal', id, 'restricted', '#286b9e' FROM users WHERE login = 'admin';

\if :{?demo}
-- @@DEMO
-- Демо-режим: администратор — Алексей Морозов (тот же логин admin и тот же пароль).
UPDATE users SET first_name = 'Алексей', last_name = 'Морозов', middle_name = 'Александрович', job_title = 'Руководитель проектов',
    phone1 = '+7 495 000-10-20', birthday = '1980-03-14', can_vacations = true WHERE login = 'admin';


-- ---- подразделения (дерево)
INSERT INTO departments (name, sort, image) VALUES
    ('Генеральная дирекция', 10, ''), ('IT и цифровая трансформация', 20, ''), ('HR и корпоративные коммуникации', 30, ''),
    ('Финансы', 40, ''), ('Продажи', 50, '');
INSERT INTO departments (name, parent_id, sort, image)
    SELECT v.n, p.id, v.s, '' FROM (VALUES
        ('Стратегия', 'Генеральная дирекция', 60), ('Администрация', 'Генеральная дирекция', 70),
        ('Разработка', 'IT и цифровая трансформация', 80), ('Инфраструктура', 'IT и цифровая трансформация', 90),
        ('Аналитика', 'IT и цифровая трансформация', 100), ('HR', 'HR и корпоративные коммуникации', 110),
        ('Корпоративные коммуникации', 'HR и корпоративные коммуникации', 120), ('Бухгалтерия', 'Финансы', 130),
        ('Финансовое планирование', 'Финансы', 140), ('Ключевые клиенты', 'Продажи', 150), ('Региональные продажи', 'Продажи', 160)
    ) AS v(n, parent, s) JOIN departments p ON p.name = v.parent AND p.parent_id IS NULL;
UPDATE departments SET description = E'## Чем занимается подразделение\n\nМы отвечаем за **цифровые продукты**, инфраструктуру и информационную безопасность компании.\n\n- Разработка и поддержка внутренних систем\n- *Эксплуатация* серверов, сетей и рабочих мест\n- Аналитика данных и отчётность\n\n### Контакты\n\nСлужба поддержки: **support@corpnet.local**'
    WHERE name = 'IT и цифровая трансформация';
UPDATE departments SET description = E'## HR и корпоративные коммуникации\n\nПодбор и развитие персонала, адаптация, **внутренние коммуникации** и корпоративные мероприятия.'
    WHERE name = 'HR и корпоративные коммуникации';

-- ---- направления деятельности
INSERT INTO directions (name, description, sort, department_id)
    SELECT v.n, 'Направление деятельности с подразделами, новостями и материалами', v.s, d.id
    FROM (VALUES ('HR', 10, 'HR и корпоративные коммуникации'), ('IT', 20, 'IT и цифровая трансформация'),
                 ('Продажи', 30, 'Продажи'), ('Финансы', 40, 'Финансы')) AS v(n, s, dept) JOIN departments d ON d.name = v.dept;
INSERT INTO directions (parent_id, name, description, sort)
    SELECT p.id, v.n, 'Новости, документы, фото и видео раздела', v.s FROM (VALUES
        ('HR', 'Приём на работу', 10), ('HR', 'Адаптация и воспитание', 20), ('HR', 'Корпоративная культура', 30),
        ('IT', 'Разработка', 10), ('IT', 'Инфраструктура', 20), ('IT', 'Информационная безопасность', 30),
        ('Продажи', 'Продукты', 10), ('Продажи', 'Работа с клиентами', 20),
        ('Финансы', 'Бюджетирование', 10), ('Финансы', 'Отчётность', 20)) AS v(parent, n, s)
    JOIN directions p ON p.name = v.parent AND p.parent_id IS NULL;

-- ---- сотрудники (пароль всех: corpnet123)
INSERT INTO users (login, email, password_hash, first_name, last_name, middle_name, job_title, extra_info, department_id, role,
                   phone1, phone2, birthday, is_head, can_vacations, company_news)
SELECT v.login, v.login || '@corpnet.local', '$2a$10$dwG1/93z2gJGJoP04WoQXecuzuEOD3QjI0nJ5R/.a0ratgXKaGJKu', v.fn, v.ln, v.mn, v.title,
       'Работаю в компании с удовольствием. Пишите — всегда рад помочь.', d.id, v.role,
       '+7 495 000-' || lpad((10 + v.i)::text, 2, '0') || '-' || lpad((20 + v.i)::text, 2, '0'),
       '+7 916 ' || (100 + v.i) || '-' || lpad((10 + v.i)::text, 2, '0') || '-' || lpad((30 + v.i)::text, 2, '0'),
       make_date(1980 + (v.i * 7) % 20, split_part(v.bday, '-', 1)::int, split_part(v.bday, '-', 2)::int),
       v.head, v.i = 9, v.i = 5
FROM (VALUES
    (1,  'elena.sokolova',      'Елена',     'Соколова',    'Сергеевна',     'HR Business Partner',                          'HR',                             'editor', '10-03', false, 'Москва'),
    (2,  'ilya.kuznetsov',      'Илья',      'Кузнецов',    'Иванович',      'Backend Developer',                            'Разработка',                     'user',   '07-21', false, 'Казань'),
    (3,  'olga.vasilieva',      'Ольга',     'Васильева',   'Петровна',      'Финансовый директор',                          'Финансы',                        'user',   '11-02', true,  'Москва'),
    (4,  'dmitry.fedorov',      'Дмитрий',   'Фёдоров',     'Андреевич',     'Руководитель отдела продаж',                   'Продажи',                        'user',   '05-30', true,  'Санкт-Петербург'),
    (5,  'maria.orlova',        'Мария',     'Орлова',      'Викторовна',    'Менеджер по корпоративным коммуникациям',      'Корпоративные коммуникации',     'editor', '10-01', true,  'Москва'),
    (6,  'sergey.volkov',       'Сергей',    'Волков',      'Николаевич',    'Product Manager',                              'IT и цифровая трансформация',    'editor', '01-17', false, 'Москва'),
    (7,  'natalia.belova',      'Наталья',   'Белова',      'Дмитриевна',    'Финансовый аналитик',                          'Финансовое планирование',        'user',   '09-09', false, 'Москва'),
    (8,  'andrey.novikov',      'Андрей',    'Новиков',     'Павлович',      'Генеральный директор',                         'Генеральная дирекция',           'user',   '04-04', true,  'Москва'),
    (9,  'tatiana.lebedeva',    'Татьяна',   'Лебедева',    'Михайловна',    'Директор по персоналу',                        'HR и корпоративные коммуникации','user',   '12-12', true,  'Москва'),
    (10, 'pavel.kozlov',        'Павел',     'Козлов',      'Александрович', 'Frontend Developer',                           'Разработка',                     'user',   '10-05', false, 'Санкт-Петербург'),
    (11, 'ekaterina.morozova',  'Екатерина', 'Морозова',    'Сергеевна',     'QA Engineer',                                  'Разработка',                     'user',   '02-27', false, 'Казань'),
    (12, 'vladimir.popov',      'Владимир',  'Попов',       'Иванович',      'DevOps Engineer',                              'Инфраструктура',                 'user',   '06-15', false, 'Новосибирск'),
    (13, 'anastasia.smirnova',  'Анастасия', 'Смирнова',    'Петровна',      'Data Analyst',                                 'Аналитика',                      'user',   '08-08', false, 'Москва'),
    (14, 'yulia.kuzmina',       'Юлия',      'Кузьмина',    'Андреевна',     'Главный бухгалтер',                            'Бухгалтерия',                    'user',   '03-03', false, 'Москва'),
    (15, 'alexander.solovyov',  'Александр', 'Соловьёв',     'Викторович',    'Бухгалтер',                                    'Бухгалтерия',                    'user',   '10-20', false, 'Москва'),
    (16, 'irina.grigorieva',    'Ирина',     'Григорьева',  'Николаевна',    'Менеджер по работе с ключевыми клиентами',     'Ключевые клиенты',               'user',   '11-23', false, 'Санкт-Петербург'),
    (17, 'maxim.zaitsev',       'Максим',    'Зайцев',      'Дмитриевич',    'Региональный менеджер',                        'Региональные продажи',           'user',   '09-30', false, 'Новосибирск'),
    (18, 'anna.petrova',        'Анна',      'Петрова',     'Павловна',      'Специалист по подбору персонала',              'HR',                             'user',   '10-12', false, 'Москва'),
    (19, 'roman.borisov',       'Роман',     'Борисов',     'Михайлович',    'Системный администратор',                      'Инфраструктура',                 'user',   '05-05', false, 'Казань'),
    (20, 'victoria.krylova',    'Виктория',  'Крылова',     'Александровна', 'Корпоративный юрист',                          'Администрация',                  'user',   '07-07', false, 'Москва'),
    (21, 'nikolay.orlov',       'Николай',   'Орлов',       'Сергеевич',     'Руководитель направления стратегии',           'Стратегия',                      'user',   '12-30', true,  'Москва'),
    (22, 'svetlana.medvedeva',  'Светлана',  'Медведева',   'Ивановна',      'Офис-менеджер',                                'Администрация',                  'user',   '01-29', false, 'Москва'),
    (23, 'artem.zhukov',        'Артём',     'Жуков',       'Петрович',      'Менеджер по продажам',                         'Ключевые клиенты',               'user',   '10-27', false, 'Санкт-Петербург'),
    (24, 'daria.komarova',      'Дарья',     'Комарова',    'Андреевна',     'Дизайнер интерфейсов',                         'IT и цифровая трансформация',    'user',   '04-18', false, 'Москва'),
    (25, 'kirill.shcherbakov',  'Кирилл',    'Щербаков',    'Викторович',    'Системный аналитик',                           'Аналитика',                      'user',   '06-02', false, 'Москва'),
    (26, 'polina.egorova',      'Полина',    'Егорова',     'Николаевна',    'SMM-менеджер',                                 'Корпоративные коммуникации',     'user',   '08-21', false, 'Казань'),
    (27, 'grigory.tikhonov',    'Григорий',  'Тихонов',     'Дмитриевич',    'Менеджер по продажам',                         'Региональные продажи',           'user',   '02-14', false, 'Новосибирск'),
    (28, 'alina.frolova',       'Алина',     'Фролова',     'Павловна',      'Специалист по обучению',                       'HR',                             'user',   '11-11', false, 'Москва'),
    (29, 'egor.antonov',        'Егор',      'Антонов',     'Михайлович',    'Руководитель отдела разработки',               'Разработка',                     'user',   '09-19', true,  'Москва'),
    (30, 'larisa.dmitrieva',    'Лариса',    'Дмитриева',   'Александровна', 'Экономист',                                    'Финансовое планирование',        'user',   '03-25', false, 'Москва'),
    (31, 'boris.korolev',       'Борис',     'Королёв',     'Сергеевич',     'Специалист по информационной безопасности',    'Инфраструктура',                 'user',   '12-05', false, 'Санкт-Петербург'),
    (32, 'valeria.kiseleva',    'Валерия',   'Киселёва',    'Ивановна',      'Бизнес-аналитик',                              'Аналитика',                      'user',   '07-30', false, 'Москва'),
    (33, 'fedor.makarov',       'Фёдор',     'Макаров',     'Петрович',      'Менеджер по закупкам',                         'Администрация',                  'user',   '05-18', false, 'Москва'),
    (34, 'oksana.bogdanova',    'Оксана',    'Богданова',   'Андреевна',     'Руководитель проектов',                        'IT и цифровая трансформация',    'user',   '10-08', false, 'Казань')
) AS v(i, login, fn, ln, mn, title, dept, role, bday, head, branch)
JOIN departments d ON d.name = v.dept;

UPDATE users SET department_id = (SELECT id FROM departments WHERE name = 'IT и цифровая трансформация'), is_head = true WHERE login = 'admin';

INSERT INTO calendars (name, kind, owner_id, visibility, color)
    SELECT 'Мой календарь', 'personal', id, 'restricted', '#286b9e' FROM users WHERE login <> 'admin';

UPDATE departments d SET head_id = u.id FROM users u WHERE (d.name, u.login) IN (
    ('Генеральная дирекция', 'andrey.novikov'), ('IT и цифровая трансформация', 'admin'), ('HR и корпоративные коммуникации', 'tatiana.lebedeva'),
    ('Финансы', 'olga.vasilieva'), ('Продажи', 'dmitry.fedorov'), ('Разработка', 'egor.antonov'), ('Корпоративные коммуникации', 'maria.orlova'));

-- ---- новости (одна отложена, одна — черновик)
INSERT INTO news (title, summary, body, category_id, author_id, cover, important, pinned, status, department_id, direction_id, published_at, views_count)
SELECT v.title, v.summary, v.body, c.id, u.id, '', v.imp, v.pin, v.status, u.department_id, dr.id,
       now() + v.shift, 40 + (v.i * 37) % 260
FROM (VALUES
    (1, 'Компания запускает новую программу развития сотрудников',
        'Бесплатное обучение, менторство и внутренние карьерные треки для всех подразделений стартуют с октября.',
        E'С 1 октября в компании стартует программа развития сотрудников. Она объединяет профессиональное обучение, наставничество и карьерные треки внутри подразделений.\n\n## Что входит в программу\n\n- Бюджет на внешнее обучение: до 60 000 ₽ на сотрудника в год\n- Внутренние курсы и мастер-классы от коллег-экспертов\n- Индивидуальный план развития, согласованный с руководителем\n- Доступ к библиотеке онлайн-курсов\n\nЗаявки принимаются через HR Business Partner вашего подразделения.',
        'HR', 'elena.sokolova', true, true, 'published', 'HR', NULL, interval '-2 hours'),
    (2, 'Обновление корпоративного портала',
        'Новый интерфейс, быстрый поиск, мессенджер и календарь — всё в одном месте.',
        E'Мы обновили корпоративный портал: он стал заметно быстрее, а поиск теперь работает по новостям, сотрудникам, подразделениям и документам одновременно.\n\n## Что нового\n\n- Мессенджер с личными и групповыми чатами\n- Календари с повторяющимися событиями\n- Комментарии и реакции под новостями\n- Уведомления в реальном времени\n\nИдеи по улучшению — в группу **IT Community**.',
        'Компания', 'sergey.volkov', true, false, 'published', 'IT', NULL, interval '-21 hours'),
    (3, 'Осенний корпоративный турнир',
        'Футбол, настольный теннис и киберспорт: регистрируйте команды до 10 октября.',
        E'Приглашаем всех сотрудников принять участие в осеннем корпоративном турнире. Соревнования пройдут в субботу на спортивной площадке рядом с офисом.\n\nДисциплины: мини-футбол, настольный теннис, дартс и киберспортивный турнир.',
        'Мероприятия', 'maria.orlova', false, false, 'published', NULL, NULL, interval '-40 hours'),
    (4, 'Новый проект: автоматизация внутренних заявок',
        'Единая система заявок заменит почту и таблицы: пилот запускаем в ноябре.',
        E'Команда цифровой трансформации начинает проект по автоматизации внутренних заявок: на IT-поддержку, закупки, доступы и командировки.\n\nЦель — сократить среднее время обработки заявки с трёх рабочих дней до одного.',
        'Проекты', 'sergey.volkov', false, false, 'published', 'IT', NULL, interval '-59 hours'),
    (5, 'Изменение графика работы офиса',
        'С 15 октября офис открывается в 8:00 и закрывается в 20:00.',
        E'По результатам опроса сотрудников мы расширяем часы работы офиса: с 15 октября он будет открыт с 8:00 до 20:00 в будние дни.',
        'Компания', 'svetlana.medvedeva', false, false, 'published', NULL, 'Москва', interval '-78 hours'),
    (6, 'Итоги квартала и планы подразделений',
        'Выручка выросла на 18%, три ключевых проекта завершены в срок.',
        E'Подведены итоги третьего квартала. Выручка компании выросла на 18% по сравнению с аналогичным периодом прошлого года, операционная маржа — на 2,4 п.п.\n\n## Ключевые достижения\n\n- Запущено два новых продукта\n- Завершена миграция инфраструктуры\n- Реализована программа адаптации новых сотрудников',
        'Компания', 'natalia.belova', true, false, 'published', 'Финансы', NULL, interval '-97 hours'),
    (7, 'Казанский офис: новое помещение',
        'С декабря команда Казани переезжает в новый бизнес-центр.',
        E'Команда казанского филиала переезжает в новый бизнес-центр. Рабочие места, переговорные и зона отдыха уже готовятся; подробности — у офис-менеджера.',
        'Компания', 'ilya.kuznetsov', false, false, 'published', NULL, 'Казань', interval '-116 hours'),
    (8, 'Обновлены материалы базы знаний',
        'Актуализированы регламенты по информационной безопасности и работе с клиентами.',
        E'Мы обновили материалы базы знаний: актуализированы регламенты по информационной безопасности и работе с персональными данными. Просим ознакомиться до конца месяца.',
        'IT', 'boris.korolev', false, false, 'published', 'IT', NULL, interval '-135 hours'),
    (9, 'Корпоративный день открытых дверей',
        'Приглашаем сотрудников с семьями познакомиться с офисом и командами.',
        E'В субботу в главном офисе пройдёт день открытых дверей. Для детей подготовлена творческая программа, для взрослых — экскурсии по подразделениям.',
        'Мероприятия', 'maria.orlova', false, false, 'published', NULL, 'Москва', interval '-154 hours'),
    (10, 'Итоги внутреннего опроса',
        '87% сотрудников довольны условиями работы. Главная точка роста — внутренние коммуникации.',
        E'Завершился ежегодный опрос вовлечённости. В нём приняли участие 94% сотрудников. Уровень удовлетворённости условиями работы составил 87%.',
        'HR', 'admin', false, false, 'published', 'HR', NULL, interval '-173 hours'),
    (11, 'График праздничных мероприятий (запланировано)',
        'Новогодний корпоратив, детский утренник и благотворительная ярмарка — даты уже известны.',
        E'Мы подготовили график праздничных мероприятий на конец года. Эта публикация запланирована и появится в ленте автоматически.',
        'Мероприятия', 'polina.egorova', false, false, 'published', NULL, NULL, interval '3 days'),
    (12, 'Черновик: регламент командировок',
        'Работа над новым регламентом ещё идёт.', E'Черновик нового регламента командировок.',
        'HR', 'anna.petrova', false, false, 'draft', 'HR', NULL, interval '0 hours')
) AS v(i, title, summary, body, cat, author, imp, pin, status, dir, branch, shift)
JOIN categories c ON c.name = v.cat
JOIN users u ON u.login = v.author
LEFT JOIN directions dr ON dr.name = v.dir AND dr.parent_id IS NULL;
UPDATE news SET announced = true WHERE status = 'published' AND published_at <= now();

-- ---- история версий и комментарии к редакциям
INSERT INTO news_revisions (news_id, version, title, summary, body, cover, category_id, department_id, status, published_at, change_note, author_id)
SELECT n.id, 1, n.title, n.summary, n.body, n.cover, n.category_id, n.department_id, n.status, n.published_at, 'Первая публикация', n.author_id FROM news n;
INSERT INTO news_revisions (news_id, version, title, summary, body, cover, category_id, department_id, status, published_at, change_note, author_id)
SELECT n.id, 2, n.title, n.summary, n.body || E'\n\nПодробности и шаблоны — в разделе «Документы».', n.cover, n.category_id, n.department_id, n.status, n.published_at,
       'Добавлена ссылка на документы', n.author_id FROM news n WHERE n.title LIKE 'Компания запускает%';
INSERT INTO news_revision_comments (version_id, author_id, body)
SELECT r.id, (SELECT id FROM users WHERE login = 'admin'), 'Проверьте формулировку про бюджет на обучение перед публикацией.'
FROM news_revisions r JOIN news n ON n.id = r.news_id WHERE n.title LIKE 'Компания запускает%' AND r.version = 1;

-- ---- аналитика чтения и показов
INSERT INTO news_read_stats (news_id, user_id, max_depth, seconds, opens)
SELECT n.id, u.id, 20 + ((n.id * 13 + u.id * 7) % 81), 15 + ((n.id * 29 + u.id * 11) % 240), 1 + (n.id + u.id) % 3
FROM news n JOIN users u ON (n.id * 5 + u.id) % 3 <> 0 WHERE n.status = 'published' AND n.published_at <= now();
INSERT INTO news_feed_impressions (news_id, day, impressions, clicks)
SELECT n.id, current_date - g, 20 + ((n.id * 17 + g * 5) % 60), 3 + ((n.id * 3 + g) % 25)
FROM news n CROSS JOIN generate_series(0, 6) g WHERE n.status = 'published' AND n.published_at <= now();
INSERT INTO news_category_clicks (category_id, day, clicks)
SELECT c.id, current_date - g, 5 + ((c.id * 7 + g * 3) % 30) FROM categories c CROSS JOIN generate_series(0, 6) g;

-- ---- реакции и комментарии к новостям
INSERT INTO reactions (entity_type, entity_id, user_id, emoji)
    SELECT 'news', n.id, u.id, '👍' FROM news n JOIN users u ON (n.id * 7 + u.id) % 3 = 0 WHERE n.status = 'published';
UPDATE news n SET likes_count = (SELECT count(*) FROM reactions l WHERE l.entity_type = 'news' AND l.entity_id = n.id AND l.emoji = '👍');
INSERT INTO comments (entity_type, entity_id, user_id, body, created_at)
    SELECT 'news', n.id, u.id, v.body, now() - interval '3 hours' * v.k
    FROM (VALUES
        ('Компания запускает%', 'ilya.kuznetsov', 'Отличная инициатива! Можно ли использовать бюджет на зарубежные конференции?', 1),
        ('Компания запускает%', 'pavel.kozlov', 'Супер, давно ждали такого формата.', 2),
        ('Обновление корпоративного%', 'vladimir.popov', 'Поиск стал реально быстрее, спасибо команде!', 3),
        ('Осенний корпоративный%', 'artem.zhukov', 'Записываем сборную отдела продаж!', 4)
    ) AS v(t, login, body, k) JOIN news n ON n.title LIKE v.t JOIN users u ON u.login = v.login;
UPDATE news n SET comments_count = (SELECT count(*) FROM comments c WHERE c.entity_type = 'news' AND c.entity_id = n.id AND c.deleted_at IS NULL);

-- ---- группы
INSERT INTO user_groups (name, description, visibility, owner_id)
    SELECT v.n, v.d, 'public', u.id FROM (VALUES
        ('IT Community', 'Обсуждение технологий, архитектуры и разработки', 'admin'),
        ('Корпоративные коммуникации', 'Новости компании и внутренние мероприятия', 'maria.orlova'),
        ('Спорт и активный отдых', 'Турниры, секции и совместные тренировки', 'artem.zhukov')) AS v(n, d, owner) JOIN users u ON u.login = v.owner;
INSERT INTO group_members (group_id, user_id, role)
    SELECT g.id, u.id, 'owner' FROM user_groups g JOIN users u ON u.id = g.owner_id;
INSERT INTO group_members (group_id, user_id, role)
    SELECT g.id, u.id, 'member' FROM user_groups g JOIN users u ON u.login <> 'admin'
    WHERE (g.id + u.id) % 4 = 0 AND u.id <> g.owner_id;
INSERT INTO group_posts (group_id, user_id, body)
    SELECT g.id, g.owner_id, v.body FROM user_groups g JOIN (VALUES
        ('IT Community', 'Коллеги, делимся полезными ссылками и докладами с последних конференций. Что смотрели интересного?'),
        ('IT Community', 'В пятницу в 16:00 — внутренний митап по Go и PostgreSQL. Приходите, будет практика!'),
        ('Корпоративные коммуникации', 'Готовим материалы к осеннему дню открытых дверей. Нужны фотографии с прошлых мероприятий!')) AS v(n, body) ON v.n = g.name;

-- ---- события общего календаря
INSERT INTO events (calendar_id, title, description, location, starts_at, ends_at, all_day, creator_id)
    SELECT c.id, v.t, v.d, v.l,
           date_trunc('day', now()) + v.day * interval '1 day' + v.h * interval '1 hour',
           date_trunc('day', now()) + v.day * interval '1 day' + (v.h + v.dur) * interval '1 hour', false, u.id
    FROM (VALUES
        ('Мероприятия', 'Осенний корпоративный турнир', 'Футбол, настольный теннис, дартс', 'Спортивная площадка у офиса', 3, 11, 5),
        ('Мероприятия', 'День открытых дверей', 'Экскурсии по подразделениям', 'Главный офис', 6, 12, 4),
        ('Видеоконференции', 'Итоги квартала: планы подразделений', 'Видеоконференция руководителей', 'Видеоконференция', 1, 15, 1),
        ('Видеоконференции', 'Планёрка IT', 'Еженедельная планёрка', 'Переговорная 2', 2, 10, 1)
    ) AS v(cal, t, d, l, day, h, dur) JOIN calendars c ON c.name = v.cal JOIN users u ON u.login = 'maria.orlova';

-- ---- график отпусков (общий календарь по умолчанию создаётся схемой)
INSERT INTO vacations (user_id, starts_on, ends_on, deputy_id, city, note, created_by, calendar_id)
    SELECT u.id, current_date + v.s, current_date + v.s + v.len, d.id, v.city, '', a.id, (SELECT id FROM vac_calendars WHERE is_default LIMIT 1)
    FROM (VALUES ('andrey.novikov', 10, 13, 'olga.vasilieva', 'Сочи'), ('olga.vasilieva', 30, 13, 'natalia.belova', 'Казань'),
                 ('dmitry.fedorov', 45, 9, 'irina.grigorieva', 'Санкт-Петербург'), ('tatiana.lebedeva', 60, 13, 'elena.sokolova', 'Калининград'),
                 ('egor.antonov', 20, 6, 'ilya.kuznetsov', 'Новосибирск')) AS v(login, s, len, deputy, city)
    JOIN users u ON u.login = v.login JOIN users d ON d.login = v.deputy JOIN users a ON a.login = 'tatiana.lebedeva';

-- ---- идеи
INSERT INTO ideas (title, body, author_id, status)
    SELECT v.t, v.b, u.id, 'new' FROM (VALUES
        ('Тёмная тема портала', 'Добавить тёмную тему оформления для работы в вечернее время.', 'pavel.kozlov'),
        ('Электронная очередь в столовую', 'Предлагаю сделать бронирование времени обеда через портал.', 'svetlana.medvedeva'),
        ('Ежемесячный день без совещаний', 'Один день в месяц — только глубокая работа.', 'egor.antonov')) AS v(t, b, login) JOIN users u ON u.login = v.login;
-- ---- модули ТЗ: аудитории, адаптация, опросы, «Спросите директора»
-- Демо-данные модулей ТЗ: аудитории, чек-лист адаптации, опросы, «Спросите директора».
-- Идемпотентно: повторный запуск ничего не дублирует.

INSERT INTO audiences (name, description, rules)
SELECT * FROM (VALUES
  ('Новички (до 90 дней)', 'Сотрудники, работающие меньше трёх месяцев', '{"newbies": true}'::jsonb),
  ('Руководители', 'Руководители подразделений', '{"roles": ["editor"]}'::jsonb),
  ('Стаж более года', 'Сотрудники со стажем от 365 дней', '{"tenure_min_days": 365}'::jsonb)
) v(name, description, rules)
WHERE NOT EXISTS (SELECT 1 FROM audiences a WHERE a.name = v.name);

-- демо: часть сотрудников — новички, у них назначены наставники
UPDATE users SET hire_date = current_date - (id % 40)::int WHERE hire_date IS NULL AND id % 7 = 0;
UPDATE users SET hire_date = current_date - (400 + id * 13 % 2000)::int WHERE hire_date IS NULL;
UPDATE users SET mentor_id = (SELECT m.id FROM users m WHERE m.department_id = users.department_id AND m.id <> users.id AND m.hire_date < current_date - 365 ORDER BY m.id LIMIT 1)
 WHERE mentor_id IS NULL AND hire_date > current_date - 90;

INSERT INTO ob_templates (name, description, audience_id, duration_days)
SELECT 'Адаптация нового сотрудника', 'Первые 90 дней: знакомство, документы, обучение, обратная связь',
       (SELECT id FROM audiences WHERE name = 'Новички (до 90 дней)'), 90
WHERE NOT EXISTS (SELECT 1 FROM ob_templates WHERE name = 'Адаптация нового сотрудника');

INSERT INTO ob_items (template_id, sort, section, title, description, link, assignee, due_day, auto_event)
SELECT t.id, v.sort, v.section, v.title, v.descr, v.link, v.assignee, v.due, v.ev
FROM ob_templates t, (VALUES
  (1,'Первая неделя','Заполните профиль','Фото, телефон, дата рождения, должность — коллегам проще вас найти','/settings','employee',3,'profile_fill'),
  (2,'Первая неделя','Расскажите о себе в «Знакомьтесь»','Короткий рассказ о себе увидят все сотрудники','/onboarding','employee',5,'intro'),
  (3,'Первая неделя','Познакомьтесь с наставником','Назначьте первую встречу','/people','employee',2,''),
  (4,'Первая неделя','Выдать рабочее место и доступы','Компьютер, почта, пропуск, учётные записи','','hr',1,''),
  (5,'Первая неделя','Провести вводную встречу с командой','Цели подразделения, роли, процессы','','manager',3,''),
  (6,'Первый месяц','Пройдите вводный курс','Структура компании, ценности, безопасность','/learning','employee',14,''),
  (7,'Первый месяц','Ознакомьтесь с обязательными документами','Правила, политики, охрана труда','/must-read','employee',10,''),
  (8,'Первый месяц','Встреча 1:1 с наставником','Что получается, какие вопросы','','mentor',21,''),
  (9,'Первый месяц','Согласовать план на испытательный срок','Цели и критерии успеха','','manager',14,''),
  (10,'Три месяца','Итоговая встреча по адаптации','Обратная связь двусторонняя','','manager',80,'')
) v(sort, section, title, descr, link, assignee, due, ev)
WHERE t.name = 'Адаптация нового сотрудника' AND NOT EXISTS (SELECT 1 FROM ob_items i WHERE i.template_id = t.id);

INSERT INTO sv_surveys (title, description, kind, anonymity, status, audience_id, onboarding_day, min_group)
SELECT 'Как проходит ваша адаптация?', 'Короткий опрос на 30-й день работы. Ответы анонимны.', 'onboarding', 'anonymous', 'active',
       (SELECT id FROM audiences WHERE name = 'Новички (до 90 дней)'), 30, 5
WHERE NOT EXISTS (SELECT 1 FROM sv_surveys WHERE title = 'Как проходит ваша адаптация?');
INSERT INTO sv_surveys (title, description, kind, anonymity, status, min_group)
SELECT 'Пульс-опрос: настроение в команде', 'Три вопроса, минута времени. Ответы анонимны, срезы показываются от 5 ответов.', 'pulse', 'anonymous', 'active', 5
WHERE NOT EXISTS (SELECT 1 FROM sv_surveys WHERE title = 'Пульс-опрос: настроение в команде');

INSERT INTO sv_questions (survey_id, sort, kind, title, options, required)
SELECT s.id, v.sort, v.kind, v.title, v.opts::jsonb, v.req FROM sv_surveys s, (VALUES
  ('Как проходит ваша адаптация?',1,'rating','Насколько вам комфортно в команде?','[]',true),
  ('Как проходит ваша адаптация?',2,'single','Хватает ли информации для работы?','["Да, вполне","Не хватает отдельных тем","Не хватает многого"]',true),
  ('Как проходит ваша адаптация?',3,'text','Что бы вы улучшили в адаптации?','[]',false),
  ('Пульс-опрос: настроение в команде',1,'scale','Оцените своё настроение на работе (1–10)','[]',true),
  ('Пульс-опрос: настроение в команде',2,'nps','Порекомендуете ли вы нашу компанию как место работы?','[]',true),
  ('Пульс-опрос: настроение в команде',3,'text','Что вас сейчас больше всего беспокоит?','[]',false)
) v(sv, sort, kind, title, opts, req)
WHERE s.title = v.sv AND NOT EXISTS (SELECT 1 FROM sv_questions q WHERE q.survey_id = s.id);

UPDATE qa_config SET responder_ids = (SELECT array_agg(id) FROM users WHERE role = 'admin') WHERE id = 1 AND responder_ids = '{}';
UPDATE fb_topics SET handler_ids = (SELECT array_agg(id) FROM users WHERE role = 'admin') WHERE handler_ids = '{}';

INSERT INTO qa_questions (author_id, anonymous, topic, question, status, answer, answered_by, answered_at, votes)
SELECT (SELECT id FROM users WHERE role <> 'admin' ORDER BY id LIMIT 1), false, 'Развитие', 'Планируется ли в этом году компенсация обучения и конференций?', 'answered',
       'Да, бюджет на обучение сохранён: заявки принимаются через раздел «Сервисы». Подробности — в новости об изменениях в социальном пакете.',
       (SELECT id FROM users WHERE role = 'admin' ORDER BY id LIMIT 1), now() - interval '2 days', 14
WHERE NOT EXISTS (SELECT 1 FROM qa_questions);


-- ---- тестовые фото (лежат в frontend/public/demo): аватары — звери в пиджаках, обложки новостей — цветные иллюстрации
UPDATE users SET avatar = '/demo/avatars/' || ((id - 1) % 34 + 1) || '.jpg' WHERE avatar = '';
UPDATE news SET cover = '/demo/covers/' || ((id - 1) % 12 + 1) || '.jpg' WHERE cover = '';
\endif
