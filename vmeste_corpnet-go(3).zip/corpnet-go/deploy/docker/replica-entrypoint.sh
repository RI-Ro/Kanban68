#!/bin/bash
# Реплика: при первом запуске снимает копию основной БД (pg_basebackup -R, слот site_b) и стартует в режиме standby.
set -euo pipefail
PGDATA=${PGDATA:-/var/lib/postgresql/data}
if [ ! -s "$PGDATA/PG_VERSION" ]; then
  echo "[replica] жду основную БД ${PRIMARY_HOST}…"
  until pg_isready -h "$PRIMARY_HOST" -U "$POSTGRES_USER" >/dev/null 2>&1; do sleep 2; done
  mkdir -p "$PGDATA"; chown postgres:postgres "$PGDATA"; chmod 700 "$PGDATA"
  echo "[replica] pg_basebackup со слотом site_b"
  PGPASSWORD="$REPL_PASSWORD" gosu postgres pg_basebackup -h "$PRIMARY_HOST" -U replicator -D "$PGDATA" -X stream -S site_b -R -P --checkpoint=fast
fi
chown -R postgres:postgres "$PGDATA"; chmod 700 "$PGDATA"
exec gosu postgres postgres -c config_file=/etc/postgresql/postgresql.conf
