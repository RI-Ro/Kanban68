#!/usr/bin/env bash
# Площадка A (главная): роль репликации, слот для площадки B и правило доступа в pg_hba.conf.
# Запускать на сервере БД площадки A от суперпользователя PostgreSQL (обычно: sudo -u postgres):
#   REPL_PASSWORD='длинный-пароль' ./pg-primary-init.sh --replica-net 10.20.0.0/24 [--slot site_b] [--db corpnet]
# Повторный запуск безопасен: уже созданное не пересоздаётся. HBA_TYPE=host — если TLS между площадками не используется (по умолчанию hostssl).
set -euo pipefail
SLOT=site_b; NET=""; DB=corpnet
while [ $# -gt 0 ]; do
  case "$1" in
    --replica-net) NET="$2"; shift 2 ;;
    --slot)        SLOT="$2"; shift 2 ;;
    --db)          DB="$2"; shift 2 ;;
    *) echo "неизвестный аргумент: $1" >&2; exit 2 ;;
  esac
done
: "${REPL_PASSWORD:?задайте REPL_PASSWORD}"; : "${NET:?укажите --replica-net <подсеть площадки B, например 10.20.0.0/24>}"
PSQL=(psql -X -q -v ON_ERROR_STOP=1 -d postgres)

"${PSQL[@]}" -v pw="$REPL_PASSWORD" -v slot="$SLOT" <<'SQL'
SELECT format('CREATE ROLE replicator WITH REPLICATION LOGIN PASSWORD %L', :'pw')
 WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'replicator') \gexec
SELECT format('ALTER ROLE replicator WITH PASSWORD %L', :'pw')
 WHERE EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'replicator') \gexec
SELECT format('SELECT pg_create_physical_replication_slot(%L)', :'slot')
 WHERE NOT EXISTS (SELECT 1 FROM pg_replication_slots WHERE slot_name = :'slot') \gexec
SQL

HBA=$("${PSQL[@]}" -tA -c 'SHOW hba_file')
add() { grep -qxF "$1" "$HBA" || echo "$1" >> "$HBA"; }
add "# --- Вместе: репликация и работа площадки B (pg-primary-init.sh)"
add "${HBA_TYPE:-hostssl} replication replicator $NET scram-sha-256"
add "${HBA_TYPE:-hostssl} $DB          corpnet    $NET scram-sha-256"
"${PSQL[@]}" -c 'SELECT pg_reload_conf()' >/dev/null
echo "готово: роль replicator, слот $SLOT, правила pg_hba.conf для $NET (файл $HBA)"
"${PSQL[@]}" -c "SELECT slot_name, slot_type, active FROM pg_replication_slots"
