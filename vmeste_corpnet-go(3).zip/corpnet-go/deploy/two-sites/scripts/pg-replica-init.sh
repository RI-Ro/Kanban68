#!/usr/bin/env bash
# Площадка B: первичная заливка реплики с основной БД площадки A (pg_basebackup) и запуск в режиме standby.
# Запускать на сервере БД площадки B от пользователя postgres, при ОСТАНОВЛЕННОМ PostgreSQL и ПУСТОМ каталоге данных:
#   REPL_PASSWORD='...' ./pg-replica-init.sh --primary 10.10.0.10 --pgdata /var/lib/postgresql/16/main [--port 5432] [--slot site_b]
# Каталог данных очищается скриптом только если указан --force.
set -euo pipefail
HOST=""; PGDATA=""; PORT=5432; SLOT=site_b; FORCE=no; SSLMODE=${SSLMODE:-prefer}
while [ $# -gt 0 ]; do
  case "$1" in
    --primary) HOST="$2"; shift 2 ;;
    --pgdata)  PGDATA="$2"; shift 2 ;;
    --port)    PORT="$2"; shift 2 ;;
    --slot)    SLOT="$2"; shift 2 ;;
    --force)   FORCE=yes; shift ;;
    *) echo "неизвестный аргумент: $1" >&2; exit 2 ;;
  esac
done
: "${REPL_PASSWORD:?задайте REPL_PASSWORD}"; : "${HOST:?--primary}"; : "${PGDATA:?--pgdata}"
if [ -d "$PGDATA" ] && [ -n "$(ls -A "$PGDATA" 2>/dev/null)" ]; then
  [ "$FORCE" = yes ] || { echo "каталог $PGDATA не пуст; остановите PostgreSQL и повторите с --force (данные будут удалены)" >&2; exit 1; }
  find "$PGDATA" -mindepth 1 -delete
fi
mkdir -p "$PGDATA"; chmod 700 "$PGDATA"
export PGPASSWORD="$REPL_PASSWORD" PGSSLMODE="$SSLMODE"
# -R: создаёт standby.signal и primary_conninfo; -S: использовать слот (WAL не потеряется при обрыве связи); -X stream: WAL во время копирования
pg_basebackup -h "$HOST" -p "$PORT" -U replicator -D "$PGDATA" -X stream -S "$SLOT" -R -P --checkpoint=fast
echo "заливка завершена. Положите 99-vmeste.conf в conf.d/ и запустите PostgreSQL: он стартует в режиме реплики (standby.signal)."
