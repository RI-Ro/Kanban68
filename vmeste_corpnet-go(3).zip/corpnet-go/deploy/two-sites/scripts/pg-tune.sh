#!/usr/bin/env bash
# Генератор postgresql-настроек под железо. Печатает drop-in файл для conf.d/ (его потом кладут как 99-vmeste.conf).
#   ./pg-tune.sh --ram-gb 16 --cpu 8 [--role primary|replica] [--ssd yes|no] [--max-conn 200] > 99-vmeste.conf
# Формулы — типовые для OLTP-веб-приложения (портал: много коротких запросов, чтений в десятки раз больше записей).
set -euo pipefail
RAM=16; CPU=8; ROLE=primary; SSD=yes; MAXC=200
while [ $# -gt 0 ]; do
  case "$1" in
    --ram-gb)   RAM="$2"; shift 2 ;;
    --cpu)      CPU="$2"; shift 2 ;;
    --role)     ROLE="$2"; shift 2 ;;
    --ssd)      SSD="$2"; shift 2 ;;
    --max-conn) MAXC="$2"; shift 2 ;;
    *) echo "неизвестный аргумент: $1" >&2; exit 2 ;;
  esac
done
[[ "$ROLE" == primary || "$ROLE" == replica ]] || { echo "--role primary|replica" >&2; exit 2; }
# shared_buffers = 25% ОЗУ (не более 16 ГБ), effective_cache_size = 70%, work_mem = ОЗУ*25% / соединения / 3 (в пределах 8..64 МБ)
SB=$(( RAM * 1024 / 4 )); [ $SB -gt 16384 ] && SB=16384
ECS=$(( RAM * 1024 * 70 / 100 ))
WM=$(( RAM * 1024 * 25 / 100 / MAXC / 3 )); [ $WM -lt 8 ] && WM=8; [ $WM -gt 64 ] && WM=64
[ "$ROLE" = replica ] && WM=$(( WM * 2 > 64 ? 64 : WM * 2 ))   # на реплике — тяжёлое чтение (ленты, поиск, аналитика)
MWM=$(( RAM * 1024 / 16 )); [ $MWM -gt 2048 ] && MWM=2048
MAXWAL=$(( RAM / 2 )); [ $MAXWAL -lt 2 ] && MAXWAL=2; [ $MAXWAL -gt 32 ] && MAXWAL=32
RPC=1.1; EIO=200; [ "$SSD" = no ] && { RPC=4.0; EIO=2; }
PW=$(( CPU < 2 ? 1 : 2 ))
cat <<CONF
# ---- Вместе: PostgreSQL ($ROLE), рассчитано pg-tune.sh: ОЗУ ${RAM} ГБ, ${CPU} ядер, SSD=${SSD}, соединений ${MAXC}
# Файл кладётся в conf.d/ (в postgresql.conf должно быть include_dir = 'conf.d'); перезапуск: systemctl restart postgresql

# --- соединения и память
listen_addresses = '*'                    # доступ ограничивает pg_hba.conf и межсетевой экран
max_connections = ${MAXC}                 # приложение держит PG_POOL_MAX (по умолчанию 12) на экземпляр и на каждый пул (основной + реплика)
shared_buffers = ${SB}MB
effective_cache_size = ${ECS}MB
work_mem = ${WM}MB
maintenance_work_mem = ${MWM}MB
huge_pages = try
temp_file_limit = 10GB

# --- журнал WAL и контрольные точки
wal_level = replica
wal_compression = on
wal_buffers = 64MB
max_wal_size = ${MAXWAL}GB
min_wal_size = 1GB
checkpoint_timeout = 15min
checkpoint_completion_target = 0.9

# --- репликация
max_wal_senders = 10
max_replication_slots = 10
wal_keep_size = 4GB                       # запас на случай обрыва связи между площадками (слот хранит ещё больше)
max_slot_wal_keep_size = 50GB             # предел: брошенный слот не должен заполнить диск
hot_standby = on
hot_standby_feedback = on                 # запросы на реплике не отменяются из-за очистки на основной
max_standby_streaming_delay = 60s
max_standby_archive_delay = 60s
wal_receiver_timeout = 60s
wal_retrieve_retry_interval = 5s
# synchronous_standby_names = 'ANY 1 (site_b)'   # раскомментируйте, если нужна нулевая потеря данных (запись станет ждать связь)

# --- планировщик и диск
random_page_cost = ${RPC}
effective_io_concurrency = ${EIO}
default_statistics_target = 150
jit = off                                 # для коротких запросов портала JIT только мешает

# --- параллельность
max_worker_processes = ${CPU}
max_parallel_workers = ${CPU}
max_parallel_workers_per_gather = ${PW}
max_parallel_maintenance_workers = ${PW}

# --- автоочистка (таблицы уведомлений, сессий, событий меняются часто)
autovacuum = on
autovacuum_max_workers = 4
autovacuum_naptime = 20s
autovacuum_vacuum_scale_factor = 0.05
autovacuum_analyze_scale_factor = 0.02
autovacuum_vacuum_cost_limit = 1000

# --- устойчивость к обрывам и «зависшим» клиентам (связь между площадками — WAN)
tcp_keepalives_idle = 30
tcp_keepalives_interval = 10
tcp_keepalives_count = 6
idle_in_transaction_session_timeout = 60s
deadlock_timeout = 1s

# --- наблюдаемость (порог совпадает с SLOW_SQL_MS приложения)
shared_preload_libraries = 'pg_stat_statements'
track_io_timing = on
track_activity_query_size = 2048
pg_stat_statements.max = 10000
pg_stat_statements.track = top
log_min_duration_statement = 200ms
log_checkpoints = on
log_lock_waits = on
log_temp_files = 10MB
log_autovacuum_min_duration = 1s
log_connections = off
log_line_prefix = '%m [%p] %q%u@%d app=%a '
CONF
