#!/usr/bin/env bash
# Скрипт предназначен для сборки единого файла миграций deploy/migrations/kanban_deploy.sql
# из файлов backend/migrations/0*.sql (без 0004_seed.sql).
# Запуск из любого каталога: deploy/migrations/build.sh
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$DIR/../../backend/migrations"
OUT="$DIR/kanban_deploy.sql"

{
cat <<'HDR'
-- =====================================================================
-- Файл предназначен для развёртывания структуры базы данных одним запуском.
-- Содержит все миграции backend/migrations в порядке нумерации,
-- кроме 0004_seed.sql (демонстрационные данные, применяются отдельно).
-- Исходные файлы миграций сохранены без изменений.
--
-- Запуск на пустой базе суперпользователем PostgreSQL:
--     sudo -u postgres createdb kanban
--     sudo -u postgres psql -d kanban -v ON_ERROR_STOP=1 -f deploy/migrations/kanban_deploy.sql
--
-- Порядок выполнения:
--   1. 0001_roles.sql выполняется суперпользователем (создание ролей).
--   2. Ролям выдаётся доступ к текущей базе данных, создаются расширения и схема app.
--   3. Остальные миграции выполняются от имени app_owner (SET ROLE),
--      поэтому владельцем схемы, таблиц и SECURITY DEFINER-функций
--      становится app_owner.
--
-- Пароли ролей по умолчанию (change_me_owner, change_me_user) необходимо
-- заменить после применения: ALTER ROLE app_user PASSWORD '...';
--
-- Файл формируется скриптом deploy/migrations/build.sh, вручную не правится.
-- =====================================================================

\set ON_ERROR_STOP on
HDR
for f in "$SRC"/0*.sql; do
  n="$(basename "$f")"
  [ "$n" = "0004_seed.sql" ] && continue
  printf '\n-- #####################################################################\n'
  printf -- '-- Миграция %s\n' "$n"
  printf -- '-- #####################################################################\n\n'
  printf "\\\\echo '--> %s'\n\n" "$n"
  cat "$f"
  printf '\n'
  if [ "$n" = "0001_roles.sql" ]; then
cat <<'MID'

-- Выдача ролям доступа к текущей базе данных.
SELECT format('GRANT CONNECT ON DATABASE %I TO app_user, app_owner', current_database()) \gexec
SELECT format('GRANT CREATE ON DATABASE %I TO app_owner', current_database()) \gexec

-- Расширения создаются суперпользователем (схема public закрыта для app_owner),
-- схема app создаётся сразу с владельцем app_owner.
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE SCHEMA IF NOT EXISTS app AUTHORIZATION app_owner;
GRANT USAGE ON SCHEMA public TO app_owner;
SET ROLE app_owner;
MID
  fi
done
printf '\nRESET ROLE;\n'
} > "$OUT"
echo "Создан $OUT"
