// Модуль предназначен для настройки сборщика Vite: плагин React, порт dev-сервера, прокси к API и каталог сборки.

import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { brotliCompressSync, gzipSync, constants } from "node:zlib";
import { readdirSync, readFileSync, writeFileSync, statSync } from "node:fs";
import { join } from "node:path";

// Плагин precompress предназначен для предсжатия собранных файлов: рядом с каждым текстовым файлом > 1 КБ создаются .br (q11)
// и .gz (9), если они меньше оригинала. Сервер выбирает вариант по Accept-Encoding и не тратит CPU на сжатие при запросе.
function precompress() {
  let outDir = "dist";
  return {
    name: "precompress",
    apply: "build",
    configResolved(c) { outDir = c.build.outDir; },
    closeBundle() {
      const walk = (d) => readdirSync(d).flatMap((n) => {
        const p = join(d, n);
        return statSync(p).isDirectory() ? walk(p) : [p];
      });
      for (const f of walk(outDir)) {
        if (!/\.(js|css|html|svg|json|map|txt|webmanifest)$/.test(f)) continue;
        const buf = readFileSync(f);
        if (buf.length < 1024) continue;
        const br = brotliCompressSync(buf, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } });
        if (br.length < buf.length) writeFileSync(f + ".br", br);
        const gz = gzipSync(buf, { level: 9 });
        if (gz.length < buf.length) writeFileSync(f + ".gz", gz);
      }
    },
  };
}

export default defineConfig({
  plugins: [react(), precompress()],
  server: {
    port: 5173,
    proxy: {
      // Маршрут /api/ws указан первым: Vite выбирает первое совпадение по префиксу, а правило "/api" перехватывало бы
      // и WebSocket-соединение, передавая его в http-прокси без апгрейда протокола.
      "/api/ws": { target: "ws://localhost:8080", ws: true, changeOrigin: true },
      "/api": { target: "http://localhost:8080", changeOrigin: true },
    },
  },
  build: {
    outDir: "dist",
    // Карты кода не раздаются клиентам по умолчанию: они нужны только для отладки и увеличивают дистрибутив.
    sourcemap: false,
    chunkSizeWarningLimit: 700,
    rollupOptions: {
      output: {
        // Библиотеки выносятся в отдельные чанки: они меняются редко и годами лежат в кэше браузера.
        manualChunks(id) {
          if (!id.includes("node_modules")) return undefined;
          if (/node_modules\/(react|react-dom|scheduler)\//.test(id)) return "vendor-react";
          if (/node_modules\/xlsx\//.test(id)) return "vendor-xlsx";
          if (/node_modules\/lucide-react\//.test(id)) return "vendor-icons";
          return "vendor";
        },
      },
    },
  },
});
