// Модуль предназначен для преобразования JSX в обычный JS для проверок без сборщика: интерфейс целиком не собирается,
// строится один кадр разметки для обхода и проверки.
import fs from "fs";
import path from "path";
import { createRequire } from "module";

const require = createRequire(import.meta.url);
const SRC = path.join(import.meta.dirname, "..", "..", "src");
const OUT = path.join(import.meta.dirname, "build");

// Функция loadTypescript предназначена для загрузки компилятора TypeScript, используемого для преобразования JSX.
export async function loadTypescript() {
  for (const name of ["typescript", "esbuild"]) {
    try {
      return { name, mod: require(name) };
    } catch { /* ищем дальше */ }
  }
  return null;
}

const FILES = [
  ["lib/format.js", "format.mjs"],
  ["lib/charts.jsx", "charts.mjs"],
  ["components/System.jsx", "system.mjs"],
];

// Подмена импортов: вместо react, lucide-react и api.js подставляются заглушки харнесса.
const REWRITE = [
  [/from "react"/g, 'from "../react.mjs"'],
  [/from "lucide-react"/g, 'from "../icons.mjs"'],
  [/from "\.\/format\.js"/g, 'from "./format.mjs"'],
  [/from "\.\.\/lib\/format\.js"/g, 'from "./format.mjs"'],
  [/from "\.\.\/lib\/charts\.jsx"/g, 'from "./charts.mjs"'],
  [/from "\.\.\/lib\/api\.js"/g, 'from "../api.mjs"'],
];

// Функция build предназначена для сборки модулей, необходимых проверкам, в каталог tests/harness/build.
export async function build() {
  const found = await loadTypescript();
  if (!found) return null;
  fs.mkdirSync(OUT, { recursive: true });

  for (const [from, to] of FILES) {
    const code = fs.readFileSync(path.join(SRC, from), "utf8");
    let js;
    if (found.name === "typescript") {
      const ts = found.mod;
      const out = ts.transpileModule(code, {
        fileName: from, reportDiagnostics: true,
        compilerOptions: {
          jsx: ts.JsxEmit.React, module: ts.ModuleKind.ESNext,
          target: ts.ScriptTarget.ES2020,
        },
      });
      if (out.diagnostics?.length) {
        for (const d of out.diagnostics) {
          console.log("✗", from, ts.flattenDiagnosticMessageText(d.messageText, "\n"));
        }
        throw new Error("JSX не разбирается");
      }
      js = out.outputText;
    } else {
      js = found.mod.transformSync(code, { loader: "jsx", format: "esm" }).code;
    }
    for (const [re, sub] of REWRITE) js = js.replace(re, sub);
    fs.writeFileSync(path.join(OUT, to), js);
  }
  return OUT;
}
