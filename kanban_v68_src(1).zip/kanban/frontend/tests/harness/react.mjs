// Модуль предназначен для минимальной реализации React в харнессе: хуки возвращают начальные значения,
// элементы собираются в дерево, эффекты не выполняются.
let hookState = [];
let hookIdx = 0;

// Функция useState предназначена для возврата начального состояния.
export function useState(init) {
  const i = hookIdx++;
  if (!(i in hookState)) hookState[i] = typeof init === "function" ? init() : init;
  return [hookState[i], (v) => { hookState[i] = typeof v === "function" ? v(hookState[i]) : v; }];
}
// Функция useMemo предназначена для немедленного вычисления значения.
export function useMemo(fn) { return fn(); }
// Функция useRef предназначена для создания ссылки.
export function useRef(v) { return { current: v }; }
// Функция useCallback предназначена для возврата переданной функции.
export function useCallback(fn) { return fn; }
// Функция useEffect предназначена для заглушки эффекта (не выполняется).
export function useEffect() {}
// Функция createElement предназначена для создания узла дерева разметки.
export function createElement(type, props, ...children) {
  const kids = children.flat(Infinity).filter((c) => c != null && c !== false);
  // children передаются и свойством, как в React: иначе компонент-обёртка не видит вложенного содержимого.
  const merged = { ...(props || {}) };
  if (kids.length) merged.children = kids.length === 1 ? kids[0] : kids;
  return { type, props: merged, children: kids };
}
export const Fragment = "fragment";
// Функция resetHooks предназначена для сброса состояния хуков.
export function resetHooks(seed = []) { hookState = seed.slice(); hookIdx = 0; }

// Функция renderComponent предназначена для отрисовки компонента; каждый компонент получает своё состояние хуков.
export function renderComponent(type, props, seed = []) {
  const savedState = hookState;
  const savedIdx = hookIdx;
  hookState = seed.slice();
  hookIdx = 0;
  try {
    return type(props || {});
  } finally {
    hookState = savedState;
    hookIdx = savedIdx;
  }
}
export default { createElement, Fragment, useState, useMemo, useRef, useCallback, useEffect };
