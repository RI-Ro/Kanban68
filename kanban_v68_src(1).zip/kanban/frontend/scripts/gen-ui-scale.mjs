// Скрипт предназначен для генерации src/ui-scale.css: размеры произвольных значений Tailwind вида text-[14px], h-[36px]
// умножаются на --k (масштаб элементов пользователя × масштаб дизайна), а размеры шрифта — ещё и на --fs (размер шрифта). Запуск: node scripts/gen-ui-scale.mjs (перед сборкой, если менялись размеры в разметке).
import { readdirSync, readFileSync, writeFileSync, statSync } from "node:fs";
import { join } from "node:path";

const PROPS = {
  text: "font-size", w: "width", h: "height", "min-w": "min-width", "min-h": "min-height", "max-w": "max-width",
  "max-h": "max-height", leading: "line-height", gap: "gap", p: "padding", px: "padding-inline", py: "padding-block",
  m: "margin", mt: "margin-top", mb: "margin-bottom", ml: "margin-left", mr: "margin-right", rounded: "border-radius",
};

// Функция walk предназначена для обхода каталога исходников.
function* walk(dir) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) yield* walk(p);
    else if (/\.(jsx?|)$/.test(name) && /\.jsx?$/.test(name)) yield p;
  }
}

const re = /(?<![\w:\-\[])((?:text|w|h|min-w|min-h|max-w|max-h|leading|gap|p|px|py|mt|mb|ml|mr|m|rounded)-\[(\d+(?:\.\d+)?)px\])(?![\w\]])/g;
const found = new Map();
for (const f of walk("src")) {
  for (const m of readFileSync(f, "utf8").matchAll(re)) found.set(m[1], m[2]);
}
const lines = ["/* Файл создан скриптом scripts/gen-ui-scale.mjs: размеры произвольных значений Tailwind (text-[14px] и т. п.) масштабируются переменными --k и --fs. Редактировать вручную не нужно. */"];
for (const [cls, px] of [...found].sort()) {
  const prop = PROPS[cls.split("-[")[0]];
  const mul = prop === "font-size" ? "var(--k) * var(--fs)" : "var(--k)";
  lines.push(`.${cls.replace(/[\[\]]/g, "\\$&").replace(/\./g, "\\.")} { ${prop}: calc(${px}px * ${mul}); }`);
}
writeFileSync("src/ui-scale.css", lines.join("\n") + "\n");
console.log("правил:", found.size);
