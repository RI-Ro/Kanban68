// Модуль предназначен для запуска клиентского приложения: загрузка публичных настроек сервера и первый рендер компонента App.

import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { loadAppConfig } from "./lib/appConfig.js";

// Шрифт — системный стек (--font-ui в styles.css): ничего не загружается из сети.
import "./styles.css";
import "./ui-scale.css";

loadAppConfig().finally(() => {
  createRoot(document.getElementById("root")).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
});
