// Модуль предназначен для шаблонов задач: список шаблонов, применение в выбранной колонке, создание и изменение.

import React, { useEffect, useState } from "react";
import { Plus, Trash2, Zap, ListChecks } from "lucide-react";
import { api } from "../lib/api.js";
import { PRIORITIES, TASK_COLORS, resolveUser, plural } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Field, ConfirmDialog, inputStyle } from "../lib/ui.jsx";

// Компонент Templates предназначен для списка шаблонов и их применения. Шаблоны заменяют периодические задачи:
// экземпляр создаётся по действию пользователя, а не по расписанию.
export default function Templates({
  theme, directory, team, boardId, boardTitle, columns, onClose, onError, onInfo, onCreated,
}) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [confirm, setConfirm] = useState(null);
  const [applying, setApplying] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      setItems(await api.templates());
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const apply = async (tpl, columnId) => {
    try {
      const task = await api.applyTemplate(tpl.id, boardId, columnId);
      onInfo(`Задача «${task.title}» создана`);
      setApplying(null);
      onCreated(task);
      onClose();
    } catch (e) {
      onError(e.message);
    }
  };

  const remove = (tpl) => setConfirm({
    title: "Удалить шаблон?",
    message: `Шаблон «${tpl.name}» будет удалён. Созданные по нему задачи останутся.`,
    confirmLabel: "Удалить",
    onConfirm: async () => {
      setConfirm(null);
      try {
        await api.deleteTemplate(tpl.id);
        load();
      } catch (e) {
        onError(e.message);
      }
    },
  });

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" padded={false} geometryKey="templates">
      <div className="px-6 pt-5 pb-4">
        <ModalHeader theme={theme} title="Шаблоны задач"
          subtitle={boardTitle ? `Создание в проекте «${boardTitle}»` : "Заготовки для повторяющихся работ"}
          onClose={onClose}
          extra={
            <button onClick={() => setAdding(true)} className="btn-primary !py-[7px] !px-4 !text-[13px]">
              <Plus size={15} /> Создать
            </button>
          } />
      </div>

      <div style={{ borderColor: theme.border }} className="border-t max-h-[55vh] overflow-y-auto px-4 py-3">
        {loading && <p style={{ color: theme.textMuted }} className="text-[13px] py-6 text-center">Загружаем…</p>}

        {!loading && items.map((tpl) => (
          <div key={tpl.id} className="glass p-3 mb-2">
            <div className="flex items-center gap-2">
              <div className="min-w-0 flex-1">
                <div style={{ color: theme.text }} className="text-[14px] font-semibold truncate">
                  {tpl.name}
                </div>
                <div style={{ color: theme.textMuted }} className="text-[12px] truncate">
                  {PRIORITIES[tpl.priority]?.label || tpl.priority}
                  {tpl.dueInDays != null && ` · срок +${plural(tpl.dueInDays, "день", "дня", "дней")}`}
                  {tpl.steps?.length > 0 && ` · ${plural(tpl.steps.length, "пункт", "пункта", "пунктов")}`}
                  {!tpl.boardId && " · личный"}
                </div>
              </div>

              <div className="flex -space-x-1.5 shrink-0">
                {(tpl.assignees || []).slice(0, 3).map((id) => (
                  <span key={id} className="inline-flex"
                    style={{ boxShadow: `0 0 0 2px ${theme.surfaceAlt}`, borderRadius: 999, lineHeight: 0 }}>
                    <Avatar user={resolveUser(directory, id)} size={20} theme={theme} />
                  </span>
                ))}
              </div>

              <button onClick={() => setApplying(tpl)}
                className="btn-pill !py-1 !px-3 !text-[13px] shrink-0 disabled:opacity-50 disabled:cursor-default"
                style={{ color: theme.accent }}
                disabled={!boardId} title={boardId ? "Создать задачу" : "Откройте проект"}>
                <Zap size={14} /> Создать
              </button>
              <button onClick={() => remove(tpl)} className="btn-icon shrink-0 hover:!text-[var(--t-danger)]"
                aria-label={`Удалить шаблон: ${tpl.name}`} title="Удалить шаблон">
                <Trash2 size={16} />
              </button>
            </div>

            {/* Выбор колонки отображается только при применении шаблона. */}
            {applying?.id === tpl.id && (
              <div className="flex flex-wrap gap-1.5 mt-2 pt-2"
                style={{ borderTop: `1px solid ${theme.border}` }}>
                <span className="text-[12px] font-medium self-center mr-1"
                  style={{ color: theme.textMuted }}>В колонку:</span>
                {columns.map((c) => (
                  <button key={c.id} onClick={() => apply(tpl, c.id)}
                    className="btn-pill !py-1 !px-3 !text-[13px]">
                    {c.title}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}

        {!loading && items.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[14px] text-center py-8 px-4 leading-relaxed">
            Шаблонов нет. Они пригодятся для повторяющихся работ: набор пунктов
            чек-листа, исполнители и срок заводятся одним нажатием.
          </p>
        )}
      </div>

      {adding && (
        <TemplateForm theme={theme} directory={directory} team={team}
          boardId={boardId} boardTitle={boardTitle}
          onClose={() => setAdding(false)}
          onSaved={() => { setAdding(false); load(); onInfo("Шаблон создан"); }}
          onError={onError} />
      )}

      {confirm && <ConfirmDialog theme={theme} {...confirm} onCancel={() => setConfirm(null)} />}
    </Modal>
  );
}

// Компонент TemplateForm предназначен для создания и изменения шаблона.
function TemplateForm({ theme, directory, team, boardId, boardTitle, onClose, onSaved, onError }) {
  const [form, setForm] = useState({
    name: "", title: "", description: "", priority: "normal", color: "none",
    dueInDays: "", stepsText: "", assignees: [], shared: Boolean(boardId),
  });
  const [busy, setBusy] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async () => {
    if (!form.name.trim()) return onError("Укажите название шаблона");
    setBusy(true);
    try {
      await api.createTemplate({
        // Общий шаблон привязан к проекту и виден его участникам; личный виден только автору в любом проекте.
        boardId: form.shared && boardId ? boardId : null,
        name: form.name.trim(),
        title: form.title.trim() || form.name.trim(),
        description: form.description,
        priority: form.priority,
        color: form.color,
        tags: [],
        dueInDays: form.dueInDays === "" ? null : Number(form.dueInDays),
        steps: form.stepsText.split("\n").map((x) => x.trim()).filter(Boolean),
        assignees: form.assignees,
      });
      onSaved();
    } catch (e) {
      onError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const candidates = team.map((id) => resolveUser(directory, id)).filter((u) => !u.deleted);

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="template-new">
      <ModalHeader theme={theme} title="Новый шаблон" onClose={onClose} />

      <Field label="Название шаблона" theme={theme} hint="Видно только в списке шаблонов">
        <input value={form.name} onChange={(e) => set("name", e.target.value)} autoFocus
          placeholder="например, Еженедельный отчёт" style={inputStyle(theme)}
          className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
      </Field>

      <Field label="Название задачи" theme={theme} hint="Пусто — возьмётся название шаблона">
        <input value={form.title} onChange={(e) => set("title", e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
      </Field>

      <Field label="Описание" theme={theme}>
        <textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={2}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none resize-none" />
      </Field>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Приоритет" theme={theme}>
          <select value={form.priority} onChange={(e) => set("priority", e.target.value)}
            style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none">
            {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
        </Field>
        <Field label="Срок, дней" theme={theme} hint="От дня создания">
          <input type="number" min="0" value={form.dueInDays}
            onChange={(e) => set("dueInDays", e.target.value)} placeholder="без срока"
            style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
        </Field>
      </div>

      <Field label="Чек-лист" theme={theme} hint="По одному пункту в строке">
        <textarea value={form.stepsText} onChange={(e) => set("stepsText", e.target.value)} rows={4}
          placeholder={"Собрать данные\nСогласовать с отделом\nОтправить"}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none resize-none" />
      </Field>

      {candidates.length > 0 && (
        <Field label="Исполнители по умолчанию" theme={theme}>
          <div className="flex flex-wrap gap-1.5">
            {candidates.map((u) => {
              const active = form.assignees.includes(u.id);
              return (
                <button key={u.id}
                  onClick={() => set("assignees", active
                    ? form.assignees.filter((a) => a !== u.id)
                    : [...form.assignees, u.id])}
                  aria-pressed={active}
                  style={{
                    background: active ? theme.accent : theme.surfaceAlt,
                    color: active ? theme.accentText : theme.text,
                    border: `1px solid ${active ? "transparent" : theme.border}`,
                  }}
                  className="flex items-center gap-1.5 pl-1.5 pr-3 py-1 rounded-full text-[13px] font-medium transition-colors duration-150">
                  <Avatar user={u} size={16} theme={theme} />{u.fullName.split(" ")[0]}
                </button>
              );
            })}
          </div>
        </Field>
      )}

      {boardId && (
        <label style={{ color: theme.textMuted }} className="flex items-center gap-2 text-[13px] mb-3">
          <input type="checkbox" checked={form.shared}
            onChange={(e) => set("shared", e.target.checked)} />
          Общий для проекта «{boardTitle}» — иначе шаблон будет виден только вам
        </label>
      )}

      <button onClick={submit} disabled={busy}
        className="btn-primary w-full !py-2.5 disabled:opacity-50 disabled:cursor-default">
        {busy ? "Сохраняем…" : "Создать шаблон"}
      </button>
    </Modal>
  );
}
