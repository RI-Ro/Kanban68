// Модуль предназначен для формы создания и правки задачи.

import React, { useState } from "react";
import { Trash2, Plus, X, Users as UsersIcon, Calendar as CalendarIcon } from "lucide-react";
import { PRIORITIES, fmtDate, resolveUser, TASK_COLORS, taskColorFill } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Field, MultilineField, inputStyle } from "../lib/ui.jsx";
import AssigneePicker from "./AssigneePicker.jsx";
import { assigneeCandidates, outsideTeam } from "../lib/assignees.js";

// Функция opaque предназначена для получения оттенка заливки карточки без прозрачности (точка в палитре выбора).
const opaque = (rgba) => rgba.replace(/,\s*[\d.]+\)\s*$/, ", 1)");

// Функция today предназначена для получения даты через три дня (срок по умолчанию) в формате YYYY-MM-DD.
const today = () => new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10);

// Функция emptyTask предназначена для создания пустого описания задачи для колонки.
const emptyTask = (columnId) => ({
  title: "", description: "", priority: "normal", color: "none",
  incomingNumber: "", incomingDate: "",
  columnId, dueDate: today(), assignees: [], tags: [], steps: [], reminderAt: "",
  recurFreq: "none", recurInterval: 1, recurWeekdays: [], recurMonthday: null, recurUntil: null,
});

// Компонент TaskModal предназначен для формы создания и правки задачи.
export default function TaskModal({ theme, directory, team, teamGroups = [], boardMemberIds, currentUser, columns, initial, onClose, onSave, onRequestDelete, busy }) {
  const [form, setForm] = useState(() => ({
    ...emptyTask(columns[0]?.id),
    ...(initial || {}),
    dueDate: initial?.dueDate || today(),
    recurFreq: initial?.recurFreq || "none",
    recurInterval: initial?.recurInterval || 1,
    recurWeekdays: initial?.recurWeekdays || [],
    recurMonthday: initial?.recurMonthday ?? null,
    recurUntil: initial?.recurUntil || null,
  }));
  const [tagText, setTagText] = useState((initial?.tags || []).join(", "));
  const [error, setError] = useState("");

  const isEdit = Boolean(initial?.id);
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  // Кандидаты в исполнители: личная команда, участники проекта и уже назначенные; форма отправляет полный список исполнителей,
  // поэтому отсутствие уже назначенного означало бы его снятие.
  const candidates = assigneeCandidates({
    team, assigned: initial?.assignees || [], currentUserId: currentUser?.id,
  }).map((id) => resolveUser(directory, id));
  const outsideMyTeam = outsideTeam({ team, assigned: initial?.assignees || [] });

  const toggleAssignee = (id) =>
    set("assignees", form.assignees.includes(id) ? form.assignees.filter((a) => a !== id) : [...form.assignees, id]);

  const submit = () => {
    if (!form.title.trim()) return setError("Укажите название задачи");
    if (!form.columnId) return setError("Выберите колонку");
    // Приоритет «установлен срок» требует указания даты.
    if (form.priority === "dated" && !form.dueDate) {
      return setError("Для приоритета «Установлен срок» укажите срок исполнения");
    }
    onSave({
      ...form,
      title: form.title.trim(),
      tags: tagText.split(",").map((t) => t.trim().replace(/^#/, "")).filter(Boolean),
      // Чек-лист передаётся только при создании; у существующей задачи пункты правятся в карточке.
      steps: isEdit ? undefined : (form.steps || []),
      // Напоминание создаётся отдельным запросом после сохранения задачи: оно принадлежит пользователю, а не задаче.
      reminderAt: form.reminderAt || "",
    });
  };

  const hasDeletedAssignee = form.assignees.some((id) => resolveUser(directory, id).deleted);

  return (
    // Ширина окна совпадает с окном просмотра задачи (max-w-3xl).
    <Modal theme={theme} onClose={onClose} width="max-w-3xl" geometryKey="task-form">
      <ModalHeader theme={theme} title={isEdit ? "Редактировать задачу" : "Новая задача"} onClose={onClose} />

      <Field label="Название" theme={theme}>
        <input value={form.title} onChange={(e) => set("title", e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()}
          autoFocus style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2.5 text-[15px] font-medium outline-none"
          placeholder="Новая задача" />
      </Field>

      <Field label="Описание" theme={theme}>
        <textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={3}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] leading-[1.5] outline-none resize-none" />
      </Field>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Входящий №" theme={theme}>
          <input value={form.incomingNumber || ""} onChange={(e) => set("incomingNumber", e.target.value)}
            placeholder="например, 01-15/238" style={inputStyle(theme)}
            className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
        </Field>
        <Field label="Дата документа" theme={theme}>
          <input type="date" value={String(form.incomingDate || "").slice(0, 10)}
            onChange={(e) => set("incomingDate", e.target.value)} style={inputStyle(theme)}
            className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
        </Field>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Приоритет" theme={theme}>
          <select value={form.priority} onChange={(e) => set("priority", e.target.value)} style={inputStyle(theme)}
            className="w-full rounded-xl px-2.5 py-2 text-[14px] outline-none">
            {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
        </Field>
        <Field label="Колонка" theme={theme}>
          <select value={form.columnId || ""} onChange={(e) => set("columnId", e.target.value)} style={inputStyle(theme)}
            className="w-full rounded-xl px-2.5 py-2 text-[14px] outline-none">
            {columns.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
          </select>
        </Field>
      </div>

      <Field label="Срок исполнения" theme={theme}>
        <input type="date" value={String(form.dueDate || "").slice(0, 10)} onChange={(e) => set("dueDate", e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
      </Field>

      <Field label="Повторение" theme={theme}
        hint="Цикличная задача: при завершении автоматически создаётся следующая с новым сроком.">
        <select value={form.recurFreq} onChange={(e) => set("recurFreq", e.target.value)} style={inputStyle(theme)}
          className="w-full rounded-xl px-3 py-2 text-[14px] outline-none">
          <option value="none">Без повторения</option>
          <option value="daily">Ежедневно</option>
          <option value="weekly">Еженедельно</option>
          <option value="monthly">Ежемесячно</option>
        </select>

        {form.recurFreq !== "none" && (
          <div className="mt-2 space-y-2">
            <div className="flex items-center gap-2">
              <span style={{ color: theme.textMuted }} className="text-[13px]">Каждые</span>
              <input type="number" min="1" max="99" value={form.recurInterval}
                onChange={(e) => set("recurInterval", Math.max(1, parseInt(e.target.value || "1", 10)))}
                style={inputStyle(theme)} className="w-16 rounded-xl px-2.5 py-1.5 text-[14px] outline-none" />
              <span style={{ color: theme.textMuted }} className="text-[13px]">
                {form.recurFreq === "daily" ? "дн." : form.recurFreq === "weekly" ? "нед." : "мес."}
              </span>
            </div>

            {form.recurFreq === "weekly" && (
              <div className="flex flex-wrap gap-1">
                {["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"].map((d, i) => {
                  const active = (form.recurWeekdays || []).includes(i);
                  return (
                    <button key={i} type="button"
                      onClick={() => set("recurWeekdays", active
                        ? form.recurWeekdays.filter((x) => x !== i)
                        : [...(form.recurWeekdays || []), i].sort((a, b) => a - b))}
                      aria-pressed={active}
                      style={{ background: active ? theme.accent : theme.surfaceAlt, color: active ? theme.accentText : theme.text, border: `1px solid ${active ? theme.accent : theme.border}` }}
                      className="w-10 h-8 rounded-full text-[12.5px] font-medium transition-colors">{d}</button>
                  );
                })}
              </div>
            )}

            {form.recurFreq === "monthly" && (
              <div className="flex items-center gap-2">
                <span style={{ color: theme.textMuted }} className="text-[13px]">Число месяца</span>
                <input type="number" min="1" max="31" value={form.recurMonthday || ""}
                  placeholder="как у срока"
                  onChange={(e) => set("recurMonthday", e.target.value ? Math.min(31, Math.max(1, parseInt(e.target.value, 10))) : null)}
                  style={inputStyle(theme)} className="w-20 rounded-xl px-2.5 py-1.5 text-[14px] outline-none" />
              </div>
            )}

            <div className="flex items-center gap-2">
              <span style={{ color: theme.textMuted }} className="text-[13px]">До даты (необязательно)</span>
              <input type="date" value={form.recurUntil || ""}
                onChange={(e) => set("recurUntil", e.target.value || null)}
                style={inputStyle(theme)} className="rounded-xl px-2.5 py-1.5 text-[14px] outline-none" />
            </div>
          </div>
        )}
      </Field>

      <Field label="Исполнители" theme={theme}
        hint={candidates.length === 0 ? "Команда пуста — добавьте сотрудников в разделе «Моя команда»."
          : hasDeletedAssignee ? "Среди исполнителей есть удалённая учётная запись — назначьте замену."
          : outsideMyTeam.size > 0 ? "Отмеченные точкой назначены не из вашей команды — снимайте их осознанно."
          : undefined}>
        {/* Выбор исполнителей с группами команды: тот же компонент AssigneePicker, что в окне «Поручить». */}
        <div style={{ borderColor: theme.border }} className="border rounded-2xl p-2 max-h-[320px] overflow-y-auto">
          <AssigneePicker theme={theme} directory={directory}
            candidates={candidates.map((u) => u.id)}
            groups={teamGroups}
            selected={form.assignees}
            onToggle={toggleAssignee}
            onChange={(next) => set("assignees", next)}
            outside={outsideMyTeam} />
        </div>
      </Field>

      <Field label="Цвет карточки" theme={theme}
        hint="Заливка полупрозрачная — карточка остаётся читаемой в любой теме и на любом фоне доски.">
        {/* Цвет выбирается точками: оттенок карточки полупрозрачный, точка рисуется без прозрачности. */}
        <div className="flex flex-wrap items-center gap-2">
          {TASK_COLORS.map((c) => {
            const fill = taskColorFill(c.id, theme);
            const active = (form.color || "none") === c.id;
            return (
              <button key={c.id} type="button" onClick={() => set("color", c.id)} title={c.label}
                aria-label={c.label} aria-pressed={active}
                style={{
                  background: fill ? opaque(fill) : "transparent",
                  border: fill ? "none" : `1.5px dashed ${theme.textMuted}`,
                  boxShadow: active ? `0 0 0 2px ${theme.surface}, 0 0 0 4px ${theme.accent}` : "none",
                }}
                className="w-6 h-6 rounded-full flex items-center justify-center transition-transform hover:scale-110">
                {c.id === "none" && <X size={12} style={{ color: theme.textMuted }} />}
              </button>
            );
          })}
          <span style={{ color: theme.textMuted }} className="text-[13px] ml-1">
            {(TASK_COLORS.find((c) => c.id === (form.color || "none")) || TASK_COLORS[0]).label}
          </span>
        </div>
      </Field>

      {/* Напоминание из формы задачи: создаётся только новое и только личное. */}
      <Field label="Напомнить мне об этой задаче" theme={theme}
        hint="Необязательно. Прозвонит будильником в указанное время — окно поверх всего, с возможностью отложить.">
        <div className="flex items-center gap-2">
          <input type="datetime-local" value={form.reminderAt || ""}
            onChange={(e) => set("reminderAt", e.target.value)}
            style={inputStyle(theme)}
            className="flex-1 rounded-xl px-3 py-2 text-[14px] outline-none" />
          {form.reminderAt && (
            <button type="button" onClick={() => set("reminderAt", "")}
              className="btn-icon" title="Убрать напоминание" aria-label="Убрать напоминание">
              <X size={16} />
            </button>
          )}
        </div>
      </Field>

      {/* Чек-лист в форме создания; у существующей задачи пункты правятся в карточке. */}
      {!isEdit && (
        <Field label="Чек-лист" theme={theme}
          hint="Пункты будут созданы вместе с задачей. Исполнитель пункта получает доступ к задаче.">
          <NewTaskChecklist theme={theme} candidates={candidates}
            steps={form.steps || []} onChange={(next) => set("steps", next)} />
        </Field>
      )}

      <Field label="Теги через запятую" theme={theme}>
        <input value={tagText} onChange={(e) => setTagText(e.target.value)} style={inputStyle(theme)}
          className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" placeholder="интерфейс, сервер, срочно" />
      </Field>

      {/* Подвал закреплён у нижнего края окна. */}
      <div style={{ background: theme.surface, borderColor: theme.border }}
        className="sticky -bottom-5 -mx-5 -mb-5 mt-4 px-5 py-3 border-t z-10">
        {error && <p style={{ color: theme.danger }} className="text-[13px] mb-2" role="alert">{error}</p>}
        <div className="flex items-center gap-2">
          {isEdit && (
            <button onClick={() => onRequestDelete(form.id)} className="btn-icon"
              style={{ color: theme.danger }} title="Удалить задачу" aria-label="Удалить задачу">
              <Trash2 size={17} />
            </button>
          )}
          <span className="flex-1" />
          <button type="button" onClick={onClose} className="btn-pill">Отмена</button>
          <button onClick={submit} disabled={busy} className="btn-primary disabled:opacity-50">
            {busy ? "Сохраняем…" : isEdit ? "Сохранить изменения" : "Создать задачу"}
          </button>
        </div>
      </div>
    </Modal>
  );
}

// Компонент NewTaskChecklist предназначен для черновика чек-листа новой задачи: пункты хранятся в состоянии формы
// и передаются вместе с задачей одним запросом и одной транзакцией.
function NewTaskChecklist({ theme, candidates, steps, onChange }) {
  const [draft, setDraft] = useState({ body: "", assigneeId: "", dueDate: "" });

  const add = () => {
    const body = draft.body.trim();
    if (!body) return;
    onChange([...steps, {
      body,
      assigneeId: draft.assigneeId || null,
      dueDate: draft.dueDate || null,
    }]);
    setDraft({ body: "", assigneeId: "", dueDate: "" });
  };

  const removeAt = (i) => onChange(steps.filter((_, idx) => idx !== i));

  return (
    <div>
      {steps.map((s, i) => {
        const u = s.assigneeId ? candidates.find((c) => c.id === s.assigneeId) : null;
        return (
          <div key={i} style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
            className="flex items-start gap-2.5 rounded-xl px-3 py-2 mb-1.5">
            <span style={{ borderColor: theme.textMuted }}
              className="w-4 h-4 rounded-md border-[1.5px] mt-0.5 shrink-0" aria-hidden />
            <div className="flex-1 min-w-0">
              <div style={{ color: theme.text }} className="text-[14px] break-words whitespace-pre-wrap">{s.body}</div>
              {(u || s.dueDate) && (
                <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 mt-0.5">
                  {u && (
                    <span style={{ color: theme.textMuted }} className="text-[12px] flex items-center gap-1">
                      <UsersIcon size={11} />{u.fullName}
                    </span>
                  )}
                  {s.dueDate && (
                    <span style={{ color: theme.textMuted }} className="text-[12px] flex items-center gap-1">
                      <CalendarIcon size={11} />до {fmtDate(s.dueDate)}
                    </span>
                  )}
                </div>
              )}
            </div>
            <button type="button" onClick={() => removeAt(i)} className="btn-icon -my-1 -mr-1.5"
              style={{ width: 28, height: 28, color: theme.danger }}
              title="Убрать пункт" aria-label="Убрать пункт"><X size={14} /></button>
          </div>
        );
      })}

      <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
        className="rounded-2xl p-3">
        <MultilineField theme={theme} value={draft.body}
          onChange={(body) => setDraft({ ...draft, body })} onSubmit={add}
          placeholder="Что нужно сделать. Ctrl+Enter — добавить, Enter — новая строка"
          className="w-full rounded-xl px-3 py-2 text-[14px] outline-none mb-2" />
        <div className="grid grid-cols-2 gap-2">
          <div>
            <div style={{ color: theme.textMuted }} className="text-[12px] font-medium mb-1">Исполнитель</div>
            <select value={draft.assigneeId} onChange={(e) => setDraft({ ...draft, assigneeId: e.target.value })}
              style={inputStyle(theme)} className="w-full rounded-xl px-2.5 py-2 text-[13px] outline-none">
              <option value="">Не назначен</option>
              {candidates.filter((u) => !u.deleted).map((u) => (
                <option key={u.id} value={u.id}>{u.fullName}</option>
              ))}
            </select>
          </div>
          <div>
            <div style={{ color: theme.textMuted }} className="text-[12px] font-medium mb-1">Срок пункта</div>
            <input type="date" value={draft.dueDate}
              onChange={(e) => setDraft({ ...draft, dueDate: e.target.value })}
              style={inputStyle(theme)} className="w-full rounded-xl px-2.5 py-2 text-[13px] outline-none" />
          </div>
        </div>
        <button type="button" onClick={add} disabled={!draft.body.trim()}
          className="btn-pill mt-3 disabled:opacity-40" style={{ padding: "5px 14px", fontSize: 13, gap: 6, background: theme.surface }}>
          <Plus size={14} style={{ color: theme.accent }} /> Добавить пункт
        </button>
      </div>
    </div>
  );
}
