import React, { useRef, useState } from "react";
import { Camera, Trash2 } from "lucide-react";
import { api } from "../lib/api.js";
import { Avatar } from "../lib/ui.jsx";

// Модуль предназначен для выбора фотографии пользователя: себе или (для администратора) выбранному пользователю.
// Изображение перед отправкой приводится в браузере к квадрату 512 px (JPEG): так принимаются и WebP, и снимки с телефона.

// Функция toSquareJpeg предназначена для кадрирования изображения по центру в квадрат и сжатия; при ошибке возвращает исходный файл.
async function toSquareJpeg(file) {
  try {
    const bmp = await createImageBitmap(file);
    const side = Math.min(bmp.width, bmp.height);
    const out = Math.min(side, 512);
    const canvas = document.createElement("canvas");
    canvas.width = out; canvas.height = out;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, out, out);
    ctx.drawImage(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side, 0, 0, out, out);
    const blob = await new Promise((res) => canvas.toBlob(res, "image/jpeg", 0.9));
    return blob ? new File([blob], "photo.jpg", { type: "image/jpeg" }) : file;
  } catch {
    return file;
  }
}

// Компонент PhotoEditor предназначен для показа текущего фото и кнопок «Выбрать фото» и «Убрать».
// userId задаётся для администратора; без него меняется фото текущего пользователя.
export default function PhotoEditor({ theme, user, userId, onChanged, onError, onInfo }) {
  const input = useRef(null);
  const [busy, setBusy] = useState(false);
  const has = Boolean(user?.photoVersion);

  const pick = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setBusy(true);
    try {
      const ready = await toSquareJpeg(file);
      await (userId ? api.adminUploadPhoto(userId, ready) : api.uploadMyPhoto(ready));
      onInfo?.("Фото сохранено");
      await onChanged?.();
    } catch (err) {
      onError?.(err.message);
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await (userId ? api.adminDeletePhoto(userId) : api.deleteMyPhoto());
      onInfo?.("Фото убрано");
      await onChanged?.();
    } catch (err) {
      onError?.(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex items-center gap-4">
      <Avatar user={user} size={84} theme={theme} />
      <div className="flex flex-col gap-2 items-start">
        <input ref={input} type="file" accept="image/*" className="hidden" onChange={pick} />
        <button onClick={() => input.current?.click()} disabled={busy} className="btn-pill">
          <Camera size={14} style={{ color: theme.accent }} /> {has ? "Заменить фото" : "Выбрать фото"}
        </button>
        {has && (
          <button onClick={remove} disabled={busy} className="btn-pill" style={{ color: theme.danger }}>
            <Trash2 size={14} /> Убрать фото
          </button>
        )}
        <span style={{ color: theme.textMuted }} className="text-[12px] max-w-[240px]">
          Без фото показываются инициалы. Фото из LDAP обновляется при входе, но не заменяет загруженное вручную.
        </span>
      </div>
    </div>
  );
}
