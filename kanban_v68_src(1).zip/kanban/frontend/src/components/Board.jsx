// Модуль предназначен для отображения доски проекта: карточки задач, колонки, представление «Входящие» и общие элементы
// (капсулы приоритета и счётчика, стопка аватаров исполнителей).

import React, { useRef, useState } from "react";
import {
  Plus, MessageSquare, Paperclip, CalendarDays, AlertTriangle, Repeat,
  Settings, Share2, Check, CheckCircle2, Users, Flag,
} from "lucide-react";
import { PRIORITIES, TASK_COLORS, fmtDate, isOverdue, isUnseen, plural, resolveUser, dueColor, dueLevel } from "../lib/theme.js";
import { Avatar } from "../lib/ui.jsx";

// Функция tint предназначена для получения полупрозрачного тона цвета темы для капсул (фон 16 % и текст того же цвета).
export function tint(color, alpha = 0.16) {
  const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(color || "");
  if (!m) return `color-mix(in srgb, ${color} ${Math.round(alpha * 100)}%, transparent)`;
  let h = m[1];
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  const n = parseInt(h, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${alpha})`;
}

// Функция taskColorSolid предназначена для получения непрозрачного цвета задачи для узкой метки (в TASK_COLORS хранятся полупрозрачные заливки).
export function taskColorSolid(colorId, theme) {
  const c = TASK_COLORS.find((x) => x.id === colorId);
  if (!c || c.id === "none") return null;
  const m = /rgba?\(([^,]+),([^,]+),([^,)]+)/.exec(theme.dark ? c.dark : c.light);
  return m ? `rgb(${m[1]},${m[2]},${m[3]})` : null;
}

// Функция cardSurface предназначена для получения цвета поверхности карточки (обводка аватаров): у светлой темы «Стекло» карточка белая.
export const cardSurface = (theme) => (theme.brand && !theme.dark ? "#fff" : theme.surfaceAlt);

// Компонент PriorityPill предназначен для отображения капсулы приоритета; приоритет «Обычный» не показывается, если не задан always.
export function PriorityPill({ priority, theme, always = false }) {
  const pr = PRIORITIES[priority] || PRIORITIES.normal;
  if (!always && (priority === "normal" || !PRIORITIES[priority])) return null;
  const c = theme[pr.color];
  const urgent = priority === "urgent" || priority === "very_urgent";
  return (
    <span className="pill" style={{ background: tint(c), color: c, padding: "0 8px", fontSize: 11.5, lineHeight: "20px", gap: 4 }}
      title={`Приоритет: ${pr.label}`}>
      {urgent && <Flag size={11} strokeWidth={2.5} />}
      {pr.label}
    </span>
  );
}

const metaPill = { padding: "0 8px", fontSize: 11.5, lineHeight: "20px", gap: 4 };

// Компонент AvatarStack предназначен для отображения перекрывающихся аватаров исполнителей (перекрытие 4 px с обводкой цветом поверхности).
export function AvatarStack({ assignees, doneIds, theme, ring, max = 3, size = 22 }) {
  return (
    <div className="flex items-center">
      {assignees.slice(0, max).map((u, i) => (
        // Исполнители, отметившие выполнение, выделяются зелёным контуром и галочкой.
        <span key={`${u.id}-${i}`} className="relative inline-flex"
          style={{
            marginLeft: i === 0 ? 0 : -3,
            boxShadow: `0 0 0 2px ${doneIds.includes(u.id) ? theme.success : ring}`,
            borderRadius: 999,
            lineHeight: 0,
            zIndex: max - i,
          }}
          title={doneIds.includes(u.id)
            ? `${u.fullName} — свою часть выполнил(а)`
            : u.fullName}>
          <Avatar user={u} size={size} theme={theme} />
          {doneIds.includes(u.id) && (
            <span style={{ background: theme.success, boxShadow: `0 0 0 1.5px ${ring}` }}
              className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full flex items-center justify-center">
              <Check size={7} color="#fff" strokeWidth={4} />
            </span>
          )}
        </span>
      ))}
      {assignees.length > max && (
        <span style={{ background: theme.surface, color: theme.textMuted, boxShadow: `0 0 0 2px ${ring}`, width: size, height: size, marginLeft: -3 }}
          className="rounded-full inline-flex items-center justify-center text-[10px] font-semibold tabular-nums">
          +{assignees.length - max}
        </span>
      )}
    </div>
  );
}

// Компонент TaskCard предназначен для отображения карточки задачи на доске.
export function TaskCard({ task, theme, directory, onOpen, draggable, dragging, onDragStart, onDragEnd, onHover, sourceLabel, highlight, currentUserId, onOpenUser }) {
  const assignees = task.assignees.map((id) => resolveUser(directory, id));
  const hasDeleted = assignees.some((u) => u.deleted);
  const completed = Boolean(task.completedAt);
  const overdue = isOverdue(task.dueDate, completed);
  const stepsDone = task.steps.filter((s) => s.done).length;
  // Автор отображается на любой чужой задаче.
  const author = task.createdBy && task.createdBy !== currentUserId
    ? resolveUser(directory, task.createdBy)
    : null;
  const mark = taskColorSolid(task.color, theme);
  const doneIds = task.assigneesDone || [];
  const dueInfo = dueLevel(task.dueDate, completed);
  // Цвет срока используется только для близкого (менее недели) или прошедшего срока.
  const dueTint = dueInfo && (dueInfo.id === "overdue" || dueInfo.id === "week1")
    ? dueColor(task.dueDate, completed, theme) : null;
  // Изменённая после последнего просмотра задача: обводка вокруг карточки и полужирное название; открытие карточки снимает отметку.
  const unseen = isUnseen(task);
  const ring = cardSurface(theme);
  const ready = task.readyAt && !task.completedAt;
  const hasTopRow = ready || sourceLabel || (task.priority && task.priority !== "normal" && PRIORITIES[task.priority]) || task.tags?.length > 0;

  const handleDragOver = (e) => {
    if (!draggable) return;
    e.preventDefault();
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const after = e.clientY > rect.top + rect.height / 2;
    onHover(task.columnId, task.position + (after ? 1 : 0));
  };

  return (
    <article
      draggable={draggable}
      onDragStart={(e) => {
        if (!draggable) return;
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", task.id);
        onDragStart(task.id);
      }}
      onDragEnd={onDragEnd}
      onDragOver={handleDragOver}
      onClick={() => onOpen(task.id)}
      style={{
        // Временная подсветка (6 с) изменения другим пользователем: кольцо и свечение цветом автора изменения, без мигания.
        // Непросмотренное изменение: постоянная обводка акцентным цветом (как у только что созданной задачи), пока карточку
        // не откроют. Обводка рисуется поверх заливки цвета задачи и видна при любом выбранном цвете.
        boxShadow: highlight
          ? `0 0 0 2px ${highlight.color}, 0 0 18px -2px ${highlight.color}`
          : unseen
          ? `0 0 0 2px ${theme.accent}, 0 0 18px -2px ${theme.accent}`
          : undefined,
        transition: "box-shadow .18s ease-out, transform .15s ease-out, opacity .15s ease-out",
        opacity: dragging === task.id ? 0.35 : completed ? 0.78 : 1,
      }}
      className={`glass group relative isolate overflow-hidden p-3 mb-2 hover:-translate-y-px ${draggable ? "cursor-grab active:cursor-grabbing" : "cursor-pointer"}`}
    >
      {/* Пользовательский цвет задачи: метка по верхнему краю и заливка карточки 15 % цвета самым нижним слоем (под текстом). */}
      {mark && (
        <>
          <span aria-hidden style={{ background: `color-mix(in srgb, ${mark} 15%, transparent)`, zIndex: -1 }}
            className="absolute inset-0 pointer-events-none" />
          <span aria-hidden style={{ background: mark }} className="absolute left-0 right-0 top-0 h-[3px]" />
        </>
      )}

      {hasTopRow && (
        <div className="flex items-center gap-1 mb-2 flex-wrap">
          {/* Готовность к сдаче: первая капсула карточки. */}
          {ready && (
            <span className="pill font-semibold" style={{ ...metaPill, background: theme.success, color: "#fff" }}>
              <Check size={11} strokeWidth={3} /> Готова к сдаче
            </span>
          )}
          <PriorityPill priority={task.priority} theme={theme} />
          {sourceLabel && (
            <span className="pill" style={{ ...metaPill, background: tint(theme.textMuted, 0.14), color: theme.textMuted }}>{sourceLabel}</span>
          )}
          {task.tags?.map((t) => (
            <span key={t} className="pill" style={{ ...metaPill, background: tint(theme.textMuted, 0.14), color: theme.textMuted, maxWidth: "100%" }}>
              <span className="truncate">#{t}</span>
            </span>
          ))}
        </div>
      )}

      <h4 style={{
          color: completed ? theme.textMuted : theme.text,
          textDecoration: completed ? "line-through" : "none",
          fontWeight: unseen ? 700 : 550,
        }} className="text-[14px] leading-[19px] flex items-start gap-1.5">
        {completed && <CheckCircle2 size={15} style={{ color: theme.success }} className="shrink-0 mt-[2px]" aria-label="Завершена" />}
        <span className="min-w-0 break-words">{task.title}</span>
      </h4>

      {task.incomingNumber && (
        <div style={{ color: theme.textMuted }} className="text-[12px] mt-1 tabular-nums truncate"
          title="Реквизиты входящего документа">
          вх. № {task.incomingNumber}
          {task.incomingDate ? ` от ${fmtDate(task.incomingDate)}` : ""}
        </div>
      )}

      {author && (
        <button
          onClick={(e) => { e.stopPropagation(); onOpenUser && onOpenUser(author); }}
          className="flex items-center gap-1.5 mt-1.5 max-w-full rounded-full transition-opacity hover:opacity-75"
          title={`Поставил(а): ${author.fullName}. Нажмите, чтобы связаться`}>
          <Avatar user={author} size={18} theme={theme} />
          <span style={{ color: theme.textMuted }} className="text-[12px] truncate">
            {author.fullName}
          </span>
        </button>
      )}

      {task.steps.length > 0 && (
        <div className="flex items-center gap-2 mt-2.5" title={`Чек-лист: выполнено ${stepsDone} из ${task.steps.length}`}>
          <span style={{ background: tint(theme.textMuted, 0.2) }} className="flex-1 h-1 rounded-full overflow-hidden">
            <span style={{ width: `${(stepsDone / task.steps.length) * 100}%`, background: stepsDone === task.steps.length ? theme.success : theme.accent }}
              className="block h-full rounded-full" />
          </span>
          <span style={{ color: theme.textMuted }} className="text-[12px] font-medium tabular-nums">{stepsDone}/{task.steps.length}</span>
        </div>
      )}

      {/* Нижняя строка переносится: при многих исполнителях и счётчиках значки не наезжают друг на друга. */}
      <div className="flex items-center justify-between gap-x-2 gap-y-1.5 mt-2.5 flex-wrap">
        <div style={{ color: theme.textMuted }} className="flex items-center gap-x-2.5 gap-y-1 flex-wrap text-[12px] min-w-0 tabular-nums">
          {/* Просроченный срок: красная капсула со значком, совмещённая с датой. */}
          {task.dueDate && overdue ? (
            <span className="pill font-semibold shrink-0" style={{ ...metaPill, marginLeft: -2, background: tint(theme.danger), color: theme.danger }}
              title={`Просрочено: срок ${fmtDate(task.dueDate)}`} aria-label={`Просрочено, срок ${fmtDate(task.dueDate)}`}>
              <AlertTriangle size={12} />{fmtDate(task.dueDate)}
            </span>
          ) : task.dueDate && (
            <span style={{ color: dueTint || theme.textMuted }}
              title={dueInfo ? `Срок — ${dueInfo.label.toLowerCase()}` : "Срок исполнения"}
              className={`flex items-center gap-1 shrink-0 ${dueTint ? "font-semibold" : "font-medium"}`}>
              <CalendarDays size={13} />{fmtDate(task.dueDate)}
            </span>
          )}
          {task.commentCount > 0 && <span className="flex items-center gap-1 shrink-0" title="Комментарии"><MessageSquare size={13} />{task.commentCount}</span>}
          {task.attachmentCount > 0 && <span className="flex items-center gap-1 shrink-0" title="Вложения"><Paperclip size={13} />{task.attachmentCount}</span>}
          {task.recurFreq && task.recurFreq !== "none" && (
            <span title="Повторяющаяся задача" className="flex"><Repeat size={13} /></span>
          )}
          {task.grants?.length > 0 && <span title="Есть внешние участники" className="flex"><Share2 size={13} /></span>}
        </div>

        <div className="flex items-center gap-1.5 shrink-0 ml-auto">
          {hasDeleted && (
            <span title="Среди исполнителей есть удалённая учётная запись" style={{ color: theme.warning }} className="flex"><AlertTriangle size={13} /></span>
          )}
          <AvatarStack assignees={assignees} doneIds={doneIds} theme={theme} ring={ring} />
        </div>
      </div>
    </article>
  );
}

// Компонент CountPill предназначен для отображения счётчика задач капсулой рядом с заголовком колонки.
export function CountPill({ theme, children, color, title }) {
  return (
    <span className="pill tabular-nums font-semibold"
      style={{ padding: "0 7px", fontSize: 12, lineHeight: "20px", minWidth: 22, justifyContent: "center",
        background: tint(color || theme.textMuted, 0.16), color: color || theme.textMuted }}
      title={title}>
      {children}
    </span>
  );
}

const iconBtn = { width: 26, height: 26 };

// Компонент Column предназначен для отображения колонки с карточками и приёма перетаскивания.
export function Column({ column, tasks, theme, directory, canEdit, canCreate, canMoveTask, dragging, dropTarget, onOpen, onDragStart, onDragEnd, onHover, onDrop, onQuickAdd, onSettings, onExpandColumn, highlights, currentUserId, onOpenUser }) {
  const count = tasks.length;
  const overLimit = column.wipLimit > 0 && count > column.wipLimit;
  const load = column.wipLimit > 0 ? Math.min(1, count / column.wipLimit) : 0;
  const isTarget = dropTarget?.columnId === column.id;

  // Перетаскивание принимается, пока перемещается карточка; карточки становятся перетаскиваемыми только при праве на перенос (canMoveTask).
  const handleDragOver = (e) => {
    if (!dragging) return;
    e.preventDefault();
    onHover(column.id, count);
  };

  const insertionLine = (index) =>
    isTarget && dropTarget.index === index ? <div style={{ background: theme.accent }} className="h-[2px] rounded-full mx-1 mb-2 -mt-1" /> : null;

  return (
    <section
      onDragOver={handleDragOver}
      onDrop={(e) => { e.preventDefault(); onDrop(column.id); }}
      style={isTarget && dragging ? { boxShadow: `0 0 0 2px ${theme.accent}` } : undefined}
      className="glass-pane flex flex-col w-[18.5vw] min-w-[232px] max-w-[330px] shrink-0 max-h-full p-2"
    >
      <header className="pl-2.5 pr-0.5 pt-0.5 pb-1.5">
        <div className="flex items-center gap-1.5 min-h-[30px]">
          <span style={{ background: column.color || theme.textMuted }} className="w-2 h-2 rounded-full shrink-0 mr-0.5" />
          {/* Нажатие на название разворачивает колонку списком на весь экран. */}
          <button onClick={() => onExpandColumn && onExpandColumn(column)}
            style={{ color: theme.text }}
            className="font-semibold text-[15px] tracking-[-0.01em] truncate text-left rounded-md transition-opacity hover:opacity-70"
            title={`${column.title} — открыть колонку списком`}>
            {column.title}
          </button>
          {column.wipLimit > 0 ? (
            <CountPill theme={theme} color={overLimit ? theme.danger : null}
              title={`${plural(count, "задача", "задачи", "задач")} · не больше ${column.wipLimit} одновременно`}>
              {count}/{column.wipLimit}
            </CountPill>
          ) : (
            <CountPill theme={theme} title={plural(count, "задача", "задачи", "задач")}>{count}</CountPill>
          )}
          {column.isDone && <span title="Колонка завершения" className="flex shrink-0"><Check size={13} style={{ color: theme.success }} /></span>}
          <div className="ml-auto -mr-0.5 flex items-center shrink-0">
            {canCreate && (
              <button onClick={() => onQuickAdd(column.id)} className="btn-icon" style={iconBtn}
                title="Добавить задачу" aria-label="Добавить задачу в колонку">
                <Plus size={16} />
              </button>
            )}
            {canEdit && (
              <button onClick={onSettings} className="btn-icon" style={iconBtn}
                title="Настроить колонки" aria-label="Настроить колонки">
                <Settings size={14} />
              </button>
            )}
          </div>
        </div>

        {column.wipLimit > 0 && (
          <div style={{ background: tint(theme.textMuted, 0.18) }} className="h-[3px] rounded-full overflow-hidden mt-1.5 mr-2"
            title={`Не больше ${column.wipLimit} задач одновременно`}>
            <div style={{ width: `${load * 100}%`, background: overLimit ? theme.danger : (column.color || theme.accent) }} className="h-full rounded-full transition-all" />
          </div>
        )}
      </header>

      <div className="overflow-y-auto flex-1 min-h-[60px] -mx-1 px-1 pt-0.5">
        {insertionLine(0)}
        {tasks.map((t, i) => (
          <React.Fragment key={t.id}>
            <TaskCard task={t} theme={theme} directory={directory} onOpen={onOpen}
              draggable={canMoveTask ? canMoveTask(t) : canEdit}
              dragging={dragging} onDragStart={onDragStart} onDragEnd={onDragEnd} onHover={onHover}
              highlight={highlights?.[t.id]} currentUserId={currentUserId} onOpenUser={onOpenUser} />
            {insertionLine(i + 1)}
          </React.Fragment>
        ))}

        {count === 0 && (
          <div style={{ color: theme.textMuted, borderColor: isTarget && dragging ? theme.accent : tint(theme.textMuted, 0.35) }}
            className="text-[13px] text-center py-7 mb-2 border border-dashed rounded-2xl transition-colors">
            {canCreate ? "Перетащите задачу сюда" : "Пусто"}
          </div>
        )}
      </div>

      {canCreate && (
        <button onClick={() => onQuickAdd(column.id)} style={{ color: theme.textMuted }}
          className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl text-[13px] font-medium transition-colors hover:bg-[var(--t-surfaceAlt)] hover:text-[var(--t-text)]">
          <Plus size={15} /> Добавить задачу
        </button>
      )}
    </section>
  );
}

// Компонент BoardView предназначен для отображения всех колонок проекта.
export function BoardView({ columns, tasks, theme, directory, canEdit, canManage, canCreate, canMoveTask, hideCompleted, onOpenTask, onMove, onQuickAdd, onSettings, onShowCompleted, onExpandColumn, highlights, currentUserId, onOpenUser }) {
  const [dragging, setDragging] = useState(null);
  const [dropTarget, setDropTarget] = useState(null);
  const target = useRef(null);

  const hover = (columnId, index) => {
    target.current = { columnId, index };
    setDropTarget((prev) => (prev?.columnId === columnId && prev?.index === index ? prev : { columnId, index }));
  };

  const finish = () => {
    setDragging(null);
    setDropTarget(null);
    target.current = null;
  };

  const drop = (fallbackColumnId) => {
    const taskId = dragging;
    const t = target.current || { columnId: fallbackColumnId, index: 0 };
    finish();
    if (taskId) onMove(taskId, t.columnId, t.index);
  };

  // «Скрыть завершённые» скрывает задачи, но не колонки: доска сохраняет форму.
  const visibleColumns = columns;
  const hiddenCount = hideCompleted ? tasks.filter((t) => t.completedAt).length : 0;

  return (
    <>
      {hiddenCount > 0 && (
        <button onClick={onShowCompleted} className="btn-pill mb-3" style={{ padding: "5px 14px", fontSize: 13, color: theme.textMuted }}>
          Скрыто завершённых: {hiddenCount}. Показать
        </button>
      )}

      <div className="flex gap-3 h-full items-start pb-2">
        {visibleColumns.map((col) => (
          // Порядок задач задаётся выше по дереву (App.jsx) и уже применён к списку.
          <Column key={col.id} column={col}
            tasks={tasks.filter((t) => t.columnId === col.id
              && !(hideCompleted && t.completedAt))}
            theme={theme} directory={directory} canEdit={canEdit} canCreate={canCreate} canMoveTask={canMoveTask} dragging={dragging} dropTarget={dropTarget}
            onOpen={onOpenTask} onDragStart={setDragging} onDragEnd={finish} onHover={hover} onDrop={drop}
            onQuickAdd={onQuickAdd} onSettings={onSettings} onExpandColumn={onExpandColumn}
            highlights={highlights} currentUserId={currentUserId} onOpenUser={onOpenUser} />
        ))}

        {canManage && (
          <button onClick={onSettings} style={{ border: `1.5px dashed ${tint(theme.textMuted, 0.4)}`, color: theme.textMuted }}
            className="w-[18.5vw] min-w-[232px] max-w-[330px] shrink-0 rounded-[24px] py-4 flex items-center justify-center gap-1.5 text-[13px] font-medium transition-colors hover:bg-[var(--t-surfaceAlt)] hover:text-[var(--t-text)]">
            <Plus size={15} /> Добавить колонку
          </button>
        )}
      </div>
    </>
  );
}

// Компонент InboxView предназначен для представления «Входящие»: задачи, порученные пользователю или поставленные им.
export function InboxView({ tasks, theme, directory, hideCompleted, onOpenTask, highlights, currentUserId, onOpenUser }) {
  // «Скрыть завершённые» действует и во «Входящих».
  const shown = hideCompleted ? tasks.filter((t) => !t.completedAt) : tasks;

  const groups = Object.entries(
    shown.reduce((acc, t) => {
      (acc[t.boardTitle || "Без проекта"] ||= []).push(t);
      return acc;
    }, {})
  );

  if (groups.length === 0) {
    return (
      <div className="max-w-md mx-auto text-center py-16">
        <Users size={30} style={{ color: theme.textMuted }} className="mx-auto mb-3" />
        <h3 style={{ color: theme.text }} className="font-semibold text-[17px] mb-1.5">
          {hideCompleted && tasks.length > 0 ? "Незавершённых входящих задач нет" : "Входящих задач нет"}
        </h3>
        <p style={{ color: theme.textMuted }} className="text-[14px] leading-relaxed">
          {hideCompleted && tasks.length > 0
            ? `Все входящие задачи завершены (${tasks.length}). Нажмите «Завершённые» в шапке, чтобы показать их.`
            : "Сюда попадают задачи из чужих проектов, к которым вам открыли доступ точечно, — без доступа к остальной доске."}
        </p>
      </div>
    );
  }

  return (
    <>
      <p style={{ color: theme.textMuted }} className="text-[14px] leading-[21px] mb-4 max-w-2xl">
        Задачи из проектов, участником которых вы не являетесь. Колонки здесь — проекты-источники, а не статусы.
        У каждой карточки указан автор — кто именно поставил задачу.
      </p>
      <div className="flex gap-3 items-start pb-2">
        {groups.map(([title, list]) => (
          <section key={title} className="glass-pane w-[300px] shrink-0 flex flex-col max-h-full p-2">
            <header className="pl-2.5 pr-2 pt-0.5 pb-1.5 flex items-center gap-2 min-h-[36px]">
              <h3 style={{ color: theme.text }} className="font-semibold text-[15px] tracking-[-0.01em] truncate">{title}</h3>
              <CountPill theme={theme} title={plural(list.length, "задача", "задачи", "задач")}>{list.length}</CountPill>
            </header>
            <div className="overflow-y-auto -mx-1 px-1 pt-0.5">
              {list.map((t) => (
                <TaskCard key={t.id} task={t} theme={theme} directory={directory} onOpen={onOpenTask}
                  draggable={false} dragging={null} onDragStart={() => {}} onDragEnd={() => {}} onHover={() => {}}
                  sourceLabel={t.access === "read" ? "просмотр" : "участие"} showAuthor
                  highlight={highlights?.[t.id]} currentUserId={currentUserId} onOpenUser={onOpenUser} />
              ))}
            </div>
          </section>
        ))}
      </div>
    </>
  );
}
