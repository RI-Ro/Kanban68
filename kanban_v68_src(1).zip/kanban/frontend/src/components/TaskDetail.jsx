// Модуль предназначен для карточки задачи: шапка с реквизитами и действиями, исполнители, вкладки «Детали» (чек-лист, отчёт),
// «Комментарии», «Файлы», «Связи», окна смены исполнителей и срока.

import FavStar from "./FavStar.jsx";
import React, { useEffect, useRef, useState } from "react";
import {
  MessageSquarePlus, Smile, Star, Pencil, Trash2, Calendar, Users as UsersIcon, Eye, Lock, Share2, Send, Upload,
  Paperclip, Download, ExternalLink, Check, CheckCheck, X, Plus, CircleDot, CheckCircle2, RotateCcw, Video, Mail, Copy, Printer,
  FolderInput, UserPlus, Hash, BellPlus, Link2, PackageCheck, MoreHorizontal, Flag,
} from "lucide-react";
import { api } from "../lib/api.js";
import FilePreview from "./FilePreview.jsx";
import AuthImage, { downloadFile } from "./AuthImage.jsx";
import AssigneePicker from "./AssigneePicker.jsx";
import { assigneeCandidates, outsideTeam } from "../lib/assignees.js";
import { printTaskPdf } from "../lib/taskPdf.js";
import { onRealtimeMessage } from "../lib/realtime.js";
import { TASK_COLORS, PRIORITIES, GRANT_LABEL, dueColor, recurLabel, fmtDate, fmtDateTime, fmtRelative, fmtSize, resolveUser, conferenceLink, conferenceNames, taskMailLink } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Checkbox, ConfirmDialog, Field, MultilineField, inputStyle, RecurMark } from "../lib/ui.jsx";
import { EmojiPicker, withEmoji } from "./EmojiKit.jsx";
import { taskColorSolid } from "./Board.jsx";

// Функция upsertById предназначена для замены элемента списка по id или добавления в конец (собственные оптимистичные правки и события).
function upsertById(list, item) {
  const i = list.findIndex((x) => x.id === item.id);
  if (i === -1) return [...list, item];
  const next = [...list];
  next[i] = item;
  return next;
}

// Компонент TaskDetail предназначен для карточки задачи.
export default function TaskDetail({ theme, task, directory, team, currentUser, onClose, onEdit, onTaskPatched, onRequestDelete, onRequestCopy, onRequestMove, onRequestReminder, onOpenBoard, teamGroups = [], onError, onOpenUser, onOpenTask, onOpenTaskChat }) {
  const [tab, setTab] = useState("details");
  const [comments, setComments] = useState([]);
  const [files, setFiles] = useState([]);
  const [activity, setActivity] = useState([]);
  const [links, setLinks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [assignOpen, setAssignOpen] = useState(false);
  const [dueOpen, setDueOpen] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const access = task.access;

  // Ссылка вида /tasks/<id> открывает карточку при загрузке приложения; копирование выполняется тем же способом, что в переписке.
  const copyTaskLink = async () => {
    const url = `${window.location.origin}/tasks/${task.id}`;
    const done = () => {
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 1800);
    };
    try {
      await navigator.clipboard.writeText(url);
      done();
      return;
    } catch {
      /* используется запасной способ ниже */
    }
    try {
      const field = document.createElement("textarea");
      field.value = url;
      field.style.position = "fixed";
      field.style.opacity = "0";
      document.body.appendChild(field);
      field.select();
      document.execCommand("copy");
      field.remove();
      done();
    } catch {
      onError("Не удалось скопировать ссылку. Адрес задачи: " + url);
    }
  };
  // Автор задачи имеет полный доступ (правило task_access на сервере): кнопка редактирования и прочие действия ему доступны.
  const isAuthor = task.createdBy === currentUser?.id;
  const canEdit = access === "edit" || isAuthor;
  const readOnly = access === "read" && !isAuthor;
  // Менять исполнителей вправе тот, кто вправе править задачу.
  const canAssign = canEdit && !Boolean(task.completedAt);
  const completed = Boolean(task.completedAt);
  const pr = PRIORITIES[task.priority] || PRIORITIES.medium;
  const assignees = task.assignees.map((id) => resolveUser(directory, id));

  // В конференцию приглашаются исполнители, автор задачи и пользователи с точечным доступом; дубли удаляются.
  const confParticipants = [
    ...new Set([
      ...task.assignees,
      task.createdBy,
      ...(task.grants || []).map((g) => g.userId),
    ].filter(Boolean)),
  ]
    .map((id) => resolveUser(directory, id))
    .filter((u) => !u.deleted && u.phone);
  const confLink =
    confParticipants.length >= 2 ? conferenceLink(confParticipants, currentUser.id) : null;
  const confNames = conferenceNames(confParticipants, currentUser.id);

  // Назначение и снятие головного исполнителя.
  const setHead = async (userId) => {
    try { onTaskPatched(await api.setTaskHead(task.id, userId)); } catch (e) { onError(e.message); }
  };

  // Цвет карточки: полоса вверху окна и выбор цвета без перехода в редактирование.
  const colorMark = taskColorSolid(task.color, theme);
  const [colorOpen, setColorOpen] = useState(false);
  const setColor = async (id) => {
    setColorOpen(false);
    if ((task.color || "none") === id) return;
    try { onTaskPatched(await api.updateTask(task.id, { color: id })); } catch (e) { onError(e.message); }
  };

  // Незавершённые задачи, блокирующие данную.
  const blockedBy = links.filter(
    (l) => l.kind === "blocks" && l.toTask === task.id && !l.completed);

  // Отметка исполнителя доступна, только если текущий пользователь входит в число исполнителей.
  const iAmAssignee = task.assignees.includes(currentUser.id);
  const doneIds = task.assigneesDone || [];
  // Исполнители, открывавшие задачу: одна галочка — открывал, две — отметил свою часть выполненной.
  const seenIds = task.assigneesSeen || [];
  // Исполнители, чей просмотр новее последнего изменения задачи: зелёная галочка, у остальных — серая.
  const freshIds = task.assigneesFresh || [];
  const iMarkedDone = doneIds.includes(currentUser.id);

  const markAssignment = async (next) => {
    try {
      const updated = await api.completeAssignment(task.id, next);
      onTaskPatched(updated);
      reloadActivity();
    } catch (e) {
      onError(e.message);
    }
  };
  const mailLink = taskMailLink(confParticipants, task.title, currentUser.id);
  // Вызов выполняется только после подтверждения.
  const [pendingCall, setPendingCall] = useState(null);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    Promise.all([api.comments(task.id), api.attachments(task.id), api.activity(task.id),
                 api.taskLinks(task.id)])
      .then(([c, f, a, l]) => {
        if (!alive) return;
        setComments(c);
        setFiles(f);
        setActivity(a);
        setLinks(l);
      })
      .catch((e) => onError(e.message))
      .finally(() => alive && setLoading(false));
    return () => { alive = false; };
  }, [task.id, onError]);

  // Пока карточка открыта, выполняется подписка на события этой задачи.
  useEffect(() => {
    const offComment = onRealtimeMessage("comment", (e) => {
      if (e.payload.taskId !== task.id) return;
      setComments((prev) =>
        e.action === "deleted" ? prev.filter((c) => c.id !== e.payload.id) : upsertById(prev, e.payload)
      );
    });
    const offAttachment = onRealtimeMessage("attachment", (e) => {
      if (e.payload.taskId !== task.id) return;
      setFiles((prev) =>
        e.action === "deleted" ? prev.filter((f) => f.id !== e.payload.id) : upsertById(prev, e.payload)
      );
    });
    const offStep = onRealtimeMessage("step", (e) => {
      if (e.payload.taskId !== task.id) return;
      const cur = task.steps || [];
      const next = e.action === "deleted"
        ? cur.filter((x) => x.id !== e.payload.step.id)
        : upsertById(cur, e.payload.step);
      onTaskPatched({ ...task, steps: next });
    });
    return () => { offComment(); offAttachment(); offStep(); };
  }, [task.id, task, onTaskPatched]);

  const reloadActivity = () => api.activity(task.id).then(setActivity).catch(() => {});

  const toggleComplete = async () => {
    try {
      const updated = await api.completeTask(task.id, !completed);
      onTaskPatched(updated);
      reloadActivity();
    } catch (e) {
      onError(e.message);
    }
  };

  const dueTone = dueColor(task.dueDate, completed, theme);
  const canChangeDue = canEdit && !completed;
  // Редкие действия: печать, копия, напоминание, перенос (меню «⋯»).
  const moreItems = [
    { key: "print", icon: Printer, label: "Печать / сохранить в PDF", onClick: () => printTaskPdf(task, directory) },
    { key: "copy", icon: Copy, label: "Копировать задачу", onClick: () => onRequestCopy(task) },
    { key: "remind", icon: BellPlus, label: "Напомнить об этой задаче", onClick: () => onRequestReminder?.(task) },
    ...(canEdit
      ? [{ key: "move", icon: FolderInput, label: "Перенести в другой проект", onClick: () => onRequestMove?.(task) }]
      : []),
  ];
  const showReady = !task.completedAt && (iAmAssignee || (canEdit && task.readyAt));
  const hasActions = canEdit || iAmAssignee || showReady;

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-3xl" padded={false} geometryKey="task-detail">
      {/* Цвет карточки — полоса в самом верху окна, как плашка готовности к сдаче. */}
      {colorMark && <div aria-hidden style={{ background: colorMark }} className="h-[6px] w-full" />}
      {/* Плашка готовности к сдаче расположена выше остального содержимого; у завершённой задачи не отображается. */}
      {task.readyAt && !task.completedAt && (
        <div style={{ background: tint(theme.success, 16), color: theme.text }}
          className="px-6 py-2.5 flex items-center gap-2 flex-wrap">
          <PackageCheck size={16} style={{ color: theme.success }} />
          <span className="text-[13px] font-semibold">Готова к сдаче</span>
          <span style={{ color: theme.textMuted }} className="text-[12px]">
            {task.readyBy ? resolveUser(directory, task.readyBy).fullName : ""} · {fmtDateTime(task.readyAt)}
          </span>
        </div>
      )}

      <div className="px-6 pt-5 pb-4">
        {/* Шапка: название и действия. Правка — с подписью, редкие действия — в меню «⋯», ссылка — отдельной кнопкой. */}
        <div className="flex items-start gap-3">
          <FavStar theme={theme} task={task} size={20} onError={onError} />
          <h2 style={{ color: theme.text }}
            className="flex-1 min-w-0 text-[21px] leading-[28px] font-bold tracking-[-0.015em] break-words pt-0.5">
            {task.title}
          </h2>
          <div className="flex items-center gap-1 shrink-0 -mr-2">
            {canEdit && (
              <button onClick={() => onEdit(task)} className="btn-pill mr-1" style={COMPACT_PILL}
                title="Редактировать задачу">
                <Pencil size={14} /> Редактировать
              </button>
            )}
            {/* Ссылка на задачу строится от текущего адреса приложения. */}
            <button onClick={copyTaskLink} className="btn-icon"
              style={linkCopied ? { color: theme.success } : undefined}
              title={linkCopied ? "Ссылка скопирована" : "Скопировать ссылку на задачу"}
              aria-label={linkCopied ? "Ссылка скопирована" : "Скопировать ссылку на задачу"}>
              {linkCopied ? <Check size={17} /> : <Link2 size={17} />}
            </button>
            <MoreMenu theme={theme} items={moreItems} />
            <button onClick={onClose} className="btn-icon" title="Закрыть" aria-label="Закрыть">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Капсулы реквизитов: приоритет, проект, колонка, срок, повторение, входящий номер, особые режимы доступа. */}
        <div className="flex items-center gap-1.5 flex-wrap mt-3">
          <span className="pill" style={{ background: tint(theme[pr.color], 16), color: theme[pr.color] }}>
            <Flag size={12} /> {pr.label}
          </span>
          {task.boardTitle && (
            // Название проекта — ссылка; переход проверяет права доступа.
            <button onClick={() => onOpenBoard?.(task.boardId)}
              style={{ background: theme.surfaceAlt, color: theme.text }}
              className="pill transition-opacity hover:opacity-80"
              title="Перейти в проект">
              <span style={{ background: theme.accent }} className="w-2 h-2 rounded-full" />
              {task.boardTitle}
            </button>
          )}
          {/* Колонка рядом с проектом показывает стадию работы. */}
          {task.columnTitle && (
            <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="pill" title="Колонка на доске">
              <CircleDot size={12} /> {task.columnTitle}
            </span>
          )}
          {/* Срок отображается капсулой с цветом по остатку времени; тот, кто вправе менять срок, меняет его отсюда. */}
          {canChangeDue ? (
            <button onClick={() => setDueOpen(true)}
              style={{ background: dueTone ? tint(dueTone, 16) : theme.surfaceAlt, color: dueTone || theme.textMuted }}
              className="pill transition-opacity hover:opacity-80 tabular-nums"
              title={task.dueDate ? "Изменить срок" : "Назначить срок"}
              aria-label={task.dueDate ? `Изменить срок, сейчас ${fmtDate(task.dueDate)}` : "Назначить срок"}>
              <Calendar size={12} />
              {task.dueDate ? fmtDate(task.dueDate) : "Назначить срок"}
              <Pencil size={11} style={{ opacity: 0.7 }} />
            </button>
          ) : (
            <span style={{ background: dueTone ? tint(dueTone, 16) : theme.surfaceAlt, color: dueTone || theme.textMuted }}
              className="pill tabular-nums" title="Срок исполнения">
              <Calendar size={12} /> {fmtDate(task.dueDate)}
            </span>
          )}
          {/* Периодичность отображается в шапке карточки. */}
          {recurLabel(task) && (
            <span style={{ background: theme.surfaceAlt }} className="pill">
              <RecurMark task={task} theme={theme} withText />
            </span>
          )}
          {/* Входящий номер и его дата — реквизиты документа. */}
          {task.incomingNumber && (
            <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="pill tabular-nums" title="Входящий номер">
              <Hash size={12} />{task.incomingNumber}
              {task.incomingDate ? ` от ${fmtDate(task.incomingDate)}` : ""}
            </span>
          )}
          {readOnly && (
            <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="pill">
              <Eye size={12} /> только просмотр
            </span>
          )}
          {access === "contribute" && !isAuthor && (
            <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="pill">
              <Lock size={12} /> участие без редактирования
            </span>
          )}
          {completed && (
            <span style={{ background: tint(theme.success, 16), color: theme.success }} className="pill"
              title="Когда задачу пометили завершённой">
              <Check size={12} /> завершена {fmtDateTime(task.completedAt)}
            </span>
          )}
        </div>

        {/* Строка действий: завершение и отметки исполнителя. */}
        {hasActions && (
          <div className="flex items-center gap-2 flex-wrap mt-4">
            {canEdit && (
              <button onClick={toggleComplete}
                className={completed ? "btn-pill" : "btn-primary"}
                style={completed ? COMPACT_PILL : COMPACT_PRIMARY}>
                {completed ? <RotateCcw size={15} /> : <CheckCircle2 size={15} />}
                {completed ? "Вернуть в работу" : "Пометить завершённой"}
              </button>
            )}

            {iAmAssignee && (
              // Без права правки отметка исполнителя — основное действие и выделяется.
              <button onClick={() => markAssignment(!iMarkedDone)}
                className={!canEdit && !iMarkedDone ? "btn-primary" : "btn-pill"}
                style={!canEdit && !iMarkedDone ? COMPACT_PRIMARY : COMPACT_PILL}>
                {iMarkedDone ? <RotateCcw size={14} /> : <CheckCheck size={15} style={!canEdit ? undefined : { color: theme.success }} />}
                {iMarkedDone ? "Снять мою отметку о выполнении" : "Я выполнил свою часть"}
              </button>
            )}

            {/* Цвет карточки меняется здесь же, без перехода в редактирование. */}
            {canEdit && (
              <span className="relative">
                <button onClick={() => setColorOpen((v) => !v)} className="btn-pill" style={COMPACT_PILL}
                  title="Цвет карточки" aria-label="Цвет карточки" aria-expanded={colorOpen}>
                  <span style={{ background: colorMark || "transparent", border: colorMark ? "none" : `1.5px dashed ${theme.textMuted}` }}
                    className="w-3.5 h-3.5 rounded-full inline-block" />
                  Цвет
                </button>
                {colorOpen && (
                  <>
                    <div className="fixed inset-0 z-[60]" onClick={() => setColorOpen(false)} />
                    <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
                      className="absolute left-0 top-full mt-2 z-[61] p-2.5 rounded-2xl shadow-xl flex flex-wrap gap-2 w-[220px]">
                      {TASK_COLORS.map((c) => {
                        const solid = taskColorSolid(c.id, theme);
                        const active = (task.color || "none") === c.id;
                        return (
                          <button key={c.id} type="button" onClick={() => setColor(c.id)} title={c.label} aria-label={c.label} aria-pressed={active}
                            style={{
                              background: solid || "transparent",
                              border: solid ? "none" : `1.5px dashed ${theme.textMuted}`,
                              boxShadow: active ? `0 0 0 2px ${theme.surface}, 0 0 0 4px ${theme.accent}` : "none",
                            }}
                            className="w-6 h-6 rounded-full flex items-center justify-center transition-transform hover:scale-110">
                            {c.id === "none" && <X size={12} style={{ color: theme.textMuted }} />}
                          </button>
                        );
                      })}
                    </div>
                  </>
                )}
              </span>
            )}

            {/* Готовность к сдаче: состояние между «в работе» и «завершена» (исполнитель закончил, ожидается приёмка). */}
            {showReady && (
              <button
                onClick={async () => {
                  try { onTaskPatched(await api.setTaskReady(task.id, !task.readyAt)); }
                  catch (e) { onError(e.message); }
                }}
                className="btn-pill" style={COMPACT_PILL}>
                <PackageCheck size={15} style={task.readyAt ? undefined : { color: theme.success }} />
                {task.readyAt ? "Снять отметку о готовности" : "Задача готова к сдаче"}
              </button>
            )}
          </div>
        )}

        {blockedBy.length > 0 && !completed && (
          <div style={{ background: tint(theme.danger, 12), border: `1px solid ${tint(theme.danger, 40)}` }}
            className="w-full mt-3 rounded-xl px-3 py-2.5 text-[13px] leading-snug"
            role="status">
            <span style={{ color: theme.danger }} className="font-semibold">Заблокирована. </span>
            <span style={{ color: theme.text }}>
              Нельзя завершить, пока не закрыты: {blockedBy.map((l) => `«${l.title}»`).join(", ")}.
            </span>
          </div>
        )}

        {task.description && (
          <p style={{ color: theme.text }} className="text-[14px] leading-[1.55] mt-4 whitespace-pre-wrap break-words">{task.description}</p>
        )}

        {/* Исполнители: заголовок с действиями над составом, капсулы с отметками и легенда. */}
        <div className="mt-5">
          <div className="flex items-center gap-2 flex-wrap mb-2">
            <span style={{ color: theme.text }} className="text-[13px] font-semibold flex items-center gap-1.5">
              <UsersIcon size={14} style={{ color: theme.textMuted }} /> Исполнители
            </span>
            <span style={{ background: theme.surfaceAlt, color: theme.textMuted }}
              className="text-[11px] font-medium px-1.5 rounded-full tabular-nums leading-[18px]">{assignees.length}</span>
            <span className="flex-1" />
            {canAssign && (
              // Смена исполнителей выполняется отдельной кнопкой: условия задачи не меняются.
              <button onClick={() => setAssignOpen(true)} className="btn-pill" style={SMALL_PILL}>
                <UserPlus size={13} style={{ color: theme.accent }} /> Поручить
              </button>
            )}
            {/* Групповой чат внутри системы: название задачи, участники — исполнители, автор и приглашённые. */}
            {onOpenTaskChat && (assignees.length > 0 || (task.grants || []).length > 0) && (
              <button onClick={() => onOpenTaskChat(task)} className="btn-pill" style={SMALL_PILL}
                title="Создать групповой чат по задаче или перейти в него" aria-label="Чат задачи">
                <MessageSquarePlus size={13} style={{ color: theme.accent }} /> Чат задачи
              </button>
            )}
            {mailLink && (
              <a href={mailLink} className="btn-pill" style={SMALL_PILL}
                title={`Написать: ${confNames}`} aria-label={`Написать участникам: ${confNames}`}>
                <Mail size={13} style={{ color: theme.accent }} /> Написать участникам
              </a>
            )}
            {/* Видеоконференция со всеми участниками: схема callto://n1&n2 объединяет несколько номеров в один вызов. */}
            {confLink && (
              <button onClick={() => setPendingCall({ href: confLink, names: confNames })}
                className="btn-pill" style={SMALL_PILL}
                title={`Собрать участников: ${confNames}`} aria-label={`Видеоконференция: ${confNames}`}>
                <Video size={13} style={{ color: theme.accent }} /> Видеоконференция
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            {assignees.length === 0 && (
              <span style={{ color: theme.textMuted }} className="text-[13px]">Не назначены</span>
            )}
            {assignees.map((u, i) => {
              const done = doneIds.includes(u.id);
              const seen = seenIds.includes(u.id);
              const fresh = freshIds.includes(u.id);
              // Три состояния отметки: две зелёные галочки — отметил свою часть выполненной; зелёная — видел задачу в текущем виде; серая — видел ранее.
              const mark = done
                ? { icon: <CheckCheck size={14} style={{ color: theme.success }} />,
                    hint: "Две зелёные галочки: исполнитель отметил свою часть выполненной" }
                : fresh
                ? { icon: <Check size={14} style={{ color: theme.success }} />,
                    hint: "Зелёная галочка: исполнитель видел задачу после последнего изменения" }
                : seen
                ? { icon: <Check size={14} style={{ color: theme.textMuted }} />,
                    hint: "Серая галочка: исполнитель знакомился с задачей, но после этого она менялась" }
                : { icon: null, hint: "Исполнитель ещё не открывал задачу" };
              const isHead = task.headAssignee === u.id;
              return (
                <span key={`${u.id}-${i}`} className="inline-flex items-center">
                <button onClick={() => onOpenUser(u)}
                  style={{ background: theme.surfaceAlt, border: `1px solid ${isHead ? theme.accent : theme.border}`, boxShadow: isHead ? `0 0 0 1px ${theme.accent}` : "none" }}
                  title={`${u.fullName}${isHead ? " (головной исполнитель)" : ""} — ${mark.hint}`}
                  className="flex items-center gap-1.5 p-[2px] pr-2.5 rounded-full transition-opacity hover:opacity-85">
                  <Avatar user={u} size={24} theme={theme} />
                  <span style={{ color: u.deleted ? theme.textMuted : theme.text, textDecoration: u.deleted ? "line-through" : "none" }} className="text-[13px]">
                    {u.fullName}
                  </span>
                  {isHead && <Star size={13} fill={theme.accent} style={{ color: theme.accent }} aria-label="Головной исполнитель" />}
                  {mark.icon}
                </button>
                {canAssign && assignees.length > 1 && (
                  // Головного назначает и снимает тот, кто может править задачу; повторное нажатие снимает отметку.
                  <button onClick={() => setHead(isHead ? null : u.id)} className="btn-icon"
                    style={{ width: 22, height: 22, color: isHead ? theme.accent : theme.textMuted }}
                    title={isHead ? "Снять отметку головного исполнителя" : "Назначить головным исполнителем"}
                    aria-label="Головной исполнитель">
                    <Star size={13} fill={isHead ? theme.accent : "none"} />
                  </button>
                )}
                </span>
              );
            })}
          </div>

          {assignees.length > 0 && (
            // Легенда обозначений галочек.
            <div style={{ color: theme.textMuted }} className="flex items-center gap-x-3 gap-y-1 mt-2 text-[11px] flex-wrap">
              <span className="flex items-center gap-1"><Check size={12} /> ознакомился</span>
              <span className="flex items-center gap-1"><Check size={12} style={{ color: theme.success }} /> видел последние изменения</span>
              <span className="flex items-center gap-1"><CheckCheck size={12} style={{ color: theme.success }} /> выполнил свою часть</span>
            </div>
          )}
        </div>
      </div>

      {/* Вкладки капсулой-переключателем, счётчики — малыми капсулами; при узком окне прокрутка вбок. */}
      <div style={{ borderColor: theme.border }} className="px-6 pt-3 pb-3 border-t overflow-x-auto">
        <div role="tablist" aria-label="Разделы задачи" className="segmented">
          {[["details", "Детали", null], ["comments", "Комментарии", comments.length], ["files", "Файлы", files.length], ["links", "Связи", links.length], ["activity", "История", null]].map(([key, label, count]) => (
            <button key={key} role="tab" aria-selected={tab === key} onClick={() => setTab(key)}
              className="whitespace-nowrap flex items-center gap-1.5" style={{ padding: "5px 12px" }}>
              {label}
              {count !== null && (
                <span style={{ background: tab === key ? theme.surfaceAlt : tint(theme.textMuted, 16), color: theme.textMuted }}
                  className="text-[11px] font-medium leading-[18px] min-w-[18px] px-1.5 rounded-full tabular-nums text-center">
                  {count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Прокрутка карточки общая, её обеспечивает окно (Modal). */}
      <div className="px-6 pt-2 pb-8">
        {loading && <p style={{ color: theme.textMuted }} className="text-[13px]">Загружаем…</p>}

        {!loading && tab === "details" && (
          <DetailsTab theme={theme} task={task} directory={directory} team={team} currentUser={currentUser} canEdit={canEdit} readOnly={readOnly} access={access} isAuthor={isAuthor}
            onTaskPatched={onTaskPatched} onError={onError} onRequestDelete={onRequestDelete} reloadActivity={reloadActivity} />
        )}

        {!loading && tab === "comments" && (
          <CommentsTab theme={theme} task={task} directory={directory} currentUser={currentUser}
            comments={comments} setComments={setComments} readOnly={readOnly} onError={onError} onOpenUser={onOpenUser} />
        )}

        {!loading && tab === "files" && (
          <FilesTab theme={theme} task={task} directory={directory} files={files} setFiles={setFiles} readOnly={readOnly} onError={onError} />
        )}

        {!loading && tab === "links" && (
          <LinksTab theme={theme} task={task} links={links} setLinks={setLinks}
            canEdit={canEdit} onError={onError} onOpenTask={onOpenTask} />
        )}

        {!loading && tab === "activity" && (
          <div>
            {activity.map((h) => (
              <div key={h.id} className="flex items-start gap-3 py-2">
                <span style={{ background: theme.accent }} className="w-2 h-2 rounded-full mt-[7px] shrink-0" />
                <div className="min-w-0">
                  <div style={{ color: theme.text }} className="text-[13px] leading-snug break-words">{h.body}</div>
                  <div style={{ color: theme.textMuted }} className="text-[12px] mt-0.5 tabular-nums">
                    {fmtDateTime(h.createdAt)}{h.actorId ? ` · ${resolveUser(directory, h.actorId).fullName}` : ""}
                  </div>
                </div>
              </div>
            ))}
            {activity.length === 0 && <p style={{ color: theme.textMuted }} className="text-[13px]">Записей нет.</p>}
          </div>
        )}
      </div>

      {/* Окно смены исполнителей расположено в карточке: состояние assignOpen объявлено рядом с остальными действиями над задачей. */}
      {assignOpen && (
        <AssignModal theme={theme} task={task} directory={directory} team={team} teamGroups={teamGroups}
          currentUser={currentUser}
          onClose={() => setAssignOpen(false)}
          onSaved={(t) => { onTaskPatched(t); setAssignOpen(false); }}
          onError={onError} />
      )}

      {dueOpen && (
        <DueDateModal theme={theme} task={task}
          onClose={() => setDueOpen(false)}
          onSaved={(t) => { onTaskPatched(t); setDueOpen(false); reloadActivity(); }}
          onError={onError} />
      )}

      {pendingCall && (
        <ConfirmDialog theme={theme}
          title="Начать видеоконференцию?"
          message={`Вызов будет отправлен участникам: ${pendingCall.names}. Убедитесь, что это не случайное нажатие.`}
          confirmLabel="Позвонить" danger={false}
          onCancel={() => setPendingCall(null)}
          onConfirm={() => {
            const href = pendingCall.href;
            setPendingCall(null);
            window.location.href = href;
          }} />
      )}
    </Modal>
  );
}

/* Раздел: общие функции вида. */

// Функция tint предназначена для получения полупрозрачного тона цвета темы для капсул приоритета, срока и статусов.
function tint(color, pct) {
  return `color-mix(in srgb, ${color} ${pct}%, transparent)`;
}

// Компактные размеры кнопок окна: стандартные .btn-primary и .btn-pill рассчитаны на шапку экрана.
const COMPACT_PRIMARY = { padding: "7px 16px", fontSize: 13 };
const COMPACT_PILL = { padding: "6px 14px", fontSize: 13 };
const SMALL_PILL = { padding: "4px 12px", fontSize: 12.5, gap: 6 };

// Компонент MoreMenu предназначен для меню «⋯» с подписанными пунктами; закрывается щелчком вне меню и по Escape
// (Escape не закрывает окно задачи).
function MoreMenu({ theme, items }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDown);
    ref.current?.querySelector('[role="menuitem"]')?.focus();
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  const onKeyDown = (e) => {
    if (!open) return;
    const list = [...ref.current.querySelectorAll('[role="menuitem"]')];
    const at = list.indexOf(document.activeElement);
    if (e.key === "Escape") {
      e.stopPropagation();
      setOpen(false);
      ref.current.querySelector("button")?.focus();
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      list[(at + 1) % list.length]?.focus();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      list[(at - 1 + list.length) % list.length]?.focus();
    }
  };

  return (
    <div ref={ref} className="relative" onKeyDown={onKeyDown}>
      <button onClick={() => setOpen((v) => !v)} className="btn-icon"
        style={open ? { background: theme.surfaceAlt, color: theme.text } : undefined}
        aria-haspopup="menu" aria-expanded={open}
        title="Ещё действия" aria-label="Ещё действия">
        <MoreHorizontal size={18} />
      </button>
      {open && (
        <div role="menu"
          style={{ background: theme.surface, border: `1px solid ${theme.border}`, boxShadow: "0 16px 40px -16px rgba(0,0,0,.45)" }}
          className="absolute right-0 top-full mt-1.5 z-30 min-w-[248px] p-1.5 rounded-2xl">
          {items.map(({ key, icon: Icon, label, onClick }) => (
            <button key={key} role="menuitem"
              onClick={() => { setOpen(false); onClick(); }}
              style={{ color: theme.text }}
              className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2 text-[13px] text-left transition-colors hover:bg-[var(--t-surfaceAlt)] focus-visible:bg-[var(--t-surfaceAlt)]">
              <Icon size={15} style={{ color: theme.textMuted }} className="shrink-0" />
              {label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* Раздел: детали. */
/* Компонент DetailsTab предназначен для вкладки «Детали»: описание, чек-лист, отчёт, точечный доступ. */

function DetailsTab({ theme, task, directory, team, currentUser, canEdit, readOnly, access, isAuthor, onTaskPatched, onError, onRequestDelete, reloadActivity }) {
  const [grantOpen, setGrantOpen] = useState(false);
  const [grantSearch, setGrantSearch] = useState("");

  // Функция patchSteps предназначена для изменения только массива steps задачи без перезагрузки карточки.
  const patchSteps = (updater) => onTaskPatched({ ...task, steps: updater(task.steps) });

  const toggleStep = async (stepId, done) => {
    // Оптимистичное обновление отметки.
    patchSteps((steps) => steps.map((s) => (s.id === stepId ? { ...s, done } : s)));
    try {
      const updated = await api.toggleStep(task.id, stepId, done);
      // Ответ сервера объединяется с пунктом по id с сохранением порядка.
      patchSteps((steps) => steps.map((s) => (s.id === stepId ? { ...s, ...updated } : s)));
    } catch (e) {
      // Откат: возвращается прежнее значение отметки.
      patchSteps((steps) => steps.map((s) => (s.id === stepId ? { ...s, done: !done } : s)));
      onError(e.message);
    }
  };

  const renameStep = async (stepId, payload) => {
    try {
      const updated = await api.renameStep(task.id, stepId, payload);
      patchSteps((steps) => steps.map((s) => (s.id === stepId ? updated : s)));
    } catch (e) {
      onError(e.message);
    }
  };

  const addStep = async (payload) => {
    const body = (payload.body || "").trim();
    if (!body) return;
    try {
      const created = await api.createStep(task.id, { ...payload, body });
      patchSteps((steps) => (steps.some((s) => s.id === created.id)
        ? steps.map((s) => (s.id === created.id ? created : s))
        : [...steps, created]));
    } catch (e) {
      onError(e.message);
    }
  };

  const deleteStep = async (stepId) => {
    const prev = task.steps;
    patchSteps((steps) => steps.filter((s) => s.id !== stepId));
    try {
      await api.deleteStep(task.id, stepId);
    } catch (e) {
      onTaskPatched({ ...task, steps: prev });
      onError(e.message);
    }
  };

  const saveGrants = async (grants) => {
    try {
      const updated = await api.setGrants(task.id, grants);
      onTaskPatched(updated);
      reloadActivity();
    } catch (e) {
      onError(e.message);
    }
  };

  const candidates = directory
    // Точечный доступ выдаётся любому пользователю системы, а не только своей команде: команда определяет, кому можно поручать задачи.
    .filter((u) => u.id !== currentUser?.id)
    .filter((u) => !u.deleted && !task.assignees.includes(u.id) && !task.grants.some((g) => g.userId === u.id))
    .filter((u) => {
      const q = grantSearch.trim().toLowerCase();
      if (!q) return true;
      return u.fullName.toLowerCase().includes(q)
        || (u.position || "").toLowerCase().includes(q);
    })
    .slice(0, 8);

  return (
    <div>
      {task.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-5">
          {task.tags.map((t) => (
            <span key={t} style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="pill">#{t}</span>
          ))}
        </div>
      )}

      {/* Сначала чек-лист (ход работы), затем отчёт (итог). */}
      <ChecklistSection theme={theme} task={task} directory={directory} team={team}
        currentUser={currentUser} canManage={canEdit || task.createdBy === currentUser?.id}
        onToggle={toggleStep} onRename={renameStep} onAdd={addStep} onDelete={deleteStep} />

      <ReportSection theme={theme} task={task}
        canWrite={canEdit || access === "contribute" || isAuthor}
        onSaved={(t) => onTaskPatched(t)} onError={onError} />

      {canEdit && (
        <div style={{ borderColor: theme.border }} className="mb-5 pt-5 border-t">
          <div className="flex items-center gap-2">
            <span style={{ color: theme.text }} className="text-[15px] font-semibold flex-1">Доступ к задаче</span>
            <button onClick={() => setGrantOpen((v) => !v)} className="btn-pill" aria-expanded={grantOpen}
              style={{ padding: "4px 12px", fontSize: 12.5, gap: 6 }}>
              <Share2 size={13} style={{ color: theme.accent }} />
              {grantOpen ? "Скрыть поиск" : "Открыть доступ"}
              {task.grants.length > 0 && (
                <span style={{ color: theme.textMuted }} className="tabular-nums">· {task.grants.length}</span>
              )}
            </button>
          </div>

          {task.grants.map((g) => {
            const u = resolveUser(directory, g.userId);
            return (
              <div key={g.userId} className="flex items-center gap-2.5 mt-2.5">
                <Avatar user={u} size={24} theme={theme} />
                <span style={{ color: theme.text }} className="text-[13px] flex-1 truncate">{u.fullName}</span>
                <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="pill">{GRANT_LABEL[g.access]}</span>
                <button onClick={() => saveGrants(task.grants.filter((x) => x.userId !== g.userId))}
                  className="btn-icon" style={{ width: 28, height: 28, color: theme.danger }}
                  title="Отозвать доступ" aria-label={`Отозвать доступ: ${u.fullName}`}><X size={14} /></button>
              </div>
            );
          })}

          {grantOpen && (
            <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }} className="rounded-2xl p-3 mt-3">
              <input value={grantSearch} onChange={(e) => setGrantSearch(e.target.value)} placeholder="Найти сотрудника — по имени или должности, по всей системе"
                style={{ ...inputStyle(theme), background: theme.surface }} className="w-full rounded-xl px-3 py-2 text-[13px] outline-none mb-2" />
              {candidates.map((u) => (
                <div key={u.id} className="flex items-center gap-2.5 py-1">
                  <Avatar user={u} size={24} theme={theme} />
                  <span style={{ color: theme.text }} className="text-[13px] flex-1 truncate">{u.fullName}</span>
                  <button onClick={() => saveGrants([...task.grants, { userId: u.id, access: "read" }])}
                    className="btn-pill" style={{ padding: "3px 10px", fontSize: 12, background: theme.surface }}>Просмотр</button>
                  <button onClick={() => saveGrants([...task.grants, { userId: u.id, access: "contribute" }])}
                    className="btn-pill" style={{ padding: "3px 10px", fontSize: 12, background: theme.surface, color: theme.accent }}>Участие</button>
                </div>
              ))}
              {candidates.length === 0 && <p style={{ color: theme.textMuted }} className="text-[12px]">Никого не найдено.</p>}
              <p style={{ color: theme.textMuted }} className="text-[12px] mt-2 leading-relaxed">
                Человек получит только эту задачу — остальная доска останется закрытой. Она появится у него в разделе «Входящие».
              </p>
            </div>
          )}
        </div>
      )}

      {canEdit && (
        <button onClick={() => onRequestDelete(task.id)} style={{ color: theme.danger }}
          className="flex items-center gap-1.5 text-[13px] font-medium rounded-full px-3 py-1.5 -ml-3 transition-colors hover:bg-[var(--t-surfaceAlt)]">
          <Trash2 size={14} /> Удалить задачу
        </button>
      )}
    </div>
  );
}

/* Раздел: расширенный чек-лист. */

// Права в чек-листе: canManage — автор задачи, редактор или владелец проекта (правит текст, исполнителя и срок, добавляет и удаляет пункты);
// отметку о выполнении и фактический срок ставит только назначенный исполнитель пункта.
// Компонент ReportSection предназначен для отчёта о выполнении задачи: свободный текст, который выводится в печатной версии.
function ReportSection({ theme, task, canWrite, onSaved, onError }) {
  const [text, setText] = useState(task.report || "");
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);

  // Внешние изменения отчёта (например, по WebSocket) подхватываются, пока пользователь его не редактирует.
  useEffect(() => {
    if (!dirty) setText(task.report || "");
  }, [task.report, dirty]);

  const save = async () => {
    setSaving(true);
    try {
      const updated = await api.setReport(task.id, text);
      onSaved(updated);
      setDirty(false);
    } catch (e) {
      onError(e.message);
    } finally {
      setSaving(false);
    }
  };

  // У завершённой задачи отчёт доступен только для чтения: по нему задачу принимали.
  const locked = Boolean(task.completedAt);

  // Высота поля подгоняется под содержимое после каждой правки.
  const reportRef = useRef(null);
  useEffect(() => {
    const el = reportRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${el.scrollHeight}px`;
  }, [text]);

  if (!canWrite || locked) {
    if (!task.report) {
      return locked && canWrite ? (
        <div style={{ borderColor: theme.border }} className="mb-5 pt-5 border-t">
          <SectionTitle theme={theme}>Отчёт о выполнении</SectionTitle>
          <p style={{ color: theme.textMuted }} className="text-[12.5px] leading-relaxed">
            Задача завершена без отчёта. Чтобы его добавить, верните задачу в работу.
          </p>
        </div>
      ) : null;
    }
    return (
      <div style={{ borderColor: theme.border }} className="mb-5 pt-5 border-t">
        <SectionTitle theme={theme}>Отчёт о выполнении</SectionTitle>
        <p style={{ color: theme.text }} className="text-[14px] leading-[1.55] whitespace-pre-wrap break-words">{task.report}</p>
        {locked && canWrite && (
          <p style={{ color: theme.textMuted }} className="text-[12px] mt-1.5">
            Задача завершена — отчёт не редактируется. Верните её в работу, если нужно исправить.
          </p>
        )}
      </div>
    );
  }

  return (
    <div style={{ borderColor: theme.border }} className="mb-5 pt-5 border-t">
      <SectionTitle theme={theme}>Отчёт о выполнении</SectionTitle>
      {/* В отчёте Enter переносит строку. */}
      {/* Поле растёт под текст, а не прокручивается внутри себя. */}
      <textarea ref={reportRef} value={text}
        onChange={(e) => { setText(e.target.value); setDirty(true); }}
        onKeyDown={(e) => {
          if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); save(); }
        }}
        placeholder="Что сделано по задаче… Ctrl+Enter — сохранить" rows={3}
        style={{ ...inputStyle(theme), resize: "none", overflow: "hidden" }}
        className="w-full rounded-xl px-3 py-2.5 text-[14px] leading-[1.5] outline-none" />
      {dirty && (
        <div className="flex gap-2 mt-2">
          <button onClick={save} disabled={saving} className="btn-primary disabled:opacity-50"
            style={{ padding: "6px 14px", fontSize: 13 }}>
            {saving ? "Сохранение…" : "Сохранить отчёт"}
          </button>
          <button onClick={() => { setText(task.report || ""); setDirty(false); }}
            className="btn-pill" style={{ padding: "5px 14px", fontSize: 13 }}>
            Отмена
          </button>
        </div>
      )}
    </div>
  );
}

// Раздел: чек-лист.
// Компонент ChecklistSection предназначен для объединённого чек-листа: у пункта необязательные исполнитель и срок.
// Если исполнитель задан — отметку ставит только он (или ведущий чек-лист), иначе любой участник. Состав правит автор, редактор
// или владелец проекта (canManage).
function ChecklistSection({ theme, task, directory, team, currentUser, canManage, onToggle, onRename, onAdd, onDelete }) {
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState({ body: "", assigneeId: "", dueDate: "" });
  const [editingId, setEditingId] = useState(null);

  const teamSet = new Set(team || []);
  const candidates = directory
    .filter((u) => !u.deleted && (teamSet.has(u.id) || u.id !== currentUser.id))
    .filter((u) => teamSet.has(u.id))
    .sort((a, b) => a.fullName.localeCompare(b.fullName, "ru"));

  const resetDraft = () => setDraft({ body: "", assigneeId: "", dueDate: "" });
  const stepsTotal = (task.steps || []).length;
  const stepsDone = (task.steps || []).filter((s) => s.done).length;

  // Функция submitNew предназначена для добавления пункта; keepOpen (Enter) оставляет форму открытой и пустой для ввода следующего пункта.
  const submitNew = (keepOpen = false) => {
    if (!draft.body.trim()) return;
    onAdd({ body: draft.body.trim(), assigneeId: draft.assigneeId || null, dueDate: draft.dueDate || null });
    resetDraft();
    if (!keepOpen) setAdding(false);
  };

  const editor = (value, setValue, onSave, onCancel, onSubmitKey = onSave) => (
    <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }} className="rounded-2xl p-3 mb-2">
      <MultilineField theme={theme} value={value.body} autoFocus
        onChange={(body) => setValue({ ...value, body })}
        onSubmit={onSubmitKey}
        placeholder="Что нужно сделать. Ctrl+Enter — добавить, Enter — новая строка"
        className="w-full rounded-xl px-3 py-2 text-[13px] outline-none mb-2" />
      <div className="grid grid-cols-2 gap-2">
        <div>
          <div style={{ color: theme.textMuted }} className="text-[12px] font-medium mb-1">Исполнитель</div>
          <select value={value.assigneeId} onChange={(e) => setValue({ ...value, assigneeId: e.target.value })}
            style={inputStyle(theme)} className="w-full rounded-xl px-2.5 py-2 text-[13px] outline-none">
            <option value="">Не назначен (любой может отметить)</option>
            {candidates.map((u) => <option key={u.id} value={u.id}>{u.fullName}</option>)}
          </select>
        </div>
        <div>
          <div style={{ color: theme.textMuted }} className="text-[12px] font-medium mb-1">Срок (необязательно)</div>
          <input type="date" value={value.dueDate || ""} onChange={(e) => setValue({ ...value, dueDate: e.target.value })}
            style={inputStyle(theme)} className="w-full rounded-xl px-2.5 py-2 text-[13px] outline-none" />
        </div>
      </div>
      <div className="flex gap-2 mt-3">
        <button onClick={onSave} className="btn-primary" style={{ padding: "6px 14px", fontSize: 13 }}>Сохранить</button>
        <button onClick={onCancel} className="btn-pill" style={{ padding: "5px 14px", fontSize: 13, background: theme.surface }}>Отмена</button>
      </div>
    </div>
  );

  return (
    // Запас снизу: последний пункт не упирается в границу прокручиваемой области.
    <div className="mb-5 pb-2">
      <div className="flex items-center gap-3 mb-2.5">
        <span style={{ color: theme.text }} className="text-[15px] font-semibold">Чек-лист</span>
        {stepsTotal > 0 && (
          <>
            {/* Полоса прогресса: отмечено пунктов из общего числа. */}
            <span style={{ background: theme.surfaceAlt }} className="flex-1 h-1.5 rounded-full overflow-hidden max-w-[240px]"
              role="progressbar" aria-valuemin={0} aria-valuemax={stepsTotal} aria-valuenow={stepsDone}
              aria-label="Выполнено пунктов чек-листа">
              <span style={{ width: `${(stepsDone / stepsTotal) * 100}%`, background: stepsDone === stepsTotal ? theme.success : theme.accent }}
                className="block h-full rounded-full transition-[width] duration-150 ease-out" />
            </span>
            <span style={{ color: theme.textMuted }} className="text-[12px] font-medium tabular-nums">{stepsDone}/{stepsTotal}</span>
          </>
        )}
      </div>
      {(task.steps || []).length === 0 && !adding && (
        <p style={{ color: theme.textMuted }} className="text-[13px] mb-2">Пунктов пока нет.</p>
      )}

      {(task.steps || []).map((s) => {
        if (editingId === s.id) {
          return (
            <StepEditor key={s.id} theme={theme} candidates={candidates} initial={s} editor={editor}
              onSave={(val) => { onRename(s.id, { body: val.body.trim(), assigneeId: val.assigneeId || null, dueDate: val.dueDate || null }); setEditingId(null); }}
              onCancel={() => setEditingId(null)} />
          );
        }
        const assignee = s.assigneeId ? resolveUser(directory, s.assigneeId) : null;
        const iAmAssignee = s.assigneeId === currentUser.id;
        const canToggle = canManage || iAmAssignee || (!s.assigneeId);
        const doneBy = s.doneBy ? resolveUser(directory, s.doneBy) : null;
        const overdue = s.dueDate && !s.done && s.dueDate < todayStr();
        return (
          <div key={s.id} className="group rounded-xl px-2 py-1.5 -mx-2 transition-colors hover:bg-[var(--t-surfaceAlt)]">
            <div className="flex items-start gap-2.5">
              <span className="flex items-center pt-[3px]" title={canToggle ? "" : "Отметить может только назначенный исполнитель"}>
                <Checkbox theme={theme} checked={s.done} disabled={!canToggle} onChange={(next) => onToggle(s.id, next)} />
              </span>
              <div className="flex-1 min-w-0">
                {/* Пункт может быть многострочным: переносы строк сохраняются. */}
                <div style={{ color: s.done ? theme.textMuted : theme.text, textDecoration: s.done ? "line-through" : "none" }}
                  className="text-[14px] leading-[1.45] whitespace-pre-wrap break-words">{s.body}</div>
                {(assignee || s.dueDate || (s.done && (doneBy || s.doneAt))) && (
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 mt-0.5">
                    {assignee && !assignee.deleted && (
                      <span style={{ color: theme.textMuted }} className="text-[12px] flex items-center gap-1"><UsersIcon size={12} />{assignee.fullName}</span>
                    )}
                    {s.dueDate && (
                      <span style={{ color: overdue ? theme.danger : theme.textMuted }} className="text-[12px] flex items-center gap-1 tabular-nums"><Calendar size={12} />до {fmtDate(s.dueDate)}</span>
                    )}
                    {s.done && (doneBy || s.doneAt) && (
                      <span style={{ color: theme.success }} className="text-[12px] flex items-center gap-1 tabular-nums">
                        <Check size={12} />
                        {doneBy && !doneBy.deleted ? doneBy.fullName : "выполнено"}
                        {s.doneAt ? ` · ${fmtDateTime(s.doneAt)}` : ""}
                      </span>
                    )}
                  </div>
                )}
              </div>
              {canManage && (
                <span className="flex items-center gap-0.5 -my-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                  <button onClick={() => setEditingId(s.id)} className="btn-icon" style={{ width: 28, height: 28 }}
                    title="Изменить" aria-label="Изменить пункт"><Pencil size={13} /></button>
                  <button onClick={() => onDelete(s.id)} className="btn-icon" style={{ width: 28, height: 28, color: theme.danger }}
                    title="Удалить" aria-label="Удалить пункт"><Trash2 size={13} /></button>
                </span>
              )}
            </div>
          </div>
        );
      })}

      {adding && editor(draft, setDraft, () => submitNew(false),
        () => { resetDraft(); setAdding(false); },
        () => submitNew(true))}

      {canManage && !adding && (
        <button onClick={() => setAdding(true)} className="btn-pill mt-2" style={{ padding: "5px 14px", fontSize: 13, gap: 6 }}>
          <Plus size={14} style={{ color: theme.accent }} /> Добавить пункт
        </button>
      )}
    </div>
  );
}

// Компонент SectionTitle предназначен для заголовка раздела.
function SectionTitle({ theme, children }) {
  return <div style={{ color: theme.text }} className="text-[15px] font-semibold mb-2.5">{children}</div>;
}

// Компонент StepEditor предназначен для редактирования пункта чек-листа.
function StepEditor({ theme, editor, initial, onSave, onCancel }) {
  const [val, setVal] = useState({ body: initial.body, assigneeId: initial.assigneeId || "", dueDate: initial.dueDate || "" });
  return editor(val, setVal, () => onSave(val), onCancel);
}

// Функция todayStr предназначена для получения сегодняшней даты в формате YYYY-MM-DD.
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/* Раздел: комментарии. */
/* Компонент CommentsTab предназначен для вкладки «Комментарии». */

function CommentsTab({ theme, task, directory, currentUser, comments, setComments, readOnly, onError, onOpenUser }) {
  const [text, setText] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");
  const [emojiFor, setEmojiFor] = useState(null);   // null | "new" | "edit": открытый набор смайлов

  const send = async () => {
    const body = text.trim();
    if (!body) return;
    setText("");
    try {
      const created = await api.addComment(task.id, body);
      setComments((prev) => upsertById(prev, created));
    } catch (e) {
      onError(e.message);
    }
  };

  const saveEdit = async (id) => {
    const body = editText.trim();
    if (!body) return;
    try {
      const updated = await api.editComment(id, body);
      setComments((prev) => upsertById(prev, updated));
      setEditingId(null);
    } catch (e) {
      onError(e.message);
    }
  };

  const remove = async (id) => {
    try {
      await api.deleteComment(id);
      setComments((prev) => prev.filter((c) => c.id !== id));
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <div>
      {comments.map((c) => {
        const author = resolveUser(directory, c.authorId);
        const mine = c.authorId === currentUser.id;
        // На правку комментария отводится 1 час после отправки; позже карандаш скрывается (удалять можно).
        const editable = Date.now() - new Date(c.createdAt).getTime() < 3600_000;
        return (
          <div key={c.id} className="flex gap-3 py-2.5 group">
            <button onClick={() => onOpenUser(author)} className="shrink-0 rounded-full" aria-label={author.fullName}><Avatar user={author} size={30} theme={theme} /></button>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline gap-2 flex-wrap min-h-[24px]">
                <span style={{ color: author.deleted ? theme.textMuted : theme.text }} className="text-[13px] font-semibold">{author.fullName}</span>
                <span style={{ color: theme.textMuted }} className="text-[12px]" title={fmtDateTime(c.createdAt)}>{fmtRelative(c.createdAt)}</span>
                {c.editedAt && (
                  <span style={{ color: theme.textMuted }} className="text-[12px]" title={`Изменено ${fmtDateTime(c.editedAt)}`}>· изменено {fmtRelative(c.editedAt)}</span>
                )}
                {mine && editingId !== c.id && (
                  <span className="ml-auto flex items-center gap-0.5 self-center opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                    {editable && (
                      <button onClick={() => { setEditingId(c.id); setEditText(c.body); }} className="btn-icon" style={{ width: 28, height: 28 }}
                        title="Изменить (в течение часа после отправки)" aria-label="Изменить комментарий"><Pencil size={13} /></button>
                    )}
                    <button onClick={() => remove(c.id)} className="btn-icon" style={{ width: 28, height: 28, color: theme.danger }}
                      title="Удалить" aria-label="Удалить комментарий"><Trash2 size={13} /></button>
                  </span>
                )}
              </div>

              {editingId === c.id ? (
                <div className="flex items-center gap-1 mt-1">
                  <input value={editText} onChange={(e) => setEditText(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") saveEdit(c.id); if (e.key === "Escape") setEditingId(null); }}
                    autoFocus style={inputStyle(theme)} className="flex-1 rounded-xl px-3 py-2 text-[14px] outline-none" />
                  <span className="relative">
                    <button onClick={() => setEmojiFor(emojiFor === "edit" ? null : "edit")} className="btn-icon"
                      title="Смайлы" aria-label="Смайлы"><Smile size={16} /></button>
                    {emojiFor === "edit" && (
                      <EmojiPicker theme={theme} onPick={(ch) => { setEditText((t) => t + ch); setEmojiFor(null); }} onClose={() => setEmojiFor(null)} />
                    )}
                  </span>
                  <button onClick={() => saveEdit(c.id)} className="btn-icon" style={{ color: theme.success }}
                    title="Сохранить" aria-label="Сохранить"><Check size={16} /></button>
                  <button onClick={() => setEditingId(null)} className="btn-icon"
                    title="Отмена" aria-label="Отмена"><X size={16} /></button>
                </div>
              ) : (
                <p style={{ color: theme.text }} className="text-[14px] leading-[1.5] break-words whitespace-pre-wrap">{withEmoji(c.body, 22)}</p>
              )}
            </div>
          </div>
        );
      })}

      {comments.length === 0 && <p style={{ color: theme.textMuted }} className="text-[13px] py-2">Комментариев пока нет. Начните обсуждение.</p>}

      {readOnly ? (
        <p style={{ color: theme.textMuted }} className="text-[12px] mt-4">Доступ только на просмотр — комментировать нельзя.</p>
      ) : (
        <div className="flex items-end gap-2 mt-3">
          {/* Клавиши как в чек-листе и отчёте: Enter отправляет, Ctrl+Enter переносит строку. */}
          <MultilineField theme={theme} value={text} onChange={setText} onSubmit={send}
            placeholder="Написать комментарий. Ctrl+Enter — отправить, Enter — новая строка"
            className="flex-1 rounded-xl px-3.5 py-2.5 text-[14px] outline-none" />
          <span className="relative shrink-0">
            <button onClick={() => setEmojiFor(emojiFor === "new" ? null : "new")} className="btn-icon" style={{ width: 42, height: 42 }}
              title="Смайлы" aria-label="Смайлы"><Smile size={18} /></button>
            {emojiFor === "new" && (
              <EmojiPicker theme={theme} onPick={(ch) => { setText((t) => t + ch); setEmojiFor(null); }} onClose={() => setEmojiFor(null)} />
            )}
          </span>
          <button onClick={send} className="btn-primary shrink-0" style={{ width: 42, height: 42, padding: 0 }}
            title="Отправить" aria-label="Отправить комментарий"><Send size={16} /></button>
        </div>
      )}
    </div>
  );
}

/* Раздел: файлы. */
/* Размеры кнопок вкладки «Файлы». */

const FILE_BTN = { width: 32, height: 32 };

// Компонент FilesTab предназначен для вкладки «Файлы».
function FilesTab({ theme, task, directory, files, setFiles, readOnly, onError }) {
  // Окно предпросмотра общее с перепиской (компонент FilePreview).
  const [preview, setPreview] = useState(null);
  const inputRef = useRef();
  const [uploading, setUploading] = useState(false);
  const [renamingId, setRenamingId] = useState(null);
  const [renameText, setRenameText] = useState("");

  const upload = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const created = await api.uploadAttachment(task.id, file);
      setFiles((prev) => upsertById(prev, created));
    } catch (e) {
      onError(e.message);
    } finally {
      setUploading(false);
    }
  };

  const rename = async (id) => {
    const title = renameText.trim();
    if (!title) return;
    try {
      const updated = await api.renameAttachment(id, title);
      setFiles((prev) => upsertById(prev, updated));
      setRenamingId(null);
    } catch (e) {
      onError(e.message);
    }
  };

  const remove = async (id) => {
    try {
      await api.deleteAttachment(id);
      setFiles((prev) => prev.filter((f) => f.id !== id));
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <div>
      {files.map((f) => {
        const author = resolveUser(directory, f.authorId);
        const isImage = f.mime?.startsWith("image/");
        return (
          <div key={f.id} className="rounded-2xl px-2 py-2 -mx-2 group transition-colors hover:bg-[var(--t-surfaceAlt)]">
            <div className="flex items-center gap-3">
              {isImage ? (
                <button onClick={() => setPreview(f)} className="shrink-0" title="Посмотреть">
                  <AuthImage path={`/attachments/${f.id}/content`} alt={f.title}
                    className="w-10 h-10 rounded-xl object-cover" theme={theme} />
                </button>
              ) : (
                <span style={{ background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }} className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"><Paperclip size={16} /></span>
              )}

              <div className="min-w-0 flex-1">
                {renamingId === f.id ? (
                  <div className="flex items-center gap-1.5">
                    <input value={renameText} onChange={(e) => setRenameText(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") rename(f.id); if (e.key === "Escape") setRenamingId(null); }}
                      autoFocus style={inputStyle(theme)} className="flex-1 rounded-xl px-3 py-1.5 text-[13px] outline-none" />
                    <button onClick={() => rename(f.id)} className="btn-icon" style={{ width: 30, height: 30, color: theme.success }}
                      title="Сохранить" aria-label="Сохранить название"><Check size={15} /></button>
                    <button onClick={() => setRenamingId(null)} className="btn-icon" style={{ width: 30, height: 30 }}
                      title="Отмена" aria-label="Отмена"><X size={15} /></button>
                  </div>
                ) : (
                  <div style={{ color: theme.text }} className="text-[13px] font-medium truncate">{f.title || f.filename}</div>
                )}
                <div style={{ color: theme.textMuted }} className="text-[12px] truncate tabular-nums">
                  {fmtSize(f.size)} · {author.fullName} · {fmtRelative(f.createdAt)}
                  {f.editedAt && <span title={`Изменено ${fmtDateTime(f.editedAt)}`}> · изменено</span>}
                </div>
              </div>

              <div className="flex items-center gap-0.5 shrink-0">
                {/* Предпросмотр открывается в окне, а не в новой вкладке. */}
                <button onClick={() => setPreview(f)} className="btn-icon" style={FILE_BTN}
                  title="Посмотреть в окне" aria-label="Посмотреть в окне"><ExternalLink size={15} /></button>
                <button onClick={() => downloadFile(`/attachments/${f.id}/content?download=1`, f.filename)}
                  className="btn-icon" style={FILE_BTN} title="Скачать" aria-label="Скачать"><Download size={15} /></button>
                {f.canEdit && (
                  <>
                    <button onClick={() => { setRenamingId(f.id); setRenameText(f.title || f.filename); }} className="btn-icon" style={FILE_BTN}
                      title="Переименовать" aria-label="Переименовать"><Pencil size={14} /></button>
                    <button onClick={() => remove(f.id)} className="btn-icon" style={{ ...FILE_BTN, color: theme.danger }}
                      title="Удалить" aria-label="Удалить файл"><Trash2 size={14} /></button>
                  </>
                )}
              </div>
            </div>
          </div>
        );
      })}

      {files.length === 0 && <p style={{ color: theme.textMuted }} className="text-[13px] py-2">Файлов нет.</p>}

      {!readOnly && (
        <>
          <input ref={inputRef} type="file" className="hidden" onChange={(e) => { upload(e.target.files?.[0]); e.target.value = ""; }} />
          <button onClick={() => inputRef.current?.click()} disabled={uploading}
            className="btn-pill mt-3 disabled:opacity-50" style={{ padding: "6px 14px", fontSize: 13, gap: 6 }}>
            <Upload size={14} style={{ color: theme.accent }} /> {uploading ? "Загружаем…" : "Загрузить файл"}
          </button>
        </>
      )}

      {/* Окно предпросмотра расположено внутри корневого элемента вкладки. */}
      {preview && (
        <FilePreview theme={theme} title={preview.title} filename={preview.filename}
          mime={preview.mime} path={`/attachments/${preview.id}/content`}
          pdfPath={`/attachments/${preview.id}/pdf`}
          downloadPath={`/attachments/${preview.id}/content?download=1`}
          onClose={() => setPreview(null)} />
      )}
    </div>
  );
}

/* Раздел: связи. */

// Типы связей и подписи с обоих концов: подпись зависит от направления.
const LINK_KINDS = {
  blocks: {
    out: "Блокирует", in: "Заблокирована задачей",
    hint: "пока блокирующая задача не завершена, эту закрыть нельзя",
  },
  relates: {
    out: "Связана с", in: "Связана с",
    hint: "задачи касаются одного вопроса",
  },
  subtask: {
    // Направление: from — родитель, to — часть работы.
    out: "Подзадача", in: "Родительская задача",
    hint: "часть более крупной работы",
  },
};

// Функция excerpt предназначена для получения короткого фрагмента описания вокруг найденного слова.
function excerpt(text, q, around = 28) {
  const src = (text || "").replace(/\s+/g, " ").trim();
  const low = src.toLowerCase();
  const at = low.indexOf(q);
  if (at < 0) return "";
  // У отдельных символов нижний регистр длиннее исходного (например, «İ»), в этом случае позиция в исходной строке не определяется и фрагмент берётся с начала.
  const from = low.length === src.length ? Math.max(0, at - around) : 0;
  const to = Math.min(src.length, from + q.length + around * 2);
  return (from > 0 ? "…" : "") + src.slice(from, to) + (to < src.length ? "…" : "");
}

// Компонент LinksTab предназначен для вкладки «Связи».
function LinksTab({ theme, task, links, setLinks, canEdit, onError, onOpenTask }) {
  const [adding, setAdding] = useState(false);
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState("relates");
  const [found, setFound] = useState([]);
  const [searching, setSearching] = useState(false);

  // Поиск задач для связывания выполняется по уже загруженной доске, без отдельного запроса.
  useEffect(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) { setFound([]); return; }
    setSearching(true);
    // Ответ на устаревший запрос отбрасывается.
    let dead = false;
    const timer = setTimeout(async () => {
      try {
        const all = await api.tasks(task.boardId);
        if (dead) return;
        const hit = (t) => [t.title, t.description, t.incomingNumber]
          .some((v) => (v || "").toLowerCase().includes(q));
        setFound(all
          .filter((t) => t.id !== task.id && hit(t))
          .filter((t) => !links.some((l) => l.toTask === t.id || l.fromTask === t.id))
          .slice(0, 6));
      } catch (e) {
        if (!dead) onError(e.message);
      } finally {
        if (!dead) setSearching(false);
      }
    }, 300);
    return () => { dead = true; clearTimeout(timer); };
  }, [query, task.id, task.boardId, links, onError]);

  const add = async (toTask) => {
    try {
      const created = await api.createTaskLink(task.id, toTask, kind);
      setLinks((prev) => [...prev, created]);
      setAdding(false);
      setQuery("");
    } catch (e) {
      onError(e.message);
    }
  };

  const remove = async (id) => {
    try {
      await api.deleteTaskLink(id);
      setLinks((prev) => prev.filter((l) => l.id !== id));
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <div>
      {links.map((l) => {
        // Направление определяет подпись связи.
        const outgoing = l.fromTask === task.id;
        const info = LINK_KINDS[l.kind] || LINK_KINDS.relates;
        const label = outgoing ? info.out : info.in;
        // Незавершённая блокирующая задача препятствует завершению данной; это отображается явно.
        const blocking = l.kind === "blocks" && !outgoing && !l.completed;
        return (
          <div key={l.id}
            className="rounded-xl px-2 py-2 -mx-2 flex items-center gap-2.5 group transition-colors hover:bg-[var(--t-surfaceAlt)]">
            <span className="pill shrink-0"
              style={{
                background: blocking ? tint(theme.danger, 16) : theme.surfaceAlt,
                color: blocking ? theme.danger : theme.textMuted,
              }}
              title={info.hint}>
              {label}
            </span>
            <button onClick={() => onOpenTask && onOpenTask(l.toTask === task.id ? l.fromTask : l.toTask)}
              className="flex-1 min-w-0 text-left">
              <span style={{
                color: theme.text,
                textDecoration: l.completed ? "line-through" : "none",
                opacity: l.completed ? 0.65 : 1,
              }} className="text-[14px] truncate block hover:underline underline-offset-2">
                {l.title}
              </span>
            </button>
            {canEdit && (
              <button onClick={() => remove(l.id)} className="btn-icon opacity-0 group-hover:opacity-100 focus-visible:opacity-100 transition-opacity shrink-0"
                style={{ width: 28, height: 28, color: theme.danger }} title="Убрать связь" aria-label="Убрать связь">
                <X size={14} />
              </button>
            )}
          </div>
        );
      })}

      {links.length === 0 && (
        <p style={{ color: theme.textMuted }} className="text-[13px] py-2">Связей нет.</p>
      )}

      {canEdit && !adding && (
        <button onClick={() => setAdding(true)} className="btn-pill mt-3" style={{ padding: "6px 14px", fontSize: 13, gap: 6 }}>
          <Plus size={14} style={{ color: theme.accent }} /> Связать с задачей
        </button>
      )}

      {adding && (
        <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
          className="rounded-2xl p-3 mt-3">
          <div className="segmented mb-2.5" style={{ background: theme.surface }}>
            {Object.entries(LINK_KINDS).map(([k, v]) => (
              <button key={k} onClick={() => setKind(k)} title={v.hint} aria-pressed={kind === k}
                style={{ padding: "5px 12px", fontSize: 12.5 }}>
                {v.out}
              </button>
            ))}
          </div>
          <input value={query} onChange={(e) => setQuery(e.target.value)} autoFocus
            placeholder="Название, описание или входящий номер (от двух символов)"
            style={{ ...inputStyle(theme), background: theme.surface }}
            className="w-full rounded-xl px-3 py-2 text-[13px] outline-none mb-1.5" />

          {searching && (
            <p style={{ color: theme.textMuted }} className="text-[12px] py-1">Ищем…</p>
          )}
          {found.map((t) => {
            // При совпадении не по названию отображается, что именно совпало.
            const q = query.trim().toLowerCase();
            const inTitle = (t.title || "").toLowerCase().includes(q);
            const inNumber = (t.incomingNumber || "").toLowerCase().includes(q);
            const hint = inTitle ? "" : inNumber
              ? `вх. № ${t.incomingNumber}`
              : excerpt(t.description, q);
            return (
              <button key={t.id} onClick={() => add(t.id)}
                className="w-full text-left px-3 py-2 rounded-xl transition-colors hover:bg-[var(--t-surface)]">
                <span style={{ color: theme.text }} className="block text-[13px] truncate">
                  {t.title}
                </span>
                {hint && (
                  <span style={{ color: theme.textMuted }} className="block text-[12px] truncate">
                    {hint}
                  </span>
                )}
              </button>
            );
          })}
          {!searching && query.trim().length >= 2 && found.length === 0 && (
            <p style={{ color: theme.textMuted }} className="text-[12px] py-1">
              Ничего не найдено в этом проекте.
            </p>
          )}

          <button onClick={() => { setAdding(false); setQuery(""); }}
            className="btn-pill mt-2" style={{ padding: "4px 12px", fontSize: 12.5, background: theme.surface }}>
            Отмена
          </button>
        </div>
      )}
    </div>
  );
}

/* Раздел: поручение задачи. */

// Смена исполнителей без открытия формы редактирования: условия задачи не меняются, сохраняется патч `assignees`;
// сервер определяет добавленных и снятых исполнителей и рассылает уведомления.
/* Раздел: срок задачи. */

// Окно DueDateModal предназначено для изменения срока задачи отдельно от формы редактирования.
const MODAL_BTN = { padding: "8px 18px", fontSize: 14 };

// Компонент DueDateModal предназначен для окна изменения срока задачи.
function DueDateModal({ theme, task, onClose, onSaved, onError }) {
  const [date, setDate] = useState(task.dueDate || "");
  const [busy, setBusy] = useState(false);

  // Приоритет «Установлен срок» без даты не допускается (как в форме задачи).
  const datedPriority = task.priority === "dated";

  const save = async (value) => {
    setBusy(true);
    try {
      // Пустая строка снимает срок, отсутствие поля сохраняет прежний; null не передаётся: сервер воспринимает его как «не менять».
      onSaved(await api.updateTask(task.id, { dueDate: value || "" }));
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  // Частые сдвиги отсчитываются от сегодняшнего дня.
  const shift = (days) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="task-due">
      <ModalHeader theme={theme} title="Срок исполнения"
        subtitle={`«${task.title}»`} onClose={onClose} />

      <div className="flex flex-wrap gap-1.5 mb-3">
        {[["Сегодня", 0], ["Завтра", 1], ["Через неделю", 7], ["Через месяц", 30]].map(([label, d]) => (
          <button key={label} onClick={() => setDate(shift(d))}
            className="btn-pill" style={{ padding: "4px 12px", fontSize: 12.5 }}>{label}</button>
        ))}
      </div>

      <Field label="Дата" theme={theme}
        hint={datedPriority
          ? "У задачи приоритет «Установлен срок» — снять дату нельзя, только перенести"
          : (task.dueDate ? `Сейчас: ${fmtDate(task.dueDate)}` : "Срок не задан")}>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
      </Field>

      <div className="flex items-center gap-2 mt-5">
        {task.dueDate && !datedPriority && (
          <button onClick={() => save("")} disabled={busy}
            className="btn-pill disabled:opacity-50" style={{ ...MODAL_BTN, color: theme.danger }}
            title="Оставить задачу без срока">
            Снять срок
          </button>
        )}
        <span className="flex-1" />
        <button onClick={onClose} className="btn-pill" style={MODAL_BTN}>Отмена</button>
        <button onClick={() => save(date)} disabled={busy || !date}
          className="btn-primary disabled:opacity-50" style={MODAL_BTN}>
          {busy ? "Сохраняем…" : "Сохранить"}
        </button>
      </div>
    </Modal>
  );
}

// Компонент AssignModal предназначен для окна смены исполнителей.
function AssignModal({ theme, task, directory, team, teamGroups = [], currentUser, onClose, onSaved, onError }) {
  const [ids, setIds] = useState(task.assignees || []);
  const [busy, setBusy] = useState(false);

  // Кандидаты и сторонние исполнители определяются правилом из lib/assignees.js, общим с формой задачи.
  const candidates = assigneeCandidates({
    team, assigned: task.assignees || [], currentUserId: currentUser?.id,
  });
  const outside = outsideTeam({ team, assigned: task.assignees || [] });

  const toggle = (id) => setIds((prev) =>
    (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  const save = async () => {
    setBusy(true);
    try {
      onSaved(await api.updateTask(task.id, { assignees: ids }));
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  const chosen = ids.map((id) => resolveUser(directory, id));

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="task-assign">
      <ModalHeader theme={theme} title="Поручить задачу"
        subtitle={`«${task.title}»`} onClose={onClose} />

      {/* Выбранные исполнители отображаются сверху вне групп. */}
      <div className="flex flex-wrap gap-1.5 mb-3">
        {chosen.length === 0 && (
          <span style={{ color: theme.textMuted }} className="text-[12.5px]">Исполнители не назначены</span>
        )}
        {chosen.map((u) => (
          <button key={u.id} onClick={() => toggle(u.id)}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="flex items-center gap-1.5 p-[2px] pr-2.5 rounded-full text-[13px] transition-opacity hover:opacity-85"
            title="Убрать из исполнителей" aria-label={`Убрать из исполнителей: ${u.fullName}`}>
            <Avatar user={u} size={24} theme={theme} />
            {u.fullName}
            <X size={13} style={{ color: theme.textMuted }} />
          </button>
        ))}
      </div>

      <div style={{ borderColor: theme.border }} className="border-t pt-2 max-h-[46vh] overflow-y-auto mb-3">
        <AssigneePicker theme={theme} directory={directory}
          candidates={candidates} groups={teamGroups}
          selected={ids} onToggle={toggle} onChange={setIds} outside={outside} />
      </div>

      <div className="flex justify-end gap-2">
        <button onClick={onClose} className="btn-pill" style={MODAL_BTN}>Отмена</button>
        <button onClick={save} disabled={busy} className="btn-primary disabled:opacity-50" style={MODAL_BTN}>
          {busy ? "Сохраняем…" : "Поручить"}
        </button>
      </div>
    </Modal>
  );
}
