import React, { useMemo, useState } from "react";
import { ChevronDown, ChevronRight, Check, Users } from "lucide-react";
import { resolveUser } from "../lib/theme.js";
import { Avatar, inputStyle } from "../lib/ui.jsx";

// Модуль предназначен для выбора исполнителей с группами команды. Единый компонент для формы задачи и окна «Поручить»:
// группы, раздел «Моя команда», поиск, выбор всех.

// Компонент AssigneePicker предназначен для выбора исполнителей. onChange получает новый список выбранных целиком;
// он используется для «выбрать всех»: серия вызовов onToggle в форме задачи приводила к потере выбора.
export default function AssigneePicker({
  theme, directory, candidates, groups = [], selected, onToggle, onChange, outside = new Set(),
}) {
  const [open, setOpen] = useState(() => new Set());
  const [q, setQ] = useState("");

  const candidateSet = useMemo(() => new Set(candidates), [candidates]);

  // Группы ограничиваются списком кандидатов: пользователь мог выйти из команды.
  const visibleGroups = useMemo(
    () => groups
      .map((g) => ({ ...g, members: g.members.filter((id) => candidateSet.has(id)) }))
      .filter((g) => g.members.length > 0),
    [groups, candidateSet]);

  // «Моя команда»: все кандидаты раскрывающимся списком с общей кнопкой «выбрать всех».
  const TEAM_ID = "__team__";
  const sections = [...visibleGroups, { id: TEAM_ID, title: "Моя команда", members: candidates }];

  // Группы, в которых состоит пользователь (для подписи «выбран в группе …»).
  const groupsOf = useMemo(() => {
    const map = new Map();
    for (const g of visibleGroups) {
      for (const id of g.members) {
        if (!map.has(id)) map.set(id, []);
        map.get(id).push(g.title);
      }
    }
    return map;
  }, [visibleGroups]);

  // Одиночный выбор выполняется через onChange, если он передан.
  const toggleOne = (id) => {
    if (onChange) {
      onChange(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id]);
    } else {
      onToggle?.(id);
    }
  };

  // Массовый выбор и снятие одним изменением списка.
  const setMany = (ids, on) => {
    if (onChange) {
      const cur = new Set(selected);
      ids.forEach((id) => (on ? cur.add(id) : cur.delete(id)));
      onChange([...cur]);
      return;
    }
    // Запасной путь для вызовов без onChange.
    ids.forEach((id) => {
      if (selected.includes(id) !== on) onToggle?.(id);
    });
  };

  const toggleOpen = (id) => setOpen((prev) => {
    const next = new Set(prev);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    return next;
  });

  const needle = q.trim().toLowerCase();

  const row = (id, currentGroup) => {
    const u = resolveUser(directory, id);
    const active = selected.includes(id);
    // Подпись о других группах выводится только у выбранного пользователя, состоящего более чем в одной группе.
    const elsewhere = active
      ? (groupsOf.get(id) || []).filter((t) => t !== currentGroup)
      : [];
    return (
      <button key={`${currentGroup || "-"}-${id}`} type="button"
        onClick={() => !u.deleted && toggleOne(id)} disabled={u.deleted}
        style={{
          background: active ? theme.surfaceAlt : undefined,
          borderColor: active ? theme.accent : "transparent",
          opacity: u.deleted ? 0.45 : 1,
        }}
        aria-pressed={active}
        className="w-full flex items-center gap-2.5 rounded-xl px-2.5 py-1.5 text-left border mb-0.5 transition-colors hover:bg-[var(--t-surfaceAlt)] disabled:cursor-not-allowed">
        <span style={{
            background: active ? theme.accent : "transparent",
            borderColor: active ? theme.accent : theme.border,
          }}
          className="w-4 h-4 rounded-md border-[1.5px] flex items-center justify-center shrink-0">
          {active && <Check size={11} color={theme.accentText} strokeWidth={3} />}
        </span>
        <Avatar user={u} size={26} theme={theme} />
        <span className="flex-1 min-w-0">
          <span style={{ color: theme.text }} className="text-[13px] block truncate">
            {u.fullName}
            {outside.has(id) && (
              <span title="Назначен не из вашей команды"
                style={{ background: theme.warning }}
                className="inline-block w-1.5 h-1.5 rounded-full ml-1.5 align-middle" />
            )}
          </span>
          <span style={{ color: theme.textMuted }} className="text-[12px] block truncate">
            {u.position || "Должность не указана"}
            {elsewhere.length > 0 && (
              <span style={{ color: theme.accent }}> · выбран также в: {elsewhere.join(", ")}</span>
            )}
          </span>
        </span>
      </button>
    );
  };

  // Поиск: плоский список по всем кандидатам.
  if (needle) {
    const found = candidates.filter((id) => {
      const u = resolveUser(directory, id);
      return u.fullName.toLowerCase().includes(needle)
        || (u.position || "").toLowerCase().includes(needle);
    });
    return (
      <div>
        <Search theme={theme} q={q} setQ={setQ} />
        {found.length === 0
          ? <p style={{ color: theme.textMuted }} className="text-[13px] py-3 text-center">Никого не нашлось.</p>
          : found.map((id) => row(id, null))}
      </div>
    );
  }

  return (
    <div>
      <Search theme={theme} q={q} setQ={setQ} />

      {sections.map((g) => {
        const isOpen = open.has(g.id);
        const pickable = g.members.filter((id) => !resolveUser(directory, id).deleted);
        const chosen = g.members.filter((id) => selected.includes(id)).length;
        const allChosen = pickable.length > 0 && pickable.every((id) => selected.includes(id));
        const isTeam = g.id === TEAM_ID;
        return (
          <div key={g.id} style={{ borderColor: theme.border }}
            className={`border rounded-xl mb-1.5 ${isTeam && visibleGroups.length > 0 ? "mt-2" : ""}`}>
            <div className="flex items-center gap-2 px-2.5 py-2">
              <button type="button" onClick={() => toggleOpen(g.id)} aria-expanded={isOpen}
                className="flex items-center gap-1.5 flex-1 min-w-0 text-left">
                {isOpen
                  ? <ChevronDown size={14} style={{ color: theme.textMuted }} />
                  : <ChevronRight size={14} style={{ color: theme.textMuted }} />}
                <Users size={13} style={{ color: isTeam ? theme.textMuted : theme.accent }} />
                <span style={{ color: theme.text }} className="text-[13px] font-semibold truncate">{g.title}</span>
                <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="text-[11px] font-medium px-1.5 rounded-full leading-[18px] tabular-nums shrink-0">
                  {chosen > 0 ? `${chosen} из ${g.members.length}` : g.members.length}
                </span>
              </button>
              {/* «Выбрать всех»: снятие затрагивает только участников этого списка и не затрагивает выбранных через другие группы. */}
              {pickable.length > 0 && (
                <button type="button"
                  onClick={() => setMany(allChosen ? g.members : pickable, !allChosen)}
                  style={{ color: theme.accent }} className="text-[12px] font-medium shrink-0 rounded-full px-2 py-0.5 transition-colors hover:bg-[var(--t-surfaceAlt)]">
                  {allChosen ? "снять всех" : "выбрать всех"}
                </button>
              )}
            </div>
            {isOpen && (
              <div style={{ borderColor: theme.border }} className="border-t px-1 py-1">
                {g.members.length === 0
                  ? <p style={{ color: theme.textMuted }} className="text-[13px] px-2 py-2">Список пуст.</p>
                  : g.members.map((id) => row(id, isTeam ? null : g.title))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// Компонент Search предназначен для поля поиска. Отступ вокруг поля оставляет место для контура фокуса: в прокручиваемом
// контейнере (окно «Поручить») края контура иначе обрезались.
function Search({ theme, q, setQ }) {
  return (
    <div className="p-[3px] mb-1">
      <input value={q} onChange={(e) => setQ(e.target.value)}
        placeholder="Имя или должность"
        style={inputStyle(theme)}
        className="w-full rounded-xl px-3 py-2 text-[13px] outline-none" />
    </div>
  );
}
