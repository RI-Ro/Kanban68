import React, { useState } from "react";
import { BellPlus } from "lucide-react";
import { api } from "../lib/api.js";
import { Modal, ModalHeader, Field, inputStyle } from "../lib/ui.jsx";

// Модуль предназначен для создания напоминания по задаче из её карточки.

// Функция defaultWhen предназначена для получения времени напоминания по умолчанию: завтра в 10:00.
function defaultWhen() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  d.setHours(10, 0, 0, 0);
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}

// Компонент TaskReminderModal предназначен для создания напоминания по задаче.
export default function TaskReminderModal({ theme, task, onClose, onSaved, onError }) {
  const [title, setTitle] = useState(task.title || "");
  const [when, setWhen] = useState(defaultWhen());
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!title.trim() || !when) return onError("Укажите название и время напоминания");
    setBusy(true);
    try {
      // Время из поля ввода местное; toISOString переводит его в UTC, в базу передаётся тот же момент.
      await api.createReminder({
        title: title.trim(),
        remindAt: new Date(when).toISOString(),
        recurFreq: "none",
        recurInterval: 1,
        recurWeekdays: [],
        taskId: task.id,
      });
      onSaved();
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="task-reminder">
      <ModalHeader theme={theme} title="Напомнить о задаче"
        subtitle={`«${task.title}»`} onClose={onClose} />

      <Field label="О чём напомнить" theme={theme}>
        <input value={title} onChange={(e) => setTitle(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
      </Field>

      <Field label="Когда" theme={theme}
        hint="Прозвонит будильником: окно поверх всего с возможностью отложить.">
        <input type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
      </Field>

      <p style={{ color: theme.textMuted }} className="text-[12px] leading-relaxed mb-4">
        Напоминание видите только вы. Задача останется привязанной — из
        напоминания её можно будет открыть одним нажатием.
      </p>

      <div className="flex justify-end gap-2">
        <button onClick={onClose} className="btn-pill">Отмена</button>
        <button onClick={submit} disabled={busy}
          className="btn-primary disabled:opacity-50">
          <BellPlus size={14} /> {busy ? "Создаём…" : "Напомнить"}
        </button>
      </div>
    </Modal>
  );
}
