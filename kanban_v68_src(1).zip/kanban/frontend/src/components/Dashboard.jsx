// Модуль предназначен для вкладки «Сводка»: метрики по задачам за период и проект (поток по неделям, входящие документы,
// срез на текущий момент, время выполнения, по проектам и исполнителям, личная нагрузка).

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Check } from "lucide-react";
import { api } from "../lib/api.js";
import { PRIORITIES, fmtDate, resolveUser, dueColor, orderedBoards, plural } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Spinner, inputStyle, RecurMark } from "../lib/ui.jsx";
import { emptyFilters, matchesFilters } from "../lib/filters.js";
import TaskFilters from "./TaskFilters.jsx";

// Функция monthsAgo предназначена для получения даты n месяцев назад.
const monthsAgo = (n) => {
  const d = new Date();
  d.setMonth(d.getMonth() - n);
  return d.toISOString().slice(0, 10);
};
// Функция today предназначена для получения локальной даты (не UTC).
const today = () => {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};

const FILTER_KEY = "kanban.dashboardFilter";

// Функция inWorkTone предназначена для получения приглушённого акцентного цвета полосы «в работе».
const inWorkTone = (theme) => `color-mix(in srgb, ${theme.accent} 60%, ${theme.surfaceAlt})`;

// Компонент Dashboard предназначен для отображения сводки метрик.
export default function Dashboard({ theme, directory, boards, currentUser, hideCompleted, onError, onOpenTask }) {
  // Фильтр сохраняется между перезагрузками, как фильтры доски. Конец периода по умолчанию — «сегодня» и пересчитывается
  // при каждой загрузке (toAuto): раньше сохранялась дата последнего посещения, и задачи, созданные после неё, не попадали
  // в график «Поставлено и выполнено», хотя в «Остаток открытых» (без периода) учитывались.
  const [filter, setFilter] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(FILTER_KEY) || "{}");
      const toAuto = saved.toAuto !== false;
      return {
        from: saved.from || monthsAgo(6),
        to: toAuto ? today() : (saved.to || today()),
        toAuto,
        boardId: saved.boardId || "",
      };
    } catch {
      return { from: monthsAgo(6), to: today(), toAuto: true, boardId: "" };
    }
  });
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState("");
  const [userTasks, setUserTasks] = useState(null);
  // Номер последнего отправленного запроса: устаревшие ответы по прежнему фильтру игнорируются.
  const reqSeq = useRef(0);

  useEffect(() => {
    localStorage.setItem(FILTER_KEY, JSON.stringify(filter));
  }, [filter]);

  const load = useCallback(async () => {
    const seq = ++reqSeq.current;
    setLoading(true);
    setFailed("");
    try {
      const params = new URLSearchParams({
        from: filter.from, to: filter.toAuto ? today() : filter.to,
      });
      if (filter.boardId) params.set("boardId", filter.boardId);
      const res = await api.dashboard(params.toString());
      if (seq !== reqSeq.current) return;   // ответ устарел
      setData(res);
    } catch (e) {
      if (seq !== reqSeq.current) return;
      // Сообщение об ошибке загрузки сводки отображается на месте данных.
      setFailed(e.message || "Не удалось загрузить сводку");
      onError(e.message);
    } finally {
      if (seq === reqSeq.current) setLoading(false);
    }
  }, [filter, onError]);

  // Если вкладка осталась открытой за полночь, конец периода «сегодня» обновляется.
  useEffect(() => {
    if (filter.toAuto && filter.to !== today()) setFilter((f) => ({ ...f, to: today() }));
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  // Один автоматический повтор через 1,5 с: первый запрос уходит одновременно с загрузкой справочников и обновлением токена.
  useEffect(() => {
    if (!failed || data) return;
    const t = setTimeout(() => load(), 1500);
    return () => clearTimeout(t);
  }, [failed, data, load]);

  const set = (k, v) => setFilter((f) => (k === "to" ? { ...f, to: v, toAuto: v === today() } : { ...f, [k]: v }));

  // Функция openUser предназначена для открытия списка задач пользователя; override задаёт срез, отличающийся от текущего фильтра.
  const openUser = async (userId, kind, override = {}) => {
    try {
      const params = new URLSearchParams({
        from: override.from || filter.from,
        to: override.to || filter.to,
        status: override.status || "all",
        kind,
      });
      if (filter.boardId) params.set("boardId", filter.boardId);
      const tasks = await api.dashboardUserTasks(userId, params.toString());
      setUserTasks({ user: resolveUser(directory, userId), kind, tasks, override });
    } catch (e) {
      onError(e.message);
    }
  };

  // Функция openList предназначена для открытия списка задач под числом метрики с тем же отбором (период, проект), что в расчёте.
  const openList = async (kind, title, subtitle, extra = {}) => {
    try {
      const params = new URLSearchParams({ from: filter.from, to: filter.to, kind, ...extra });
      if (filter.boardId) params.set("boardId", filter.boardId);
      const tasks = await api.dashboardTasks(params.toString());
      setUserTasks({ title, subtitle, kind, tasks });
    } catch (e) {
      onError(e.message);
    }
  };

  if (loading && !data) {
    return <Spinner theme={theme} label="Считаем статистику…" />;
  }
  if (!data) {
    return (
      <div className="max-w-md mx-auto text-center py-16">
        <p style={{ color: theme.text }} className="text-[14px] font-medium mb-1.5">
          Сводка не загрузилась
        </p>
        <p style={{ color: theme.textMuted }} className="text-[12.5px] mb-4">
          {failed || "Данные ещё не получены."}
        </p>
        <button onClick={load} className="btn-primary">
          Повторить
        </button>
      </div>
    );
  }

  const my = data.myLoad || {};
  const flow = data.flow || {};
  const att = data.attention || {};
  const inc = data.incoming || {};
  const people = data.people || [];
  const byBoard = data.byBoard || [];
  const authorsOf = new Map((data.byAssignee || []).map((a) => [a.userId, a.asAuthor]));

  const pct = (n, of) => (of > 0 ? Math.round((n / of) * 100) : null);
  const onTimePct = pct(flow.onTime || 0, flow.withDue || 0);
  const incInTimePct = pct(inc.inTime || 0, inc.completed || 0);
  const days = (n) => (n == null ? "—" : `${n < 10 ? n.toFixed(1).replace(".", ",") : Math.round(n)} дн.`);
  const period = `${fmtDate(filter.from)} — ${fmtDate(filter.to)}`;

  // Капсула поля фильтра: поле даты и выбор проекта оформлены как соседние сегменты.
  const fieldPill = {
    background: theme.surfaceAlt, border: `1px solid ${theme.border}`, color: theme.text,
    colorScheme: theme.dark ? "dark" : "light",
  };

  return (
    <div className="max-w-[1500px] mx-auto pb-6">
      {/* Блок: фильтр (период и проект). Период относится к потоку (поставлено и выполнено). */}
      <div className="glass-pane p-1.5 mb-4 flex flex-wrap items-center gap-2"
        style={{ borderRadius: 26 }}>
        <label className="flex items-center gap-2 rounded-full h-9 pl-3.5 pr-2.5" style={fieldPill}>
          <span style={{ color: theme.textMuted }} className="text-[12px] font-medium">Период с</span>
          <input type="date" value={filter.from} onChange={(e) => set("from", e.target.value)}
            style={{ color: theme.text }}
            className="bg-transparent text-[13px] tabular-nums outline-none" />
        </label>
        <label className="flex items-center gap-2 rounded-full h-9 pl-3.5 pr-2.5" style={fieldPill}>
          <span style={{ color: theme.textMuted }} className="text-[12px] font-medium">по</span>
          <input type="date" value={filter.to} onChange={(e) => set("to", e.target.value)}
            style={{ color: theme.text }}
            className="bg-transparent text-[13px] tabular-nums outline-none" />
        </label>

        <select value={filter.boardId} onChange={(e) => set("boardId", e.target.value)}
          aria-label="Проект" style={fieldPill}
          className="rounded-full h-9 pl-3.5 pr-3 text-[13px] font-medium outline-none min-w-[180px] max-w-[280px]">
          <option value="">Все проекты</option>
          {orderedBoards(boards).map((b) => <option key={b.id} value={b.id}>{"  ".repeat(b.depth) + b.title}</option>)}
        </select>

        {loading && (
          <span style={{ color: theme.textMuted }} className="text-[12px] px-2">обновляем…</span>
        )}
      </div>

      {/* Блок: четыре главных числа */}
      <div className="flex flex-wrap gap-2 mb-4">
        <Metric theme={theme} label="Поставлено" value={flow.created || 0}
          sub="за период"
          hint="Задачи, созданные за период"
          onClick={() => openList("created", "Поставлено за период", period)} />
        <Metric theme={theme} label="Выполнено" value={flow.completed || 0}
          sub="за период"
          hint="Задачи, завершённые за период (по дате завершения)"
          onClick={() => openList("completed", "Выполнено за период", period)} />
        <Metric theme={theme} label="В срок"
          value={onTimePct == null ? "—" : `${onTimePct}%`}
          sub={flow.withDue ? `из ${flow.withDue} со сроком` : "нет задач со сроком"}
          hint="Доля выполненных за период не позже срока — среди задач, у которых срок был"
          onClick={flow.withDue ? () => openList("late", "Выполнены с опозданием", period) : undefined} />
        <Metric theme={theme} label="Просрочено" value={att.overdue || 0} alert
          sub={`открыто ${att.open || 0}`}
          hint="Открытые задачи с истёкшим сроком — на сегодня, без учёта периода"
          onClick={() => openList("overdue", "Просрочено", "на сегодня")} />
      </div>

      <div className="grid gap-4 items-start xl:grid-cols-[minmax(0,1fr)_400px] mb-4">
        <div className="grid gap-4 min-w-0">
        {/* Блок: поток по неделям */}
        <Panel theme={theme} title="Поставлено и выполнено"
          subtitle={`По неделям · ${period}`}
          aside={<Legend theme={theme} items={[["Поставлено", theme.accent], ["Выполнено", theme.success]]} />}>
          {(flow.weeks || []).length === 0 ? <Empty theme={theme} /> : (
            <WeeksChart theme={theme} weeks={flow.weeks} />
          )}
          <div style={{ borderColor: theme.border }} className="border-t mt-4 pt-3 grid sm:grid-cols-3 gap-x-4">
            <StatRow theme={theme} label="В срок" value={flow.onTime || 0}
              sub={flow.withDue ? `${onTimePct}% от ${flow.withDue}` : "нет задач со сроком"}
              onClick={() => openList("ontime", "Выполнены в срок", period)} />
            <StatRow theme={theme} label="С опозданием" value={flow.late || 0}
              tone={flow.late > 0 ? theme.danger : undefined}
              sub={flow.withDue ? `${100 - onTimePct}% от ${flow.withDue}` : ""}
              onClick={() => openList("late", "Выполнены с опозданием", period)} />
            <StatRow theme={theme} label="Остаток открытых" value={att.open || 0}
              sub="на сегодня"
              onClick={() => openList("open", "Открытые задачи", "на сегодня")} />
          </div>
        </Panel>

        {/* Блок: входящие документы */}
        <Panel theme={theme} title="Входящие документы"
          subtitle={`Срок исполнения — ${inc.days || 30} дней со дня даты входящего`}>
          <div className="grid grid-cols-3 gap-2 mb-3">
            <MiniStat theme={theme} label="В работе" value={inc.open || 0}
              onClick={() => openList("incoming_open", "Входящие в работе", "контрольный срок — 30 дней")} />
            <MiniStat theme={theme} label={`Горят (≤ ${inc.burnDays || 5} дн.)`} value={inc.burning || 0}
              tone={inc.burning > 0 ? theme.warning : undefined}
              onClick={() => openList("incoming_burning", "Входящие: горят", `осталось ${inc.burnDays || 5} дней или меньше`)} />
            <MiniStat theme={theme} label="Просрочено" value={inc.overdue || 0}
              tone={inc.overdue > 0 ? theme.danger : undefined}
              onClick={() => openList("incoming_overdue", "Входящие: просрочен контрольный срок", "30 дней со дня даты входящего")} />
          </div>
          <StatRow theme={theme} label="Закрыто за период" value={inc.completed || 0}
            sub={inc.completed ? `в срок ${inc.inTime} (${incInTimePct}%), среднее время ${days(inc.avgDays)}` : "нет закрытых входящих"}
            onClick={() => openList("incoming_done", "Входящие, закрытые за период", period)} />
          {inc.completed > inc.inTime && (
            <StatRow theme={theme} label="Закрыто с опозданием" value={inc.completed - inc.inTime}
              tone={theme.danger}
              onClick={() => openList("incoming_late", "Входящие, закрытые с опозданием", period)} />
          )}
          {(inc.nearest || []).length > 0 && (
            <>
              <Divider theme={theme} />
              <div style={{ color: theme.textMuted }} className="text-[12px] mb-1 pl-2">Ближайшие контрольные сроки</div>
              {inc.nearest.map((t) => (
                <button key={t.id} onClick={() => onOpenTask(t.id)}
                  className="w-full flex items-baseline gap-2 py-1.5 px-2 text-left rounded-lg hover:bg-[var(--t-surfaceAlt)]">
                  <span className="min-w-0 flex-1">
                    <span style={{ color: theme.text }} className="text-[13px] block truncate">{t.title}</span>
                    <span style={{ color: theme.textMuted }} className="text-[12px] block tabular-nums">
                      вх. {t.incomingNumber} от {fmtDate(t.incomingDate)} · до {fmtDate(t.deadline)}
                    </span>
                  </span>
                  <span className="tabular-nums text-[12px] shrink-0 font-medium"
                    style={{ color: t.daysLeft < 0 ? theme.danger : t.daysLeft <= (inc.burnDays || 5) ? theme.warning : theme.textMuted }}>
                    {t.daysLeft < 0 ? `просрочено на ${-t.daysLeft}` : t.daysLeft === 0 ? "сегодня" : `${t.daysLeft} дн.`}
                  </span>
                </button>
              ))}
            </>
          )}
        </Panel>

        </div>
        {/* Блок: срез на текущий момент */}
        <Panel theme={theme} title="Требует внимания"
          subtitle="Состояние на сегодня, без учёта периода">
          <StatRow theme={theme} label="Просрочено" value={att.overdue || 0}
            tone={att.overdue > 0 ? theme.danger : undefined}
            onClick={() => openList("overdue", "Просрочено", "на сегодня")} />
          <div className="flex flex-wrap gap-1.5 pl-2 pb-2">
            {[["overdue_1_3", "до 3 дней", att.overdue1to3], ["overdue_4_7", "4–7 дней", att.overdue4to7],
              ["overdue_8", "больше недели", att.overdue8plus]].map(([k, label, n]) => (
              <button key={k} disabled={!n} onClick={() => openList(k, `Просрочено: ${label}`, "на сегодня")}
                style={{ background: theme.surfaceAlt, color: n ? theme.text : theme.textMuted, border: `1px solid ${theme.border}` }}
                className="pill hover:brightness-110 disabled:opacity-60">
                {label} <b className="tabular-nums">{n || 0}</b>
              </button>
            ))}
          </div>
          {(att.oldestOverdue || []).length > 0 && (
            <div className="pl-2 pb-2">
              <div style={{ color: theme.textMuted }} className="text-[12px] mb-1">Давнее всего</div>
              {att.oldestOverdue.map((t) => (
                <button key={t.id} onClick={() => onOpenTask(t.id)}
                  className="w-full flex items-baseline gap-2 py-1 text-left text-[13px] rounded-lg hover:bg-[var(--t-surfaceAlt)] px-1.5 -mx-1.5">
                  <span style={{ color: theme.text }} className="truncate flex-1 min-w-0">{t.title}</span>
                  <span style={{ color: theme.danger }} className="tabular-nums text-[12px] shrink-0">
                    {plural(t.daysLate, "день", "дня", "дней")}
                  </span>
                </button>
              ))}
            </div>
          )}
          <Divider theme={theme} />
          <StatRow theme={theme} label="Зависли" value={att.stale || 0}
            sub={`без движения больше ${att.staleDays || 14} дней`}
            onClick={() => openList("stale", "Зависшие задачи", `без движения больше ${att.staleDays || 14} дней`)} />
          <StatRow theme={theme} label="Ждут сдачи" value={att.waitingReady || 0}
            sub={att.waitingReady ? `в среднем ${days(att.readyAvgDays)}, дольше всех ${att.readyMaxDays} дн.` : "никто не ждёт"}
            onClick={() => openList("ready", "Ждут сдачи", "готовы к сдаче, не приняты")} />
          <StatRow theme={theme} label="Без исполнителя" value={att.noAssignee || 0}
            tone={att.noAssignee > 0 ? theme.warning : undefined}
            onClick={() => openList("no_assignee", "Без исполнителя", "открытые")} />
          <StatRow theme={theme} label="Без срока" value={att.noDue || 0}
            sub={att.open ? `${pct(att.noDue || 0, att.open)}% открытых` : ""}
            onClick={() => openList("no_due", "Без срока", "открытые")} />
          <StatRow theme={theme} label="Срочные открытые" value={att.urgent || 0}
            sub={att.urgentOverdue ? `из них просрочены: ${att.urgentOverdue}` : "«Срочно» и «Весьма срочно»"}
            onClick={() => openList("urgent", "Срочные открытые", "«Срочно» и «Весьма срочно»")} />
        </Panel>
      </div>

      <div className="grid gap-4 items-start lg:grid-cols-2 xl:grid-cols-3 mb-4">
        {/* Блок: время выполнения */}
        <Panel theme={theme} title="Время выполнения"
          subtitle="От создания до завершения, медиана — за период">
          <div className="flex items-baseline gap-2 mb-3">
            <span style={{ color: theme.text }} className="text-[34px] leading-10 font-bold tracking-[-0.02em] tabular-nums">
              {days(flow.medianDays)}
            </span>
            <span style={{ color: theme.textMuted }} className="text-[13px]">
              по {plural(flow.completed || 0, "задаче", "задачам", "задачам")}
            </span>
          </div>
          {(flow.byPriority || []).length === 0 ? <Empty theme={theme} /> : (
            <div>
              {flow.byPriority.map((p) => (
                <div key={p.priority} className="flex items-baseline gap-2 py-1.5 px-2">
                  <span style={{ background: theme[(PRIORITIES[p.priority] || {}).color] || theme.textMuted }}
                    className="w-1.5 h-1.5 rounded-full self-center shrink-0" />
                  <span style={{ color: theme.text }} className="text-[13.5px] flex-1 min-w-0 truncate">
                    {PRIORITIES[p.priority]?.label || p.priority}
                  </span>
                  <span style={{ color: theme.textMuted }} className="text-[12px] tabular-nums">{p.n}</span>
                  <span style={{ color: theme.text }} className="text-[14px] font-semibold tabular-nums w-16 text-right">
                    {days(p.medianDays)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </Panel>

        {/* Блок: накопление задач */}
        <Panel theme={theme} title="Где копятся задачи"
          subtitle="Открытые по колонкам, на сегодня">
          {(att.byColumn || []).length === 0 ? <Empty theme={theme} /> : (
            <div>
              {att.byColumn.map((c) => {
                const max = Math.max(...att.byColumn.map((x) => x.count), 1);
                return (
                  <button key={c.title} onClick={() => openList("column", `Колонка «${c.title}»`, "открытые", { column: c.title })}
                    className="w-full rounded-[12px] px-2 py-2 text-left hover:bg-[var(--t-surfaceAlt)] transition-colors duration-150">
                    <div className="flex items-baseline gap-2 mb-1">
                      <span style={{ color: theme.text }} className="text-[13.5px] flex-1 min-w-0 truncate">{c.title}</span>
                      <span style={{ color: theme.text }} className="text-[14px] font-semibold tabular-nums">{c.count}</span>
                    </div>
                    <StackBar theme={theme} total={max} thin parts={[[c.count, inWorkTone(theme)]]} title={`${c.title}: ${c.count}`} />
                  </button>
                );
              })}
            </div>
          )}
        </Panel>
        {/* Блок: по проектам */}
        <Panel theme={theme} title="По проектам"
          subtitle="Поставленные за период задачи: готово и просрочено">
          {byBoard.length === 0 ? (
            <Empty theme={theme} />
          ) : (
            <div>
              {byBoard.map((b, i) => {
                const inWork = Math.max(0, b.total - b.done - b.overdue);
                return (
                  <div key={b.boardId} style={{ borderColor: theme.border }}
                    className={`py-2.5 ${i ? "border-t" : ""}`}>
                    <div className="flex items-baseline gap-2 mb-1.5">
                      <span style={{ color: theme.text }} className="text-[14px] font-medium truncate flex-1 min-w-0">
                        {b.title}
                      </span>
                      {b.overdue > 0 && (
                        <span style={{ color: theme.danger }} className="text-[12px] tabular-nums shrink-0">
                          {b.overdue} просроч.
                        </span>
                      )}
                      <span style={{ color: theme.textMuted }} className="text-[13px] tabular-nums shrink-0">
                        <span style={{ color: theme.text }} className="font-semibold">{b.done}</span> / {b.total}
                      </span>
                    </div>
                    <StackBar theme={theme} total={b.total} thin
                      parts={[[b.done, theme.success], [inWork, inWorkTone(theme)], [b.overdue, theme.danger]]}
                      title={`Готово: ${b.done} · в работе: ${inWork} · просрочено: ${b.overdue}`} />
                  </div>
                );
              })}
            </div>
          )}
        </Panel>
      </div>

      <div className="mb-4">
        {/* Блок: по исполнителям */}
        <Panel theme={theme} title="По исполнителям"
          subtitle="Открыто — на сегодня; закрыто и «в срок» — за период. Нажмите на имя или число, чтобы увидеть задачи"
          aside={<Legend theme={theme} items={[["Закрыто", theme.success], ["Открыто", inWorkTone(theme)], ["Просрочено", theme.danger]]} />}>
          {people.length === 0 ? (
            <Empty theme={theme} />
          ) : (
            <div className="-mx-2">
              {people.map((a) => {
                const u = resolveUser(directory, a.userId);
                const inWork = Math.max(0, a.open - a.overdue);
                const p = pct(a.onTime, a.withDue);
                const authored = authorsOf.get(a.userId) || 0;
                return (
                  <div key={a.userId} className="flex items-center gap-3 px-2 py-2 rounded-[14px] hover:bg-[var(--t-surfaceAlt)] transition-colors duration-150">
                    <button onClick={() => openUser(a.userId, "involved")}
                      className="flex items-center gap-3 min-w-0 w-40 lg:w-56 shrink-0 text-left">
                      <Avatar user={u} size={32} theme={theme} />
                      <span className="min-w-0">
                        <span style={{ color: theme.text }} className="text-[14px] font-medium truncate block">{u.fullName}</span>
                        <span style={{ color: theme.textMuted }} className="text-[12px] truncate block tabular-nums">
                          {authored ? `поставил(а) ${authored}` : "исполнитель"}
                        </span>
                      </span>
                    </button>
                    <StackBar theme={theme} total={a.done + a.open}
                      parts={[[a.done, theme.success], [inWork, inWorkTone(theme)], [a.overdue, theme.danger]]}
                      title={`Закрыто за период: ${a.done} · открыто: ${inWork} · просрочено: ${a.overdue}`} />
                    <button disabled={!a.open} onClick={() => openList("person_open", `${u.fullName}: открытые`, "на сегодня", { userId: a.userId })}
                      className="text-right shrink-0 w-[84px] tabular-nums disabled:cursor-default">
                      <span style={{ color: theme.text }} className="text-[15px] font-semibold leading-5 block">{a.open}</span>
                      <span className="text-[12px] leading-4 block" style={{ color: a.overdue > 0 ? theme.danger : theme.textMuted }}>
                        {a.overdue > 0 ? `${a.overdue} просроч.` : "открыто"}
                      </span>
                    </button>
                    <button disabled={!a.done} onClick={() => openList("person_done", `${u.fullName}: закрыто за период`, period, { userId: a.userId })}
                      className="text-right shrink-0 w-[150px] tabular-nums whitespace-nowrap disabled:cursor-default">
                      <span style={{ color: theme.text }} className="text-[15px] font-semibold leading-5 block">{a.done}</span>
                      <span className="text-[12px] leading-4 block" style={{ color: theme.textMuted }}>
                        {p == null ? "закрыто" : `закрыто · ${p}% в срок`}
                      </span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </Panel>

      </div>

      {/* Блок: личные задачи */}
      <Panel theme={theme} title="Мои задачи" subtitle="Личная нагрузка на сегодня, без учёта периода">
        <div className="flex flex-wrap gap-2">
          <Metric theme={theme} label="Мне поручено"
            value={my.assigned || 0}
            hint="Незавершённые задачи, где я исполнитель"
            onClick={() => openUser(currentUser.id, "assigned", { status: "open" })} />
          <Metric theme={theme} label="Из них просрочено"
            value={my.assignedOverdue || 0} alert
            hint="Мои задачи с истёкшим сроком"
            onClick={() => openUser(currentUser.id, "assigned", { status: "overdue" })} />
          <Metric theme={theme} label="Я поручил"
            value={my.createdByMe || 0}
            hint="Незавершённые задачи, которые создал я"
            onClick={() => openUser(currentUser.id, "created", { status: "open" })} />
          <Metric theme={theme} label="Открыт доступ"
            value={my.grantedToMe || 0}
            hint="Задачи чужих проектов, открытые мне точечно"
            onClick={() => openUser(currentUser.id, "granted", { status: "open" })} />
          <Metric theme={theme} label="Я автор — всего"
            value={my.createdByMeTotal || 0}
            hint="Все поставленные мной задачи, включая завершённые"
            onClick={() => openUser(currentUser.id, "created", { status: "all" })} />
          <Metric theme={theme} label="Всего моих задач"
            value={my.myTotal || 0}
            hint="Где я исполнитель или автор, без повторов — в пределах моей видимости"
            onClick={() => openUser(currentUser.id, "involved", { status: "all" })} />
        </div>
      </Panel>

      {userTasks && (
        <UserTasksModal theme={theme} directory={directory} data={userTasks} onClose={() => setUserTasks(null)}
          onOpenTask={(id) => { setUserTasks(null); onOpenTask(id); }} />
      )}
    </div>
  );
}

// Компонент Metric предназначен для плитки метрики с числом.
function Metric({ theme, label, value, sub, alert = false, hint, onClick }) {
  const Tag = onClick ? "button" : "div";
  const hot = alert && value > 0;
  return (
    <Tag onClick={onClick} title={hint}
      className={`glass stat-pill text-left ${onClick ? "transition-[filter,transform] duration-150 ease-out hover:brightness-110 active:translate-y-px" : ""}`}>
      <span className="stat-label truncate">{label}</span>
      <span className="stat-value" style={hot ? { color: theme.danger } : undefined}>{value}</span>
      {sub && <span style={{ color: theme.textMuted }} className="text-[11px] leading-4 truncate">{sub}</span>}
    </Tag>
  );
}

// Компонент StatRow предназначен для строки метрики в панели: подпись слева, число справа (число кликабельно при наличии списка).
function StatRow({ theme, label, value, sub, tone, onClick }) {
  const clickable = onClick && value > 0;
  const Tag = clickable ? "button" : "div";
  return (
    <Tag onClick={clickable ? onClick : undefined}
      className={`w-full flex items-baseline gap-3 rounded-[12px] px-2 py-2 text-left ${clickable ? "hover:bg-[var(--t-surfaceAlt)] transition-colors duration-150" : ""}`}>
      <span className="flex-1 min-w-0">
        <span style={{ color: theme.text }} className="text-[13.5px] block">{label}</span>
        {sub && <span style={{ color: theme.textMuted }} className="text-[12px] block leading-4">{sub}</span>}
      </span>
      <span style={{ color: tone || theme.text }} className="tabular-nums text-[16px] font-semibold shrink-0">{value}</span>
    </Tag>
  );
}

// Компонент MiniStat предназначен для малой плитки метрики в ряду внутри панели.
function MiniStat({ theme, label, value, tone, onClick }) {
  const clickable = onClick && value > 0;
  const Tag = clickable ? "button" : "div";
  return (
    <Tag onClick={clickable ? onClick : undefined}
      style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
      className={`rounded-[14px] px-3 py-2 text-left ${clickable ? "transition-[filter] duration-150 hover:brightness-110" : ""}`}>
      <span style={{ color: theme.textMuted }} className="text-[12px] block truncate">{label}</span>
      <span style={{ color: tone || theme.text }} className="text-[22px] leading-7 font-bold tabular-nums block">{value}</span>
    </Tag>
  );
}

// Компонент Divider предназначен для разделителя.
function Divider({ theme }) {
  return <div style={{ borderColor: theme.border }} className="border-t my-2" />;
}

// Компонент WeeksChart предназначен для столбиков по неделям (поставлено и выполнено); высота считается от наибольшего значения,
// ненулевое значение всегда видно.
function WeeksChart({ theme, weeks }) {
  const H = 132;
  const max = Math.max(1, ...weeks.flatMap((w) => [w.created, w.completed]));
  const h = (n) => (n > 0 ? Math.max(3, Math.round((n / max) * H)) : 0);
  const step = Math.max(1, Math.ceil(weeks.length / 10));
  const label = (iso) => `${iso.slice(8, 10)}.${iso.slice(5, 7)}`;
  return (
    <div>
      <div className="flex items-end gap-1" style={{ height: H }} role="img"
        aria-label="Столбики по неделям: поставлено и выполнено">
        {weeks.map((w) => (
          <div key={w.week} className="flex-1 min-w-0 flex items-end justify-center gap-[2px]" style={{ height: H }}
            title={`Неделя с ${label(w.week)}: поставлено ${w.created}, выполнено ${w.completed}`}>
            <span style={{ height: h(w.created), background: theme.accent }} className="w-full max-w-[12px] rounded-t-[4px]" />
            <span style={{ height: h(w.completed), background: theme.success }} className="w-full max-w-[12px] rounded-t-[4px]" />
          </div>
        ))}
      </div>
      <div className="flex gap-1 mt-1.5">
        {weeks.map((w, i) => (
          <span key={w.week} style={{ color: theme.textMuted }}
            className="flex-1 min-w-0 text-center text-[11px] tabular-nums overflow-visible whitespace-nowrap">
            {i % step === 0 ? label(w.week) : ""}
          </span>
        ))}
      </div>
    </div>
  );
}

// Компонент Panel предназначен для блока страницы: стеклянная панель с заголовком, подзаголовком и областью справа (легенда или действие).
function Panel({ theme, title, subtitle, aside, children, className = "" }) {
  return (
    <section className={`glass-pane p-5 min-w-0 ${className}`}>
      <div className="flex items-start justify-between gap-4 mb-3">
        <div className="min-w-0">
          <h3 style={{ color: theme.text }} className="text-[18px] leading-6 font-semibold tracking-[-0.01em]">{title}</h3>
          {subtitle && (
            <p style={{ color: theme.textMuted }} className="text-[13px] leading-5 mt-0.5">{subtitle}</p>
          )}
        </div>
        {aside && <div className="shrink-0 pt-1">{aside}</div>}
      </div>
      {children}
    </section>
  );
}

// Компонент StackBar предназначен для полосы из частей (готово, в работе, просрочено); доли считаются от общего числа.
function StackBar({ theme, total, parts, thin = false, title }) {
  return (
    <div title={title} style={{ background: theme.surfaceAlt }}
      className={`${thin ? "h-1.5" : "h-2"} flex-1 min-w-[60px] rounded-full overflow-hidden flex gap-px`}>
      {total > 0 && parts.filter(([n]) => n > 0).map(([n, color], i) => (
        <span key={i} style={{ width: `${(n / total) * 100}%`, background: color }} className="h-full" />
      ))}
    </div>
  );
}

// Компонент Legend предназначен для легенды.
function Legend({ theme, items }) {
  return (
    <div className="hidden md:flex items-center gap-3">
      {items.map(([label, color]) => (
        <span key={label} className="flex items-center gap-1.5 text-[12px] font-medium" style={{ color: theme.textMuted }}>
          <span style={{ background: color }} className="w-2 h-2 rounded-full" />
          {label}
        </span>
      ))}
    </div>
  );
}

// Компонент Empty предназначен для отображения отсутствия данных.
function Empty({ theme }) {
  return (
    <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-10">
      За выбранный период данных нет.
    </p>
  );
}

// Компонент UserTasksModal предназначен для окна со списком задач по метрике или пользователю.
function UserTasksModal({ theme, directory, data, onClose, onOpenTask }) {
  const { user, kind, tasks } = data;
  // Списки по метрикам приходят с готовым заголовком, список по пользователю — с пользователем и видом.

  // Отбор как в проектах, но без исполнителя: список относится к одному пользователю.
  const [filters, setFilters] = useState(emptyFilters);
  const [q, setQ] = useState("");

  const shown = useMemo(
    () => tasks.filter((t) => matchesFilters(t, filters, q)),
    [tasks, filters, q]);

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-2xl" padded={false} geometryKey="dashboard-user-tasks">
      <div className="p-5 pb-3">
        <ModalHeader theme={theme} onClose={onClose}
          title={data.title || user.fullName}
          subtitle={
            data.title
              ? `${data.subtitle ? data.subtitle + ": " : ""}${shown.length}${shown.length === tasks.length ? "" : ` из ${tasks.length}`}${tasks.length >= 200 ? " (показано не больше 200)" : ""}`
              : (kind === "created" ? "Поручено другим" :
             kind === "granted" ? "Открыт доступ" :
             kind === "involved" ? "Исполняет или поставил" : "Назначено задач") +
            `: ${shown.length}${shown.length === tasks.length ? "" : ` из ${tasks.length}`}` +
            (data.override?.status === "overdue" ? " · только просроченные" : "")
          } />
      </div>
      <div className="px-3 pb-2">
        <input value={q} onChange={(e) => setQ(e.target.value)}
          placeholder="Поиск: название, описание, вх. номер, тег"
          style={inputStyle(theme)}
          className="w-full rounded-lg px-3 py-1.5 text-[12.5px] outline-none" />
      </div>
      <TaskFilters theme={theme} filters={filters} setFilters={setFilters}
        directory={directory} tags={[...new Set(tasks.flatMap((t) => t.tags || []))].sort()} />

      <div style={{ borderColor: theme.border }}
        className="border-t max-h-[55vh] overflow-y-auto px-3 py-2 pb-6">
        {shown.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[12.5px] py-6 text-center">
            По заданным условиям задач нет.
          </p>
        )}
        {shown.map((t) => {
          const author = t.createdBy ? resolveUser(directory, t.createdBy) : null;
          const assignees = (t.assignees || []).map((id) => resolveUser(directory, id));
          const doneIds = t.assigneesDone || [];
          return (
            <button key={t.id} onClick={() => onOpenTask(t.id)}
              style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
              className="w-full rounded-[14px] px-3 py-2.5 mb-1.5 text-left flex items-start gap-2.5 transition-[filter] duration-150 ease-out hover:brightness-110">
              <span style={{ background: theme[(PRIORITIES[t.priority] || {}).color] || theme.textMuted }}
                className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" />

              <div className="min-w-0 flex-1">
                <div style={{
                  color: theme.text,
                  textDecoration: t.completed ? "line-through" : "none",
                  opacity: t.completed ? 0.65 : 1,
                }} className="text-[12.5px] font-medium truncate flex items-center gap-1.5">
                  <RecurMark task={t} theme={theme} />
                  {t.readyAt && !t.completed && (
                    <span style={{ background: `color-mix(in srgb, ${theme.success} 18%, transparent)`, color: theme.success }}
                      className="pill shrink-0" >
                      к сдаче
                    </span>
                  )}
                  <span className="truncate">{t.title}</span>
                </div>

                {/* Проект и колонка показывают стадию задачи. */}
                <div style={{ color: theme.textMuted }} className="text-[11px] truncate">
                  <span style={{ color: theme.accent }}>{t.boardTitle}</span>
                  {t.columnTitle ? ` · ${t.columnTitle}` : ""}
                  {` · ${PRIORITIES[t.priority]?.label || t.priority}`}
                  {t.incomingNumber ? ` · вх. ${t.incomingNumber}${t.incomingDate ? ` от ${fmtDate(t.incomingDate)}` : ""}` : ""}
                  {t.commentCount ? ` · ${t.commentCount} комм.` : ""}
                  {t.attachmentCount ? ` · ${t.attachmentCount} файл.` : ""}
                </div>

                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1">
                  {author && (
                    <span className="flex items-center gap-1 min-w-0" title={`Поставил(а): ${author.fullName}`}>
                      <Avatar user={author} size={16} theme={theme} />
                      <span style={{ color: theme.textMuted }} className="text-[10.5px] truncate max-w-[140px]">
                        {author.fullName}
                      </span>
                    </span>
                  )}
                  {assignees.length > 0 ? (
                    <span className="flex items-center gap-1 min-w-0">
                      <span style={{ color: theme.textMuted }} className="text-[10.5px]">→</span>
                      <span className="flex -space-x-1.5">
                        {assignees.slice(0, 4).map((u, i) => (
                          <span key={`${u.id}-${i}`} className="inline-flex relative"
                            style={{
                              boxShadow: `0 0 0 2px ${doneIds.includes(u.id) ? theme.success : theme.surfaceAlt}`,
                              borderRadius: 999, lineHeight: 0,
                            }}
                            title={doneIds.includes(u.id)
                              ? `${u.fullName} — свою часть выполнил(а)`
                              : u.fullName}>
                            <Avatar user={u} size={16} theme={theme} />
                            {doneIds.includes(u.id) && (
                              <span style={{ background: theme.success }}
                                className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full flex items-center justify-center">
                                <Check size={6} color="#fff" strokeWidth={4} />
                              </span>
                            )}
                          </span>
                        ))}
                      </span>
                      {assignees.length > 4 && (
                        <span style={{ color: theme.textMuted }} className="text-[10.5px]">
                          +{assignees.length - 4}
                        </span>
                      )}
                    </span>
                  ) : (
                    <span style={{ color: theme.textMuted }} className="text-[10.5px]">без исполнителя</span>
                  )}
                </div>
              </div>

              {t.dueDate && (
                <span className="text-[12px] tabular-nums shrink-0 mt-0.5"
                  style={{ color: dueColor(t.dueDate, t.completed, theme) || theme.textMuted }}>
                  {fmtDate(t.dueDate)}
                </span>
              )}
            </button>
          );
        })}
        {tasks.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-8">
            Задач нет.
          </p>
        )}
      </div>
    </Modal>
  );
}
