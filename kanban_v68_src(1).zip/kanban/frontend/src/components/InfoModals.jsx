import React, { useEffect, useState } from "react";
import { Modal, ModalHeader, Spinner } from "../lib/ui.jsx";
import { appConfig } from "../lib/appConfig.js";
import { accessTokenValue as getToken } from "../lib/api.js";

// Модуль предназначен для окон «О системе» (текст из config.yaml) и «Руководство пользователя» (предпросмотр PDF).

// Компонент AboutModal предназначен для показа сведений о системе: название, описание, контакты и часы работы
// администратора, автор. Пустые поля не выводятся; переводы строк сохраняются.
export function AboutModal({ theme, onClose }) {
  const a = appConfig.about || {};
  const rows = [
    ["Описание", a.description],
    ["Контакты администратора", a.adminContacts],
    ["Часы работы администратора", a.adminHours],
    ["Автор проекта", a.author],
    ["Дополнительно", a.extra],
  ].filter(([, v]) => v && String(v).trim());
  return (
    <Modal theme={theme} onClose={onClose} width="max-w-lg" geometryKey="about">
      <ModalHeader theme={theme} title={a.title || appConfig.appName} subtitle="О системе" onClose={onClose} />
      <div className="space-y-4">
        {rows.map(([label, value]) => (
          <div key={label}>
            <div style={{ color: theme.textMuted }} className="text-[12px] font-medium mb-1">{label}</div>
            <div style={{ color: theme.text }} className="text-[14px] leading-[21px] whitespace-pre-line break-words">{value}</div>
          </div>
        ))}
        {rows.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px]">Администратор ещё не заполнил сведения о системе.</p>
        )}
      </div>
    </Modal>
  );
}

// Компонент GuideModal предназначен для предпросмотра PDF «Руководство пользователя»: файл запрашивается с авторизацией и
// показывается встроенным просмотрщиком браузера.
export function GuideModal({ theme, onClose, onError }) {
  const [url, setUrl] = useState(null);
  useEffect(() => {
    let alive = true;
    let obj = null;
    (async () => {
      try {
        const res = await fetch("/api/user-guide.pdf", { headers: { Authorization: `Bearer ${getToken()}` }, cache: "no-cache" });
        if (!res.ok) throw new Error("Руководство недоступно");
        obj = URL.createObjectURL(await res.blob());
        if (alive) setUrl(obj);
      } catch (e) { onError?.(e.message); onClose(); }
    })();
    return () => { alive = false; if (obj) URL.revokeObjectURL(obj); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <Modal theme={theme} onClose={onClose} width="max-w-5xl" geometryKey="user-guide">
      <ModalHeader theme={theme} title={`Руководство пользователя об информационном ресурсе «${appConfig.appName}»`}
        onClose={onClose}
        extra={url && <a href={url} download="Руководство_пользователя.pdf" className="btn-pill !text-[13px]">Скачать PDF</a>} />
      {url ? (
        <iframe title="Руководство пользователя" src={url} style={{ border: `1px solid ${theme.border}` }}
          className="w-full h-[72vh] rounded-xl bg-white" />
      ) : <Spinner theme={theme} label="Загружаем руководство…" />}
    </Modal>
  );
}
