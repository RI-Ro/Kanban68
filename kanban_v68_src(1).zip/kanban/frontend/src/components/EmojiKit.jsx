import React, { useEffect } from "react";
import AnimatedEmoji, { ANIMATED } from "./AnimatedEmoji.jsx";

// Модуль предназначен для работы со смайлами: набор для выбора, разбор текста с кодами анимированных смайлов и эмодзи.
// Используется в переписке чатов и в комментариях к задачам.

/* Раздел: смайлы. */

// Набор смайлов ограничен: полный справочник эмодзи требует отдельной библиотеки значительного размера.
const EMOJI = [
  {
    title: "Реакции",
    items: ["👍", "👎", "👌", "🤝", "🙏", "👏", "💪", "🤙", "✌️", "🫡", "🤞", "✍️"],
  },
  {
    title: "Настроение",
    items: [
      "😀", "😃", "😄", "😁", "🙂", "😉", "😊", "😇",
      "😍", "😘", "😜", "😝", "🤪", "🤗", "🤔", "🤨",
      "😐", "😑", "🙄", "😏", "😒", "😞", "😔", "😟",
      "😕", "🙁", "😖", "😫", "😩", "😢", "😭", "😤",
      "😠", "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱",
      "😨", "😰", "😥", "😓", "🤗", "🤭", "🤫", "😬",
      "😴", "🤤", "😪", "😵", "🤐", "🥴", "🤢", "🤮",
      "🤧", "😷", "🤒", "🤕", "🧱", "🤦", "🤷", "🙈",
      "🙉", "🙊", "😎", "🤓", "🥳", "🥺", "😈", "👻",
    ],
  },
  {
    title: "Работа",
    items: [
      "✅", "❌", "❗", "❓", "⚠️", "📌", "📎", "📅",
      "📊", "📈", "📉", "📝", "📁", "📂", "🗓️", "⏰",
      "🕐", "💼", "💰", "🧾", "✉️", "📞", "📠", "🖨️",
      "💻", "🖥️", "🔒", "🔑", "🔧", "⚙️", "🎯", "🚀",
    ],
  },
  {
    title: "Прочее",
    items: [
      "🔥", "⚡", "💡", "🎉", "🎁", "☕", "🍪", "🍰",
      "🌚", "🌝", "☀️", "🌧️", "❄️", "🌈", "🚗", "✈️",
      "🏠", "🏢", "❤️", "💔", "💯", "🤝", "🕊️", "🍀",
    ],
  },
];
// Компонент EmojiPicker предназначен для выбора смайла из набора.
export function EmojiPicker({ theme, onPick, onClose }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <>
      {/* Прозрачная подложка закрывает набор при нажатии вне его. */}
      <div className="fixed inset-0 z-[60]" onClick={onClose} />
      <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
        className="absolute bottom-full left-0 mb-3 z-[61] p-2.5 rounded-2xl shadow-xl w-[320px] max-h-[360px] overflow-y-auto">
        {EMOJI.map((group) => (
          <div key={group.title} className="mb-2">
            <div style={{ color: theme.textMuted }}
              className="text-[12px] font-medium mb-1 px-1">{group.title}</div>
            <div className="grid grid-cols-8 gap-1">
              {group.items.map((ch, i) => (
                <button key={`${ch}-${i}`} onClick={() => onPick(ch)}
                  className="text-[24px] leading-none p-1 rounded-lg transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]">
                  {ch}
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Анимированные смайлы показываются последним разделом. */}
        <div className="mb-2">
          <div style={{ color: theme.textMuted }}
            className="text-[12px] font-medium mb-1 px-1">Анимированные</div>
          <div className="grid grid-cols-5 gap-1">
            {ANIMATED.map((e) => (
              <button key={e.code} onClick={() => onPick(e.code)} title={e.title}
                className="p-1 rounded-lg transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)] flex items-center justify-center">
                <AnimatedEmoji code={e.code} size={30} />
              </button>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}


/* Раздел: смайлы в тексте. */

// Эмодзи в сообщении отображаются крупнее текста; регулярное выражение EMOJI_RE описывает последовательности эмодзи.
const EMOJI_RE = /(\p{Extended_Pictographic}(\uFE0F|\p{Emoji_Modifier})?(\u200D\p{Extended_Pictographic}(\uFE0F|\p{Emoji_Modifier})?)*)/gu;

// Функция withEmoji предназначена для разбора текста сообщения: коды анимированных смайлов и эмодзи заменяются изображениями.
// Бюджет смайлов одного сообщения: первые ANIM_LIMIT анимируются, следующие до STILL_LIMIT рисуются без анимации,
// остальные — простым символом. Так сообщение из 200 смайлов не нагружает страницу.
const ANIM_LIMIT = 12;
const STILL_LIMIT = 60;

export function withEmoji(text, size = 36, budget = { anim: 0, still: 0 }) {
  if (!text) return text;

  // Сначала выделяются коды анимированных смайлов, затем в остальных фрагментах — обычные эмодзи.
  const codes = ANIMATED.map((e) => e.code);
  // Экранирование кодов не требуется: они содержат только латиницу и двоеточия.
  const codeRe = new RegExp("(" + codes.join("|") + ")", "g");

  const out = [];
  let last = 0;
  let key = 0;
  for (const m of text.matchAll(codeRe)) {
    if (m.index > last) out.push(...splitEmoji(text.slice(last, m.index), size, key++, budget));
    if (budget.anim < ANIM_LIMIT) {
      budget.anim++;
      out.push(<AnimatedEmoji key={`a${key++}`} code={m[0]} size={size} />);
    } else if (budget.still < STILL_LIMIT) {
      budget.still++;
      out.push(<AnimatedEmoji key={`a${key++}`} code={m[0]} size={Math.round(size * 0.7)} still />);
    } else {
      out.push(<span key={`a${key++}`} style={{ fontSize: size * 0.6 }}>🙂</span>);
    }
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(...splitEmoji(text.slice(last), size, key++, budget));
  return out.length ? out : text;
}

// Функция splitEmoji предназначена для разбора обычных эмодзи внутри фрагмента текста. Подряд идущие эмодзи
// объединяются в один элемент, чтобы сообщение из сотен эмодзи не создавало сотни узлов DOM.
function splitEmoji(text, size, seed, budget) {
  const parts = [];
  let last = 0;
  let run = "";
  let runStart = 0;
  const flush = () => {
    if (!run) return;
    // Длинная серия уменьшается: 100+ эмодзи подряд занимают разумное место.
    const count = [...run].length;
    const px = count > 40 ? Math.round(size * 0.6) : count > 12 ? Math.round(size * 0.8) : size;
    parts.push(
      <span key={`e${seed}-${runStart}`} style={{ fontSize: px, lineHeight: 1.1, verticalAlign: "middle" }}>{run}</span>
    );
    run = "";
  };
  for (const m of text.matchAll(EMOJI_RE)) {
    const between = text.slice(last, m.index);
    if (between) {
      flush();
      parts.push(between);
    }
    if (!run) runStart = m.index;
    run += m[0];
    last = m.index + m[0].length;
  }
  flush();
  if (last === 0) return [text];
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

