import React, { useEffect, useRef, useState } from "react";

// Модуль предназначен для часов в шапке: время берётся с сервера, а не с компьютера пользователя. Поправка к часам
// браузера пересчитывается раз в минуту (середина интервала запроса компенсирует задержку сети); между синхронизациями
// секунды идут по часам браузера. Формат: 15.01.2022 22:00:00

const pad = (n) => String(n).padStart(2, "0");

// Функция formatClock предназначена для вывода момента в формате «ДД.ММ.ГГГГ ЧЧ:ММ:СС» (местный часовой пояс).
export function formatClock(ms) {
  const d = new Date(ms);
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

// Компонент ServerClock предназначен для отображения часов с серверным временем.
export default function ServerClock({ theme }) {
  const offset = useRef(0);
  const [synced, setSynced] = useState(false);
  const [info, setInfo] = useState(null);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    let alive = true;
    const sync = async () => {
      try {
        const t0 = Date.now();
        const res = await fetch("/api/time", { cache: "no-store" });
        const t1 = Date.now();
        if (!res.ok) return;
        const data = await res.json();
        if (!alive) return;
        // Серверный момент относится к середине интервала запроса.
        offset.current = data.now - (t0 + t1) / 2;
        setInfo({ zone: data.zone, drift: Math.round(offset.current / 1000) });
        setSynced(true);
      } catch { /* при ошибке сохраняется последняя поправка */ }
    };
    sync();
    const t = setInterval(sync, 60 * 1000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now() + offset.current), 1000);
    return () => clearInterval(t);
  }, []);

  const shown = Date.now() + offset.current;
  void now;
  const drift = info?.drift || 0;
  const title = synced
    ? `Время сервера (${info?.zone || "—"}). Часы компьютера ${drift === 0 ? "совпадают с серверными" : drift > 0 ? `отстают на ${drift} с` : `спешат на ${-drift} с`}. Синхронизация раз в минуту.`
    : "Синхронизация времени с сервером…";
  return (
    <span title={title} style={{ color: synced ? theme.text : theme.textMuted }}
      className="hidden md:inline-block px-2.5 text-[13px] font-medium tabular-nums whitespace-nowrap">
      {formatClock(shown)}
    </span>
  );
}
