import React, { useEffect, useState } from "react";
import { BellOff, Clock, ExternalLink } from "lucide-react";
import { api } from "../lib/api.js";
import { startAlarm, stopAlarm } from "../lib/sound.js";

// Компонент AlarmModal предназначен для окна сработавшего напоминания. Отличия от обычного окна: располагается поверх
// всех окон и подтверждений, сопровождается звуком (будильник), закрывается только явным действием.

export default function AlarmModal({ theme, alarms, onDismiss, onError, onOpenTask }) {
  // Отображается самое старое из несработавших напоминаний; остальные разбираются по очереди.
  const current = alarms[0];
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!current) return;
    startAlarm();
    return () => stopAlarm();
  }, [current?.id]);

  // Пока окно открыто, прокрутка страницы отключена.
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);

  if (!current) return null;

  const snooze = async () => {
    setBusy(true);
    try {
      if (current.reminderId) await api.snoozeReminder(current.reminderId, 5);
      stopAlarm();
      onDismiss(current.id, "Напоминание отложено на 5 минут");
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  const dismiss = () => {
    stopAlarm();
    onDismiss(current.id);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4"
      style={{ background: theme.dark ? "rgba(0,0,0,.6)" : "rgba(24,24,40,.38)" }}
      role="alertdialog" aria-modal="true" aria-label="Напоминание">
      <style>{`
        @keyframes kanban-alarm-rock {
          0%, 100% { transform: rotate(-9deg); }
          50%      { transform: rotate(9deg); }
        }
        @keyframes kanban-alarm-ring {
          0%, 100% { opacity: .15; transform: scale(.9); }
          50%      { opacity: .85; transform: scale(1.12); }
        }
        @keyframes kanban-alarm-hand {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
      `}</style>

      <div style={{ borderRadius: 28, boxShadow: theme.dark ? "0 1px 0 rgba(255,255,255,.05) inset, 0 32px 80px -20px rgba(0,0,0,.75)" : "0 32px 80px -28px rgba(30,30,60,.4)" }}
        className="glass-pane w-full max-w-md p-7 text-center">

        <AlarmClock theme={theme} />

        <div className="text-[13px] font-medium mt-4 mb-1.5"
          style={{ color: theme.textMuted }}>
          Напоминание
        </div>

        <h2 style={{ color: theme.text, fontFamily: "var(--font-ui)" }}
          className="text-[26px] font-bold leading-tight tracking-[-0.02em] break-words mb-1.5">
          {current.title}
        </h2>

        <p style={{ color: theme.textMuted }} className="text-[14px] mb-6 tabular-nums">
          {current.missed && current.dueAt
            ? `Пропущено: ${new Date(current.dueAt).toLocaleString("ru-RU", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}`
            : `Сейчас ${new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}`}
          {alarms.length > 1 && ` · ещё напоминаний: ${alarms.length - 1}`}
        </p>

        {/* Привязанная задача открывается из окна; будильник при этом выключается. */}
        {current.taskId && (
          <button onClick={() => { dismiss(); onOpenTask?.(current.taskId); }}
            style={{ color: theme.accent }}
            className="btn-pill w-full h-11 font-semibold mb-2">
            <ExternalLink size={15} /> Открыть задачу
          </button>
        )}

        <div className="flex flex-col sm:flex-row gap-2">
          <button onClick={snooze} disabled={busy}
            className="btn-pill flex-1 h-12 font-semibold disabled:opacity-50">
            <Clock size={16} /> Отложить на 5 минут
          </button>
          <button onClick={dismiss} disabled={busy}
            className="btn-primary flex-1 h-12 text-[15px] disabled:opacity-50">
            <BellOff size={16} /> Отключить
          </button>
        </div>

        <p style={{ color: theme.textMuted }} className="text-[12px] mt-4 leading-relaxed">
          Окно закроется только по одной из этих кнопок — чтобы напоминание
          не пропало от случайного нажатия.
        </p>
      </div>
    </div>
  );
}

// Компонент AlarmClock предназначен для отображения векторного будильника с анимацией (качание, звонки, секундная стрелка).
function AlarmClock({ theme }) {
  return (
    <svg viewBox="0 0 120 120" width="120" height="120" className="mx-auto"
      style={{ animation: "kanban-alarm-rock 0.9s ease-in-out infinite", transformOrigin: "60px 78px" }}
      aria-hidden>
      {/* звон по сторонам */}
      <g style={{ animation: "kanban-alarm-ring 0.45s ease-in-out infinite" }}>
        <path d="M14 34 C6 30, 4 20, 8 12" fill="none" stroke={theme.accent} strokeWidth="4" strokeLinecap="round" />
        <path d="M106 34 C114 30, 116 20, 112 12" fill="none" stroke={theme.accent} strokeWidth="4" strokeLinecap="round" />
      </g>

      {/* колокольчики и ножки */}
      <circle cx="27" cy="26" r="12" fill={theme.accent} />
      <circle cx="93" cy="26" r="12" fill={theme.accent} />
      <rect x="24" y="98" width="12" height="16" rx="4" fill={theme.accent} transform="rotate(-20 30 106)" />
      <rect x="84" y="98" width="12" height="16" rx="4" fill={theme.accent} transform="rotate(20 90 106)" />

      {/* корпус */}
      <circle cx="60" cy="66" r="40" fill={theme.accent} />
      <circle cx="60" cy="66" r="32" fill={theme.surface} stroke={theme.border} strokeWidth="2" />

      {/* деления */}
      {[0, 90, 180, 270].map((a) => (
        <rect key={a} x="59" y="38" width="2" height="7" rx="1" fill={theme.textMuted}
          transform={`rotate(${a} 60 66)`} />
      ))}

      {/* стрелки */}
      <rect x="59" y="46" width="2.5" height="21" rx="1.2" fill={theme.text} />
      <rect x="59" y="52" width="2.5" height="15" rx="1.2" fill={theme.text}
        transform="rotate(115 60 66)" />
      <g style={{ animation: "kanban-alarm-hand 2s linear infinite", transformOrigin: "60px 66px" }}>
        <rect x="59.4" y="44" width="1.6" height="23" rx="0.8" fill={theme.danger} />
      </g>
      <circle cx="60" cy="66" r="3.2" fill={theme.text} />
    </svg>
  );
}
