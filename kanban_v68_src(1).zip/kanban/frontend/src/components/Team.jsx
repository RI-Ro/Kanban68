// Модуль предназначен для окна «Моя команда»: состав команды и раскладка по группам.

import React, { useState } from "react";
import { Check, Video, Search, Plus, Trash2, Users, Pencil } from "lucide-react";
import { videoCallLink } from "../lib/theme.js";
import { appConfig } from "../lib/appConfig.js";
import { Avatar, Modal, ModalHeader, ConfirmDialog, inputStyle } from "../lib/ui.jsx";

// Компонент Team предназначен для редактирования состава команды и групп.
export default function Team({ theme, directory, team, groups: initialGroups = [], currentUser, onClose, onSave, onOpenUser }) {
  const [selected, setSelected] = useState(new Set(team));
  // Две вкладки: состав команды (кому можно поручать задачи) и раскладка по группам.
  const [tab, setTab] = useState("members");
  const [groups, setGroups] = useState(() =>
    initialGroups.map((g) => ({ ...g, members: [...g.members] })));
  const [activeGroup, setActiveGroup] = useState(initialGroups[0]?.id || null);
  const [query, setQuery] = useState("");
  const [saving, setSaving] = useState(false);
  // Состояние подтверждения звонка.
  const [confirmCall, setConfirmCall] = useState(null);

  // Текущий пользователь в собственную команду не добавляется.
  const pool = directory.filter((u) => u.id !== currentUser?.id);

  const q = query.trim().toLowerCase();
  const matched = q
    ? pool.filter((u) => `${u.fullName} ${u.position} ${u.phone}`.toLowerCase().includes(q))
    : pool;

  // Ограничение числа строк (LIMIT): до ввода поискового запроса отображаются уже выбранные участники и первые записи справочника.
  const LIMIT = 60;
  const preselected = matched.filter((u) => selected.has(u.id));
  const rest = matched.filter((u) => !selected.has(u.id));
  const list = q
    ? matched.slice(0, LIMIT)
    : [...preselected, ...rest.slice(0, Math.max(0, LIMIT - preselected.length))];
  const hidden = matched.length - list.length;

  const toggle = (id) => setSelected((prev) => {
    const next = new Set(prev);
    next.has(id) ? next.delete(id) : next.add(id);
    return next;
  });

  const save = async () => {
    setSaving(true);
    // Новые группы передаются без идентификатора (его назначает сервер); временные идентификаторы с префиксом используются только в окне.
    const payload = groups.map((g) => ({
      id: String(g.id).startsWith("new-") ? undefined : g.id,
      title: g.title,
      members: g.members,
    }));
    await onSave([...selected], payload);
    setSaving(false);
  };

  const addGroup = () => {
    const id = `new-${Date.now()}`;
    setGroups((prev) => [...prev, { id, title: "Новая группа", members: [] }]);
    setActiveGroup(id);
  };
  const renameGroup = (id, title) =>
    setGroups((prev) => prev.map((g) => (g.id === id ? { ...g, title } : g)));
  const removeGroup = (id) => {
    setGroups((prev) => prev.filter((g) => g.id !== id));
    setActiveGroup((cur) => (cur === id ? null : cur));
  };
  const toggleInGroup = (groupId, userId) => {
    setGroups((prev) => prev.map((g) => {
      if (g.id !== groupId) return g;
      const has = g.members.includes(userId);
      return { ...g, members: has ? g.members.filter((x) => x !== userId) : [...g.members, userId] };
    }));
    // В группу включается только участник команды: пользователь сразу отмечается в составе.
    setSelected((prev) => new Set(prev).add(userId));
  };

  const current = groups.find((g) => g.id === activeGroup) || null;
  const teamList = [...selected].map((id) => directory.find((u) => u.id === id)).filter(Boolean)
    .sort((a, b) => a.fullName.localeCompare(b.fullName, "ru"));

  return (
    // Окно шире обычного: раскладке по группам нужны две колонки.
    <Modal theme={theme} onClose={onClose} padded={false} width="max-w-2xl" geometryKey="team">
      <div className="px-6 pt-5 pb-4">
        <ModalHeader theme={theme} title="Моя команда" subtitle="Отмеченных сотрудников можно назначать исполнителями задач" onClose={onClose} />
        <div className="flex items-center gap-3 flex-wrap">
          <div className="segmented" role="tablist" aria-label="Раздел">
            {[["members", "Состав", selected.size], ["groups", "Группы", groups.length]].map(([id, label, n]) => (
              <button key={id} onClick={() => setTab(id)} role="tab" aria-selected={tab === id}
                className="flex items-center gap-1.5">
                {label}
                <span className="tabular-nums" style={{ color: theme.textMuted }}>{n}</span>
              </button>
            ))}
          </div>
          {tab === "members" && (
          <div className="relative flex-1 min-w-[220px]">
            <Search size={15} style={{ color: theme.textMuted }} className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Имя, должность или телефон"
              aria-label="Поиск сотрудников"
              style={inputStyle(theme)} className="w-full pl-10 pr-4 py-2 rounded-full text-[14px] outline-none" />
          </div>
          )}
        </div>
      </div>

      {tab === "groups" && (
        <GroupsEditor theme={theme} groups={groups} current={current} teamList={teamList}
          onSelect={setActiveGroup} onAdd={addGroup} onRename={renameGroup}
          onRemove={removeGroup} onToggle={toggleInGroup} />
      )}

      {tab === "members" && (
      <div style={{ borderColor: theme.border }} className="border-t max-h-[50vh] overflow-y-auto px-3 py-2">
        {list.map((u) => {
          const on = selected.has(u.id);
          return (
          <div key={u.id} style={{ background: on ? theme.surfaceAlt : undefined }}
            className="flex items-center gap-3 px-3 py-2 rounded-2xl mb-0.5 transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]">
            <button onClick={() => onOpenUser(u)} className="shrink-0 rounded-full" title="Карточка сотрудника" aria-label={`Карточка: ${u.fullName}`}><Avatar user={u} size={34} theme={theme} /></button>
            <button onClick={() => onOpenUser(u)} className="flex-1 min-w-0 text-left">
              <div style={{ color: theme.text, textDecoration: u.deleted ? "line-through" : "none", opacity: u.deleted ? 0.6 : 1 }} className="text-[14px] font-semibold truncate">{u.fullName}</div>
              <div style={{ color: theme.textMuted }} className="text-[13px] leading-[18px] truncate">{u.deleted ? "Учётная запись удалена" : u.position || "Должность не указана"}</div>
            </button>
            {appConfig.videoCalls && u.phone && !u.deleted && (
              <button onClick={() => setConfirmCall(u)}
                className="btn-pill !py-1 !px-3 !text-[13px] shrink-0"
                title={`Видеозвонок: ${u.phone}`}>
                <Video size={14} style={{ color: theme.accent }} /> Видео
              </button>
            )}
            {!u.deleted && (
              <button onClick={() => toggle(u.id)} role="checkbox" aria-checked={on}
                aria-label={on ? `Убрать из команды: ${u.fullName}` : `Добавить в команду: ${u.fullName}`}
                className="w-9 h-9 flex items-center justify-center shrink-0 rounded-full transition-colors duration-150 hover:bg-[var(--t-surface)]"
                title={on ? "Убрать из команды" : "Добавить в команду"}>
                <span style={{ background: on ? theme.accent : "transparent", border: `1.5px solid ${on ? theme.accent : theme.border}` }}
                  className="w-5 h-5 rounded-md flex items-center justify-center">
                  {on && <Check size={13} strokeWidth={3} color={theme.accentText} />}
                </span>
              </button>
            )}
          </div>
          );
        })}
        {list.length === 0 && <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-6">Никого не найдено.</p>}

        {hidden > 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-3 leading-relaxed">
            Показаны первые {list.length} из {matched.length}.<br />
            Уточните запрос, чтобы найти нужного сотрудника.
          </p>
        )}
      </div>
      )}

      <div style={{ borderColor: theme.border }} className="border-t px-6 py-3.5 flex items-center gap-2">
        <span style={{ color: theme.textMuted }} className="text-[13px] flex-1 tabular-nums">Выбрано: {selected.size}</span>
        <button onClick={onClose} className="btn-pill">Отмена</button>
        <button onClick={save} disabled={saving} className="btn-primary disabled:opacity-50 disabled:cursor-default">{saving ? "Сохраняем…" : "Сохранить"}</button>
      </div>

      {confirmCall && (
        <ConfirmDialog theme={theme}
          title="Начать видеозвонок?"
          message={`Вызов будет отправлен: ${confirmCall.fullName} (${confirmCall.phone}).`}
          confirmLabel="Позвонить"
          danger={false}
          onCancel={() => setConfirmCall(null)}
          onConfirm={() => {
            const href = videoCallLink(confirmCall);
            setConfirmCall(null);
            if (href) window.location.href = href;
          }} />
      )}
    </Modal>
  );
}

// Компонент GroupsEditor предназначен для раскладки команды по группам: слева список групп, справа участники с отметками
// для выбранной группы. Один пользователь может входить в несколько групп.
function GroupsEditor({ theme, groups, current, teamList, onSelect, onAdd, onRename, onRemove, onToggle }) {
  const [editing, setEditing] = useState(null);

  return (
    <div style={{ borderColor: theme.border }} className="border-t flex min-h-[320px] max-h-[55vh]">
      <div style={{ borderColor: theme.border }} className="w-[220px] shrink-0 border-r overflow-y-auto p-2.5">
        {groups.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px] px-1.5 py-3 leading-relaxed">
            Групп пока нет. Они помогают быстро выбирать исполнителей: раскрыл группу — отметил нужных.
          </p>
        )}
        {groups.map((g) => (
          <div key={g.id}
            style={current?.id === g.id ? { background: theme.surfaceAlt, boxShadow: `0 0 0 1px ${theme.border}` } : undefined}
            className="rounded-full mb-1 group transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]">
            {editing === g.id ? (
              <input autoFocus value={g.title}
                onChange={(e) => onRename(g.id, e.target.value)}
                onBlur={() => setEditing(null)}
                onKeyDown={(e) => { if (e.key === "Enter") setEditing(null); }}
                style={inputStyle(theme)}
                className="w-full rounded-full px-3 py-1.5 text-[13px] outline-none" />
            ) : (
              <div className="flex items-center gap-0.5 pl-3 pr-1 py-1">
                <button onClick={() => onSelect(g.id)} className="flex-1 min-w-0 text-left flex items-center gap-2 py-1">
                  <Users size={14} style={{ color: theme.textMuted }} className="shrink-0" />
                  <span style={{ color: theme.text, fontWeight: current?.id === g.id ? 600 : 500 }} className="text-[13px] truncate">{g.title || "Без названия"}</span>
                  <span style={{ background: theme.surface, color: theme.textMuted }} className="pill !px-1.5 !text-[11px] !leading-4 tabular-nums shrink-0">{g.members.length}</span>
                </button>
                <button onClick={() => setEditing(g.id)}
                  className="btn-icon !w-7 !h-7 opacity-0 group-hover:opacity-100 focus-visible:opacity-100"
                  aria-label="Переименовать группу" title="Переименовать"><Pencil size={13} /></button>
                <button onClick={() => onRemove(g.id)}
                  className="btn-icon !w-7 !h-7 opacity-0 group-hover:opacity-100 focus-visible:opacity-100 hover:!text-[var(--t-danger)]"
                  aria-label="Удалить группу" title="Удалить группу"><Trash2 size={13} /></button>
              </div>
            )}
          </div>
        ))}
        <button onClick={onAdd} style={{ color: theme.accent }}
          className="flex items-center gap-1.5 text-[13px] font-medium px-3 py-2 mt-1 rounded-full transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]">
          <Plus size={14} /> Группа
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-2.5">
        {!current && (
          <p style={{ color: theme.textMuted }} className="text-[13px] py-8 text-center">
            Выберите группу слева или создайте новую.
          </p>
        )}
        {current && teamList.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px] py-8 text-center">
            В команде пока никого нет. Добавьте людей на вкладке «Состав».
          </p>
        )}
        {current && teamList.map((u) => {
          const on = current.members.includes(u.id);
          const elsewhere = groups.filter((g) => g.id !== current.id && g.members.includes(u.id));
          return (
            <button key={u.id} onClick={() => onToggle(current.id, u.id)}
              role="checkbox" aria-checked={on}
              style={{ background: on ? theme.surfaceAlt : undefined }}
              className="w-full flex items-center gap-3 rounded-2xl px-3 py-2 text-left mb-0.5 transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]">
              <span style={{
                  background: on ? theme.accent : "transparent",
                  borderColor: on ? theme.accent : theme.border,
                }}
                className="w-5 h-5 rounded-md border-[1.5px] flex items-center justify-center shrink-0">
                {on && <Check size={13} color={theme.accentText} strokeWidth={3} />}
              </span>
              <Avatar user={u} size={30} theme={theme} />
              <span className="flex-1 min-w-0">
                <span style={{ color: theme.text }} className="text-[14px] font-medium block truncate">{u.fullName}</span>
                <span style={{ color: theme.textMuted }} className="text-[12px] block truncate">
                  {u.position || "Должность не указана"}
                  {elsewhere.length > 0 && (
                    <span style={{ color: theme.accent }}> · также в: {elsewhere.map((g) => g.title).join(", ")}</span>
                  )}
                </span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
