import React, { useState } from "react";
import { Video, Mail } from "lucide-react";
import { api } from "../lib/api.js";
import { Modal, ModalHeader, ConfirmDialog } from "../lib/ui.jsx";
import { appConfig } from "../lib/appConfig.js";
import { conferenceLink, conferenceNames, resolveUser } from "../lib/theme.js";

// Компонент InviteMembers предназначен для сбора участников диаграммы или доски: письмо (mailto), видеоконференция
// (ссылка телефонного клиента) и уведомление внутри приложения, как в карточке задачи.
export default function InviteMembers({ theme, kind, object, directory, currentUser, onClose, onError }) {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState("");
  const [pendingCall, setPendingCall] = useState(null);

  const isBoard = kind === "whiteboard";
  const what = isBoard ? "доске" : "диаграмме";

  // Участники — все, допущенные к объекту; для конференции используются пользователи с указанным телефоном.
  const members = (object.members || [])
    .map((m) => resolveUser(directory, m.userId))
    .filter((u) => u && !u.deleted);
  const confParticipants = members.filter((u) => u.phone);

  const confLink = confParticipants.length >= 2
    ? conferenceLink(confParticipants, currentUser?.id) : null;
  const confNames = conferenceNames(confParticipants, currentUser?.id);

  const mails = members
    .filter((u) => u.email && u.id !== currentUser?.id)
    .map((u) => u.email);
  const mailNames = conferenceNames(members.filter((u) => u.email), currentUser?.id);

  const subject = isBoard
    ? `Совместное обсуждение на доске "${object.title}"`
    : `Диаграмма "${object.title}"`;
  const letter = isBoard
    ? `Уважаемые коллеги!\n\nПрошу принять участие в совместном обсуждении на доске "${object.title}".`
    : `Уважаемые коллеги!\n\nПрошу ознакомиться с диаграммой "${object.title}".`;
  const mailLink = appConfig.groupEmail && mails.length
    ? `mailto:${mails.join(",")}?subject=${encodeURIComponent(subject)}`
      + `&body=${encodeURIComponent(letter)}`
    : null;

  // Функция notify предназначена для отправки уведомления внутри приложения (самостоятельно или вместе с вызовом или письмом).
  const notify = async (inviteKind) => {
    setBusy(true);
    try {
      if (isBoard) await api.inviteWhiteboard(object.id, inviteKind);
      else await api.inviteChart(object.id, inviteKind);
      setDone("Уведомление отправлено участникам");
    } catch (e) {
      onError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="invite-members">
      <ModalHeader theme={theme} title="Собрать участников"
        subtitle={`«${object.title}»`} onClose={onClose} />

      <p style={{ color: theme.textMuted }} className="text-[13.5px] leading-relaxed mb-3">
        {members.length <= 1
          ? `Кроме вас, в ${what} пока никого нет — добавьте участников.`
          : `Участники: ${conferenceNames(members, currentUser?.id)}.`}
      </p>

      {done && (
        <p style={{ color: theme.success }} className="text-[13px] mb-1" role="status">{done}</p>
      )}

      {mailLink && (
        <a href={mailLink} onClick={() => notify("review")}
          style={{ color: theme.text }}
          className="glass w-full mt-3 px-4 py-3 text-[14px] font-semibold flex items-center gap-3 transition-opacity hover:opacity-90"
          title={`Написать: ${mailNames}`}>
          <span style={{ background: theme.surface, color: theme.accent }} className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"><Mail size={16} /></span>
          <span className="flex flex-col items-start leading-tight min-w-0 text-left">
            <span>Написать участникам</span>
            <span style={{ color: theme.textMuted }} className="text-[12px] font-normal mt-0.5">
              {mailNames}
            </span>
          </span>
        </a>
      )}

      {confLink && (
        <button onClick={() => setPendingCall({ href: confLink, names: confNames })}
          style={{ color: theme.text }}
          className="glass w-full mt-3 px-4 py-3 text-[14px] font-semibold flex items-center gap-3 transition-opacity hover:opacity-90"
          title={`Собрать участников: ${confNames}`}>
          <span style={{ background: theme.surface, color: theme.accent }} className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"><Video size={16} /></span>
          <span className="flex flex-col items-start leading-tight min-w-0 text-left">
            <span>Видеоконференция</span>
            <span style={{ color: theme.textMuted }} className="text-[12px] font-normal mt-0.5">
              {confNames}
            </span>
          </span>
        </button>
      )}

      {appConfig.videoCalls && !confLink && members.length > 1 && (
        <p style={{ color: theme.textMuted }} className="text-[12px] mt-2.5">
          Для конференции нужно, чтобы телефон был указан хотя бы у двух участников.
        </p>
      )}

      <button onClick={onClose} className="btn-pill w-full h-10 mt-4">Закрыть</button>

      {pendingCall && (
        <ConfirmDialog theme={theme}
          title="Начать видеоконференцию?"
          message={`Вызов будет отправлен участникам: ${pendingCall.names}. Убедитесь, что это не случайное нажатие.`}
          confirmLabel="Позвонить" danger={false}
          onCancel={() => setPendingCall(null)}
          onConfirm={() => {
            const href = pendingCall.href;
            setPendingCall(null);
            // Уведомление отправляется вместе с вызовом.
            notify("call");
            window.location.href = href;
          }} />
      )}
    </Modal>
  );
}
