import React, { useEffect, useState } from "react";
import { Copy, FolderInput } from "lucide-react";
import { api } from "../lib/api.js";
import { orderedBoards } from "../lib/theme.js";
import { Modal, ModalHeader, Field, inputStyle } from "../lib/ui.jsx";

// Компонент CopyTaskModal предназначен для копирования или переноса задачи в выбранные проект и колонку (режим mode).
// Оба действия запрашивают одни и те же данные и различаются режимом.
export default function CopyTaskModal({ theme, task, boards, mode = "copy", onClose, onCopied, onError }) {
  const moving = mode === "move";
  // По умолчанию предлагается текущий проект задачи, если он есть в списке.
  const [boardId, setBoardId] = useState(
    boards.some((b) => b.id === task.boardId) ? task.boardId : (boards[0]?.id || "")
  );
  const [columns, setColumns] = useState([]);
  const [columnId, setColumnId] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!boardId) { setColumns([]); setColumnId(""); return; }
    let alive = true;
    api.columns(boardId)
      .then((cols) => {
        if (!alive) return;
        setColumns(cols);
        // При копировании в тот же проект предлагается та же колонка.
        const same = boardId === task.boardId && cols.some((c) => c.id === task.columnId);
        setColumnId(same ? task.columnId : (cols[0]?.id || ""));
      })
      .catch((e) => onError(e.message));
    return () => { alive = false; };
  }, [boardId, task.boardId, task.columnId, onError]);

  const submit = async () => {
    if (!boardId || !columnId) return onError("Выберите проект и колонку");
    if (moving && boardId === task.boardId) {
      return onError("Задача уже находится в этом проекте — выберите другой");
    }
    setBusy(true);
    try {
      const res = moving
        ? await api.transferTask(task.id, boardId, columnId)
        : await api.copyTask(task.id, boardId, columnId);
      onCopied(res, boardId, mode);
    } catch (e) {
      onError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="task-transfer">
      <ModalHeader theme={theme} title={moving ? "Перенести задачу" : "Копировать задачу"}
        subtitle={moving
          ? `«${task.title}» переедет целиком: исполнители, комментарии, файлы, чек-лист, отчёт и история`
          : `«${task.title}» будет скопирована вместе с чек-листами`}
        onClose={onClose} />

      <Field label="Проект" theme={theme}>
        <select value={boardId} onChange={(e) => setBoardId(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-xl px-2.5 py-2 text-[14px] outline-none">
          {boards.length === 0 && <option value="">Нет доступных проектов</option>}
          {orderedBoards(boards).map((b) => <option key={b.id} value={b.id}>{"\u00A0\u00A0".repeat(b.depth) + b.title}</option>)}
        </select>
      </Field>

      <Field label="Колонка" theme={theme}>
        <select value={columnId} onChange={(e) => setColumnId(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-xl px-2.5 py-2 text-[14px] outline-none">
          {columns.length === 0 && <option value="">—</option>}
          {columns.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
        </select>
      </Field>

      <p style={{ color: theme.textMuted }} className="text-[12px] leading-relaxed mb-4">
        {moving ? (
          <>
            Задача перестанет быть в проекте «{task.boardTitle || "текущем"}» и появится в выбранном.
            Исполнители остаются прежними: их доступ к задаче не зависит от проекта.
            Перенос будет виден в истории задачи, участники получат уведомление.
          </>
        ) : (
          <>
            Исполнители и точечный доступ не копируются — назначьте их в новой задаче отдельно.
            После копирования откроется выбранный проект и форма новой задачи —
            дальнейшая работа идёт уже в ней.
          </>
        )}
      </p>

      <div className="flex justify-end gap-2">
        <button onClick={onClose} className="btn-pill">Отмена</button>
        <button onClick={submit} disabled={busy || !boardId || !columnId}
          className="btn-primary disabled:opacity-50">
          {moving ? <FolderInput size={14} /> : <Copy size={14} />}
          {moving ? (busy ? "Переносим…" : "Перенести") : (busy ? "Копируем…" : "Копировать")}
        </button>
      </div>
    </Modal>
  );
}
