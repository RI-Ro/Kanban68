import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  MessageSquarePlus, UsersRound, Search, Send, Paperclip, Reply, Copy, Forward, SmilePlus, Pencil, Trash2, Plus,
  Check, CheckCheck, X, UserPlus, LogOut, Smile, BarChart3, Eraser, Video,
  Image as ImageIcon, MoreHorizontal,
} from "lucide-react";
import { api } from "../lib/api.js";
import { conferenceLink, copyText, fmtDateTime, resolveUser, videoCallLink } from "../lib/theme.js";
import { onRealtimeMessage } from "../lib/realtime.js";
import { subscribePresence } from "../lib/presence.js";
import { Avatar, AvatarWithPresence, Modal, ModalHeader, Spinner, MultilineField, ConfirmDialog, inputStyle } from "../lib/ui.jsx";
import AnimatedEmoji from "./AnimatedEmoji.jsx";
import { EmojiPicker, withEmoji } from "./EmojiKit.jsx";
import FilePreview from "./FilePreview.jsx";
import AuthImage from "./AuthImage.jsx";

// Модуль предназначен для вкладки «Переписка»: слева список чатов, справа выбранный разговор. Переписка отделена от задач:
// комментарий в задаче относится к задаче, а чат — к общению между людьми (личные и групповые чаты, опросы, файлы, смайлы).
// Компонент Chats предназначен для списка чатов и выбранного разговора.

export default function Chats({ theme, directory, currentUser, onError, onUnread, openChatId, onOpened }) {
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeId, setActiveId] = useState(null);
  const [chatSearch, setChatSearch] = useState("");
  const [newChat, setNewChat] = useState(null); // "direct" | "group"
  // Список пользователей в сети: общий для приложения, обновляется автоматически.
  const [online, setOnline] = useState(new Set());
  useEffect(() => subscribePresence(setOnline), []);

  const loadChats = useCallback(async () => {
    try {
      const list = await api.chats();
      setChats(list);
      onUnread?.(list.reduce((sum, c) => sum + (c.unread || 0), 0));
      return list;
    } catch (e) {
      onError(e.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, [onError, onUnread]);

  useEffect(() => { loadChats(); }, [loadChats]);

  // Переход из всплывающего сообщения: открывается чат, о котором сообщили.
  useEffect(() => {
    if (!openChatId) return;
    setActiveId(openChatId);
    onOpened?.();
  }, [openChatId, onOpened]);

  // Список чатов перезагружается по любому событию переписки: он содержит последнее сообщение и счётчики.
  useEffect(() => {
    const offChat = onRealtimeMessage("chat", () => { loadChats(); });
    const offMsg = onRealtimeMessage("message", () => { loadChats(); });
    return () => { offChat(); offMsg(); };
  }, [loadChats]);

  const title = useCallback((c) => {
    if (c.kind === "group") return c.title || "Групповой чат";
    const other = (c.members || []).find((id) => id !== currentUser.id);
    return other ? resolveUser(directory, other).fullName : "Личный чат";
  }, [currentUser, directory]);

  const shown = useMemo(() => {
    const q = chatSearch.trim().toLowerCase();
    if (!q) return chats;
    // Поиск по названиям групповых и личных чатов; у личного чата поиск идёт по имени собеседника.
    return chats.filter((c) => title(c).toLowerCase().includes(q));
  }, [chats, chatSearch, title]);

  const active = chats.find((c) => c.id === activeId) || null;

  return (
    <div className="h-full min-h-0 flex gap-3 overflow-hidden">
      {/* Блок: список чатов */}
      <aside className="glass-pane w-[280px] xl:w-[320px] shrink-0 flex flex-col overflow-hidden">
        <div className="p-4 pb-3 flex flex-col gap-3">
          <div className="flex gap-2">
            <button onClick={() => setNewChat("direct")}
              className="btn-primary flex-1 !px-3 !py-[7px] !text-[13px]">
              <MessageSquarePlus size={15} /> Чат
            </button>
            <button onClick={() => setNewChat("group")}
              className="btn-pill flex-1 !px-3 !py-[6px] !text-[13px]">
              <UsersRound size={15} /> Групповой
            </button>
          </div>
          <div className="relative">
            <Search size={14} style={{ color: theme.textMuted }}
              className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input value={chatSearch} onChange={(e) => setChatSearch(e.target.value)}
              placeholder="Поиск по чатам" aria-label="Поиск по чатам" style={inputStyle(theme)}
              className="w-full rounded-full pl-9 pr-3 py-2 text-[13px] outline-none" />
          </div>
        </div>

        <div className="flex-1 min-h-0 overflow-y-auto px-2 pb-2">
          {loading && <Spinner theme={theme} label="Загружаем переписку…" />}
          {!loading && shown.length === 0 && (
            <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-8 px-3">
              {chatSearch ? "Ничего не нашлось." : "Переписки пока нет. Начните с кнопки «Чат»."}
            </p>
          )}
          {shown.map((c) => {
            const isActive = c.id === activeId;
            const other = c.kind === "direct"
              ? (c.members || []).find((id) => id !== currentUser.id)
              : null;
            return (
              <button key={c.id} onClick={() => setActiveId(c.id)}
                aria-current={isActive ? "true" : undefined}
                style={isActive
                  ? { background: theme.surfaceAlt, boxShadow: `0 0 0 1px ${theme.border}` }
                  : undefined}
                className={`w-full text-left rounded-2xl px-2.5 py-2 mb-1 flex items-center gap-3
                  transition-colors duration-150 ease-out
                  ${isActive ? "" : "hover:bg-[var(--t-surfaceAlt)]"}`}>
                {other
                  ? <AvatarWithPresence user={resolveUser(directory, other)} size={36}
                      theme={theme} online={online.has(other)} />
                  : <ChatAvatar chatId={c.id} hasAvatar={Boolean(c.avatarId)} size={36} theme={theme} />}
                <span className="flex-1 min-w-0">
                  <span className="flex items-baseline gap-2">
                    <span style={{ color: theme.text, fontWeight: c.unread ? 700 : 600 }}
                      className="text-[14px] leading-5 truncate flex-1 min-w-0">{title(c)}</span>
                    {c.lastAt && (
                      <span style={{ color: c.unread ? theme.accent : theme.textMuted }}
                        className="text-[12px] tabular-nums shrink-0">{shortStamp(c.lastAt)}</span>
                    )}
                  </span>
                  <span className="flex items-center gap-2 mt-0.5">
                    <span style={{ color: theme.textMuted }} className="text-[13px] leading-[18px] truncate flex-1 min-w-0">
                      {c.lastBody || "нет сообщений"}
                    </span>
                    {c.unread > 0 && (
                      // Счётчик непрочитанных на каждом чате.
                      <span style={{ background: theme.accent, color: theme.accentText }}
                        className="pill !px-[7px] !text-[11px] !leading-[18px] !font-semibold tabular-nums min-w-[20px] justify-center shrink-0">
                        {c.unread}
                      </span>
                    )}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      </aside>

      {/* Блок: разговор */}
      {active ? (
        <Conversation key={active.id} theme={theme} chat={active} title={title(active)}
          directory={directory} currentUser={currentUser} online={online}
          allChats={chats} titleOf={title}
          onError={onError} onChanged={loadChats}
          onLeft={() => { setActiveId(null); loadChats(); }} />
      ) : (
        <div className="glass-pane flex-1 min-w-0 flex flex-col items-center justify-center gap-3 p-6">
          <span style={{ background: theme.surfaceAlt, color: theme.textMuted }}
            className="w-12 h-12 rounded-full flex items-center justify-center">
            <MessageSquarePlus size={22} />
          </span>
          <p style={{ color: theme.textMuted }} className="text-[14px] text-center">
            Выберите чат слева или начните новый.
          </p>
        </div>
      )}

      {newChat && (
        <NewChatModal theme={theme} kind={newChat} directory={directory} currentUser={currentUser}
          onClose={() => setNewChat(null)} onError={onError}
          onCreated={async (id) => {
            setNewChat(null);
            await loadChats();
            setActiveId(id);
          }} />
      )}
    </div>
  );
}

// Функция shortStamp предназначена для отметки времени в списке чатов: сегодня — часы и минуты, раньше — число и месяц.
function shortStamp(at) {
  const d = new Date(at);
  if (Number.isNaN(d.getTime())) return "";
  const now = new Date();
  if (d.toDateString() === now.toDateString()) {
    return d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  }
  return d.toLocaleDateString("ru-RU", { day: "numeric", month: "short" }).replace(".", "");
}

/* Раздел: разговор. */

// Быстрый набор реакций.
// Набор реакций (24): первым идёт анимированный смайл «бьётся головой об стену» (код :bang:), остальные — эмодзи.
const REACTIONS = [
  "👍", "❤️", "😂", "😮", "😢", "🙏", "🔥", "🎉", "👏", "👀", "✅", "👎",
  ":bang:", "🤦", "🤔", "😡", "🥳", "😎", "🤝", "💯", "😅", "🙌", "💪", "⏰",
];

// Функция msgStamp предназначена для короткой отметки времени сообщения: сегодня — «23:38», раньше — «17.11 23:38».
function msgStamp(at) {
  const d = new Date(at);
  const hm = d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === new Date().toDateString()) return hm;
  return `${String(d.getDate()).padStart(2, "0")}.${String(d.getMonth() + 1).padStart(2, "0")} ${hm}`;
}

// Правка и удаление сообщения доступны в течение часа после отправки, как у комментариев к задаче.
const EDIT_WINDOW_MS = 60 * 60 * 1000;
// Функция editable предназначена для проверки, что сообщение ещё можно изменить или удалить.
const editable = (m) => Date.now() - new Date(m.createdAt).getTime() < EDIT_WINDOW_MS;

// Компонент Conversation предназначен для отображения выбранного разговора: шапка, лента сообщений, поле ввода.
function Conversation({ theme, chat, title, directory, currentUser, online, onError, onChanged, onLeft, allChats = [], titleOf }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState("");
  const [q, setQ] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [editing, setEditing] = useState(null);   // { id, body }
  const [replyTo, setReplyTo] = useState(null);   // { id, authorId, text } — сообщение, на которое отвечаем
  const [menuFor, setMenuFor] = useState(null);     // сообщение, для которого открыто меню «⋯»
  const [reactFor, setReactFor] = useState(null);   // сообщение, для которого открыт выбор реакции
  const [forwardMsg, setForwardMsg] = useState(null); // сообщение, которое пересылается
  const [flashId, setFlashId] = useState(null);   // сообщение, подсвеченное после перехода по цитате
  const [confirm, setConfirm] = useState(null);
  const [membersOpen, setMembersOpen] = useState(false);
  const [renaming, setRenaming] = useState(null);
  const [pollOpen, setPollOpen] = useState(false);
  const [preview, setPreview] = useState(null);
  const [emojiOpen, setEmojiOpen] = useState(false);
  // Меню «⋯» в шапке содержит редкие действия с чатом: очистить, удалить, переименовать, картинка.
  const [moreOpen, setMoreOpen] = useState(false);
  // Опросы загружаются отдельным запросом на чат.
  const [polls, setPolls] = useState([]);
  const fileRef = useRef(null);
  const avatarRef = useRef(null);
  const bottomRef = useRef(null);

  const isOwner = chat.ownerId === currentUser.id;

  // Адресаты звонка: в личном чате — собеседник, в групповом — все участники, кроме текущего пользователя.
  // Ссылка формируется общими функциями, как в карточке задачи.
  const others = (chat.members || [])
    .filter((id) => id !== currentUser.id)
    .map((id) => resolveUser(directory, id));
  const callLink = chat.kind === "group"
    ? conferenceLink(others)
    : (others[0] ? videoCallLink(others[0]) : null);
  const callNames = others.filter((u) => u.phone).map((u) => u.fullName).join(", ");

  // Момент, до которого переписку прочитали все остальные участники; значение вычисляет сервер.
  const readThrough = chat.readThrough ? new Date(chat.readThrough) : null;

  const load = useCallback(async () => {
    try {
      const [msgs, pl] = await Promise.all([
        api.messages(chat.id, q),
        api.polls(chat.id).catch(() => []),
      ]);
      setMessages(msgs);
      setPolls(pl);
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  }, [chat.id, q, onError]);

  useEffect(() => { load(); }, [load]);

  // Открытый чат считается прочитанным: отметка ставится при открытии и при каждом новом сообщении, пока чат на экране.
  useEffect(() => {
    api.markChatRead(chat.id).then(onChanged).catch(() => {});
  }, [chat.id, onChanged]);

  useEffect(() => {
    const offPoll = onRealtimeMessage("chat", (e) => {
      if (e.payload?.id === chat.id) load();
    });
    const off = onRealtimeMessage("message", (e) => {
      if (e.payload?.chatId !== chat.id) return;
      load();
      if (e.payload.authorId !== currentUser.id) {
        api.markChatRead(chat.id).catch(() => {});
      }
    });
    return () => { off(); offPoll(); };
  }, [chat.id, currentUser.id, load]);

  // Прокрутка к последнему сообщению выполняется только при чтении переписки целиком, не в режиме поиска.
  useEffect(() => {
    if (!q) bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages, q]);

  const send = async () => {
    const body = text.trim();
    if (!body) return;
    const reply = replyTo;
    setText("");
    setReplyTo(null);
    try {
      await api.sendMessage(chat.id, body, reply?.id);
      await load();
      onChanged();
    } catch (e) {
      onError(e.message);
      setText(body);
      setReplyTo(reply);
    }
  };

  // Функция react предназначена для постановки или снятия реакции; сервер возвращает обновлённое сообщение.
  const react = async (m, emoji) => {
    setReactFor(null);
    try {
      const upd = await api.reactMessage(m.id, emoji);
      setMessages((prev) => prev.map((x) => (x.id === m.id ? { ...x, reactions: upd.reactions } : x)));
    } catch (e) { onError(e.message); }
  };

  // Функция copyMessage предназначена для копирования сообщения целиком (текст и имя файла).
  const copyMessage = async (m) => {
    const ok = await copyText([m.body, m.filename].filter(Boolean).join("\n"));
    if (!ok) onError("Не удалось скопировать: разрешите доступ к буферу обмена");
  };

  // Функция startReply предназначена для выбора сообщения, на которое пишется ответ; фокус переходит в поле ввода.
  const startReply = (m) => {
    const text = m.body || m.filename || "";
    setReplyTo({ id: m.id, authorId: m.authorId, text: text.slice(0, 200) });
    setEditing(null);
  };

  // Функция jumpTo предназначена для перехода к исходному сообщению цитаты с кратковременной подсветкой.
  const jumpTo = (id) => {
    const el = document.getElementById(`msg-${id}`);
    if (!el) return onError("Исходное сообщение не загружено или удалено");
    el.scrollIntoView({ block: "center", behavior: "smooth" });
    setFlashId(id);
    setTimeout(() => setFlashId((cur) => (cur === id ? null : cur)), 1600);
  };

  // При смене чата ответ сбрасывается.
  useEffect(() => { setReplyTo(null); }, [chat.id]);

  const upload = async (file) => {
    if (!file) return;
    try {
      await api.sendChatFile(chat.id, file, text.trim(), replyTo?.id);
      setText("");
      setReplyTo(null);
      await load();
      onChanged();
    } catch (e) {
      onError(e.message);
    }
  };

  const saveEdit = async () => {
    const body = (editing?.body || "").trim();
    if (!body) return;
    try {
      await api.editMessage(editing.id, body);
      setEditing(null);
      await load();
      onChanged();
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <section className="glass-pane flex-1 min-w-0 flex flex-col overflow-hidden">
      <header style={{ borderColor: theme.border }}
        className="border-b px-5 py-3 flex items-center gap-1">
        {chat.kind === "group"
          ? <ChatAvatar chatId={chat.id} hasAvatar={Boolean(chat.avatarId)} size={38} theme={theme} />
          : others[0] && (
            <AvatarWithPresence user={others[0]} size={38} theme={theme} online={online?.has(others[0].id)} />
          )}
        <div className="min-w-0 flex-1 ml-2">
          <div style={{ color: theme.text }} className="text-[16px] leading-5 font-semibold truncate">
            {title}
          </div>
          <div style={{ color: theme.textMuted }} className="text-[12px] mt-0.5 truncate">
            {chat.kind === "group"
              ? `${(chat.members || []).length} участников · в сети ${
                  (chat.members || []).filter((id) => online?.has(id) && id !== currentUser.id).length}`
              // В личном чате отображается состояние собеседника (в сети или нет).
              : (others[0] && online?.has(others[0].id) ? "в сети" : "не в сети")}
          </div>
        </div>

        {/* Звонок: в личном чате — вызов собеседнику, в групповом — конференция со всеми участниками. */}
        {callLink && (
          <button
            onClick={() => setConfirm({
              title: chat.kind === "group" ? "Собрать видеоконференцию?" : "Начать видеозвонок?",
              message: `Вызов будет отправлен: ${callNames}.`,
              confirmLabel: "Позвонить",
              onConfirm: () => { setConfirm(null); window.location.href = callLink; },
            })}
            style={{ color: theme.accent }} className="btn-icon"
            aria-label={chat.kind === "group" ? "Видеоконференция" : "Видеозвонок"}
            title={chat.kind === "group" ? `Позвонить всем: ${callNames}` : `Позвонить: ${callNames}`}>
            <Video size={18} />
          </button>
        )}

        <button onClick={() => { setSearchOpen((v) => !v); setQ(""); }}
          aria-pressed={searchOpen}
          style={searchOpen ? { color: theme.accent, background: theme.surfaceAlt } : undefined}
          className="btn-icon" aria-label="Поиск по этому чату"
          title="Поиск по этому чату"><Search size={18} /></button>

        {chat.kind === "group" && (
          <button onClick={() => setPollOpen(true)} className="btn-icon"
            aria-label="Создать опрос" title="Создать опрос"><BarChart3 size={18} /></button>
        )}

        {chat.kind === "group" && (
          <button onClick={() => setMembersOpen(true)} className="btn-icon"
            aria-label="Участники чата"
            // Подсказка со списком участников и их состоянием.
            title={"Участники чата:\n" + (chat.members || [])
              .map((id) => `${resolveUser(directory, id).fullName} — ${
                online?.has(id) ? "в сети" : "не в сети"}`)
              .join("\n")}>
            <UsersRound size={18} /></button>
        )}

        {/* Картинка группового чата: владелец устанавливает новую выбором файла и снимает пунктом меню. */}
        {chat.kind === "group" && isOwner && (
          <input ref={avatarRef} type="file" accept="image/*" className="hidden"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (!file) return;
              try { await api.setChatAvatar(chat.id, file); onChanged(); }
              catch (err) { onError(err.message); }
            }} />
        )}

        <div className="relative">
          <button onClick={() => setMoreOpen((v) => !v)} className="btn-icon"
            aria-haspopup="menu" aria-expanded={moreOpen}
            style={moreOpen ? { background: theme.surfaceAlt, color: theme.text } : undefined}
            aria-label="Ещё действия с чатом" title="Ещё действия с чатом">
            <MoreHorizontal size={18} />
          </button>
          {moreOpen && (
            <>
              <div className="fixed inset-0 z-[60]" onClick={() => setMoreOpen(false)} />
              <div role="menu" style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
                className="absolute right-0 top-full mt-2 z-[61] w-[240px] p-1.5 rounded-2xl shadow-xl">
                {chat.kind === "group" && isOwner && (
                  <>
                    <MenuItem theme={theme} icon={Pencil} label="Переименовать чат"
                      onClick={() => { setMoreOpen(false); setRenaming(chat.title || ""); }} />
                    <MenuItem theme={theme} icon={ImageIcon} label="Картинка чата"
                      onClick={() => { setMoreOpen(false); avatarRef.current?.click(); }} />
                    {chat.avatarId && (
                      <MenuItem theme={theme} icon={X} label="Убрать картинку чата"
                        onClick={async () => {
                          setMoreOpen(false);
                          try { await api.setChatAvatar(chat.id, null); onChanged(); }
                          catch (err) { onError(err.message); }
                        }} />
                    )}
                    <div style={{ background: theme.border }} className="h-px my-1 mx-2" />
                  </>
                )}
                {/* Очистка и удаление выполняются для себя, поэтому доступны каждому участнику. */}
                <MenuItem theme={theme} icon={Eraser} label="Очистить переписку"
                  onClick={() => { setMoreOpen(false); setConfirm({
                    title: "Очистить переписку у себя?",
                    message: "Сообщения перестанут показываться вам. У собеседника переписка останется — удалять чужую историю нельзя. Отменить это нельзя.",
                    confirmLabel: "Очистить",
                    danger: true,
                    onConfirm: async () => {
                      setConfirm(null);
                      try { await api.clearChat(chat.id); await load(); onChanged(); }
                      catch (e) { onError(e.message); }
                    },
                  }); }} />
                <MenuItem theme={theme} icon={Trash2} label="Удалить чат"
                  onClick={() => { setMoreOpen(false); setConfirm({
                    title: "Удалить чат у себя?",
                    message: chat.kind === "direct"
                      ? "Чат исчезнет из вашего списка. У собеседника он останется, и если он напишет — разговор вернётся."
                      : "Вы выйдете из группового чата. Остальные участники и переписка останутся.",
                    confirmLabel: "Удалить",
                    danger: true,
                    onConfirm: async () => {
                      setConfirm(null);
                      try { await api.deleteChat(chat.id); onLeft(); }
                      catch (e) { onError(e.message); }
                    },
                  }); }} />
              </div>
            </>
          )}
        </div>
      </header>

      {searchOpen && (
        <div style={{ borderColor: theme.border }} className="border-b px-5 py-2.5">
          <div className="relative">
            <Search size={14} style={{ color: theme.textMuted }}
              className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input value={q} onChange={(e) => setQ(e.target.value)} autoFocus
              placeholder="Искать в переписке — по тексту и по именам файлов"
              aria-label="Искать в переписке"
              style={inputStyle(theme)}
              className="w-full rounded-full pl-9 pr-3 py-2 text-[13px] outline-none" />
          </div>
        </div>
      )}

      {/* Лента на фоне дизайна; выделяются сами сообщения (как в YouGile). */}
      <div style={{ background: theme.bg }} className="flex-1 min-h-0 overflow-y-auto px-5 py-4">
        {loading && <Spinner theme={theme} label="Загружаем сообщения…" />}
        {!loading && messages.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-10">
            {q ? "В этом чате ничего не нашлось." : "Сообщений пока нет."}
          </p>
        )}

        {messages.map((m, idx) => {
          const mine = m.authorId === currentUser.id;
          const author = m.authorId ? resolveUser(directory, m.authorId) : null;
          // Подряд идущие сообщения одного автора объединяются в группу: имя и аватар отображаются у первого сообщения группы.
          const prev = messages[idx - 1];
          const sameSeries = prev
            && prev.authorId === m.authorId
            && new Date(m.createdAt) - new Date(prev.createdAt) < 5 * 60 * 1000;
          // Имя автора отображается только в групповом чате.
          const showName = !mine && chat.kind === "group" && !sameSeries;
          const time = new Date(m.createdAt)
            .toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
          const read = readThrough && new Date(m.createdAt) <= readThrough;
          // Сообщение с опросом отображается карточкой, а не пузырём.
          const msgPolls = polls.filter((p) => p.messageId === m.id);
          const asCard = msgPolls.length > 0 && !m.deleted && editing?.id !== m.id;
          // Подложка светлая: собственные сообщения подкрашиваются акцентом, текст всегда тёмный.
          const tint = false;
          // Угол пузыря со стороны автора у продолжения серии острее.
          const corner = sameSeries ? 6 : 18;

          const nextSame = messages[idx + 1]
            && messages[idx + 1].authorId === m.authorId
            && new Date(messages[idx + 1].createdAt) - new Date(m.createdAt) < 5 * 60 * 1000;
          const forwarded = m.fwdAuthorId != null;
          // Цвета как в YouGile: чужое сообщение — спокойная подложка поверхности, своё — подкрашено акцентом.
          const bubbleBg = mine ? `color-mix(in srgb, ${theme.accent} 22%, ${theme.surface})` : theme.surface;
          const iconBg = `color-mix(in srgb, ${bubbleBg} 88%, transparent)`;
          const act = "w-7 h-7 rounded-full flex items-center justify-center hover:bg-[var(--t-surface)] transition-colors";

          return (
            <div key={m.id} id={`msg-${m.id}`}
              style={flashId === m.id ? { background: `${theme.accent}22`, borderRadius: 14, transition: "background .3s" } : { transition: "background .6s" }}
              className={`flex gap-2 items-end ${sameSeries ? "mt-1" : "mt-3"} ${mine ? "flex-row-reverse" : ""}`}>
              {/* Аватар — у последнего сообщения серии, рядом с пузырём (как в YouGile). */}
              {!mine && (
                <span className="w-[30px] shrink-0 self-end">
                  {!nextSame && author && (
                    <AvatarWithPresence user={author} size={30} theme={theme} online={online?.has(author.id)} />
                  )}
                </span>
              )}

              <div className="relative group max-w-[74%] min-w-[120px]"
                style={asCard ? undefined : {
                  background: bubbleBg, color: theme.text, borderRadius: 16,
                  [mine ? "borderBottomRightRadius" : "borderBottomLeftRadius"]: nextSame ? 16 : 4,
                }}>
                {/* Действия при наведении: реакция, ответ, меню «⋯» (копировать, переслать, изменить, удалить). */}
                {!m.deleted && editing?.id !== m.id && (
                  <div style={{ background: iconBg, color: theme.textMuted }}
                    className={`absolute top-1 right-1.5 z-10 flex items-center rounded-full transition-opacity ${(reactFor === m.id || menuFor === m.id) ? "opacity-100" : "opacity-0 group-hover:opacity-100 focus-within:opacity-100"}`}>
                    <button onClick={() => { setMenuFor(null); setReactFor(reactFor === m.id ? null : m.id); }}
                      className={act} title="Реакция" aria-label="Реакция"><SmilePlus size={15} /></button>
                    <button onClick={() => startReply(m)} className={act} title="Ответить" aria-label="Ответить"><Reply size={15} /></button>
                    <button onClick={() => { setReactFor(null); setMenuFor(menuFor === m.id ? null : m.id); }}
                      className={act} title="Ещё" aria-label="Ещё"><MoreHorizontal size={16} /></button>
                  </div>
                )}
                {reactFor === m.id && (
                  <>
                    <div className="fixed inset-0 z-[60]" onClick={() => setReactFor(null)} />
                    <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
                      className={`absolute top-9 z-[61] p-1.5 rounded-2xl shadow-xl grid grid-cols-8 gap-0.5 ${mine ? "right-1" : "left-1"}`}>
                      {REACTIONS.map((e) => (
                        <button key={e} onClick={() => react(m, e)}
                          className="text-[20px] leading-none p-1 rounded-lg hover:bg-[var(--t-surfaceAlt)] flex items-center justify-center w-9 h-9">
                          {e.startsWith(":") ? <AnimatedEmoji code={e} size={28} /> : e}
                        </button>
                      ))}
                    </div>
                  </>
                )}
                {menuFor === m.id && (
                  <>
                    <div className="fixed inset-0 z-[60]" onClick={() => setMenuFor(null)} />
                    <div role="menu" style={{ background: theme.surface, border: `1px solid ${theme.border}`, color: theme.text }}
                      className={`absolute top-9 z-[61] w-[190px] p-1.5 rounded-2xl shadow-xl ${mine ? "right-1" : "left-1"}`}>
                      <MenuItem theme={theme} icon={Copy} label="Копировать" onClick={() => { setMenuFor(null); copyMessage(m); }} />
                      <MenuItem theme={theme} icon={Forward} label="Переслать" onClick={() => { setMenuFor(null); setForwardMsg(m); }} />
                      {mine && m.body && !forwarded && Date.now() - new Date(m.createdAt).getTime() < 3600_000 && (
                        <MenuItem theme={theme} icon={Pencil} label="Редактировать"
                          onClick={() => {
                            setMenuFor(null);
                            // Ширина пузыря запоминается: поле правки занимает ту же ширину, а не сжимается до минимальной.
                            const w = document.getElementById(`msg-${m.id}`)?.querySelector(".group")?.offsetWidth || 0;
                            setEditing({ id: m.id, body: m.body, w });
                          }} />
                      )}
                      {mine && (
                        <MenuItem theme={theme} icon={Trash2} label="Удалить" danger
                          onClick={() => {
                            setMenuFor(null);
                            setConfirm({
                              title: "Удалить сообщение?",
                              message: "Текст и файл будут убраны, на их месте останется пометка «сообщение удалено».",
                              confirmLabel: "Удалить", danger: true,
                              onConfirm: async () => {
                                setConfirm(null);
                                try { await api.deleteMessage(m.id); await load(); onChanged(); } catch (e) { onError(e.message); }
                              },
                            });
                          }} />
                      )}
                    </div>
                  </>
                )}

                <div className={asCard ? "glass p-3.5 w-[min(380px,100%)]" : "px-3.5 pt-2 pb-1.5 min-w-0"}>
                  {showName && (
                    <div style={{ color: theme.text }} className="text-[13px] font-bold mb-0.5 pr-20 truncate">
                      {author.fullName}
                    </div>
                  )}

                  {m.deleted ? (
                    <span style={{ opacity: 0.7 }} className="text-[13px] italic">сообщение удалено</span>
                  ) : editing?.id === m.id ? (
                    <div className="py-1 min-w-[240px]" style={editing.w ? { minWidth: Math.max(240, editing.w - 28) } : undefined}>
                      <MultilineField theme={theme} value={editing.body} autoFocus
                        onChange={(body) => setEditing({ ...editing, body })}
                        onSubmit={saveEdit}
                        className="w-full rounded-xl px-3 py-1.5 text-[14px] outline-none mb-2" />
                      <div className="flex gap-3">
                        <button onClick={saveEdit} className="text-[12px] font-semibold flex items-center gap-1 hover:opacity-80">
                          <Check size={13} /> Сохранить
                        </button>
                        <button onClick={() => setEditing(null)} className="text-[12px] flex items-center gap-1 hover:opacity-80">
                          <X size={13} /> Отмена
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      {/* Пересланное сообщение: отметка об авторе исходного; такое сообщение не редактируется. */}
                      {forwarded && (
                        <div style={{ color: theme.accent, borderLeft: `3px solid ${theme.accent}` }}
                          className="text-[12px] leading-4 mb-1.5 pl-2">
                          <Forward size={11} className="inline mr-1 -mt-0.5" />
                          Переслано от <b>{resolveUser(directory, m.fwdAuthorId).fullName}</b>
                          {m.fwdAt && <span style={{ color: theme.textMuted }}> · {fmtDateTime(m.fwdAt)}</span>}
                        </div>
                      )}
                      {m.replyTo && (
                        <button onClick={() => jumpTo(m.replyTo)} type="button"
                          style={{ borderLeft: `3px solid ${theme.accent}`, background: `${theme.accent}14` }}
                          className="block w-full text-left rounded-md pl-2 pr-2 py-1 mb-1.5 min-w-0">
                          <span style={{ color: theme.accent }} className="block text-[12px] font-semibold truncate">
                            {m.replyAuthorId ? resolveUser(directory, m.replyAuthorId).fullName : "Сообщение"}
                          </span>
                          <span style={{ opacity: 0.85 }} className="block text-[12px] leading-4 truncate">
                            {m.replyDeleted ? "Сообщение удалено" : (m.replyText || "Вложение")}
                          </span>
                        </button>
                      )}
                      {m.body && (
                        <div style={asCard ? { color: theme.text } : undefined}
                          className={asCard
                            ? "text-[15px] leading-5 font-semibold whitespace-pre-wrap break-words"
                            : "text-[14px] leading-5 whitespace-pre-wrap break-words"}>
                          <MsgBody text={m.body} theme={theme} tint={false} />
                        </div>
                      )}

                      {m.fileId && (m.mime || "").startsWith("image/") && (
                        <button onClick={() => setPreview(m)} className="block mt-1.5">
                          <ChatImage messageId={m.id} filename={m.filename} theme={theme} />
                        </button>
                      )}
                      {m.fileId && !(m.mime || "").startsWith("image/") && (
                        <button onClick={() => setPreview(m)} style={{ color: theme.accent }}
                          className="flex items-center gap-1.5 text-[13px] font-medium mt-1 underline underline-offset-2 hover:opacity-80">
                          <Paperclip size={13} /> {m.filename}
                          <span style={{ opacity: 0.7 }} className="tabular-nums">
                            ({Math.max(1, Math.round((m.size || 0) / 1024))} КБ)
                          </span>
                        </button>
                      )}

                      {msgPolls.map((p) => (
                        <Poll key={p.id} poll={p} theme={theme} mine={mine}
                          currentUser={currentUser} directory={directory}
                          onChanged={load} onError={onError} />
                      ))}
                    </>
                  )}

                  {/* Нижняя строка: реакции слева, время и отметки доставки справа (как в YouGile). */}
                  {!m.deleted && (
                    <div className="flex items-end justify-between gap-3 mt-1">
                      <div className="flex flex-wrap gap-1 min-w-0">
                        {(m.reactions || []).map((r) => {
                          const mineR = r.users.includes(currentUser.id);
                          const names = r.users.map((id) => resolveUser(directory, id).fullName).join(", ");
                          return (
                            <button key={r.emoji} onClick={() => react(m, r.emoji)} title={names}
                              style={{
                                background: theme.surface, color: theme.text,
                                border: `1px solid ${mineR ? theme.accent : theme.border}`,
                                boxShadow: mineR ? `0 0 0 1px ${theme.accent}` : "none",
                              }}
                              className="rounded-lg px-2 h-[26px] text-[12px] flex items-center gap-1 tabular-nums">
                              <span className="text-[14px] leading-none flex items-center">
                                {r.emoji.startsWith(":") ? <AnimatedEmoji code={r.emoji} size={20} still /> : r.emoji}
                              </span>{r.users.length}
                            </button>
                          );
                        })}
                      </div>
                      <div style={{ color: theme.textMuted }}
                        className="flex items-center gap-1 text-[11px] leading-4 tabular-nums shrink-0 ml-auto">
                        {m.editedAt && <span>изм.</span>}
                        <span>{msgStamp(m.createdAt)}</span>
                        {mine && (read
                          ? <CheckCheck size={13} style={{ color: theme.accent }} title="Прочитано" />
                          : <Check size={13} title="Отправлено" />)}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      <div className="px-4 pb-4 pt-1">
        <input ref={fileRef} type="file" className="hidden"
          onChange={(e) => { upload(e.target.files?.[0]); e.target.value = ""; }} />
        {/* Плашка ответа над полем ввода: кому и на что отвечаем, крестик отменяет. */}
        {replyTo && (
          <div style={{ background: theme.surfaceAlt, borderLeft: `3px solid ${theme.accent}`, border: `1px solid ${theme.border}`, borderLeftWidth: 3, borderLeftColor: theme.accent }}
            className="flex items-center gap-2 rounded-2xl px-3 py-1.5 mb-1.5">
            <Reply size={15} style={{ color: theme.accent }} className="shrink-0" />
            <div className="min-w-0 flex-1">
              <div style={{ color: theme.accent }} className="text-[12px] font-semibold truncate">
                Ответ: {replyTo.authorId ? resolveUser(directory, replyTo.authorId).fullName : "сообщение"}
              </div>
              <div style={{ color: theme.textMuted }} className="text-[12px] truncate">{replyTo.text || "Вложение"}</div>
            </div>
            <button onClick={() => setReplyTo(null)} className="btn-icon shrink-0" aria-label="Отменить ответ" title="Отменить ответ">
              <X size={15} />
            </button>
          </div>
        )}
        {/* Поле ввода: слева скрепка и смайлы, справа отправка. */}
        <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
          className="rounded-[24px] flex items-end gap-1 p-1.5 focus-within:border-[var(--t-accent)] transition-colors duration-150">
          <button onClick={() => fileRef.current?.click()} className="btn-icon shrink-0"
            aria-label="Отправить файл" title="Отправить файл"><Paperclip size={18} /></button>

          {/* Скрепка принимает любой файл, включая изображения. */}
          <div className="relative shrink-0">
            <button onClick={() => setEmojiOpen((v) => !v)} className="btn-icon"
              aria-label="Смайлики" title="Смайлики"><Smile size={18} /></button>
            {emojiOpen && (
              <EmojiPicker theme={theme} onPick={(ch) => { setText((t) => t + ch); setEmojiOpen(false); }}
                onClose={() => setEmojiOpen(false)} />
            )}
          </div>
          {/* Отправка — Ctrl+Enter, Enter переносит строку (сообщения чаще многострочные). */}
          <MultilineField theme={theme} value={text} onChange={setText} onSubmit={send}
            placeholder="Сообщение. Ctrl+Enter — отправить, Enter — новая строка"
            className="flex-1 min-w-0 self-center !bg-transparent !border-transparent px-1.5 py-2 text-[14px] leading-5 outline-none focus-visible:!outline-none" />
          <button onClick={send} disabled={!text.trim()}
            className="btn-primary shrink-0 !w-9 !h-9 !p-0 disabled:opacity-40 disabled:cursor-default"
            aria-label="Отправить (Ctrl+Enter)" title="Отправить (Ctrl+Enter)"><Send size={16} /></button>
        </div>
      </div>

      {renaming !== null && (
        <RenameChatModal theme={theme} initial={renaming}
          onClose={() => setRenaming(null)} onError={onError}
          onSaved={async (t) => {
            try {
              await api.renameChat(chat.id, t);
              setRenaming(null);
              onChanged();
            } catch (e) { onError(e.message); }
          }} />
      )}

      {membersOpen && (
        <ChatMembersModal theme={theme} chat={chat} directory={directory} currentUser={currentUser}
          isOwner={isOwner} online={online} onClose={() => setMembersOpen(false)} onError={onError}
          onChanged={onChanged} onLeft={onLeft} />
      )}

      {pollOpen && (
        <PollModal theme={theme} onClose={() => setPollOpen(false)} onError={onError}
          onCreate={async (payload) => {
            try {
              await api.createPoll(chat.id, payload);
              setPollOpen(false);
              await load();
              onChanged();
            } catch (e) { onError(e.message); }
          }} />
      )}

      {forwardMsg && (
        <ForwardModal theme={theme} message={forwardMsg} chats={allChats} titleOf={titleOf} currentChatId={chat.id}
          onClose={() => setForwardMsg(null)} onError={onError}
          onDone={async (n) => { setForwardMsg(null); await load(); onChanged(); }} />
      )}

      {preview && (
        <FilePreview theme={theme} filename={preview.filename} mime={preview.mime}
          path={`/messages/${preview.id}/file`}
          pdfPath={`/messages/${preview.id}/pdf`}
          downloadPath={`/messages/${preview.id}/file?download=1`}
          onClose={() => setPreview(null)} />
      )}

      {confirm && <ConfirmDialog theme={theme} {...confirm} onCancel={() => setConfirm(null)} />}
    </section>
  );
}

/* Раздел: новый чат. */
/* Компонент NewChatModal предназначен для создания личного или группового чата. */

function NewChatModal({ theme, kind, directory, currentUser, onClose, onCreated, onError }) {
  const [q, setQ] = useState("");
  const [title, setTitle] = useState("");
  const [picked, setPicked] = useState([]);
  const [busy, setBusy] = useState(false);

  // Собеседник выбирается из всех пользователей системы, а не только из своей команды.
  const people = directory
    .filter((u) => !u.deleted && u.id !== currentUser.id)
    .filter((u) => {
      const needle = q.trim().toLowerCase();
      if (!needle) return true;
      return u.fullName.toLowerCase().includes(needle)
        || (u.position || "").toLowerCase().includes(needle);
    })
    .sort((a, b) => a.fullName.localeCompare(b.fullName, "ru"));

  const submit = async (userId) => {
    setBusy(true);
    try {
      const res = kind === "direct"
        ? await api.createChat({ kind: "direct", userId })
        : await api.createChat({ kind: "group", title: title.trim(), members: picked });
      onCreated(res.id);
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="chat-new">
      <ModalHeader theme={theme} onClose={onClose}
        title={kind === "direct" ? "Новый чат" : "Новый групповой чат"}
        subtitle={kind === "direct"
          ? "Выберите собеседника. Если переписка с ним уже есть, откроется она"
          : "Название и участники. Вы будете владельцем чата"} />

      {kind === "group" && (
        <input value={title} onChange={(e) => setTitle(e.target.value)}
          placeholder="Название чата" style={inputStyle(theme)}
          className="w-full rounded-xl px-3 py-2 text-[14px] outline-none mb-2" />
      )}

      <input value={q} onChange={(e) => setQ(e.target.value)}
        placeholder="Имя или должность" style={inputStyle(theme)}
        className="w-full rounded-xl px-3 py-2 text-[14px] outline-none mb-2" />

      <div style={{ borderColor: theme.border }} className="border-t pt-2 max-h-[38vh] overflow-y-auto mb-3">
        {people.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px] py-4 text-center">
            Никого не нашлось.
          </p>
        )}
        {people.map((u) => {
          const on = picked.includes(u.id);
          return (
            <button key={u.id} disabled={busy}
              onClick={() => {
                if (kind === "direct") return submit(u.id);
                setPicked((prev) => (on ? prev.filter((x) => x !== u.id) : [...prev, u.id]));
              }}
              style={{ background: on ? theme.surfaceAlt : undefined }}
              className="w-full flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-left mb-0.5 transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)] disabled:opacity-50">
              <Avatar user={u} size={30} theme={theme} />
              <span className="flex-1 min-w-0">
                <span style={{ color: theme.text }} className="text-[14px] font-medium block truncate">{u.fullName}</span>
                <span style={{ color: theme.textMuted }} className="text-[12px] block truncate">
                  {u.position || "Должность не указана"}
                </span>
              </span>
              {on && <Check size={16} style={{ color: theme.accent }} />}
            </button>
          );
        })}
      </div>

      {kind === "group" && (
        <button onClick={() => submit()} disabled={busy || !title.trim()}
          className="btn-primary w-full disabled:opacity-50 disabled:cursor-default">
          {busy ? "Создаём…" : `Создать чат${picked.length ? ` · участников: ${picked.length + 1}` : ""}`}
        </button>
      )}
    </Modal>
  );
}

// Компонент RenameChatModal предназначен для переименования группового чата.
function RenameChatModal({ theme, initial, onClose, onSaved }) {
  const [title, setTitle] = useState(initial);
  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="chat-rename">
      <ModalHeader theme={theme} title="Название чата" onClose={onClose} />
      <input value={title} onChange={(e) => setTitle(e.target.value)} autoFocus
        onKeyDown={(e) => { if (e.key === "Enter" && title.trim()) onSaved(title.trim()); }}
        style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none mb-3" />
      <div className="flex gap-2">
        <button onClick={onClose} className="btn-pill flex-1">Отмена</button>
        <button onClick={() => onSaved(title.trim())} disabled={!title.trim()}
          className="btn-primary flex-1 disabled:opacity-50 disabled:cursor-default">
          Сохранить
        </button>
      </div>
    </Modal>
  );
}

// Компонент ChatMembersModal предназначен для просмотра и изменения состава чата.
function ChatMembersModal({ theme, chat, directory, currentUser, isOwner, online, onClose, onError, onChanged, onLeft }) {
  const [q, setQ] = useState("");
  const members = chat.members || [];

  const candidates = directory
    .filter((u) => !u.deleted && !members.includes(u.id))
    .filter((u) => {
      const needle = q.trim().toLowerCase();
      if (!needle) return true;
      return u.fullName.toLowerCase().includes(needle)
        || (u.position || "").toLowerCase().includes(needle);
    })
    .slice(0, 8);

  const act = async (fn) => {
    try {
      await fn();
      onChanged();
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="chat-members">
      <ModalHeader theme={theme} title="Участники чата" onClose={onClose}
        subtitle={isOwner
          ? "Вы владелец: можете добавлять и убирать участников"
          : "Состав меняет владелец чата"} />

      <div className="mb-3">
        {members.map((id) => {
          const u = resolveUser(directory, id);
          const owner = chat.ownerId === id;
          return (
            <div key={id} className="flex items-center gap-2.5 py-1.5">
              <AvatarWithPresence user={u} size={30} theme={theme} online={online?.has(id)} />
              <span style={{ color: theme.text }} className="text-[14px] flex-1 truncate">
                {u.fullName}
              </span>
              {owner && (
                <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="pill">владелец</span>
              )}
              {/* Владельца из состава убрать нельзя. */}
              {isOwner && !owner && (
                <button onClick={() => act(() => api.removeChatMember(chat.id, id))}
                  className="btn-pill !py-1 !px-3 !text-[12px]">Убрать</button>
              )}
            </div>
          );
        })}
      </div>

      {isOwner && (
        <>
          <input value={q} onChange={(e) => setQ(e.target.value)}
            placeholder="Добавить: имя или должность" style={inputStyle(theme)}
            className="w-full rounded-xl px-3 py-2 text-[14px] outline-none mb-2" />
          {candidates.map((u) => (
            <div key={u.id} className="flex items-center gap-2.5 py-1.5">
              <Avatar user={u} size={28} theme={theme} />
              <span style={{ color: theme.text }} className="text-[14px] flex-1 truncate">{u.fullName}</span>
              <button onClick={() => act(() => api.addChatMember(chat.id, u.id))}
                style={{ color: theme.accent }} className="btn-pill !py-1 !px-3 !text-[12px]">
                <UserPlus size={13} /> Добавить
              </button>
            </div>
          ))}
        </>
      )}

      {!isOwner && (
        <button
          onClick={() => act(async () => {
            await api.removeChatMember(chat.id, currentUser.id);
            onLeft();
          })}
          className="btn-pill mt-2">
          <LogOut size={14} /> Выйти из чата
        </button>
      )}
    </Modal>
  );
}

/* Раздел: опросы. */
/* Компонент PollModal предназначен для создания опроса. */

function PollModal({ theme, onClose, onCreate }) {
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState(["", ""]);
  const [multiple, setMultiple] = useState(false);

  const valid = question.trim() && options.filter((o) => o.trim()).length >= 2;

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="chat-poll">
      <ModalHeader theme={theme} title="Новый опрос" onClose={onClose}
        subtitle="Появится сообщением в чате. Ответы видны всем участникам" />

      <input value={question} onChange={(e) => setQuestion(e.target.value)} autoFocus
        placeholder="Вопрос" style={inputStyle(theme)}
        className="w-full rounded-xl px-3 py-2 text-[14px] outline-none mb-2" />

      {options.map((o, i) => (
        <div key={i} className="flex items-center gap-2 mb-2">
          <input value={o}
            onChange={(e) => setOptions((prev) => prev.map((v, idx) => (idx === i ? e.target.value : v)))}
            placeholder={`Вариант ${i + 1}`} style={inputStyle(theme)}
            className="flex-1 rounded-xl px-3 py-2 text-[14px] outline-none" />
          {options.length > 2 && (
            <button onClick={() => setOptions((prev) => prev.filter((_, idx) => idx !== i))}
              className="btn-icon shrink-0" aria-label="Убрать вариант" title="Убрать вариант"><X size={16} /></button>
          )}
        </div>
      ))}

      {/* Максимум десять вариантов ответа. */}
      {options.length < 10 && (
        <button onClick={() => setOptions((prev) => [...prev, ""])}
          style={{ color: theme.accent }} className="flex items-center gap-1.5 text-[13px] font-medium mb-3 mt-1 hover:opacity-80">
          <Plus size={14} /> Добавить вариант
        </button>
      )}

      <label className="flex items-center gap-2 mb-3 cursor-pointer">
        <input type="checkbox" checked={multiple} onChange={(e) => setMultiple(e.target.checked)} />
        <span style={{ color: theme.text }} className="text-[13px]">
          Можно выбрать несколько вариантов
        </span>
      </label>

      <div className="flex gap-2">
        <button onClick={onClose} className="btn-pill flex-1">Отмена</button>
        <button
          onClick={() => onCreate({
            question: question.trim(),
            options: options.map((o) => o.trim()).filter(Boolean),
            multiple,
          })}
          disabled={!valid}
          className="btn-primary flex-1 disabled:opacity-50 disabled:cursor-default">
          Создать опрос
        </button>
      </div>
    </Modal>
  );
}

// Компонент Poll предназначен для отображения опроса в ленте: варианты, голоса и результаты (результаты видны сразу).
function Poll({ poll, theme, mine, currentUser, directory, onChanged, onError }) {
  const total = new Set(poll.options.flatMap((o) => (o.votes || []).map((v) => v.userId))).size;

  const vote = async (optionId) => {
    try {
      await api.vote(optionId);
      onChanged();
    } catch (e) {
      onError(e.message);
    }
  };

  const closePoll = async () => {
    try {
      await api.closePoll(poll.id);
      onChanged();
    } catch (e) {
      onError(e.message);
    }
  };

  // Опрос отображается в нейтральной карточке, цвета общие для своих и чужих; принадлежность определяет только доступность кнопки завершения.
  return (
    <div className="mt-2">
      <div style={{ color: theme.textMuted }} className="flex items-center gap-1.5 text-[12px] font-medium mb-2">
        <BarChart3 size={13} />
        {poll.closed ? "Опрос завершён" : poll.multiple ? "Опрос · несколько ответов" : "Опрос"}
      </div>

      {poll.options.map((o) => {
        const votes = (o.votes || []).length;
        const share = total ? Math.round((votes / total) * 100) : 0;
        const picked = (o.votes || []).some((v) => v.userId === currentUser.id);
        // Кто и когда проголосовал — в подсказке.
        const who = (o.votes || [])
          .map((v) => `${resolveUser(directory, v.userId).fullName} — ${fmtDateTime(v.votedAt)}`)
          .join("\n");
        return (
          <button key={o.id} onClick={() => !poll.closed && vote(o.id)}
            disabled={poll.closed}
            aria-pressed={picked}
            title={who || "Пока никто не выбрал"}
            style={{
              borderColor: picked ? theme.accent : theme.border,
              background: theme.surface,
            }}
            className={`w-full text-left border rounded-xl px-3 pt-2 pb-2.5 mb-1.5 block
              transition-colors duration-150 ease-out
              ${poll.closed ? "cursor-default" : "hover:border-[var(--t-accent)]"}`}>
            <span className="flex items-center gap-2">
              {picked
                ? <Check size={14} style={{ color: theme.accent }} className="shrink-0" />
                : null}
              <span style={{ color: theme.text, fontWeight: picked ? 600 : 500 }}
                className="text-[13px] flex-1 truncate">{o.body}</span>
              <span style={{ color: theme.textMuted }} className="text-[12px] tabular-nums shrink-0">
                {votes} · {share}%
              </span>
            </span>
            {/* Полоса голосов тонкой линией под вариантом. */}
            <span style={{ background: theme.surfaceAlt }}
              className="block h-1 rounded-full overflow-hidden mt-2">
              <span style={{
                  width: `${share}%`,
                  background: picked ? theme.accent : theme.textMuted,
                  opacity: picked ? 1 : 0.55,
                }}
                className="block h-full rounded-full transition-[width] duration-200 ease-out" />
            </span>
          </button>
        );
      })}

      {/* Развёрнутый список голосов со временем отметки. */}
      {total > 0 && (
        <div style={{ color: theme.textMuted }} className="text-[12px] leading-[18px] mt-2">
          {poll.options.flatMap((o) => (o.votes || []).map((v) => (
            <div key={`${o.id}-${v.userId}`} className="truncate">
              {resolveUser(directory, v.userId).fullName} · {o.body} · {fmtDateTime(v.votedAt)}
            </div>
          )))}
        </div>
      )}

      <div className="flex items-center gap-3 mt-2">
        <span style={{ color: theme.textMuted }} className="text-[12px] tabular-nums">
          Проголосовали: {total}
        </span>
        {mine && !poll.closed && (
          <button onClick={closePoll} style={{ color: theme.accent }}
            className="text-[12px] font-medium hover:opacity-80">
            Завершить опрос
          </button>
        )}
      </div>
    </div>
  );
}

// Компонент MenuItem предназначен для пункта меню «⋯» в шапке разговора.
function MenuItem({ theme, icon: Icon, label, onClick, danger = false }) {
  return (
    <button role="menuitem" onClick={onClick} style={{ color: danger ? theme.danger : theme.text }}
      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] text-left
        transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]">
      <Icon size={15} style={{ color: danger ? theme.danger : theme.textMuted }} className="shrink-0" />
      {label}
    </button>
  );
}

/* Раздел: картинка в переписке. */

// Компонент ChatImage предназначен для отображения картинки вложения с авторизацией (токен не передаётся в <img src>).
function ChatImage({ messageId, filename, theme }) {
  return (
    <AuthImage path={`/messages/${messageId}/file`} alt={filename} theme={theme}
      className="rounded-xl max-w-full w-40" style={{ maxHeight: 280, width: "auto" }} />
  );
}

/* Раздел: картинка чата. */

// Компонент ChatAvatar предназначен для отображения картинки группового чата с авторизацией; без картинки — значок.
function ChatAvatar({ chatId, hasAvatar, size, theme }) {
  if (!hasAvatar) {
    return (
      <span style={{ background: theme.surfaceAlt, color: theme.textMuted, width: size, height: size }}
        className="rounded-full flex items-center justify-center shrink-0">
        <UsersRound size={Math.round(size * 0.5)} />
      </span>
    );
  }
  return (
    <AuthImage path={`/chats/${chatId}/avatar`} alt="" theme={theme}
      className="rounded-full shrink-0"
      style={{ width: size, height: size, objectFit: "cover" }} />
  );
}

/* Раздел: пересылка. */

// Компонент ForwardModal предназначен для выбора чатов, в которые пересылается сообщение (до 10); автор исходного сообщения сохраняется.
function ForwardModal({ theme, message, chats, titleOf, currentChatId, onClose, onError, onDone }) {
  const [picked, setPicked] = useState(new Set());
  const [filter, setFilter] = useState("");
  const [busy, setBusy] = useState(false);
  const list = chats.filter((c) => !filter.trim() || (titleOf ? titleOf(c) : c.title).toLowerCase().includes(filter.trim().toLowerCase()));
  const toggle = (id) => setPicked((p) => {
    const n = new Set(p);
    if (n.has(id)) n.delete(id); else if (n.size < 10) n.add(id);
    return n;
  });
  const send = async () => {
    setBusy(true);
    try {
      await api.forwardMessage(message.id, [...picked]);
      onDone(picked.size);
    } catch (e) { onError(e.message); setBusy(false); }
  };
  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="forward">
      <ModalHeader theme={theme} title="Переслать сообщение" onClose={onClose}
        subtitle={(message.body || message.filename || "").slice(0, 80)} />
      <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Найти чат"
        style={inputStyle(theme)} className="w-full rounded-full px-4 py-2 text-[13.5px] outline-none mb-2" />
      <div className="max-h-[280px] overflow-y-auto mb-3">
        {list.map((c) => (
          <label key={c.id} className="flex items-center gap-2.5 px-2 py-1.5 rounded-xl cursor-pointer hover:bg-[var(--t-surfaceAlt)]">
            <input type="checkbox" checked={picked.has(c.id)} onChange={() => toggle(c.id)} />
            <span style={{ color: theme.text }} className="text-[14px] truncate">{titleOf ? titleOf(c) : c.title}</span>
            {c.id === currentChatId && <span style={{ color: theme.textMuted }} className="text-[11px]">этот чат</span>}
          </label>
        ))}
        {list.length === 0 && <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-4">Чатов нет</p>}
      </div>
      <button onClick={send} disabled={busy || picked.size === 0} className="btn-primary w-full h-10 disabled:opacity-50">
        <Forward size={14} /> Переслать{picked.size ? ` (${picked.size})` : ""}
      </button>
    </Modal>
  );
}

/* Раздел: ссылки в сообщении. */

// Компонент MsgBody предназначен для тела сообщения; разбор ссылок и смайлов запоминается и не повторяется при вводе
// текста в поле (раньше каждая буква перерисовывала все сообщения, включая сотни смайлов).
const MsgBody = React.memo(function MsgBody({ text, theme, tint }) {
  return <>{React.useMemo(() => withLinks(text, theme, tint), [text, theme, tint])}</>;
});

// Ссылки (http и адреса приложения: задачи, проекты, чаты) становятся рабочими и открываются в новом окне.
const URL_RE = /(https?:\/\/[^\s<]+|\/(?:tasks|b|ready|chats|inbox)\/[^\s<]+)/g;

// Функция withLinks предназначена для превращения ссылок в тексте сообщения в элементы-ссылки.
function withLinks(text, theme, mine) {
  if (!text) return text;
  const budget = { anim: 0, still: 0 };
  const parts = [];
  let last = 0;
  for (const m of text.matchAll(URL_RE)) {
    if (m.index > last) parts.push(...[].concat(withEmoji(text.slice(last, m.index), 36, budget)));
    parts.push(
      <a key={`l${m.index}`} href={m[0]} target="_blank" rel="noreferrer"
        style={{ color: mine ? theme.accentText : theme.accent, textDecoration: "underline" }}
        className="break-all">
        {m[0]}
      </a>
    );
    last = m.index + m[0].length;
  }
  if (last === 0) return withEmoji(text, 36, budget);
  if (last < text.length) parts.push(...[].concat(withEmoji(text.slice(last), 36, budget)));
  return parts;
}
