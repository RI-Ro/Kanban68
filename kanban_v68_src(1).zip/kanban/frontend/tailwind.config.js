// Модуль предназначен для настройки Tailwind CSS: области поиска классов и шрифтовой стек.

/* Тип конфигурации Tailwind. */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      // Шрифтовой стек совпадает с --font-ui в styles.css: только системные шрифты.
      fontFamily: {
        sans: ["system-ui", "-apple-system", "Segoe UI", "Roboto",
               "Helvetica Neue", "Noto Sans", "Liberation Sans", "Arial", "sans-serif"],
        mono: ["ui-monospace", "SFMono-Regular", "Menlo", "Consolas",
               "Liberation Mono", "DejaVu Sans Mono", "monospace"],
      },
    },
  },
  plugins: [],
};
