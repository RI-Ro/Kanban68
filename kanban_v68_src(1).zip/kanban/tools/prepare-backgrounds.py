#!/usr/bin/env python3
"""Скрипт предназначен для подготовки фотографий фонов проектов: сжатие до 1600 px по длинной стороне (JPEG, качество 78,
прогрессивный) и миниатюра 320 px. Результат кладётся в frontend/public/backgrounds, а в конце печатаются строки для
списка BG_PHOTOS в frontend/src/lib/theme.js.

Использование:
    python3 tools/prepare-backgrounds.py <папка_с_фото> [--out frontend/public/backgrounds]

Имя файла становится идентификатором фона (латиница, цифры, дефис): baikal-sunset.jpg -> img:baikal-sunset.
Название для списка задаётся словарём TITLES ниже или берётся из имени файла.
Требуется Pillow (pip install pillow). Используйте только фотографии со свободной лицензией (CC0, Unsplash, Pexels, Wikimedia
Commons с разрешающей лицензией) и сохраняйте сведения об авторе, если лицензия этого требует.
"""
import argparse
import re
import sys
from pathlib import Path

from PIL import Image, ImageOps

# Подписи фонов в интерфейсе; для остальных файлов подпись строится из имени.
TITLES = {
    "baikal": "Байкал", "kamchatka": "Камчатка", "moskva": "Москва", "spb": "Санкт-Петербург",
    "belgorod": "Белгород", "kavkaz": "Кавказ", "vulkan": "Вулкан", "zakat": "Закат", "rassvet": "Рассвет",
}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("src", type=Path)
    ap.add_argument("--out", type=Path, default=Path("frontend/public/backgrounds"))
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    lines = []
    for p in sorted(args.src.iterdir()):
        if p.suffix.lower() not in (".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff"):
            continue
        name = re.sub(r"[^a-z0-9-]+", "-", p.stem.lower()).strip("-")
        if not name:
            continue
        im = ImageOps.exif_transpose(Image.open(p)).convert("RGB")
        big = im.copy()
        big.thumbnail((1600, 1600), Image.LANCZOS)
        big.save(args.out / f"{name}.jpg", "JPEG", quality=78, optimize=True, progressive=True)
        th = im.copy()
        th.thumbnail((320, 320), Image.LANCZOS)
        th.save(args.out / f"{name}-thumb.jpg", "JPEG", quality=72, optimize=True)
        size = (args.out / f"{name}.jpg").stat().st_size // 1024
        title = TITLES.get(name.split("-")[0], name.replace("-", " ").capitalize())
        lines.append(f'  {{ id: "img:{name}", label: "{title}" }},')
        print(f"{p.name}: {big.size[0]}x{big.size[1]}, {size} КБ", file=sys.stderr)

    print("\n// Вставьте в BG_PHOTOS (frontend/src/lib/theme.js):")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
