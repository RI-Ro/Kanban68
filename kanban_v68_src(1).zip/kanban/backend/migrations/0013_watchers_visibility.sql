-- Скрипт предназначен для ограничения уведомлений видимыми задачами и для отметок прочтения в переписке:
-- пересоздание app.task_watchers и функция app.chat_read_through.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Функция app.task_watchers предназначена для получения наблюдателей задачи, которые могут её открыть.
CREATE OR REPLACE FUNCTION app.task_watchers(p_task uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH base AS (
        SELECT m.user_id FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id
         WHERE t.id = p_task
        UNION
        SELECT a.user_id FROM app.task_assignees a WHERE a.task_id = p_task
        UNION
        SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
    ),
    everyone AS (
        SELECT user_id FROM base
        UNION
        -- Заместитель получает те же уведомления, что и замещаемый.
        SELECT d.deputy_id FROM base b
          JOIN app.delegations d ON d.grantor_id = b.user_id
         WHERE current_date BETWEEN d.starts_at AND d.ends_at
    )
    -- Уведомление получает только тот, кто может открыть задачу (can_see_task).
    SELECT e.user_id FROM everyone e
     WHERE app.task_access(p_task, e.user_id) IS NOT NULL
$$;

-- Функция app.chat_read_through предназначена для определения момента, до которого переписку прочитали все остальные участники
-- (по last_read_at); используется для отметок «доставлено» и «прочитано».
CREATE OR REPLACE FUNCTION app.chat_read_through(p_chat uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT min(m.last_read_at)
      FROM app.chat_members m
     WHERE m.chat_id = p_chat AND m.user_id <> p_user
$$;

GRANT EXECUTE ON FUNCTION app.chat_read_through(uuid, uuid) TO app_user;

