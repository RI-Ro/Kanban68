-- Скрипт предназначен для исправления повторного начала личного чата после его удаления: удаление только скрывает чат у
-- пользователя (hidden_at), а app.ensure_direct_chat возвращала скрытый чат, который не попадал в список, — начать новый
-- чат с тем же собеседником было невозможно. Теперь чат возвращается в список того, кто его открывает; история остаётся
-- очищенной (cleared_at не меняется).
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0034_chat_reopen.sql
--
-- Выполняется от app_owner, идемпотентен.

CREATE OR REPLACE FUNCTION app.ensure_direct_chat(p_a uuid, p_b uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_id uuid;
BEGIN
    IF p_a IS NULL OR p_b IS NULL OR p_a = p_b THEN
        RAISE EXCEPTION 'bad_direct_chat';
    END IF;

    SELECT c.id INTO v_id
      FROM app.chats c
      JOIN app.chat_members m1 ON m1.chat_id = c.id AND m1.user_id = p_a
      JOIN app.chat_members m2 ON m2.chat_id = c.id AND m2.user_id = p_b
     WHERE c.kind = 'direct'
     LIMIT 1;

    IF v_id IS NOT NULL THEN
        -- Скрытый (удалённый у p_a) чат возвращается в его список.
        UPDATE app.chat_members SET hidden_at = NULL WHERE chat_id = v_id AND user_id = p_a AND hidden_at IS NOT NULL;
        RETURN v_id;
    END IF;

    INSERT INTO app.chats (kind, owner_id) VALUES ('direct', p_a) RETURNING id INTO v_id;
    INSERT INTO app.chat_members (chat_id, user_id) VALUES (v_id, p_a), (v_id, p_b);
    RETURN v_id;
END $$;
