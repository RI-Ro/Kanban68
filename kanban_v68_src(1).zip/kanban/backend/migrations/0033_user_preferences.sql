-- Скрипт предназначен для хранения пользовательских настроек интерфейса на сервере (масштаб элементов, размер шрифта):
-- настройки принадлежат пользователю, а не браузеру, и применяются на любом устройстве. Значение — JSON ограниченного размера.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0033_user_preferences.sql
--
-- Выполняется от app_owner после 0032_self_password_repair.sql, идемпотентен.

CREATE TABLE IF NOT EXISTS app.user_preferences (
    user_id    uuid        NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    key        text        NOT NULL CHECK (key ~ '^[a-z][a-z0-9_.]{0,63}$'),
    value      jsonb       NOT NULL CHECK (pg_column_size(value) <= 8192),
    updated_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, key)
);

ALTER TABLE app.user_preferences ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS user_preferences_own ON app.user_preferences;
CREATE POLICY user_preferences_own ON app.user_preferences FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());
GRANT SELECT, INSERT, UPDATE, DELETE ON app.user_preferences TO app_user;
