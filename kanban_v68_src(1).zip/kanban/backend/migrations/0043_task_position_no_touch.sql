-- Миграция 0043 предназначена для устранения ложной подсветки задач при перетаскивании: перенос карточки сдвигает
-- позиции соседних задач, и триггер обновлял у них updated_at, из-за чего они отображались как изменённые.
-- Теперь, если у задачи изменилась только позиция, updated_at сохраняется прежним.

-- Функция app.touch_task_updated_at предназначена для обновления updated_at задачи при содержательном изменении.
CREATE OR REPLACE FUNCTION app.touch_task_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF (to_jsonb(NEW) - 'position' - 'updated_at') = (to_jsonb(OLD) - 'position' - 'updated_at') THEN
        NEW.updated_at := OLD.updated_at;
    ELSE
        NEW.updated_at := now();
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tasks_touch ON app.tasks;
-- Триггер tasks_touch предназначен для обновления updated_at задачи, кроме перестановки позиций.
CREATE TRIGGER tasks_touch BEFORE UPDATE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.touch_task_updated_at();
