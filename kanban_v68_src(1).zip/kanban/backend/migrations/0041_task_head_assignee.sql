-- Миграция 0041 предназначена для «головного» исполнителя задачи: одного из исполнителей, отвечающего за результат.
ALTER TABLE app.task_assignees ADD COLUMN IF NOT EXISTS is_head boolean NOT NULL DEFAULT false;

-- В задаче не более одного головного исполнителя.
CREATE UNIQUE INDEX IF NOT EXISTS task_assignees_one_head_idx ON app.task_assignees (task_id) WHERE is_head;

-- Функция app.set_task_head предназначена для назначения (p_head задан) или снятия (NULL) головного исполнителя.
-- Назначать может тот, кто вправе редактировать задачу; головным может быть только действующий исполнитель.
-- Возвращает false, если прав нет или пользователь не исполнитель задачи.
CREATE OR REPLACE FUNCTION app.set_task_head(p_task uuid, p_actor uuid, p_head uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF app.task_access(p_task, p_actor) IS DISTINCT FROM 'edit' THEN
        RETURN false;
    END IF;
    IF p_head IS NOT NULL AND NOT EXISTS (SELECT 1 FROM app.task_assignees WHERE task_id = p_task AND user_id = p_head) THEN
        RETURN false;
    END IF;
    UPDATE app.task_assignees SET is_head = false WHERE task_id = p_task AND is_head;
    IF p_head IS NOT NULL THEN
        UPDATE app.task_assignees SET is_head = true WHERE task_id = p_task AND user_id = p_head;
    END IF;
    UPDATE app.tasks SET updated_at = now() WHERE id = p_task;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.set_task_head(uuid, uuid, uuid) TO app_user;
