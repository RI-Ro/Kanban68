-- Скрипт предназначен для реакций на сообщения чатов (эмодзи, как в YouGile) и пересылки сообщений с отметкой автора.
-- Реакция — пара «сообщение, пользователь, эмодзи»; повторное нажатие снимает её. Пересланное сообщение хранит автора
-- и время исходного сообщения.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0035_chat_reactions_forward.sql
--
-- Выполняется от app_owner после 0034_chat_reopen.sql, идемпотентен.

CREATE TABLE IF NOT EXISTS app.chat_reactions (
    message_id uuid        NOT NULL REFERENCES app.chat_messages(id) ON DELETE CASCADE,
    user_id    uuid        NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    emoji      text        NOT NULL CHECK (char_length(emoji) BETWEEN 1 AND 16),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (message_id, user_id, emoji)
);
CREATE INDEX IF NOT EXISTS chat_reactions_message_idx ON app.chat_reactions (message_id, created_at);

ALTER TABLE app.chat_reactions ENABLE ROW LEVEL SECURITY;

-- Функция app.message_chat предназначена для получения чата сообщения (SECURITY DEFINER: политики не зацикливаются).
CREATE OR REPLACE FUNCTION app.message_chat(p_message uuid)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT chat_id FROM app.chat_messages WHERE id = p_message $$;
GRANT EXECUTE ON FUNCTION app.message_chat(uuid) TO app_user;

DROP POLICY IF EXISTS chat_reactions_select ON app.chat_reactions;
CREATE POLICY chat_reactions_select ON app.chat_reactions FOR SELECT
    USING (app.in_chat(app.message_chat(message_id), app.current_user_id()));
DROP POLICY IF EXISTS chat_reactions_insert ON app.chat_reactions;
CREATE POLICY chat_reactions_insert ON app.chat_reactions FOR INSERT
    WITH CHECK (user_id = app.current_user_id()
                AND app.in_chat(app.message_chat(message_id), app.current_user_id()));
DROP POLICY IF EXISTS chat_reactions_delete ON app.chat_reactions;
CREATE POLICY chat_reactions_delete ON app.chat_reactions FOR DELETE
    USING (user_id = app.current_user_id());
GRANT SELECT, INSERT, DELETE ON app.chat_reactions TO app_user;

ALTER TABLE app.chat_messages
    ADD COLUMN IF NOT EXISTS fwd_author_id uuid REFERENCES app.users(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS fwd_at        timestamptz;
