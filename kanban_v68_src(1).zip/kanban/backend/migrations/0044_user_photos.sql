-- Миграция 0044 предназначена для фотографий пользователей: ручная загрузка и синхронизация из LDAP.
-- Фото хранится в БД уменьшенным (квадрат до 400 px, JPEG), поэтому отдельного файлового хранилища не требуется.

CREATE TABLE IF NOT EXISTS app.user_photos (
    user_id    uuid PRIMARY KEY REFERENCES app.users(id) ON DELETE CASCADE,
    mime_type  text  NOT NULL DEFAULT 'image/jpeg',
    data       bytea NOT NULL CHECK (octet_length(data) <= 1048576),
    checksum   text  NOT NULL,
    -- manual — задано вручную (LDAP его не перезаписывает); ldap — получено из каталога.
    source     text  NOT NULL DEFAULT 'manual' CHECK (source IN ('manual', 'ldap')),
    updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE app.user_photos ENABLE ROW LEVEL SECURITY;
-- Фото видят все авторизованные пользователи, как и справочник сотрудников.
DROP POLICY IF EXISTS user_photos_read ON app.user_photos;
CREATE POLICY user_photos_read ON app.user_photos FOR SELECT USING (app.current_user_id() IS NOT NULL);
GRANT SELECT ON app.user_photos TO app_user;

-- Функция app.set_user_photo предназначена для сохранения фото: себе, администратором или службой (синхронизация LDAP).
-- Для источника ldap фото, заданное вручную, не перезаписывается. Возвращает true, если фото изменилось.
CREATE OR REPLACE FUNCTION app.set_user_photo(p_user uuid, p_mime text, p_data bytea, p_checksum text, p_source text)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_me  uuid := app.current_user_id();
    v_cur record;
BEGIN
    IF v_me IS NOT NULL AND v_me <> p_user AND NOT app.is_admin(v_me) THEN
        RAISE EXCEPTION 'forbidden' USING ERRCODE = 'insufficient_privilege';
    END IF;
    SELECT source, checksum INTO v_cur FROM app.user_photos WHERE user_id = p_user;
    IF FOUND THEN
        IF p_source = 'ldap' AND v_cur.source = 'manual' THEN RETURN false; END IF;
        IF v_cur.checksum = p_checksum AND v_cur.source = p_source THEN RETURN false; END IF;
    END IF;
    INSERT INTO app.user_photos (user_id, mime_type, data, checksum, source)
    VALUES (p_user, p_mime, p_data, p_checksum, p_source)
    ON CONFLICT (user_id) DO UPDATE
       SET mime_type = EXCLUDED.mime_type, data = EXCLUDED.data, checksum = EXCLUDED.checksum,
           source = EXCLUDED.source, updated_at = now();
    RETURN true;
END $$;

-- Функция app.delete_user_photo предназначена для удаления фото; p_only_ldap = true удаляет только полученное из LDAP.
CREATE OR REPLACE FUNCTION app.delete_user_photo(p_user uuid, p_only_ldap boolean)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_me uuid := app.current_user_id(); v_n int;
BEGIN
    IF v_me IS NOT NULL AND v_me <> p_user AND NOT app.is_admin(v_me) THEN
        RAISE EXCEPTION 'forbidden' USING ERRCODE = 'insufficient_privilege';
    END IF;
    DELETE FROM app.user_photos WHERE user_id = p_user AND (NOT p_only_ldap OR source = 'ldap');
    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n > 0;
END $$;

GRANT EXECUTE ON FUNCTION app.set_user_photo(uuid, text, bytea, text, text) TO app_user;
GRANT EXECUTE ON FUNCTION app.delete_user_photo(uuid, boolean) TO app_user;
