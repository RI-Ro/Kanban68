-- Скрипт предназначен для настройки разграничения доступа на уровне строк (RLS): функции-помощники,
-- функции получателей событий, включение RLS, политики и привилегии рабочей роли.
-- Модель: приложение подключается ролью app_user без BYPASSRLS; в каждой транзакции выполняется
-- SELECT set_config('app.user_id', '<uuid>', true) — параметр локален для транзакции.
-- Помощники объявлены SECURITY DEFINER и принадлежат владельцу таблиц, не находящемуся под FORCE ROW LEVEL SECURITY;
-- внутри помощников RLS не применяется, что исключает рекурсию политик. Политики обращаются к защищённым таблицам
-- только через эти функции.


SET search_path = app, public;
SET client_min_messages = warning;

-- Раздел 1: функции-помощники.

-- Функция app.current_user_id предназначена для получения текущего пользователя из параметра app.user_id;
-- при отсутствии параметра возвращает NULL, и политики не возвращают строк.
CREATE OR REPLACE FUNCTION app.current_user_id() RETURNS uuid
LANGUAGE sql STABLE
AS $$
    SELECT nullif(current_setting('app.user_id', true), '')::uuid
$$;

-- Функция app.effective_users предназначена для получения действующих личностей пользователя: собственная и замещаемых на текущую дату.
CREATE OR REPLACE FUNCTION app.effective_users(p_user uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT p_user
    UNION
    SELECT d.grantor_id FROM app.delegations d
     WHERE d.deputy_id = p_user
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.board_role предназначена для определения сильнейшей роли в проекте с учётом замещения; порядок ролей задан явно.
CREATE OR REPLACE FUNCTION app.board_role(p_board uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.role::text
      FROM app.board_members m
     WHERE m.board_id = p_board
       AND m.user_id IN (SELECT app.effective_users(p_user))
     ORDER BY CASE m.role WHEN 'owner' THEN 3 WHEN 'editor' THEN 2 ELSE 1 END DESC
     LIMIT 1
$$;

-- Функция app.can_edit_board предназначена для проверки права редактирования проекта.
CREATE OR REPLACE FUNCTION app.can_edit_board(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.board_role(p_board, p_user) IN ('owner', 'editor') $$;

-- Функция app.is_board_owner предназначена для проверки, что пользователь — владелец проекта.
CREATE OR REPLACE FUNCTION app.is_board_owner(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.board_role(p_board, p_user) = 'owner' $$;

-- Функция app.can_see_board предназначена для проверки видимости проекта: участник видит проект целиком,
-- обладатель доступа к одной задаче — только строку проекта.
CREATE OR REPLACE FUNCTION app.can_see_board(p_board uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.board_role(p_board, p_user) IS NOT NULL
        OR EXISTS (
            SELECT 1 FROM app.tasks t
              JOIN app.task_grants g ON g.task_id = t.id
             WHERE t.board_id = p_board
               AND g.user_id IN (SELECT app.effective_users(p_user)))
        OR EXISTS (
            SELECT 1 FROM app.tasks t
              JOIN app.task_assignees a ON a.task_id = t.id
             WHERE t.board_id = p_board
               AND a.user_id IN (SELECT app.effective_users(p_user)))
$$;

-- Функция app.task_access предназначена для определения уровня доступа к задаче: edit (владелец или редактор проекта)
-- либо contribute (читатель проекта, исполнитель, точечное право «участие»).
CREATE OR REPLACE FUNCTION app.task_access(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_board uuid;
    v_role  text;
    v_grant text;
BEGIN
    IF p_user IS NULL OR p_task IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT t.board_id INTO v_board FROM app.tasks t WHERE t.id = p_task;
    IF v_board IS NULL THEN
        RETURN NULL;
    END IF;

    v_role := app.board_role(v_board, p_user);
    IF v_role IN ('owner', 'editor') THEN
        RETURN 'edit';
    ELSIF v_role = 'reader' THEN
        RETURN 'contribute';
    END IF;

    IF EXISTS (SELECT 1 FROM app.task_assignees a
                WHERE a.task_id = p_task
                  AND a.user_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    SELECT g.access::text INTO v_grant
      FROM app.task_grants g
     WHERE g.task_id = p_task
       AND g.user_id IN (SELECT app.effective_users(p_user))
     LIMIT 1;

    RETURN v_grant;
END $$;

-- Функция app.can_see_task предназначена для проверки видимости задачи.
CREATE OR REPLACE FUNCTION app.can_see_task(p_task uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.task_access(p_task, p_user) IS NOT NULL $$;

-- Функция app.can_contribute_task предназначена для проверки права участия в задаче.
CREATE OR REPLACE FUNCTION app.can_contribute_task(p_task uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.task_access(p_task, p_user) IN ('edit', 'contribute') $$;

-- Функция app.can_edit_task предназначена для проверки права редактирования задачи.
CREATE OR REPLACE FUNCTION app.can_edit_task(p_task uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.task_access(p_task, p_user) = 'edit' $$;

-- Функция app.can_close_task предназначена для проверки права завершения задачи: автор или владелец проекта.
CREATE OR REPLACE FUNCTION app.can_close_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (t.created_by IN (SELECT app.effective_users(p_user))
                OR app.board_role(t.board_id, p_user) = 'owner'))
$$;

-- Функция app.is_admin предназначена для проверки прав администратора запросом к БД.
CREATE OR REPLACE FUNCTION app.is_admin(p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.users u
         WHERE u.id = p_user AND u.role = 'admin'
           AND u.deleted_at IS NULL AND u.is_active)
$$;

-- Функция app.other_admins_count предназначена для подсчёта администраторов, оставшихся после исключения указанного.
CREATE OR REPLACE FUNCTION app.other_admins_count(p_except uuid)
RETURNS integer
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT count(*)::integer FROM app.users u
     WHERE u.role = 'admin' AND u.deleted_at IS NULL AND u.is_active
       AND u.id <> p_except
$$;

-- Функция app.authenticate предназначена для входа: возвращает данные для проверки пароля, так как у app_user нет права SELECT на хеш.
CREATE OR REPLACE FUNCTION app.authenticate(p_email citext)
RETURNS TABLE (id uuid, password_hash text, is_active boolean, role text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.id, u.password_hash, u.is_active, u.role::text
      FROM app.users u
     WHERE u.email = p_email AND u.deleted_at IS NULL
$$;

-- Функция app.account_state предназначена для проверки состояния учётной записи при обновлении токена (до появления app.user_id).
CREATE OR REPLACE FUNCTION app.account_state(p_user uuid)
RETURNS TABLE (is_active boolean, deleted boolean, role text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.is_active, (u.deleted_at IS NOT NULL), u.role::text
      FROM app.users u WHERE u.id = p_user
$$;

-- Функция app.revoke_user_sessions предназначена для отзыва всех сессий пользователя.
CREATE OR REPLACE FUNCTION app.revoke_user_sessions(p_user uuid)
RETURNS integer
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    WITH killed AS (
        UPDATE app.refresh_tokens SET revoked_at = now()
         WHERE user_id = p_user AND revoked_at IS NULL
        RETURNING 1)
    SELECT count(*)::integer FROM killed
$$;

-- Раздел 2: получатели событий реального времени. Функции повторяют условия видимости политик и вычисляются в БД,
-- чтобы правила не расходились с приложением.
-- Функция app.board_watchers предназначена для получения получателей событий проекта.

CREATE OR REPLACE FUNCTION app.board_watchers(p_board uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT DISTINCT m.user_id FROM app.board_members m WHERE m.board_id = p_board
    UNION
    SELECT DISTINCT d.deputy_id
      FROM app.board_members m
      JOIN app.delegations d ON d.grantor_id = m.user_id
     WHERE m.board_id = p_board
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.task_watchers предназначена для получения получателей событий задачи.
CREATE OR REPLACE FUNCTION app.task_watchers(p_task uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH base AS (
        SELECT m.user_id FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id
         WHERE t.id = p_task
        UNION
        SELECT a.user_id FROM app.task_assignees a WHERE a.task_id = p_task
        UNION
        SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
    )
    SELECT user_id FROM base
    UNION
    SELECT d.deputy_id FROM base b
      JOIN app.delegations d ON d.grantor_id = b.user_id
     WHERE current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.task_watchers_for_board предназначена для получения получателей событий удалённой задачи; проект передаётся явно.
CREATE OR REPLACE FUNCTION app.task_watchers_for_board(p_board uuid, p_task uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.board_watchers(p_board)
    UNION
    SELECT a.user_id FROM app.task_assignees a WHERE a.task_id = p_task
    UNION
    SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
$$;

-- Функция app.notify предназначена для создания уведомления от имени сервиса: app_user не может вставлять строки другим пользователям.
CREATE OR REPLACE FUNCTION app.notify(
    p_user uuid, p_body text, p_board uuid DEFAULT NULL, p_task uuid DEFAULT NULL)
RETURNS TABLE (id uuid, created_at timestamptz)
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    INSERT INTO app.notifications (user_id, body, board_id, task_id)
    VALUES (p_user, p_body, p_board, p_task)
    RETURNING notifications.id, notifications.created_at
$$;

-- Функция app.active_delegations предназначена для получения действующих замещений всех сотрудников при узкой политике delegations_select.
CREATE OR REPLACE FUNCTION app.active_delegations()
RETURNS TABLE (id uuid, grantor_id uuid, deputy_id uuid,
               starts_at text, ends_at text, note text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT d.id, d.grantor_id, d.deputy_id,
           to_char(d.starts_at, 'YYYY-MM-DD'),
           to_char(d.ends_at, 'YYYY-MM-DD'),
           d.note
      FROM app.delegations d
     WHERE current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.notify_task_watchers предназначена для создания уведомления всем наблюдателям задачи, кроме инициатора.
CREATE OR REPLACE FUNCTION app.notify_task_watchers(
    p_task uuid, p_actor uuid, p_body text)
RETURNS SETOF uuid
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    INSERT INTO app.notifications (user_id, body, board_id, task_id)
    SELECT DISTINCT w.user_id, p_body, t.board_id, t.id
      FROM app.tasks t
      CROSS JOIN LATERAL app.task_watchers(t.id) AS w(user_id)
      JOIN app.users u ON u.id = w.user_id
     WHERE t.id = p_task
       -- Инициатор не уведомляется; проверка выполняется по всем его действующим личностям.
       AND w.user_id <> ALL (SELECT app.effective_users(p_actor))
       -- Отключённым и удалённым пользователям уведомления не создаются.
       AND u.deleted_at IS NULL AND u.is_active
    RETURNING notifications.user_id
$$;

-- Раздел 3: включение RLS.

ALTER TABLE app.users           ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.team_members    ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.refresh_tokens  ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.delegations     ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.files           ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.boards          ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.board_members   ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.columns         ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.tasks           ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.task_assignees  ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.task_grants     ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.task_steps      ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.task_links      ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.task_templates  ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.comments        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.attachments     ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.activity        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.notifications   ENABLE ROW LEVEL SECURITY;

-- Раздел 4: политики.

-- Политика users_select: справочник виден всем вошедшим, включая удалённых.
CREATE POLICY users_select ON app.users FOR SELECT
    USING (app.current_user_id() IS NOT NULL);

-- Политика users_insert: регистрация выполняется до появления app.user_id (NULL допускается).
CREATE POLICY users_insert ON app.users FOR INSERT
    WITH CHECK (
        app.current_user_id() IS NULL
        OR app.is_admin(app.current_user_id())
    );

CREATE POLICY users_update ON app.users FOR UPDATE
    USING (
        id = app.current_user_id()
        OR app.is_admin(app.current_user_id())
    )
    WITH CHECK (
        id = app.current_user_id()
        OR app.is_admin(app.current_user_id())
    );

-- Политики DELETE нет: удаление пользователя — это deleted_at и is_active = false.

-- Политика team_own: личная команда доступна владельцу.
CREATE POLICY team_own ON app.team_members FOR ALL
    USING (owner_id = app.current_user_id())
    WITH CHECK (owner_id = app.current_user_id());

-- Политика refresh_tokens_service_or_own: до появления app.user_id (вход, регистрация, обновление) либо собственные строки.
CREATE POLICY refresh_tokens_service_or_own ON app.refresh_tokens FOR ALL
    USING (app.current_user_id() IS NULL OR user_id = app.current_user_id())
    WITH CHECK (app.current_user_id() IS NULL OR user_id = app.current_user_id());

-- Политики delegations: видят обе стороны; заводит и отменяет замещаемый.
CREATE POLICY delegations_select ON app.delegations FOR SELECT
    USING (grantor_id = app.current_user_id() OR deputy_id = app.current_user_id());

CREATE POLICY delegations_write ON app.delegations FOR INSERT
    WITH CHECK (grantor_id = app.current_user_id());

CREATE POLICY delegations_delete ON app.delegations FOR DELETE
    USING (grantor_id = app.current_user_id());

-- Политика files_select: доступ к файлу определяется доступом к связанной сущности.
CREATE POLICY files_select ON app.files FOR SELECT
    USING (
        owner_id = app.current_user_id()
        OR EXISTS (
            SELECT 1 FROM app.attachments a
             WHERE a.file_id = files.id
               AND app.can_see_task(a.task_id, app.current_user_id()))
        OR EXISTS (
            SELECT 1 FROM app.boards b
             WHERE b.bg_file_id = files.id
               AND app.can_see_board(b.id, app.current_user_id()))
    );

CREATE POLICY files_insert ON app.files FOR INSERT
    WITH CHECK (owner_id = app.current_user_id());

CREATE POLICY files_delete ON app.files FOR DELETE
    USING (owner_id = app.current_user_id());

-- Политика boards_select: проекты, видимые пользователю.
CREATE POLICY boards_select ON app.boards FOR SELECT
    USING (app.can_see_board(id, app.current_user_id()));

CREATE POLICY boards_insert ON app.boards FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

CREATE POLICY boards_update ON app.boards FOR UPDATE
    USING (app.is_board_owner(id, app.current_user_id()))
    WITH CHECK (app.is_board_owner(id, app.current_user_id()));

CREATE POLICY boards_delete ON app.boards FOR DELETE
    USING (app.is_board_owner(id, app.current_user_id()));

-- Функция app.board_owner_bootstrap предназначена для добавления создателя проекта владельцем.
CREATE OR REPLACE FUNCTION app.board_owner_bootstrap() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    INSERT INTO app.board_members (board_id, user_id, role)
    VALUES (NEW.id, NEW.created_by, 'owner');
    RETURN NEW;
END $$;

-- Триггер boards_owner_bootstrap предназначен для вызова app.board_owner_bootstrap после создания проекта.
CREATE TRIGGER boards_owner_bootstrap AFTER INSERT ON app.boards
    FOR EACH ROW EXECUTE FUNCTION app.board_owner_bootstrap();

-- Политика board_members_select: участники видны тем, кто видит проект.
CREATE POLICY board_members_select ON app.board_members FOR SELECT
    USING (app.board_role(board_id, app.current_user_id()) IS NOT NULL);

CREATE POLICY board_members_write ON app.board_members FOR INSERT
    WITH CHECK (app.is_board_owner(board_id, app.current_user_id()));

CREATE POLICY board_members_update ON app.board_members FOR UPDATE
    USING (app.is_board_owner(board_id, app.current_user_id()))
    WITH CHECK (app.is_board_owner(board_id, app.current_user_id()));

-- Политика board_members_delete: владелец убирает любого, кроме себя; участник может выйти сам.
CREATE POLICY board_members_delete ON app.board_members FOR DELETE
    USING (
        (app.is_board_owner(board_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );

-- Политика columns_select: колонки видит только участник проекта.
CREATE POLICY columns_select ON app.columns FOR SELECT
    USING (app.board_role(board_id, app.current_user_id()) IS NOT NULL);

CREATE POLICY columns_write ON app.columns FOR INSERT
    WITH CHECK (app.can_edit_board(board_id, app.current_user_id()));

CREATE POLICY columns_update ON app.columns FOR UPDATE
    USING (app.can_edit_board(board_id, app.current_user_id()))
    WITH CHECK (app.can_edit_board(board_id, app.current_user_id()));

CREATE POLICY columns_delete ON app.columns FOR DELETE
    USING (app.can_edit_board(board_id, app.current_user_id()));

-- Политика tasks_select: видимость задач.
CREATE POLICY tasks_select ON app.tasks FOR SELECT
    USING (app.can_see_task(id, app.current_user_id()));

CREATE POLICY tasks_insert ON app.tasks FOR INSERT
    WITH CHECK (
        app.can_edit_board(board_id, app.current_user_id())
        AND created_by = app.current_user_id()
    );

CREATE POLICY tasks_update ON app.tasks FOR UPDATE
    USING (app.can_edit_task(id, app.current_user_id()))
    WITH CHECK (app.can_edit_board(board_id, app.current_user_id()));

CREATE POLICY tasks_delete ON app.tasks FOR DELETE
    USING (app.can_edit_task(id, app.current_user_id()));

-- Политика task_assignees_select: видимость исполнителей.
CREATE POLICY task_assignees_select ON app.task_assignees FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

CREATE POLICY task_assignees_write ON app.task_assignees FOR INSERT
    WITH CHECK (app.can_edit_task(task_id, app.current_user_id()));

-- Политика task_assignees_self_update: отметку о выполнении ставит только сам исполнитель.
CREATE POLICY task_assignees_self_update ON app.task_assignees FOR UPDATE
    USING (
        user_id = app.current_user_id()
        AND app.can_see_task(task_id, app.current_user_id())
    )
    WITH CHECK (
        user_id = app.current_user_id()
        AND app.can_see_task(task_id, app.current_user_id())
    );

CREATE POLICY task_assignees_delete ON app.task_assignees FOR DELETE
    USING (app.can_edit_task(task_id, app.current_user_id()));

-- Политика task_grants_select: видимость точечных прав.
CREATE POLICY task_grants_select ON app.task_grants FOR SELECT
    USING (
        user_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    );

CREATE POLICY task_grants_write ON app.task_grants FOR INSERT
    WITH CHECK (
        app.can_edit_task(task_id, app.current_user_id())
        AND granted_by = app.current_user_id()
    );

CREATE POLICY task_grants_update ON app.task_grants FOR UPDATE
    USING (app.can_edit_task(task_id, app.current_user_id()))
    WITH CHECK (app.can_edit_task(task_id, app.current_user_id()));

CREATE POLICY task_grants_delete ON app.task_grants FOR DELETE
    USING (app.can_edit_task(task_id, app.current_user_id()));

-- Политики task_steps: отметить пункт может участник; менять текст и состав — только редактор (проверяется в обработчиках).
CREATE POLICY task_steps_select ON app.task_steps FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

CREATE POLICY task_steps_insert ON app.task_steps FOR INSERT
    WITH CHECK (app.can_edit_task(task_id, app.current_user_id()));

CREATE POLICY task_steps_update ON app.task_steps FOR UPDATE
    USING (app.can_contribute_task(task_id, app.current_user_id()))
    WITH CHECK (app.can_contribute_task(task_id, app.current_user_id()));

CREATE POLICY task_steps_delete ON app.task_steps FOR DELETE
    USING (app.can_edit_task(task_id, app.current_user_id()));

-- Политика task_links_select: связь видна, только если видны обе задачи.
CREATE POLICY task_links_select ON app.task_links FOR SELECT
    USING (
        app.can_see_task(from_task, app.current_user_id())
        AND app.can_see_task(to_task, app.current_user_id())
    );

CREATE POLICY task_links_write ON app.task_links FOR INSERT
    WITH CHECK (
        app.can_edit_task(from_task, app.current_user_id())
        AND app.can_see_task(to_task, app.current_user_id())
        AND created_by = app.current_user_id()
    );

CREATE POLICY task_links_delete ON app.task_links FOR DELETE
    USING (app.can_edit_task(from_task, app.current_user_id()));

-- Политика task_templates_select: видимость шаблонов.
CREATE POLICY task_templates_select ON app.task_templates FOR SELECT
    USING (
        owner_id = app.current_user_id()
        OR (board_id IS NOT NULL
            AND app.board_role(board_id, app.current_user_id()) IS NOT NULL)
    );

CREATE POLICY task_templates_write ON app.task_templates FOR INSERT
    WITH CHECK (
        owner_id = app.current_user_id()
        AND (board_id IS NULL OR app.can_edit_board(board_id, app.current_user_id()))
    );

CREATE POLICY task_templates_update ON app.task_templates FOR UPDATE
    USING (owner_id = app.current_user_id())
    WITH CHECK (owner_id = app.current_user_id());

CREATE POLICY task_templates_delete ON app.task_templates FOR DELETE
    USING (
        owner_id = app.current_user_id()
        OR (board_id IS NOT NULL AND app.is_board_owner(board_id, app.current_user_id()))
    );

-- Политики comments: правка своего — в течение часа; удаление редактором задачи бессрочно.
CREATE POLICY comments_select ON app.comments FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

CREATE POLICY comments_insert ON app.comments FOR INSERT
    WITH CHECK (
        app.can_contribute_task(task_id, app.current_user_id())
        AND author_id = app.current_user_id()
    );

CREATE POLICY comments_update ON app.comments FOR UPDATE
    USING (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    )
    WITH CHECK (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    );

CREATE POLICY comments_delete ON app.comments FOR DELETE
    USING (
        (author_id = app.current_user_id() AND created_at > now() - interval '1 hour')
        OR app.can_edit_task(task_id, app.current_user_id())
    );

-- Политика attachments_select: видимость вложений.
CREATE POLICY attachments_select ON app.attachments FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

CREATE POLICY attachments_insert ON app.attachments FOR INSERT
    WITH CHECK (
        app.can_contribute_task(task_id, app.current_user_id())
        AND author_id = app.current_user_id()
    );

CREATE POLICY attachments_update ON app.attachments FOR UPDATE
    USING (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    )
    WITH CHECK (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    );

CREATE POLICY attachments_delete ON app.attachments FOR DELETE
    USING (
        (author_id = app.current_user_id() AND created_at > now() - interval '1 hour')
        OR app.can_edit_task(task_id, app.current_user_id())
    );

-- Политики activity: журнал только читается; изменение и удаление не допускаются.
CREATE POLICY activity_select ON app.activity FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

CREATE POLICY activity_insert ON app.activity FOR INSERT
    WITH CHECK (
        app.can_contribute_task(task_id, app.current_user_id())
        AND actor_id = app.current_user_id()
    );

-- Политика notifications_own: уведомления видит их получатель.
CREATE POLICY notifications_own ON app.notifications FOR SELECT
    USING (user_id = app.current_user_id());

CREATE POLICY notifications_update ON app.notifications FOR UPDATE
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());

CREATE POLICY notifications_delete ON app.notifications FOR DELETE
    USING (user_id = app.current_user_id());

-- Раздел 5: привилегии рабочей роли.

GRANT USAGE ON SCHEMA app TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA app TO app_user;

-- Хеш пароля недоступен для чтения; доступ только через app.authenticate.
REVOKE SELECT ON app.users FROM app_user;
GRANT SELECT (id, email, full_name, position, phone, avatar_color,
              role, is_active, deleted_at, created_at, updated_at)
    ON app.users TO app_user;
GRANT UPDATE (full_name, position, phone, avatar_color, password_hash,
              email, is_active, deleted_at, role)
    ON app.users TO app_user;

-- Уведомления создаются только через app.notify.
REVOKE INSERT ON app.notifications FROM app_user;

-- В task_assignees рабочая роль изменяет только отметку о выполнении.
REVOKE UPDATE ON app.task_assignees FROM app_user;
GRANT UPDATE (completed_at) ON app.task_assignees TO app_user;

-- Связи задач не редактируются: только создаются и удаляются.
REVOKE UPDATE ON app.task_links FROM app_user;

GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA app TO app_user;

ALTER DEFAULT PRIVILEGES IN SCHEMA app
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app_user;
