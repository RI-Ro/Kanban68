-- Скрипт предназначен для создания ролей базы данных: владельца схемы (app_owner) и рабочей роли приложения (app_user).
-- Выполняется суперпользователем один раз на кластер: sudo -u postgres psql -d kanban -f 0001_roles.sql
-- Скрипт идемпотентен: роли общие для всех баз кластера, повторное применение безопасно.


-- Блок создаёт роль app_owner — владельца схемы, таблиц и SECURITY DEFINER-функций.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_owner') THEN
        CREATE ROLE app_owner LOGIN PASSWORD 'change_me_owner';
    END IF;
END $$;

-- Блок создаёт роль app_user — рабочую роль приложения без BYPASSRLS и SUPERUSER: разграничение доступа
-- держится на политиках RLS. Приложение проверяет роль при запуске (internal/database/db.go).
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_user') THEN
        CREATE ROLE app_user LOGIN PASSWORD 'change_me_user';
    END IF;
END $$;

ALTER ROLE app_owner NOBYPASSRLS;
ALTER ROLE app_user  NOBYPASSRLS NOSUPERUSER NOCREATEDB NOCREATEROLE;

-- Право подключения к базе выдаётся отдельно после её создания:
-- GRANT CONNECT ON DATABASE kanban TO app_user, app_owner;

-- Схема public закрыта; приложение работает со схемой app.
REVOKE ALL ON SCHEMA public FROM PUBLIC;
