-- Скрипт предназначен для хранения истории изменений этапов диаграммы (аналог app.activity для задач).
--
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Таблица app.chart_activity предназначена для хранения записей истории диаграммы.
CREATE TABLE IF NOT EXISTS app.chart_activity (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id    uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    -- Автор может быть удалён: запись истории сохраняется.
    actor_id   uuid REFERENCES app.users(id) ON DELETE SET NULL,
    body       text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chart_activity_item_idx
    ON app.chart_activity (item_id, created_at DESC);

ALTER TABLE app.chart_activity ENABLE ROW LEVEL SECURITY;

-- Политика chart_activity_select: историю читают все участники диаграммы.
DROP POLICY IF EXISTS chart_activity_select ON app.chart_activity;
CREATE POLICY chart_activity_select ON app.chart_activity FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

-- Политика chart_activity_insert: запись добавляет участник диаграммы только от своего имени.
DROP POLICY IF EXISTS chart_activity_insert ON app.chart_activity;
CREATE POLICY chart_activity_insert ON app.chart_activity FOR INSERT
    WITH CHECK (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id())
                AND actor_id = app.current_user_id());

-- Права на изменение и удаление не выдаются, политик UPDATE и DELETE нет: записи истории неизменяемы.

GRANT SELECT, INSERT ON app.chart_activity TO app_user;

