-- Скрипт предназначен для расширения досок и диаграмм: размер полотна, цвет фона и прозрачность фигур; собственные значки;
-- обсуждение и файлы этапов диаграммы; запрет замкнутых цепочек связей; ссылки в уведомлениях на диаграммы и доски.
--
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Раздел 1: размер и фон доски. Размер хранится в точках холста, а не в пикселях экрана, поэтому
-- доска одинакова на любом мониторе.

ALTER TABLE app.whiteboards
    ADD COLUMN IF NOT EXISTS width    integer NOT NULL DEFAULT 3840,
    ADD COLUMN IF NOT EXISTS height   integer NOT NULL DEFAULT 2160,
    -- Цвет фона: пустое значение означает цвет фона приложения (учитывается тема).
    ADD COLUMN IF NOT EXISTS bg_color text NOT NULL DEFAULT '';

-- Допустимые пределы размера полотна.
ALTER TABLE app.whiteboards DROP CONSTRAINT IF EXISTS whiteboards_size_ck;
ALTER TABLE app.whiteboards ADD CONSTRAINT whiteboards_size_ck
    CHECK (width BETWEEN 640 AND 16384 AND height BETWEEN 480 AND 16384);

-- Прозрачность фигуры хранится отдельной колонкой наряду с геометрией.
ALTER TABLE app.whiteboard_shapes
    ADD COLUMN IF NOT EXISTS opacity double precision NOT NULL DEFAULT 1;

ALTER TABLE app.whiteboard_shapes DROP CONSTRAINT IF EXISTS whiteboard_shapes_opacity_ck;
ALTER TABLE app.whiteboard_shapes ADD CONSTRAINT whiteboard_shapes_opacity_ck
    CHECK (opacity BETWEEN 0 AND 1);

-- Вид фигуры «значок»: картинка из набора или загруженная участником.
ALTER TABLE app.whiteboard_shapes DROP CONSTRAINT IF EXISTS whiteboard_shapes_kind_check;
ALTER TABLE app.whiteboard_shapes ADD CONSTRAINT whiteboard_shapes_kind_check
    CHECK (kind IN ('note', 'rect', 'ellipse', 'diamond', 'triangle', 'text',
                    'line', 'arrow', 'draw', 'image', 'frame', 'icon'));

-- Раздел 2: собственные значки. Встроенный набор значков находится в коде клиента.
-- Таблица app.board_icons предназначена для хранения значков, загруженных участниками.

CREATE TABLE IF NOT EXISTS app.board_icons (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title      text NOT NULL CHECK (length(btrim(title)) > 0),
    file_id    uuid NOT NULL REFERENCES app.files(id) ON DELETE RESTRICT,
    created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS board_icons_created_idx ON app.board_icons (created_at DESC);

ALTER TABLE app.board_icons ENABLE ROW LEVEL SECURITY;

-- Политика board_icons_select: значки видны всем вошедшим пользователям.
DROP POLICY IF EXISTS board_icons_select ON app.board_icons;
CREATE POLICY board_icons_select ON app.board_icons FOR SELECT
    USING (app.current_user_id() IS NOT NULL);

DROP POLICY IF EXISTS board_icons_insert ON app.board_icons;
CREATE POLICY board_icons_insert ON app.board_icons FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

-- Политика board_icons_delete: значок удаляет загрузивший его пользователь или администратор.
DROP POLICY IF EXISTS board_icons_delete ON app.board_icons;
CREATE POLICY board_icons_delete ON app.board_icons FOR DELETE
    USING (created_by = app.current_user_id() OR app.is_admin(app.current_user_id()));

-- Политика files_select_board_icons: файл значка виден всем вошедшим пользователям.
DROP POLICY IF EXISTS files_select_board_icons ON app.files;
CREATE POLICY files_select_board_icons ON app.files FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.board_icons i WHERE i.file_id = files.id)
           AND app.current_user_id() IS NOT NULL);

-- Раздел 3: обсуждение и файлы этапа диаграммы. Отдельные таблицы, так как comments и attachments привязаны к задаче.
-- Таблица app.chart_comments предназначена для хранения комментариев к записям диаграммы.

CREATE TABLE IF NOT EXISTS app.chart_comments (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id    uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    author_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    body       text NOT NULL CHECK (length(btrim(body)) > 0),
    edited_at  timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chart_comments_item_idx ON app.chart_comments (item_id, created_at);

-- Таблица app.chart_attachments предназначена для хранения файлов, прикреплённых к записям диаграммы.
CREATE TABLE IF NOT EXISTS app.chart_attachments (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id    uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    file_id    uuid NOT NULL REFERENCES app.files(id) ON DELETE RESTRICT,
    author_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    title      text NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chart_attachments_item_idx ON app.chart_attachments (item_id, created_at);

ALTER TABLE app.chart_comments    ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_attachments ENABLE ROW LEVEL SECURITY;

-- Политики chart_comments: комментировать может любой участник диаграммы, изменять и удалять — только автор комментария.
DROP POLICY IF EXISTS chart_comments_select ON app.chart_comments;
CREATE POLICY chart_comments_select ON app.chart_comments FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS chart_comments_insert ON app.chart_comments;
CREATE POLICY chart_comments_insert ON app.chart_comments FOR INSERT
    WITH CHECK (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id())
                AND author_id = app.current_user_id());

DROP POLICY IF EXISTS chart_comments_update ON app.chart_comments;
CREATE POLICY chart_comments_update ON app.chart_comments FOR UPDATE
    USING (author_id = app.current_user_id())
    WITH CHECK (author_id = app.current_user_id());

DROP POLICY IF EXISTS chart_comments_delete ON app.chart_comments;
CREATE POLICY chart_comments_delete ON app.chart_comments FOR DELETE
    USING (author_id = app.current_user_id()
           OR app.is_chart_owner(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS chart_attachments_select ON app.chart_attachments;
CREATE POLICY chart_attachments_select ON app.chart_attachments FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS chart_attachments_insert ON app.chart_attachments;
CREATE POLICY chart_attachments_insert ON app.chart_attachments FOR INSERT
    WITH CHECK (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id())
                AND author_id = app.current_user_id());

DROP POLICY IF EXISTS chart_attachments_delete ON app.chart_attachments;
CREATE POLICY chart_attachments_delete ON app.chart_attachments FOR DELETE
    USING (author_id = app.current_user_id()
           OR app.is_chart_owner(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS files_select_chart_attachments ON app.files;
CREATE POLICY files_select_chart_attachments ON app.files FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM app.chart_attachments a
         WHERE a.file_id = files.id
           AND app.can_see_chart(app.chart_of_item(a.item_id), app.current_user_id())));

-- Раздел 4: запрет замкнутых цепочек связей.
-- Функция app.chart_link_would_cycle предназначена для проверки, что новая связь замкнёт цепочку (путь из следующего этапа в текущий).

CREATE OR REPLACE FUNCTION app.chart_link_would_cycle(p_from uuid, p_to uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    -- Проверка выполняется обходом в ширину по существующим связям.
    WITH RECURSIVE reach(id) AS (
        SELECT p_to
        UNION
        SELECT l.to_item FROM app.chart_links l JOIN reach r ON l.from_item = r.id
    )
    SELECT p_from = p_to OR EXISTS (SELECT 1 FROM reach WHERE id = p_from)
$$;

-- Функция app.chart_links_no_cycle предназначена для отклонения связи, замыкающей цепочку.
CREATE OR REPLACE FUNCTION app.chart_links_no_cycle() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    IF app.chart_link_would_cycle(NEW.from_item, NEW.to_item) THEN
        RAISE EXCEPTION 'Связь замкнула бы цепочку этапов'
            USING ERRCODE = 'check_violation';
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS chart_links_no_cycle ON app.chart_links;
-- Триггер chart_links_no_cycle предназначен для вызова app.chart_links_no_cycle при вставке и изменении app.chart_links.
CREATE TRIGGER chart_links_no_cycle BEFORE INSERT OR UPDATE ON app.chart_links
    FOR EACH ROW EXECUTE FUNCTION app.chart_links_no_cycle();

-- Раздел 5: уведомления о диаграммах и досках. В уведомление добавляются поля ссылки на объект.

ALTER TABLE app.notifications
    ADD COLUMN IF NOT EXISTS chart_id uuid REFERENCES app.charts(id)      ON DELETE CASCADE,
    ADD COLUMN IF NOT EXISTS wb_id    uuid REFERENCES app.whiteboards(id) ON DELETE CASCADE;

-- Функция app.notify_obj предназначена для создания уведомления со ссылкой на диаграмму или доску.
CREATE OR REPLACE FUNCTION app.notify_obj(
    p_user uuid, p_body text, p_category text,
    p_chart uuid DEFAULT NULL, p_wb uuid DEFAULT NULL)
RETURNS TABLE (id uuid, created_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_enabled boolean;
BEGIN
    SELECT enabled INTO v_enabled
      FROM app.notification_prefs
     WHERE user_id = p_user AND category = p_category;
    IF v_enabled IS NOT NULL AND v_enabled = false THEN
        RETURN;
    END IF;
    RETURN QUERY
        INSERT INTO app.notifications (user_id, body, category, chart_id, wb_id)
        VALUES (p_user, p_body, p_category, p_chart, p_wb)
        RETURNING notifications.id, notifications.created_at;
END $$;

GRANT SELECT, INSERT, UPDATE, DELETE ON app.board_icons       TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_comments    TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_attachments TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_link_would_cycle(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.notify_obj(uuid, text, text, uuid, uuid) TO app_user;

