-- Миграция 0039 предназначена для входа по Kerberos и сверки с LDAP: у пользователя появляются логин (principal вида
-- ii-ivanov@DOMAIN1.LOCAL) и источник сведений (local — в базе, иначе идентификатор LDAP-сервера из конфигурации).
-- Логины ii-ivanov@DOMAIN1.LOCAL и ii-ivanov@DOMAIN2.LOCAL — разные пользователи; регистр не различается.
-- Применение: psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0039_user_login_source.sql

ALTER TABLE app.users ADD COLUMN IF NOT EXISTS login  text NOT NULL DEFAULT '';
ALTER TABLE app.users ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'local';

-- Логин уникален среди неудалённых пользователей; пустой логин (вход только по паролю) не учитывается.
CREATE UNIQUE INDEX IF NOT EXISTS users_login_uq ON app.users (lower(login))
    WHERE login <> '' AND deleted_at IS NULL;

GRANT SELECT (login, source) ON app.users TO app_user;
GRANT UPDATE (login, source) ON app.users TO app_user;

-- Функция app.user_by_login предназначена для поиска пользователя по логину при входе по Kerberos (до появления app.user_id).
CREATE OR REPLACE FUNCTION app.user_by_login(p_login text)
RETURNS TABLE (id uuid, is_active boolean, role text, source text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.id, u.is_active, u.role::text, u.source
      FROM app.users u
     WHERE lower(u.login) = lower(p_login) AND u.login <> '' AND u.deleted_at IS NULL
$$;

-- Функция app.user_source предназначена для получения логина и источника сведений пользователя при входе по паролю.
CREATE OR REPLACE FUNCTION app.user_source(p_user uuid)
RETURNS TABLE (login text, source text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.login, u.source FROM app.users u WHERE u.id = p_user
$$;

-- Функция app.sync_user_profile предназначена для актуализации сведений из LDAP при входе. Пустые значения не затирают
-- имеющиеся; почта меняется, только если она не занята другим пользователем. Роль и активность не затрагиваются.
CREATE OR REPLACE FUNCTION app.sync_user_profile(p_user uuid, p_full_name text, p_position text, p_phone text, p_email text)
RETURNS void
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    UPDATE app.users u SET
        full_name = COALESCE(NULLIF(btrim(p_full_name), ''), u.full_name),
        position  = COALESCE(NULLIF(btrim(p_position), ''), u.position),
        phone     = COALESCE(NULLIF(btrim(p_phone), ''), u.phone),
        email     = CASE WHEN NULLIF(btrim(p_email), '') IS NOT NULL
                          AND NOT EXISTS (SELECT 1 FROM app.users o WHERE o.email = btrim(p_email) AND o.id <> u.id)
                         THEN btrim(p_email) ELSE u.email END,
        updated_at = now()
     WHERE u.id = p_user
$$;

REVOKE EXECUTE ON FUNCTION app.user_by_login(text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.user_source(uuid) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.sync_user_profile(uuid, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.user_by_login(text) TO app_user;
GRANT EXECUTE ON FUNCTION app.user_source(uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.sync_user_profile(uuid, text, text, text, text) TO app_user;
