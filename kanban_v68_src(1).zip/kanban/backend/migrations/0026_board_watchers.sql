-- Скрипт предназначен для рассылки событий проекта всем, кому он виден: функция app.board_watchers приведена в соответствие
-- с условиями app.can_see_board (участники, автор, исполнитель, исполнитель пункта чек-листа, получатель точечного доступа)
-- с учётом замещения в обе стороны (effective_users). Сверка двух функций — раздел 9 в scripts/rls_test.sql.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0026_board_watchers.sql
--
-- Выполняется от app_owner после 0025_seen_on_read.sql, идемпотентен.


SET search_path = app, public;

-- Функция app.board_watchers предназначена для получения получателей событий проекта.
CREATE OR REPLACE FUNCTION app.board_watchers(p_board uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH direct AS (
        SELECT m.user_id FROM app.board_members m WHERE m.board_id = p_board
        UNION
        SELECT t.created_by FROM app.tasks t WHERE t.board_id = p_board
        UNION
        SELECT a.user_id FROM app.task_assignees a
          JOIN app.tasks t ON t.id = a.task_id WHERE t.board_id = p_board
        UNION
        SELECT g.user_id FROM app.task_grants g
          JOIN app.tasks t ON t.id = g.task_id WHERE t.board_id = p_board
        UNION
        SELECT s.assignee_id FROM app.task_steps s
          JOIN app.tasks t ON t.id = s.task_id
         WHERE t.board_id = p_board AND s.assignee_id IS NOT NULL
    )
    SELECT d.user_id FROM direct d
    UNION
    -- Заместитель получает события замещаемого (effective_users).
    SELECT dl.deputy_id FROM app.delegations dl
      JOIN direct d ON d.user_id = dl.grantor_id
     WHERE current_date BETWEEN dl.starts_at AND dl.ends_at
$$;
