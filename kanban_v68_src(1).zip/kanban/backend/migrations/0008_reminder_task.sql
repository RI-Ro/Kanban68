-- Скрипт предназначен для необязательной привязки напоминания к задаче: столбец, функция выдачи сработавших
-- напоминаний с задачей и функция получения названия задачи с проверкой видимости.


SET search_path = app, public;

ALTER TABLE app.reminders
    ADD COLUMN IF NOT EXISTS task_id uuid REFERENCES app.tasks(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS reminders_task_idx ON app.reminders (task_id)
    WHERE task_id IS NOT NULL;

-- Пересоздание app.due_reminders: функция возвращает задачу; DROP необходим при изменении набора столбцов результата.
DROP FUNCTION IF EXISTS app.due_reminders();

-- Функция app.due_reminders предназначена для получения сработавших напоминаний вместе с привязанной задачей.
CREATE FUNCTION app.due_reminders()
RETURNS TABLE (id uuid, user_id uuid, title text, recur_freq text,
               recur_interval int, recur_weekdays int[], task_id uuid)
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT id, user_id, title, recur_freq, recur_interval, recur_weekdays, task_id
      FROM app.reminders
     WHERE active AND remind_at <= now()
       AND (last_fired IS NULL OR last_fired < remind_at)
$$;

GRANT EXECUTE ON FUNCTION app.due_reminders() TO app_user;


-- Функция app.task_title_visible предназначена для получения названия задачи для списка напоминаний;
-- SECURITY DEFINER с проверкой видимости: недоступной задачи название не раскрывается.
CREATE OR REPLACE FUNCTION app.task_title_visible(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT t.title FROM app.tasks t
     WHERE t.id = p_task AND app.can_see_task(t.id, p_user)
$$;

GRANT EXECUTE ON FUNCTION app.task_title_visible(uuid, uuid) TO app_user;
