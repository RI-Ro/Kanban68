-- Скрипт предназначен для защиты пересланных сообщений от правки: текст и вложение сообщения с пометкой «Переслано от …»
-- изменить нельзя никому, включая переславшего (иначе можно приписать автору слова, которых он не писал).
-- Удаление сообщения (deleted_at) разрешено.
--
-- Выполняется от app_owner после 0037_system_counts_repair.sql, идемпотентен.

CREATE OR REPLACE FUNCTION app.chat_forwarded_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF OLD.fwd_author_id IS NOT NULL
       AND (NEW.body IS DISTINCT FROM OLD.body OR NEW.file_id IS DISTINCT FROM OLD.file_id)
       AND NEW.deleted_at IS NOT DISTINCT FROM OLD.deleted_at THEN
        RAISE EXCEPTION 'Пересланное сообщение нельзя изменить' USING ERRCODE = 'P0001';
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS chat_forwarded_guard ON app.chat_messages;
CREATE TRIGGER chat_forwarded_guard BEFORE UPDATE ON app.chat_messages
    FOR EACH ROW EXECUTE FUNCTION app.chat_forwarded_guard();
