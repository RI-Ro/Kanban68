-- Скрипт предназначен для панели «Доступы»: (1) матрица «все мои проекты, диаграммы и доски и статус доступа выбранного
-- пользователя» с выдачей и снятием доступа к диаграммам и доскам по образцу проектов; (2) обзор доступов ограничен
-- объектами, где просматривающий владелец или редактор (исполнитель — для задач), без исключения для администратора.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0030_access_matrix.sql
--
-- Выполняется от app_owner после 0029_reminder_alerts.sql, идемпотентен.

SET search_path = app, public;

-- Функция app.access_matrix предназначена для выдачи всех объектов текущего пользователя, доступом к которым он вправе
-- управлять (проекты, диаграммы, доски: он владелец или редактор), и уровня доступа выбранного пользователя (NULL — доступа нет).
CREATE OR REPLACE FUNCTION app.access_matrix(p_target uuid)
RETURNS TABLE (kind text, object_id uuid, title text, level text, manageable boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE v_me uuid := app.current_user_id();
BEGIN
    IF v_me IS NULL THEN RETURN; END IF;

    RETURN QUERY
    SELECT 'board'::text, b.id, b.title, m.role::text,
           (m.role IS NULL OR m.role <> 'owner')
      FROM app.boards b
      LEFT JOIN app.board_members m ON m.board_id = b.id AND m.user_id = p_target
     WHERE NOT b.archived AND app.can_edit_board(b.id, v_me)
     ORDER BY b.title;

    RETURN QUERY
    SELECT 'chart'::text, c.id, c.title, m.role::text,
           (m.role IS NULL OR m.role <> 'owner')
      FROM app.charts c
      LEFT JOIN app.chart_members m ON m.chart_id = c.id AND m.user_id = p_target
     WHERE app.can_edit_chart(c.id, v_me)
     ORDER BY c.title;

    RETURN QUERY
    SELECT 'whiteboard'::text, w.id, w.title, m.role::text,
           (m.role IS NULL OR m.role <> 'owner')
      FROM app.whiteboards w
      LEFT JOIN app.whiteboard_members m ON m.board_id = w.id AND m.user_id = p_target
     WHERE app.can_edit_wb(w.id, v_me)
     ORDER BY w.title;
END $$;

-- Функция app.set_object_access предназначена для выдачи или смены роли в диаграмме или доске (p_kind: chart | whiteboard).
-- Выдавать вправе владелец и редактор; роль владельца не меняется. Возвращает прежнюю роль.
CREATE OR REPLACE FUNCTION app.set_object_access(p_kind text, p_object uuid, p_user uuid, p_role text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_me uuid := app.current_user_id(); v_prev text;
BEGIN
    IF p_role NOT IN ('editor', 'reader') THEN
        RAISE EXCEPTION 'Роль может быть только «редактор» или «исполнитель»' USING ERRCODE = '22023';
    END IF;
    IF app.is_live_user(p_user) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;
    IF p_kind = 'chart' THEN
        IF app.can_edit_chart(p_object, v_me) IS NOT TRUE THEN
            RAISE EXCEPTION 'Нет права управлять доступом к этой диаграмме' USING ERRCODE = '42501';
        END IF;
        SELECT role::text INTO v_prev FROM app.chart_members WHERE chart_id = p_object AND user_id = p_user;
        IF v_prev = 'owner' THEN
            RAISE EXCEPTION 'Роль владельца меняется передачей владения' USING ERRCODE = '42501';
        END IF;
        INSERT INTO app.chart_members (chart_id, user_id, role) VALUES (p_object, p_user, p_role::app.board_role)
        ON CONFLICT (chart_id, user_id) DO UPDATE SET role = EXCLUDED.role;
    ELSIF p_kind = 'whiteboard' THEN
        IF app.can_edit_wb(p_object, v_me) IS NOT TRUE THEN
            RAISE EXCEPTION 'Нет права управлять доступом к этой доске' USING ERRCODE = '42501';
        END IF;
        SELECT role::text INTO v_prev FROM app.whiteboard_members WHERE board_id = p_object AND user_id = p_user;
        IF v_prev = 'owner' THEN
            RAISE EXCEPTION 'Роль владельца меняется передачей владения' USING ERRCODE = '42501';
        END IF;
        INSERT INTO app.whiteboard_members (board_id, user_id, role) VALUES (p_object, p_user, p_role::app.board_role)
        ON CONFLICT (board_id, user_id) DO UPDATE SET role = EXCLUDED.role;
    ELSE
        RAISE EXCEPTION 'Неизвестный тип объекта' USING ERRCODE = '22023';
    END IF;
    RETURN v_prev;
END $$;

-- Функция app.revoke_object_access предназначена для снятия доступа к диаграмме или доске; владельца снять нельзя.
CREATE OR REPLACE FUNCTION app.revoke_object_access(p_kind text, p_object uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_me uuid := app.current_user_id(); n int;
BEGIN
    IF p_kind = 'chart' THEN
        IF app.can_edit_chart(p_object, v_me) IS NOT TRUE THEN
            RAISE EXCEPTION 'Нет права управлять доступом к этой диаграмме' USING ERRCODE = '42501';
        END IF;
        DELETE FROM app.chart_members WHERE chart_id = p_object AND user_id = p_user AND role <> 'owner';
    ELSIF p_kind = 'whiteboard' THEN
        IF app.can_edit_wb(p_object, v_me) IS NOT TRUE THEN
            RAISE EXCEPTION 'Нет права управлять доступом к этой доске' USING ERRCODE = '42501';
        END IF;
        DELETE FROM app.whiteboard_members WHERE board_id = p_object AND user_id = p_user AND role <> 'owner';
    ELSE
        RAISE EXCEPTION 'Неизвестный тип объекта' USING ERRCODE = '22023';
    END IF;
    GET DIAGNOSTICS n = ROW_COUNT;
    RETURN n > 0;
END $$;

-- Функция app.access_overview предназначена для обзора доступов выбранного пользователя только в объектах просматривающего:
-- проекты и диаграммы/доски, где он владелец или редактор, задачи, где он редактор или исполнитель. Исключения для
-- администратора нет: чужие проекты в панели не раскрываются. Замещения показываются администратору.
CREATE OR REPLACE FUNCTION app.access_overview(p_target uuid)
RETURNS TABLE (kind text, object_id uuid, title text, board_id uuid, board_title text, level text, manageable boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE v_me uuid := app.current_user_id(); v_admin boolean;
BEGIN
    IF v_me IS NULL THEN RETURN; END IF;
    v_admin := app.is_admin(v_me);

    RETURN QUERY
    SELECT 'board'::text, b.id, b.title, b.id, b.title, m.role::text,
           app.can_manage_board_access(b.id, v_me) AND (m.role <> 'owner' OR v_admin)
      FROM app.board_members m JOIN app.boards b ON b.id = m.board_id
     WHERE m.user_id = p_target AND app.can_edit_board(b.id, v_me);

    RETURN QUERY
    SELECT 'task_grant'::text, t.id, t.title, b.id, b.title, g.access::text,
           app.can_manage_task_access(t.id, v_me)
      FROM app.task_grants g
      JOIN app.tasks t  ON t.id = g.task_id
      JOIN app.boards b ON b.id = t.board_id
     WHERE g.user_id = p_target AND app.can_edit_task(t.id, v_me);

    RETURN QUERY
    SELECT 'task_assignee'::text, t.id, t.title, b.id, b.title, NULL::text, false
      FROM app.task_assignees a
      JOIN app.tasks t  ON t.id = a.task_id
      JOIN app.boards b ON b.id = t.board_id
     WHERE a.user_id = p_target AND NOT t.archived AND t.completed_at IS NULL
       AND app.can_edit_task(t.id, v_me);

    RETURN QUERY
    SELECT 'chart'::text, c.id, c.title, NULL::uuid, NULL::text, m.role::text, (m.role <> 'owner')
      FROM app.chart_members m JOIN app.charts c ON c.id = m.chart_id
     WHERE m.user_id = p_target AND app.can_edit_chart(c.id, v_me);

    RETURN QUERY
    SELECT 'whiteboard'::text, w.id, w.title, NULL::uuid, NULL::text, m.role::text, (m.role <> 'owner')
      FROM app.whiteboard_members m JOIN app.whiteboards w ON w.id = m.board_id
     WHERE m.user_id = p_target AND app.can_edit_wb(w.id, v_me);

    IF NOT v_admin THEN RETURN; END IF;

    RETURN QUERY
    SELECT 'delegation_to'::text, d.id, u.full_name, NULL::uuid, NULL::text,
           to_char(d.starts_at, 'YYYY-MM-DD') || '…' || to_char(d.ends_at, 'YYYY-MM-DD'), false
      FROM app.delegations d JOIN app.users u ON u.id = d.deputy_id
     WHERE d.grantor_id = p_target AND d.ends_at >= current_date;

    RETURN QUERY
    SELECT 'delegation_from'::text, d.id, u.full_name, NULL::uuid, NULL::text,
           to_char(d.starts_at, 'YYYY-MM-DD') || '…' || to_char(d.ends_at, 'YYYY-MM-DD'), false
      FROM app.delegations d JOIN app.users u ON u.id = d.grantor_id
     WHERE d.deputy_id = p_target AND d.ends_at >= current_date;
END $$;

GRANT EXECUTE ON FUNCTION app.access_matrix(uuid)                      TO app_user;
GRANT EXECUTE ON FUNCTION app.set_object_access(text, uuid, uuid, text) TO app_user;
GRANT EXECUTE ON FUNCTION app.revoke_object_access(text, uuid, uuid)   TO app_user;
GRANT EXECUTE ON FUNCTION app.access_overview(uuid)                    TO app_user;
