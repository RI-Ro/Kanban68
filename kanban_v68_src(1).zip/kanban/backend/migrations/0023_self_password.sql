-- Скрипт предназначен для самостоятельной смены пароля пользователем: функция app.my_password_hash возвращает хеш
-- пароля текущего пользователя для проверки текущего пароля. Прямой SELECT на app.users.password_hash отозван в 0003_rls.sql.
-- Функция не принимает параметров и не может вернуть хеш другого пользователя (в отличие от app.authenticate(email)).
--
-- Выполняется от app_owner, идемпотентен (CREATE OR REPLACE).


-- Функция app.my_password_hash предназначена для получения хеша пароля текущего пользователя.
CREATE OR REPLACE FUNCTION app.my_password_hash()
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.password_hash
      FROM app.users u
     WHERE u.id = app.current_user_id()
       AND u.deleted_at IS NULL
       AND u.is_active
$$;

COMMENT ON FUNCTION app.my_password_hash() IS
    'Хеш пароля того, кто выполняет запрос. Нужен для подтверждения '
    'текущего пароля при самостоятельной смене. Чужой хеш отдать не может.';

-- Право вызова отзывается у PUBLIC и выдаётся адресно.
REVOKE EXECUTE ON FUNCTION app.my_password_hash() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.my_password_hash() TO app_user;
