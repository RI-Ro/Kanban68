-- Миграция 0042 предназначена для группового чата задачи: чат с названием задачи и её участниками.
ALTER TABLE app.chats ADD COLUMN IF NOT EXISTS task_id uuid REFERENCES app.tasks(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS chats_task_idx ON app.chats (task_id) WHERE task_id IS NOT NULL;

-- Функция app.task_chat предназначена для получения чата задачи: создаёт групповой чат с названием задачи и участниками
-- (исполнители, автор, пользователи с точечным доступом), а если чат уже есть, добавляет в него вызвавшего.
-- Возвращает идентификатор чата и признак «создан сейчас»; доступ к задаче проверяется (нужно хотя бы право участия).
CREATE OR REPLACE FUNCTION app.task_chat(p_task uuid, p_user uuid)
RETURNS TABLE (chat_id uuid, created boolean, members uuid[])
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_id    uuid;
    v_title text;
    v_list  uuid[];
BEGIN
    IF app.task_access(p_task, p_user) IS NULL THEN
        RAISE EXCEPTION 'forbidden';
    END IF;

    SELECT c.id INTO v_id FROM app.chats c WHERE c.task_id = p_task ORDER BY c.created_at LIMIT 1;
    IF v_id IS NOT NULL THEN
        INSERT INTO app.chat_members (chat_id, user_id) VALUES (v_id, p_user) ON CONFLICT DO NOTHING;
        RETURN QUERY SELECT v_id, false, ARRAY(SELECT m.user_id FROM app.chat_members m WHERE m.chat_id = v_id);
        RETURN;
    END IF;

    SELECT t.title INTO v_title FROM app.tasks t WHERE t.id = p_task;
    SELECT ARRAY(
        SELECT DISTINCT u.id FROM (
            SELECT a.user_id AS id FROM app.task_assignees a WHERE a.task_id = p_task
            UNION SELECT t.created_by FROM app.tasks t WHERE t.id = p_task
            UNION SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
        ) u
        JOIN app.users x ON x.id = u.id AND x.deleted_at IS NULL
        WHERE u.id IS NOT NULL AND u.id <> p_user)
      INTO v_list;

    v_id := app.create_group_chat(p_user, left(v_title, 120), v_list);
    UPDATE app.chats SET task_id = p_task WHERE id = v_id;
    RETURN QUERY SELECT v_id, true, ARRAY(SELECT m.user_id FROM app.chat_members m WHERE m.chat_id = v_id);
END $$;

GRANT EXECUTE ON FUNCTION app.task_chat(uuid, uuid) TO app_user;
