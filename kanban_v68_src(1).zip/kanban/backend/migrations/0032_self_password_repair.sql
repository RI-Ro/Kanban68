-- Скрипт предназначен для восстановления функции app.my_password_hash (миграция 0023) в базах, где она не была применена:
-- при самостоятельной смене пароля сервер получал ошибку «function app.my_password_hash does not exist».
-- Функция возвращает хеш пароля только текущего пользователя и нужна для проверки текущего пароля.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0032_self_password_repair.sql
--
-- Выполняется от app_owner (или суперпользователем после SET ROLE app_owner), идемпотентен.

CREATE OR REPLACE FUNCTION app.my_password_hash()
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.password_hash
      FROM app.users u
     WHERE u.id = app.current_user_id()
       AND u.deleted_at IS NULL
       AND u.is_active
$$;

REVOKE EXECUTE ON FUNCTION app.my_password_hash() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.my_password_hash() TO app_user;
