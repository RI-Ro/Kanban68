-- Скрипт предназначен для панели «Доступы», онбординга и офбординга: просмотр доступа пользователя, точечная выдача и снятие
-- доступа к проектам и задачам, копирование доступа коллеги, удаление учётной записи с полным снятием доступа и передачей дел.
--
-- Все функции, изменяющие доступ, выполняются в режиме SECURITY DEFINER с явной проверкой прав вызывающего:
-- администратор не получает доступ к содержимому проектов через RLS, а панель должна позволять ему управлять доступом.
-- Проверки повторяют политики 0007 (владелец и редактор управляют составом, строка владельца неизменна),
-- политику task_grants (редактор задачи) и добавляют ветку «администратор».
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0027_access_panel.sql
--
-- Выполняется от app_owner после 0026_board_watchers.sql, идемпотентен.


SET search_path = app, public;

-- Раздел 1: замещение не действует после удаления замещаемого.
-- Функция app.effective_users предназначена для получения пользователей, от имени которых действует p_user (он сам и замещаемые).
-- Удалённые (deleted_at) замещаемые исключаются; заблокированные (is_active = false) не исключаются,
-- так как блокировка может быть временной (замещение на время отпуска).
CREATE OR REPLACE FUNCTION app.effective_users(p_user uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT p_user
    UNION
    SELECT d.grantor_id FROM app.delegations d
      JOIN app.users g ON g.id = d.grantor_id
     WHERE d.deputy_id = p_user
       AND g.deleted_at IS NULL
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Раздел 2: проверка прав управления доступом.

-- Функции app.can_edit_board и app.can_edit_task возвращают NULL, а не false, если роль не найдена. В RLS это отказ,
-- но в PL/pgSQL условие «IF NOT NULL» не срабатывает, поэтому используется COALESCE, а проверки записаны как «IS NOT TRUE».
--
-- Функция app.can_manage_board_access предназначена для проверки права p_actor выдавать и снимать доступ к проекту.
CREATE OR REPLACE FUNCTION app.can_manage_board_access(p_board uuid, p_actor uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(app.is_admin(p_actor), false)
        OR COALESCE(app.can_edit_board(p_board, p_actor), false)
$$;

-- Функция app.can_manage_task_access предназначена для проверки права p_actor выдавать и снимать точечный доступ к задаче.
CREATE OR REPLACE FUNCTION app.can_manage_task_access(p_task uuid, p_actor uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(app.is_admin(p_actor), false)
        OR COALESCE(app.can_edit_task(p_task, p_actor), false)
$$;

-- Функция app.is_live_user предназначена для проверки, что учётная запись действующая: доступ выдаётся только таким.
CREATE OR REPLACE FUNCTION app.is_live_user(p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (SELECT 1 FROM app.users u
                    WHERE u.id = p_user AND u.deleted_at IS NULL AND u.is_active)
$$;

-- Раздел 3: обзор доступа пользователя.
-- Обычный пользователь видит доступ другого только в проектах, где он владелец или редактор, и в задачах, которые вправе
-- редактировать. Администратор видит всё, включая диаграммы, доски и замещения.
--
-- Функция app.access_overview предназначена для получения списка доступов пользователя p_target.
-- Поле kind: board | task_grant | task_assignee | chart | whiteboard | delegation_to | delegation_from.
-- Поле level: роль в проекте (owner/editor/reader), уровень гранта (read/contribute); для остального пусто или период.
CREATE OR REPLACE FUNCTION app.access_overview(p_target uuid)
RETURNS TABLE (kind text, object_id uuid, title text, board_id uuid,
               board_title text, level text, manageable boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE
    v_me    uuid := app.current_user_id();
    v_admin boolean;
BEGIN
    IF v_me IS NULL THEN
        RETURN;
    END IF;
    v_admin := app.is_admin(v_me);

    RETURN QUERY
    SELECT 'board'::text, b.id, b.title, b.id, b.title, m.role::text,
           app.can_manage_board_access(b.id, v_me)
             AND (m.role <> 'owner' OR v_admin)
      FROM app.board_members m JOIN app.boards b ON b.id = m.board_id
     WHERE m.user_id = p_target
       AND (v_admin OR app.can_edit_board(b.id, v_me));

    RETURN QUERY
    SELECT 'task_grant'::text, t.id, t.title, b.id, b.title, g.access::text,
           app.can_manage_task_access(t.id, v_me)
      FROM app.task_grants g
      JOIN app.tasks t  ON t.id = g.task_id
      JOIN app.boards b ON b.id = t.board_id
     WHERE g.user_id = p_target
       AND (v_admin OR app.can_edit_task(t.id, v_me));

    -- Назначения исполнителем приводятся для полноты картины: они изменяются в карточке задачи.
    RETURN QUERY
    SELECT 'task_assignee'::text, t.id, t.title, b.id, b.title, NULL::text, false
      FROM app.task_assignees a
      JOIN app.tasks t  ON t.id = a.task_id
      JOIN app.boards b ON b.id = t.board_id
     WHERE a.user_id = p_target AND NOT t.archived AND t.completed_at IS NULL
       AND (v_admin OR app.can_edit_task(t.id, v_me));

    IF NOT v_admin THEN
        RETURN;
    END IF;

    RETURN QUERY
    SELECT 'chart'::text, c.id, c.title, NULL::uuid, NULL::text, m.role::text, false
      FROM app.chart_members m JOIN app.charts c ON c.id = m.chart_id
     WHERE m.user_id = p_target;

    RETURN QUERY
    SELECT 'whiteboard'::text, w.id, w.title, NULL::uuid, NULL::text, m.role::text, false
      FROM app.whiteboard_members m JOIN app.whiteboards w ON w.id = m.board_id
     WHERE m.user_id = p_target;

    RETURN QUERY
    SELECT 'delegation_to'::text, d.id, u.full_name, NULL::uuid, NULL::text,
           to_char(d.starts_at, 'YYYY-MM-DD') || '…' || to_char(d.ends_at, 'YYYY-MM-DD'), false
      FROM app.delegations d JOIN app.users u ON u.id = d.deputy_id
     WHERE d.grantor_id = p_target AND d.ends_at >= current_date;

    RETURN QUERY
    SELECT 'delegation_from'::text, d.id, u.full_name, NULL::uuid, NULL::text,
           to_char(d.starts_at, 'YYYY-MM-DD') || '…' || to_char(d.ends_at, 'YYYY-MM-DD'), false
      FROM app.delegations d JOIN app.users u ON u.id = d.grantor_id
     WHERE d.deputy_id = p_target AND d.ends_at >= current_date;
END $$;

-- Функция app.manageable_boards предназначена для получения проектов, в которые вызывающий может добавлять людей.
CREATE OR REPLACE FUNCTION app.manageable_boards()
RETURNS TABLE (id uuid, title text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT b.id, b.title FROM app.boards b
     WHERE NOT b.archived
       AND app.can_manage_board_access(b.id, app.current_user_id())
     ORDER BY b.title
$$;

-- Раздел 4: точечные изменения доступа. Изменяется одна строка, а не весь список, как в PUT /members:
-- при замене списка одновременные правки разных редакторов затирали друг друга.

-- Функция app.set_board_access предназначена для выдачи или смены роли в проекте.
-- Возвращает прежнюю роль (NULL — доступ выдан впервые) для уведомления только новых участников.
CREATE OR REPLACE FUNCTION app.set_board_access(p_board uuid, p_user uuid, p_role text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_me   uuid := app.current_user_id();
    v_prev text;
BEGIN
    IF p_role NOT IN ('editor', 'reader') THEN
        RAISE EXCEPTION 'Роль может быть только «редактор» или «исполнитель»'
            USING ERRCODE = '22023';
    END IF;
    IF app.can_manage_board_access(p_board, v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этому проекту' USING ERRCODE = '42501';
    END IF;
    IF app.is_live_user(p_user) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;

    SELECT role::text INTO v_prev FROM app.board_members
     WHERE board_id = p_board AND user_id = p_user;
    IF v_prev = 'owner' THEN
        RAISE EXCEPTION 'Роль владельца меняется передачей владения' USING ERRCODE = '42501';
    END IF;

    INSERT INTO app.board_members (board_id, user_id, role)
    VALUES (p_board, p_user, p_role::app.board_role)
    ON CONFLICT (board_id, user_id) DO UPDATE SET role = EXCLUDED.role;
    RETURN v_prev;
END $$;

-- Функция app.revoke_board_access предназначена для снятия доступа к проекту. Строка владельца не изменяется (как в политике 0007).
CREATE OR REPLACE FUNCTION app.revoke_board_access(p_board uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_me uuid := app.current_user_id();
BEGIN
    IF app.can_manage_board_access(p_board, v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этому проекту' USING ERRCODE = '42501';
    END IF;
    IF EXISTS (SELECT 1 FROM app.board_members
                WHERE board_id = p_board AND user_id = p_user AND role = 'owner') THEN
        RAISE EXCEPTION 'Владельца нельзя снять с проекта — сначала передайте владение'
            USING ERRCODE = '42501';
    END IF;
    DELETE FROM app.board_members WHERE board_id = p_board AND user_id = p_user;
    RETURN FOUND;
END $$;

-- Функция app.set_task_access предназначена для выдачи или смены точечного доступа к задаче.
-- Возвращает прежний уровень (NULL — доступ выдан впервые).
CREATE OR REPLACE FUNCTION app.set_task_access(p_task uuid, p_user uuid, p_access text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_me   uuid := app.current_user_id();
    v_prev text;
BEGIN
    IF p_access NOT IN ('read', 'contribute') THEN
        RAISE EXCEPTION 'Уровень может быть только «просмотр» или «участие»' USING ERRCODE = '22023';
    END IF;
    IF app.can_manage_task_access(p_task, v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этой задаче' USING ERRCODE = '42501';
    END IF;
    IF app.is_live_user(p_user) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;

    SELECT access::text INTO v_prev FROM app.task_grants
     WHERE task_id = p_task AND user_id = p_user;

    INSERT INTO app.task_grants (task_id, user_id, access, granted_by)
    VALUES (p_task, p_user, p_access::app.grant_access, v_me)
    ON CONFLICT (task_id, user_id) DO UPDATE SET access = EXCLUDED.access;
    -- История записывается здесь, а не в обработчике: администратор вне состава проекта не может писать в неё под RLS.
    INSERT INTO app.activity (task_id, actor_id, body)
    VALUES (p_task, v_me, 'Изменён доступ к задаче');
    RETURN v_prev;
END $$;

-- Функция app.revoke_task_access предназначена для снятия точечного доступа к задаче.
CREATE OR REPLACE FUNCTION app.revoke_task_access(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF app.can_manage_task_access(p_task, app.current_user_id()) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этой задаче' USING ERRCODE = '42501';
    END IF;
    DELETE FROM app.task_grants WHERE task_id = p_task AND user_id = p_user;
    IF NOT FOUND THEN
        RETURN false;
    END IF;
    INSERT INTO app.activity (task_id, actor_id, body)
    VALUES (p_task, app.current_user_id(), 'Изменён доступ к задаче');
    RETURN true;
END $$;

-- Функция app.task_brief предназначена для получения проекта и названия задачи для уведомлений и событий.
-- Доступна только управляющему доступом к задаче: иначе позволяла бы узнать название чужой задачи по идентификатору.
CREATE OR REPLACE FUNCTION app.task_brief(p_task uuid)
RETURNS TABLE (board_id uuid, title text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT t.board_id, t.title FROM app.tasks t
     WHERE t.id = p_task AND app.can_manage_task_access(p_task, app.current_user_id())
$$;

-- Раздел 5: онбординг, доступ как у коллеги (только администратор).
-- Копируются членства в проектах, диаграммах и досках и точечные гранты. Владение не копируется: у проекта один владелец,
-- новый пользователь получает роль «редактор». Имеющийся доступ не понижается (ON CONFLICT DO NOTHING).
-- Назначения исполнителем не копируются.
--
-- Функция app.copy_access предназначена для копирования доступа пользователя p_from пользователю p_to.
CREATE OR REPLACE FUNCTION app.copy_access(p_from uuid, p_to uuid)
RETURNS TABLE (board_id uuid, title text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE
    v_me uuid := app.current_user_id();
BEGIN
    IF app.is_admin(v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Копировать доступ может только администратор' USING ERRCODE = '42501';
    END IF;
    IF p_from = p_to THEN
        RAISE EXCEPTION 'Нужны два разных сотрудника' USING ERRCODE = '22023';
    END IF;
    IF app.is_live_user(p_to) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;

    INSERT INTO app.chart_members (chart_id, user_id, role)
    SELECT m.chart_id, p_to, CASE WHEN m.role = 'owner' THEN 'editor' ELSE m.role END
      FROM app.chart_members m WHERE m.user_id = p_from
    ON CONFLICT DO NOTHING;

    INSERT INTO app.whiteboard_members (board_id, user_id, role)
    SELECT m.board_id, p_to, CASE WHEN m.role = 'owner' THEN 'editor' ELSE m.role END
      FROM app.whiteboard_members m WHERE m.user_id = p_from
    ON CONFLICT DO NOTHING;

    INSERT INTO app.task_grants (task_id, user_id, access, granted_by)
    SELECT g.task_id, p_to, g.access, v_me
      FROM app.task_grants g WHERE g.user_id = p_from
    ON CONFLICT DO NOTHING;

    -- Проекты возвращаются последними: по ним рассылаются уведомления и события о добавлении в проект.
    RETURN QUERY
    WITH ins AS (
        INSERT INTO app.board_members (board_id, user_id, role)
        SELECT m.board_id, p_to,
               CASE WHEN m.role = 'owner' THEN 'editor'::app.board_role ELSE m.role END
          FROM app.board_members m WHERE m.user_id = p_from
        ON CONFLICT DO NOTHING
        RETURNING board_members.board_id
    )
    SELECT b.id, b.title FROM ins JOIN app.boards b ON b.id = ins.board_id;
END $$;

-- Раздел 6: офбординг.
-- Функция app.offboard_user предназначена для удаления учётной записи с полным снятием доступа одной транзакцией.
-- - Владение проектами, диаграммами, досками и групповыми чатами переходит преемнику p_successor. Если владеть нечем,
-- преемник не нужен; если есть чем, а преемник не указан — отказ.
-- - Снимаются членства, гранты, назначения исполнителем, исполнители пунктов чек-листа, замещения и команды.
-- - Задачи без исполнителя не переназначаются: владелец и редакторы проекта получают уведомление по каждой такой задаче.
-- - Авторство (created_by) сохраняется как история.
-- Возвращает уведомления для рассылки по WebSocket и проекты со сменой состава (событие board/updated).
CREATE OR REPLACE FUNCTION app.offboard_user(p_target uuid, p_successor uuid)
RETURNS TABLE (notify_user uuid, notification_id uuid, created_at timestamptz,
               body text, board_id uuid, task_id uuid)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE
    v_me      uuid := app.current_user_id();
    v_name    text;
    v_owned   int;
    v_tasks   uuid[];
    r         record;
BEGIN
    IF app.is_admin(v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Удалять сотрудников может только администратор' USING ERRCODE = '42501';
    END IF;
    IF p_target = v_me THEN
        RAISE EXCEPTION 'Нельзя удалить собственную учётную запись' USING ERRCODE = '42501';
    END IF;

    SELECT u.full_name INTO v_name FROM app.users u
     WHERE u.id = p_target AND u.deleted_at IS NULL
       FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Учётная запись не найдена или уже удалена' USING ERRCODE = 'P0002';
    END IF;

    SELECT (SELECT count(*) FROM app.board_members m WHERE m.user_id = p_target AND m.role = 'owner')
         + (SELECT count(*) FROM app.chart_members m WHERE m.user_id = p_target AND m.role = 'owner')
         + (SELECT count(*) FROM app.whiteboard_members m WHERE m.user_id = p_target AND m.role = 'owner')
         + (SELECT count(*) FROM app.chats c WHERE c.owner_id = p_target AND c.kind = 'group')
      INTO v_owned;

    IF v_owned > 0 THEN
        IF p_successor IS NULL THEN
            RAISE EXCEPTION 'need_successor:%', v_owned USING ERRCODE = 'P0001',
                HINT = 'Сотрудник владеет проектами — выберите, кому их передать';
        END IF;
        IF p_successor = p_target OR app.is_live_user(p_successor) IS NOT TRUE THEN
            RAISE EXCEPTION 'Преемником может быть только действующий сотрудник'
                USING ERRCODE = '22023';
        END IF;

        -- Передача владения: сначала удаляется строка прежнего владельца, затем преемник становится владельцем
        -- (уникальный индекс «один владелец на проект» не допускает другой порядок).
        FOR r IN DELETE FROM app.board_members m
                  WHERE m.user_id = p_target AND m.role = 'owner'
              RETURNING m.board_id LOOP
            INSERT INTO app.board_members (board_id, user_id, role)
            VALUES (r.board_id, p_successor, 'owner')
            ON CONFLICT ON CONSTRAINT board_members_pkey DO UPDATE SET role = 'owner';
            body := 'Вам передан проект сотрудника ' || v_name || ': «'
                 || (SELECT b.title FROM app.boards b WHERE b.id = r.board_id) || '»';
            notification_id := NULL;
            SELECT n.id, n.created_at INTO notification_id, created_at
              FROM app.notify_cat(p_successor, body, 'other', r.board_id, NULL) n;
            IF notification_id IS NOT NULL THEN
                notify_user := p_successor; board_id := r.board_id; task_id := NULL;
                RETURN NEXT;
            END IF;
        END LOOP;

        FOR r IN DELETE FROM app.chart_members m
                  WHERE m.user_id = p_target AND m.role = 'owner'
              RETURNING m.chart_id LOOP
            INSERT INTO app.chart_members (chart_id, user_id, role)
            VALUES (r.chart_id, p_successor, 'owner')
            ON CONFLICT ON CONSTRAINT chart_members_pkey DO UPDATE SET role = 'owner';
        END LOOP;

        FOR r IN DELETE FROM app.whiteboard_members m
                  WHERE m.user_id = p_target AND m.role = 'owner'
              RETURNING m.board_id LOOP
            INSERT INTO app.whiteboard_members (board_id, user_id, role)
            VALUES (r.board_id, p_successor, 'owner')
            ON CONFLICT ON CONSTRAINT whiteboard_members_pkey DO UPDATE SET role = 'owner';
        END LOOP;

        FOR r IN UPDATE app.chats c SET owner_id = p_successor
                  WHERE c.owner_id = p_target AND c.kind = 'group'
              RETURNING c.id LOOP
            INSERT INTO app.chat_members (chat_id, user_id)
            VALUES (r.id, p_successor) ON CONFLICT DO NOTHING;
        END LOOP;
    END IF;

    -- Назначения: запоминаются задачи, чтобы найти оставшиеся без исполнителя.
    WITH del AS (
        DELETE FROM app.task_assignees a WHERE a.user_id = p_target RETURNING a.task_id
    )
    SELECT array_agg(DISTINCT del.task_id) INTO v_tasks FROM del;

    UPDATE app.task_steps s SET assignee_id = NULL WHERE s.assignee_id = p_target;
    DELETE FROM app.task_grants        g WHERE g.user_id = p_target;
    DELETE FROM app.board_members      m WHERE m.user_id = p_target;
    DELETE FROM app.chart_members      m WHERE m.user_id = p_target;
    DELETE FROM app.whiteboard_members m WHERE m.user_id = p_target;
    -- Из групповых чатов пользователь выводится; личная переписка сохраняется у собеседника.
    DELETE FROM app.chat_members cm
     USING app.chats c
     WHERE c.id = cm.chat_id AND c.kind = 'group' AND cm.user_id = p_target;
    DELETE FROM app.delegations d WHERE d.grantor_id = p_target OR d.deputy_id = p_target;
    DELETE FROM app.team_groups tg WHERE tg.owner_id = p_target;
    DELETE FROM app.team_members tm WHERE tm.member_id = p_target OR tm.owner_id = p_target;

    UPDATE app.users u SET deleted_at = now(), is_active = false, role = 'member'
     WHERE u.id = p_target;
    PERFORM app.revoke_user_sessions(p_target);

    -- Задачи без исполнителя: уведомление владельцу и редакторам проекта.
    FOR r IN
        SELECT t.id AS tid, t.title, t.board_id AS bid, m.user_id AS uid
          FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id AND m.role IN ('owner', 'editor')
         WHERE t.id = ANY (COALESCE(v_tasks, '{}'))
           AND NOT t.archived AND t.completed_at IS NULL
           AND NOT EXISTS (SELECT 1 FROM app.task_assignees a WHERE a.task_id = t.id)
    LOOP
        body := 'После ухода сотрудника ' || v_name || ' задача «' || r.title
             || '» осталась без исполнителя';
        notification_id := NULL;
        SELECT n.id, n.created_at INTO notification_id, created_at
          FROM app.notify_cat(r.uid, body, 'task', r.bid, r.tid) n;
        IF notification_id IS NOT NULL THEN
            notify_user := r.uid; board_id := r.bid; task_id := r.tid;
            RETURN NEXT;
        END IF;
    END LOOP;
END $$;

GRANT EXECUTE ON FUNCTION app.can_manage_board_access(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.can_manage_task_access(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.is_live_user(uuid)                  TO app_user;
GRANT EXECUTE ON FUNCTION app.access_overview(uuid)               TO app_user;
GRANT EXECUTE ON FUNCTION app.manageable_boards()                 TO app_user;
GRANT EXECUTE ON FUNCTION app.set_board_access(uuid, uuid, text)  TO app_user;
GRANT EXECUTE ON FUNCTION app.revoke_board_access(uuid, uuid)     TO app_user;
GRANT EXECUTE ON FUNCTION app.set_task_access(uuid, uuid, text)   TO app_user;
GRANT EXECUTE ON FUNCTION app.revoke_task_access(uuid, uuid)      TO app_user;
GRANT EXECUTE ON FUNCTION app.task_brief(uuid)                    TO app_user;
GRANT EXECUTE ON FUNCTION app.copy_access(uuid, uuid)             TO app_user;
GRANT EXECUTE ON FUNCTION app.offboard_user(uuid, uuid)           TO app_user;
