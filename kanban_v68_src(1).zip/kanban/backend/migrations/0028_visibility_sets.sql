-- Скрипт предназначен для ускорения проверок видимости: политики чтения задач, проектов и связанных таблиц переведены
-- с построчного вызова функций (app.can_see_task, app.can_see_board) на множества, вычисляемые один раз за запрос.
--
-- Причина замедления: политика tasks_select вызывала app.task_access для каждой строки, а функция выполняла 4–6 внутренних запросов.
-- При 40 тыс. задач чтение списка занимало около 16 секунд, сводка — около 35 секунд (13 запросов, в каждом проверка дважды).
-- После изменения: чтение 20 тыс. доступных задач — около 25 мс.
--
-- Правила доступа не менялись: задача видна владельцу и редактору проекта, автору, исполнителю, исполнителю пункта
-- чек-листа и обладателю точечного права; замещение учитывается через app.effective_users. Строка проекта видна участнику
-- и обладателю доступа к отдельной задаче (исполнитель или точечное право).
-- Точечные проверки (app.task_access, app.can_edit_task и другие для записи) сохранены без изменений.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0028_visibility_sets.sql
--
-- Выполняется от app_owner после 0027_access_panel.sql, идемпотентен.

SET search_path = app, public;

-- Функция app.my_ids предназначена для получения идентификаторов, от имени которых действует текущий пользователь.
CREATE OR REPLACE FUNCTION app.my_ids()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT app.effective_users(app.current_user_id()) $$;

-- Функция app.my_edit_boards предназначена для получения проектов, где текущий пользователь — владелец или редактор.
CREATE OR REPLACE FUNCTION app.my_edit_boards()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.board_id FROM app.board_members m
     WHERE m.role IN ('owner', 'editor')
       AND m.user_id IN (SELECT app.effective_users(app.current_user_id()))
$$;

-- Функция app.my_task_ids предназначена для получения задач, доступных через назначение, пункт чек-листа или точечное право.
CREATE OR REPLACE FUNCTION app.my_task_ids()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH me AS (SELECT app.effective_users(app.current_user_id()) AS id)
    SELECT a.task_id FROM app.task_assignees a WHERE a.user_id IN (SELECT id FROM me)
    UNION
    SELECT s.task_id FROM app.task_steps s WHERE s.assignee_id IN (SELECT id FROM me)
    UNION
    SELECT g.task_id FROM app.task_grants g WHERE g.user_id IN (SELECT id FROM me)
$$;

-- Политика tasks_select: набор проектов, набор задач автора и набор назначений вычисляются один раз за запрос (hashed SubPlan).
DROP POLICY IF EXISTS tasks_select ON app.tasks;
CREATE POLICY tasks_select ON app.tasks FOR SELECT USING (
       board_id IN (SELECT app.my_edit_boards())
    OR created_by IN (SELECT app.my_ids())
    OR id IN (SELECT app.my_task_ids()));

-- Функция app.can_see_task предназначена для проверки видимости одной задачи: один SQL-запрос вместо цепочки функций.
CREATE OR REPLACE FUNCTION app.can_see_task(p_task uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT p_user IS NOT NULL AND EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (EXISTS (SELECT 1 FROM app.board_members m
                         WHERE m.board_id = t.board_id AND m.role IN ('owner', 'editor')
                           AND m.user_id IN (SELECT app.effective_users(p_user)))
             OR t.created_by IN (SELECT app.effective_users(p_user))
             OR EXISTS (SELECT 1 FROM app.task_assignees a WHERE a.task_id = t.id
                           AND a.user_id IN (SELECT app.effective_users(p_user)))
             OR EXISTS (SELECT 1 FROM app.task_steps s WHERE s.task_id = t.id
                           AND s.assignee_id IN (SELECT app.effective_users(p_user)))
             OR EXISTS (SELECT 1 FROM app.task_grants g WHERE g.task_id = t.id
                           AND g.user_id IN (SELECT app.effective_users(p_user)))))
$$;

-- Политики чтения связанных таблиц: задача видна, если её возвращает tasks (поиск по первичному ключу).
-- Рекурсии нет: политика tasks использует только функции SECURITY DEFINER.
DROP POLICY IF EXISTS task_assignees_select ON app.task_assignees;
CREATE POLICY task_assignees_select ON app.task_assignees FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = task_assignees.task_id));
DROP POLICY IF EXISTS comments_select ON app.comments;
CREATE POLICY comments_select ON app.comments FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = comments.task_id));
DROP POLICY IF EXISTS activity_select ON app.activity;
CREATE POLICY activity_select ON app.activity FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = activity.task_id));
DROP POLICY IF EXISTS attachments_select ON app.attachments;
CREATE POLICY attachments_select ON app.attachments FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = attachments.task_id));
DROP POLICY IF EXISTS task_steps_select ON app.task_steps;
CREATE POLICY task_steps_select ON app.task_steps FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = task_steps.task_id));

-- Проекты, где текущий пользователь (или замещаемый им) — участник.
CREATE OR REPLACE FUNCTION app.my_member_boards()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.board_id FROM app.board_members m
     WHERE m.user_id IN (SELECT app.effective_users(app.current_user_id()))
$$;

-- Проекты, строка которых видна: участие либо доступ к отдельной задаче (исполнитель или точечное право).
CREATE OR REPLACE FUNCTION app.my_boards()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH me AS (SELECT app.effective_users(app.current_user_id()) AS id)
    SELECT m.board_id FROM app.board_members m WHERE m.user_id IN (SELECT id FROM me)
    UNION
    SELECT t.board_id FROM app.task_grants g JOIN app.tasks t ON t.id = g.task_id
     WHERE g.user_id IN (SELECT id FROM me)
    UNION
    SELECT t.board_id FROM app.task_assignees a JOIN app.tasks t ON t.id = a.task_id
     WHERE a.user_id IN (SELECT id FROM me)
$$;

DROP POLICY IF EXISTS boards_select ON app.boards;
CREATE POLICY boards_select ON app.boards FOR SELECT USING (id IN (SELECT app.my_boards()));
DROP POLICY IF EXISTS columns_select ON app.columns;
CREATE POLICY columns_select ON app.columns FOR SELECT USING (board_id IN (SELECT app.my_boards()));
DROP POLICY IF EXISTS board_members_select ON app.board_members;
CREATE POLICY board_members_select ON app.board_members FOR SELECT USING (board_id IN (SELECT app.my_member_boards()));
CREATE INDEX IF NOT EXISTS tasks_board_upd_idx ON app.tasks (board_id, updated_at DESC) WHERE NOT archived;

-- Активность проекта: для каждой задачи берётся только последняя подходящая запись (LATERAL ... LIMIT 1 по индексу),
-- а не все записи журнала.
CREATE OR REPLACE FUNCTION app.board_activity_at(p_board uuid, p_except uuid)
RETURNS timestamptz LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT GREATEST(
               b.updated_at,
               COALESCE((SELECT max(t.updated_at) FROM app.tasks t
                          WHERE t.board_id = b.id AND NOT t.archived),
                        b.updated_at),
               COALESCE((SELECT max(x.at)
                           FROM app.tasks t
                           CROSS JOIN LATERAL (
                                SELECT a.created_at AS at FROM app.activity a
                                 WHERE a.task_id = t.id
                                   AND (p_except IS NULL OR a.actor_id IS DISTINCT FROM p_except)
                                 ORDER BY a.created_at DESC LIMIT 1) x
                          WHERE t.board_id = b.id),
                        b.updated_at))
      FROM app.boards b WHERE b.id = p_board
$$;

GRANT EXECUTE ON FUNCTION app.my_ids(), app.my_edit_boards(), app.my_task_ids(),
                          app.my_member_boards(), app.my_boards() TO app_user;

-- Индексы для внешних ключей, по которым выполняются соединения и каскадное удаление.
CREATE INDEX IF NOT EXISTS attachments_file_idx      ON app.attachments (file_id);
CREATE INDEX IF NOT EXISTS chat_messages_file_idx    ON app.chat_messages (file_id)    WHERE file_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS chart_attachments_file_idx ON app.chart_attachments (file_id);
CREATE INDEX IF NOT EXISTS notifications_task_idx    ON app.notifications (task_id)    WHERE task_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS notifications_board_idx   ON app.notifications (board_id)   WHERE board_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS notifications_chart_idx   ON app.notifications (chart_id)   WHERE chart_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS notifications_wb_idx      ON app.notifications (wb_id)      WHERE wb_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS comments_author_idx       ON app.comments (author_id);
CREATE INDEX IF NOT EXISTS activity_actor_idx        ON app.activity (actor_id);

ANALYZE;
