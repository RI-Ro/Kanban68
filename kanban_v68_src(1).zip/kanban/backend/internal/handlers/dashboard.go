// Модуль предназначен для расчёта дашборда агрегатами на стороне БД: сводные счётчики, срезы по приоритетам,
// проектам и людям, динамика по неделям, личная сводка и списки задач исполнителя.

package handlers

import (
	"context"
	"fmt"
	"sort"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// Тип dashboardFilter предназначен для хранения параметров отбора дашборда: период, проект, исполнитель.

type dashboardFilter struct {
	From      string
	To        string
	BoardID   *uuid.UUID
	Assignee  *uuid.UUID
	Status    string // all | open | done | overdue
}

// Функция readDashboardFilter предназначена для чтения параметров отбора из запроса.
func readDashboardFilter(c *fiber.Ctx) dashboardFilter {
	f := dashboardFilter{
		From:   c.Query("from"),
		To:     c.Query("to"),
		Status: c.Query("status", "all"),
	}
	if v := c.Query("boardId"); v != "" {
		if id, err := uuid.Parse(v); err == nil {
			f.BoardID = &id
		}
	}
	if v := c.Query("assignee"); v != "" {
		if id, err := uuid.Parse(v); err == nil {
			f.Assignee = &id
		}
	}
	if f.From == "" {
		// Период по умолчанию — последние шесть месяцев.
		f.From = time.Now().AddDate(0, -6, 0).Format("2006-01-02")
	}
	if f.To == "" {
		f.To = time.Now().AddDate(0, 0, 1).Format("2006-01-02")
	}
	return f
}

// Константа dashboardWhere задаёт общее условие отбора для всех срезов дашборда. Видимость задач уже обеспечена временной таблицей dash_t (см. prepareDashboardData).
const dashboardWhere = `
	WHERE NOT t.archived
	  AND t.created_at >= $1::date
	  AND t.created_at <  $2::date
	  AND ($3::uuid IS NULL OR t.board_id = $3::uuid)
	  AND ($4::uuid IS NULL OR EXISTS (
	        SELECT 1 FROM dash_a ta
	         WHERE ta.task_id = t.id AND ta.user_id = $4::uuid))
	  AND ($5::text = 'all'
	    OR ($5::text = 'done'    AND t.completed_at IS NOT NULL)
	    OR ($5::text = 'open'    AND t.completed_at IS NULL)
	    OR ($5::text = 'overdue' AND t.completed_at IS NULL
	                       AND t.due_date IS NOT NULL AND t.due_date < current_date))`

// Метод Dashboard предназначен для получения данных дашборда одним ответом.
func (s *Server) Dashboard(c *fiber.Ctx) error {
	f := readDashboardFilter(c)
	uid := s.uid(c)
	args := []any{f.From, f.To, f.BoardID, f.Assignee, f.Status}

	byBoard := []map[string]any{}
	byAssignee := []map[string]any{}
	myLoad := map[string]int{}
	var metrics dashboardMetrics

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if e := prepareDashboardData(c.Context(), tx, uid, f.BoardID); e != nil {
			return e
		}

		// Срез по проектам.
		rows, e := tx.Query(c.Context(), `
			SELECT b.id, b.title, count(*),
			       count(*) FILTER (WHERE t.completed_at IS NOT NULL),
			       count(*) FILTER (WHERE t.completed_at IS NULL
			                          AND t.due_date IS NOT NULL
			                          AND t.due_date < current_date)
			  FROM dash_t t
			  JOIN app.boards b ON b.id = t.board_id`+dashboardWhere+`
			 GROUP BY b.id, b.title ORDER BY count(*) DESC LIMIT 20`, args...)
		if e != nil {
			return e
		}
		for rows.Next() {
			var id uuid.UUID
			var title string
			var total, done, overdue int
			if e := rows.Scan(&id, &title, &total, &done, &overdue); e != nil {
				rows.Close()
				return e
			}
			byBoard = append(byBoard, map[string]any{
				"boardId": id, "title": title,
				"total": total, "done": done, "overdue": overdue,
			})
		}
		rows.Close()

		// Срез по людям: учитываются и исполнители, и авторы задач.
		rows, e = tx.Query(c.Context(), `
			SELECT p.user_id, count(*),
			       count(*) FILTER (WHERE t.completed_at IS NOT NULL),
			       count(*) FILTER (WHERE t.completed_at IS NULL
			                          AND t.due_date IS NOT NULL
			                          AND t.due_date < current_date),
			       count(*) FILTER (WHERE p.completed_at IS NOT NULL),
			       count(*) FILTER (WHERE p.as_assignee),
			       count(*) FILTER (WHERE NOT p.as_assignee)
			  FROM dash_t t
			  JOIN LATERAL (
			         SELECT ta.user_id, ta.completed_at, true AS as_assignee
			           FROM dash_a ta WHERE ta.task_id = t.id
			         UNION ALL
			         -- Автор попадает в разрез отдельной строкой, но
			         -- только если он не в исполнителях: иначе одна
			         -- задача посчиталась бы ему дважды.
			         SELECT t.created_by, NULL::timestamptz, false
			          WHERE t.created_by IS NOT NULL
			            AND NOT EXISTS (SELECT 1 FROM dash_a x
			                             WHERE x.task_id = t.id AND x.user_id = t.created_by)
			       ) p ON true
			 WHERE NOT t.archived
			   AND ($1::uuid IS NULL OR t.board_id = $1::uuid)
			   AND ($2::text = 'all'
			     OR ($2::text = 'done'    AND t.completed_at IS NOT NULL)
			     OR ($2::text = 'open'    AND t.completed_at IS NULL)
			     OR ($2::text = 'overdue' AND t.completed_at IS NULL
			                        AND t.due_date IS NOT NULL AND t.due_date < current_date))
			 GROUP BY p.user_id ORDER BY count(*) DESC LIMIT 30`, f.BoardID, f.Status)
		if e != nil {
			return e
		}
		for rows.Next() {
			var id uuid.UUID
			var total, done, overdue, selfDone, asAssignee, asAuthor int
			if e := rows.Scan(&id, &total, &done, &overdue, &selfDone,
				&asAssignee, &asAuthor); e != nil {
				rows.Close()
				return e
			}
			byAssignee = append(byAssignee, map[string]any{
				"userId": id, "total": total, "done": done,
				"overdue": overdue, "selfDone": selfDone,
				"asAssignee": asAssignee, "asAuthor": asAuthor,
			})
		}
		rows.Close()

		// Личная сводка; не ограничивается периодом, но учитывает выбранные проект и исполнителя.
		var assigned, assignedOverdue, delegatedOut, granted int
		var createdTotal, involvedTotal int
		if e := tx.QueryRow(c.Context(), `
			SELECT
			  (SELECT count(*) FROM dash_t t
			     JOIN dash_a ta ON ta.task_id = t.id
			    WHERE ta.user_id = $1 AND NOT t.archived AND t.completed_at IS NULL
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)),
			  (SELECT count(*) FROM dash_t t
			     JOIN dash_a ta ON ta.task_id = t.id
			    WHERE ta.user_id = $1 AND NOT t.archived AND t.completed_at IS NULL
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)
			      AND t.due_date IS NOT NULL AND t.due_date < current_date),
			  (SELECT count(*) FROM dash_t t
			    WHERE t.created_by = $1 AND NOT t.archived AND t.completed_at IS NULL
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)),
			  (SELECT count(*) FROM dash_t t
			     JOIN dash_g g ON g.task_id = t.id
			    WHERE $1::uuid IS NOT NULL AND NOT t.archived AND t.completed_at IS NULL
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)),
			  -- «Я автор» целиком, вместе с завершёнными: остальные
			  -- плитки показывают текущую загрузку, а эта — объём
			  -- поставленного вообще.
			  (SELECT count(*) FROM dash_t t
			    WHERE t.created_by = $1 AND NOT t.archived
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)),
			  -- Все мои задачи: где я исполнитель ИЛИ автор, без
			  -- двойного счёта — задача, которую я поставил сам себе,
			  -- одна, а не две.
			  (SELECT count(*) FROM dash_t t
			    WHERE NOT t.archived
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)
			      AND (t.created_by = $1
			           OR EXISTS (SELECT 1 FROM dash_a ta
			                       WHERE ta.task_id = t.id AND ta.user_id = $1)))`,
			uid, f.BoardID).
			Scan(&assigned, &assignedOverdue, &delegatedOut, &granted,
				&createdTotal, &involvedTotal); e != nil {
			return e
		}
		myLoad["assigned"] = assigned
		myLoad["assignedOverdue"] = assignedOverdue
		myLoad["createdByMe"] = delegatedOut
		myLoad["grantedToMe"] = granted
		myLoad["createdByMeTotal"] = createdTotal
		myLoad["myTotal"] = involvedTotal

		// Дополнительные метрики выполняются в той же транзакции и с теми же правами.
		var me error
		metrics, me = loadDashboardMetrics(c.Context(), tx, f)
		return me
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	return httpx.JSON(c, fiber.StatusOK, fiber.Map{
		"byBoard":    byBoard,
		"byAssignee": byAssignee,
		"myLoad":     myLoad,
		"flow":       metrics.Flow,
		"attention":  metrics.Attention,
		"incoming":   metrics.Incoming,
		"people":     metrics.People,
		"filter": fiber.Map{
			"from": f.From, "to": f.To, "status": f.Status,
			"boardId": f.BoardID, "assignee": f.Assignee,
		},
	})
}

// Метод DashboardUserTasks предназначен для получения задач человека для окна детализации; параметр kind:
// assigned (поручено ему) или created (поручил он).
func (s *Server) DashboardUserTasks(c *fiber.Ctx) error {
	userID, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	kind := c.Query("kind", "assigned")
	f := readDashboardFilter(c)
	uid := s.uid(c)

	// Разрезы по человеку: поручено, поручено им другим, открыто точечно.
	var join, extra string
	switch kind {
	case "created":
		extra = ` AND t.created_by = $1`
	case "granted":
		join = `JOIN app.task_grants g ON g.task_id = t.id AND g.user_id = $1`
	case "involved":
		// Условие вместо соединения исключает двойной счёт задач.
		extra = ` AND (t.created_by = $1
		            OR EXISTS (SELECT 1 FROM dash_a ta
		                        WHERE ta.task_id = t.id AND ta.user_id = $1))`
	default:
		join = `JOIN dash_a ta ON ta.task_id = t.id AND ta.user_id = $1`
	}

	var tasks []taskBrief
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if e := prepareDashboardData(c.Context(), tx, uid, f.BoardID); e != nil {
			return e
		}
		// Разрез по человеку не ограничивается периодом создания. Сначала выбираются идентификаторы страницы,
		// затем подробности только для них.
		rows, e := tx.Query(c.Context(), `
			SELECT t.id
			  FROM dash_t t
			  `+join+`
			 WHERE ($2::uuid IS NULL OR t.board_id = $2::uuid)
			   AND ($3::text = 'all'
			     OR ($3::text = 'done'    AND t.completed_at IS NOT NULL)
			     OR ($3::text = 'open'    AND t.completed_at IS NULL)
			     OR ($3::text = 'overdue' AND t.completed_at IS NULL
			                        AND t.due_date IS NOT NULL AND t.due_date < current_date))`+extra+`
			 GROUP BY t.id, t.due_date, t.created_at
			 ORDER BY t.due_date NULLS LAST, t.created_at DESC
			 LIMIT 200`,
			userID, f.BoardID, f.Status)
		if e != nil {
			return e
		}
		ids, e := scanIDs(rows)
		if e != nil {
			return e
		}
		tasks, e = loadBriefs(c.Context(), tx, ids)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, tasks)
}

// Функция prepareDashboardData предназначена для однократного отбора данных сводки во временные таблицы транзакции.
// Видимость проверяется один раз при чтении app.tasks (политики RLS), а все срезы и списки сводки работают с готовыми
// таблицами: dash_t — доступные задачи (не в архиве, с отбором по проекту и временем последнего изменения открытых),
// dash_a — исполнители этих задач, dash_g — точечные права текущего пользователя. Раньше каждый срез заново
// проверял права построчно, и сводка считалась десятки секунд.
func prepareDashboardData(ctx context.Context, tx pgx.Tx, uid uuid.UUID, boardID *uuid.UUID) error {
	boardCond := "TRUE"
	if boardID != nil {
		// Значение имеет тип uuid, поэтому подстановка в текст запроса безопасна.
		boardCond = fmt.Sprintf("t.board_id = '%s'::uuid", boardID.String())
	}
	stmts := []string{
		`CREATE TEMP TABLE dash_t ON COMMIT DROP AS
		 SELECT t.id, t.board_id, t.column_id, t.title, t.priority, t.due_date, t.completed_at, t.archived,
		        t.created_at, t.updated_at, t.created_by, t.ready_at, t.incoming_number, t.incoming_date,
		        CASE WHEN t.completed_at IS NULL THEN GREATEST(t.updated_at,
		             COALESCE((SELECT max(a.created_at) FROM app.activity a WHERE a.task_id = t.id), t.created_at),
		             COALESCE((SELECT max(cm.created_at) FROM app.comments cm WHERE cm.task_id = t.id), t.created_at))
		        END AS touched
		   FROM app.tasks t
		  WHERE NOT t.archived AND ` + boardCond,
		`CREATE UNIQUE INDEX dash_t_pk ON dash_t (id)`,
		`CREATE TEMP TABLE dash_a ON COMMIT DROP AS
		 SELECT a.task_id, a.user_id, a.completed_at FROM app.task_assignees a
		  WHERE a.task_id IN (SELECT id FROM dash_t)`,
		`CREATE INDEX dash_a_task_idx ON dash_a (task_id)`,
		`CREATE TEMP TABLE dash_g ON COMMIT DROP AS
		 SELECT g.task_id FROM app.task_grants g
		  WHERE g.user_id = '` + uid.String() + `'::uuid AND g.task_id IN (SELECT id FROM dash_t)`,
		`ANALYZE dash_t`,
		`ANALYZE dash_a`,
	}
	for _, q := range stmts {
		if _, err := tx.Exec(ctx, q); err != nil {
			return err
		}
	}
	return nil
}

// Функция scanIDs предназначена для чтения списка идентификаторов из результата запроса и закрытия результата.
func scanIDs(rows pgx.Rows) ([]uuid.UUID, error) {
	defer rows.Close()
	ids := []uuid.UUID{}
	for rows.Next() {
		var id uuid.UUID
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}

// Функция loadBriefs предназначена для загрузки подробностей строк задач по идентификаторам с сохранением порядка идентификаторов.
func loadBriefs(ctx context.Context, tx pgx.Tx, ids []uuid.UUID) ([]taskBrief, error) {
	if len(ids) == 0 {
		return []taskBrief{}, nil
	}
	rows, err := tx.Query(ctx, briefSelect+`
		  FROM app.tasks t
		  LEFT JOIN app.task_assignees a ON a.task_id = t.id
		 WHERE t.id = ANY($1::uuid[])
		 GROUP BY t.id`, ids)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	got, err := scanBriefs(rows)
	if err != nil {
		return nil, err
	}
	pos := make(map[uuid.UUID]int, len(ids))
	for i, id := range ids {
		pos[id] = i
	}
	sort.SliceStable(got, func(i, j int) bool { return pos[got[i].ID] < pos[got[j].ID] })
	return got, nil
}

// Константа briefSelect задаёт поля строки задачи в списках сводки; порядок столбцов соответствует scanBriefs.
const briefSelect = `
			SELECT t.id, t.title, t.board_id, app.board_title(t.board_id),
			       t.column_id, app.column_title(t.column_id), t.priority::text,
			       to_char(t.due_date, 'YYYY-MM-DD'),
			       t.completed_at,
			       t.incoming_number, to_char(t.incoming_date, 'YYYY-MM-DD'), t.tags,
			       (SELECT count(*) FROM app.comments cm WHERE cm.task_id = t.id),
			       (SELECT count(*) FROM app.attachments f WHERE f.task_id = t.id),
			       t.ready_at, t.recur_freq::text, t.recur_interval, t.created_by,
			       COALESCE(array_agg(DISTINCT a.user_id)
			                FILTER (WHERE a.user_id IS NOT NULL), '{}'),
			       COALESCE(array_agg(DISTINCT a.user_id)
			                FILTER (WHERE a.completed_at IS NOT NULL), '{}')`

// Функция scanBriefs предназначена для чтения строк запроса в список taskBrief.
func scanBriefs(rows pgx.Rows) ([]taskBrief, error) {
	tasks := []taskBrief{}
	for rows.Next() {
		var t taskBrief
		if e := rows.Scan(&t.ID, &t.Title, &t.BoardID, &t.BoardTitle,
			&t.ColumnID, &t.ColumnTitle, &t.Priority, &t.DueDate, &t.CompletedAt,
			&t.IncomingNum, &t.IncomingDate, &t.Tags,
			&t.CommentCnt, &t.AttachCnt, &t.ReadyAt, &t.RecurFreq, &t.RecurInterval, &t.CreatedBy,
			&t.Assignees, &t.AssigneesDone); e != nil {
			return nil, e
		}
		t.Completed = t.CompletedAt != nil
		tasks = append(tasks, t)
	}
	return tasks, rows.Err()
}

// Тип taskBrief предназначен для описания строки задачи в списках сводки: проект, колонка, автор, исполнители.
type taskBrief struct {
	ID          uuid.UUID   `json:"id"`
	Title       string      `json:"title"`
	BoardID     uuid.UUID   `json:"boardId"`
	BoardTitle  string      `json:"boardTitle"`
	ColumnID    uuid.UUID   `json:"columnId"`
	ColumnTitle string      `json:"columnTitle"`
	Priority    string      `json:"priority"`
	DueDate     *string     `json:"dueDate"`
	Completed   bool        `json:"completed"`
	CompletedAt *time.Time  `json:"completedAt"`
	IncomingNum  string   `json:"incomingNumber"`
	IncomingDate *string  `json:"incomingDate"`
	// Теги для фильтра.
	Tags         []string `json:"tags"`
	CommentCnt   int        `json:"commentCount"`
	AttachCnt    int        `json:"attachmentCount"`
	ReadyAt      *time.Time `json:"readyAt"`
	RecurFreq     string `json:"recurFreq"`
	RecurInterval int    `json:"recurInterval"`
	CreatedBy   uuid.UUID   `json:"createdBy"`
	Assignees   []uuid.UUID `json:"assignees"`
	// Исполнители, отметившие свою часть выполненной.
	AssigneesDone []uuid.UUID `json:"assigneesDone"`
}
