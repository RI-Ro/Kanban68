// Модуль предназначен для выдачи администратору состояния системы по истории метрик, накопленной приложением.

package handlers

import (
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/example/kanban/internal/httpx"
)


// Переменная systemWindows задаёт допустимые периоды отчёта; в памяти хранится не более 24 часов истории.
var systemWindows = map[string]time.Duration{
	"1m":  time.Minute,
	"5m":  5 * time.Minute,
	"15m": 15 * time.Minute,
	"1h":  time.Hour,
	"5h":  5 * time.Hour,
	"10h": 10 * time.Hour,
	"24h": 24 * time.Hour,
}

// Метод AdminSystem предназначен для выдачи сводки состояния системы за период.
func (s *Server) AdminSystem(c *fiber.Ctx) error {
	if s.samples == nil {
		// При METRICS_ENABLED=false возвращается ответ 503 metrics_disabled.
		return httpx.Fail(c, httpx.Err(fiber.StatusServiceUnavailable, "metrics_disabled",
			"Сбор метрик отключён настройкой METRICS_ENABLED — состояние системы недоступно"))
	}

	window, ok := systemWindows[c.Query("range", "1h")]
	if !ok {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_range",
			"Период может быть 1m, 5m, 15m, 1h, 5h, 10h или 24h"))
	}

	return httpx.JSON(c, fiber.StatusOK, s.samples.Report(window, 180))
}
