package handlers

import (
	"context"
	"log/slog"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Модуль предназначен для регулярного обслуживания данных: удаления старых прочитанных уведомлений.

// Метод StartMaintenance предназначен для запуска фонового цикла очистки. Раз в сутки (и через минуту после запуска)
// удаляются прочитанные уведомления старше срока хранения; непрочитанные не затрагиваются. Удаление идёт порциями,
// чтобы не держать долгих блокировок и не раздувать журнал WAL одной транзакцией. Выполняет один экземпляр.
func (s *Server) StartMaintenance(ctx context.Context, pool *pgxpool.Pool) {
	days := s.cfg.NotificationRetentionDays
	if days <= 0 {
		return
	}
	go func() {
		timer := time.NewTimer(time.Minute)
		defer timer.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-timer.C:
				s.purgeNotifications(ctx, pool, days)
				timer.Reset(24 * time.Hour)
			}
		}
	}()
}

// Метод purgeNotifications предназначен для удаления прочитанных уведомлений старше days дней порциями по 5000 строк.
func (s *Server) purgeNotifications(ctx context.Context, pool *pgxpool.Pool, days int) {
	// Рекомендательная блокировка не даёт нескольким экземплярам чистить одновременно.
	conn, err := pool.Acquire(ctx)
	if err != nil {
		return
	}
	defer conn.Release()
	var got bool
	if err := conn.QueryRow(ctx, `SELECT pg_try_advisory_lock(7300001)`).Scan(&got); err != nil || !got {
		return
	}
	defer func() { _, _ = conn.Exec(context.Background(), `SELECT pg_advisory_unlock(7300001)`) }()

	var total int64
	for ctx.Err() == nil {
		tag, err := conn.Exec(ctx, `
			DELETE FROM app.notifications
			 WHERE id IN (SELECT id FROM app.notifications
			               WHERE read_at IS NOT NULL AND read_at < now() - make_interval(days => $1)
			               LIMIT 5000)`, days)
		if err != nil {
			slog.Warn("очистка уведомлений", "err", err)
			return
		}
		total += tag.RowsAffected()
		if tag.RowsAffected() < 5000 {
			break
		}
		time.Sleep(200 * time.Millisecond)
	}
	if total > 0 {
		slog.Info("удалены старые прочитанные уведомления", "count", total, "older_than_days", days)
	}
}
