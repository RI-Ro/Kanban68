// Модуль предназначен для работы с задачами: выборки (доска, все задачи, входящие), создание, изменение, перенос,
// копирование, перемещение между колонками, завершение, удаление, чек-лист, точечные права, отметки исполнителей,
// отчёт и готовность к сдаче.

package handlers

import (
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"context"
	"errors"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/models"
)

// Константа taskSelect задаёт единую выборку задачи для обработчиков модуля. Поле created_by возвращается всегда
// (используется во «Входящих»).
const taskSelect = `
	SELECT t.id, t.board_id, t.column_id, t.title, t.description, t.priority::text, t.color,
	       to_char(t.due_date, 'YYYY-MM-DD'),
	       t.incoming_number, to_char(t.incoming_date, 'YYYY-MM-DD'), t.position, t.tags, t.completed_at, t.created_by,
	       COALESCE(app.task_access(t.id, $1), 'read'),
	       COALESCE(array_agg(DISTINCT a.user_id) FILTER (WHERE a.user_id IS NOT NULL), '{}'),
	       COALESCE(array_agg(DISTINCT a.user_id) FILTER (WHERE a.completed_at IS NOT NULL), '{}'),
	       (SELECT count(*) FROM app.comments cm   WHERE cm.task_id = t.id),
	       (SELECT count(*) FROM app.attachments f WHERE f.task_id = t.id),
	       (SELECT count(*) FROM app.task_steps xs WHERE xs.task_id = t.id),
	       (SELECT count(*) FROM app.task_steps xs WHERE xs.task_id = t.id AND xs.done),
	       t.created_at, t.updated_at,
	       app.board_title(t.board_id), app.column_title(t.column_id),
	       t.recur_freq, t.recur_interval, t.recur_weekdays, t.recur_monthday,
	       to_char(t.recur_until, 'YYYY-MM-DD'), t.report,
	       app.assignees_seen(t.id),
	       app.assignees_fresh(t.id),
	       app.task_activity_at(t.id, $1),
	       app.seen_at('task', t.id, $1),
	       t.ready_at, t.ready_by,
	       (SELECT h.user_id FROM app.task_assignees h WHERE h.task_id = t.id AND h.is_head)
	  FROM app.tasks t
	  LEFT JOIN app.task_assignees a ON a.task_id = t.id`

// Функция scanTasks предназначена для чтения строк запроса в список задач.
func scanTasks(rows pgx.Rows) ([]models.Task, error) {
	out := []models.Task{}
	for rows.Next() {
		var t models.Task
		if err := rows.Scan(&t.ID, &t.BoardID, &t.ColumnID, &t.Title, &t.Description,
			&t.Priority, &t.Color, &t.DueDate, &t.IncomingNumber, &t.IncomingDate, &t.Position, &t.Tags, &t.CompletedAt, &t.CreatedBy, &t.Access,
			&t.Assignees, &t.AssigneesDone, &t.CommentCnt, &t.AttachCnt, &t.ExtStepCnt, &t.ExtStepDone, &t.CreatedAt, &t.UpdatedAt,
			&t.BoardTitle, &t.ColumnTitle,
			&t.RecurFreq, &t.RecurInterval, &t.RecurWeekdays, &t.RecurMonthday, &t.RecurUntil, &t.Report,
			&t.AssigneesSeen, &t.AssigneesFresh, &t.LastActivityAt, &t.SeenAt,
			&t.ReadyAt, &t.ReadyBy, &t.HeadAssignee); err != nil {
			return nil, err
		}
		out = append(out, t)
	}
	return out, rows.Err()
}

// Функция attachSteps предназначена для загрузки пунктов чек-листа и прав доступа для всей выборки одним запросом.
func attachSteps(ctx context.Context, tx pgx.Tx, tasks []models.Task) error {
	if len(tasks) == 0 {
		return nil
	}
	ids := make([]uuid.UUID, len(tasks))
	index := make(map[uuid.UUID]int, len(tasks))
	for i, t := range tasks {
		ids[i] = t.ID
		index[t.ID] = i
		tasks[i].Steps = []models.Step{}
		tasks[i].Grants = []models.Grant{}
	}

	// Отметки «избранное» текущего пользователя (RLS оставляет только его строки).
	favRows, err := tx.Query(ctx, `SELECT task_id FROM app.task_favorites WHERE task_id = ANY($1)`, ids)
	if err != nil {
		return err
	}
	for favRows.Next() {
		var id uuid.UUID
		if err := favRows.Scan(&id); err != nil {
			favRows.Close()
			return err
		}
		if i, ok := index[id]; ok {
			tasks[i].Favorite = true
		}
	}
	favRows.Close()

	rows, err := tx.Query(ctx, `
		SELECT task_id, id, body, done, position, assignee_id,
		       to_char(due_date, 'YYYY-MM-DD'),
		       done_by, to_char(done_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
		  FROM app.task_steps WHERE task_id = ANY($1) ORDER BY position`, ids)
	if err != nil {
		return err
	}
	for rows.Next() {
		var taskID uuid.UUID
		var st models.Step
		if err := rows.Scan(&taskID, &st.ID, &st.Body, &st.Done, &st.Position,
			&st.AssigneeID, &st.DueDate, &st.DoneBy, &st.DoneAt); err != nil {
			rows.Close()
			return err
		}
		if i, ok := index[taskID]; ok {
			tasks[i].Steps = append(tasks[i].Steps, st)
		}
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return err
	}

	grantRows, err := tx.Query(ctx, `
		SELECT task_id, user_id, access::text
		  FROM app.task_grants WHERE task_id = ANY($1)`, ids)
	if err != nil {
		return err
	}
	defer grantRows.Close()
	for grantRows.Next() {
		var taskID uuid.UUID
		var g models.Grant
		if err := grantRows.Scan(&taskID, &g.UserID, &g.Access); err != nil {
			return err
		}
		if i, ok := index[taskID]; ok {
			tasks[i].Grants = append(tasks[i].Grants, g)
		}
	}
	return grantRows.Err()
}

// Метод ListTasks предназначен для получения задач проекта.
func (s *Server) ListTasks(c *fiber.Ctx) error {
	boardID, err := param(c, "boardID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var tasks []models.Task
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), taskSelect+`
			 WHERE t.board_id = $2 AND NOT t.archived
			 GROUP BY t.id
			 ORDER BY t.position`, uid, boardID)
		if e != nil {
			return e
		}
		tasks, e = scanTasks(rows)
		rows.Close()
		if e != nil {
			return e
		}
		return attachSteps(c.Context(), tx, tasks)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, tasks)
}

// Метод SearchTaskIDs предназначен для обработки запроса GET /tasks-search?q=: возвращает идентификаторы доступных
// пользователю задач, в комментариях или отчёте которых встречается строка. Клиент дополняет ими поиск по полям задачи.
func (s *Server) SearchTaskIDs(c *fiber.Ctx) error {
	q := strings.TrimSpace(c.Query("q"))
	ids := []uuid.UUID{}
	if len([]rune(q)) < 2 {
		return httpx.JSON(c, fiber.StatusOK, ids)
	}
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT t.id FROM app.tasks t
			 WHERE NOT t.archived
			   AND (t.report ILIKE '%' || $1 || '%'
			        OR EXISTS (SELECT 1 FROM app.comments cq WHERE cq.task_id = t.id AND cq.body ILIKE '%' || $1 || '%'))
			 LIMIT 500`, q)
		if e != nil {
			return e
		}
		ids, e = pgx.CollectRows(rows, pgx.RowTo[uuid.UUID])
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, ids)
}

// Метод AllTasks предназначен для получения всех доступных пользователю задач из всех проектов
// (вкладка «Все задачи»); видимость ограничивает RLS.
func (s *Server) AllTasks(c *fiber.Ctx) error {
	uid := s.uid(c)

	q := strings.TrimSpace(c.Query("q"))
	status := c.Query("status", "all")
	scope := c.Query("scope", "all")
	limit := c.QueryInt("limit", 50)
	offset := c.QueryInt("offset", 0)
	// Размер страницы ограничен 200 записями.
	if limit < 1 || limit > 200 {
		limit = 50
	}
	if offset < 0 {
		offset = 0
	}

	// Списки передаются строкой через запятую.
	list := func(name string) []string {
		v := strings.TrimSpace(c.Query(name))
		if v == "" {
			return nil
		}
		out := []string{}
		for _, part := range strings.Split(v, ",") {
			if p := strings.TrimSpace(part); p != "" {
				out = append(out, p)
			}
		}
		return out
	}

	priorities := list("priority")
	assignees := list("assignee")
	tags := list("tag")
	boardID := strings.TrimSpace(c.Query("boardId"))
	dueFrom := strings.TrimSpace(c.Query("dueFrom"))
	dueTo := strings.TrimSpace(c.Query("dueTo"))

	// Даты завершения передаются моментами, так как completed_at имеет тип timestamptz.
	moment := func(name string) (*time.Time, error) {
		v := strings.TrimSpace(c.Query(name))
		if v == "" {
			return nil, nil
		}
		t, e := time.Parse(time.RFC3339Nano, v)
		if e != nil {
			return nil, httpx.Err(fiber.StatusBadRequest, "bad_date",
				"Неверная дата в фильтре по дате завершения")
		}
		return &t, nil
	}
	completedFrom, err := moment("completedFrom")
	if err != nil {
		return httpx.Fail(c, err)
	}
	completedTo, err := moment("completedTo")
	if err != nil {
		return httpx.Fail(c, err)
	}

	// Условия собираются один раз и используются и для страницы, и для подсчёта общего числа.
	where := []string{"NOT t.archived"}
	args := []any{uid}
	add := func(cond string, v any) {
		args = append(args, v)
		where = append(where, fmt.Sprintf(cond, len(args)))
	}

	if q != "" {
		add(`(t.title ILIKE '%%' || $%[1]d || '%%'
		      OR t.description ILIKE '%%' || $%[1]d || '%%'
		      OR t.incoming_number ILIKE '%%' || $%[1]d || '%%'
		      OR t.report ILIKE '%%' || $%[1]d || '%%'
		      OR EXISTS (SELECT 1 FROM app.comments cq WHERE cq.task_id = t.id AND cq.body ILIKE '%%' || $%[1]d || '%%')
		      OR EXISTS (SELECT 1 FROM unnest(t.tags) tg WHERE tg ILIKE '%%' || $%[1]d || '%%'))`, q)
	}
	if boardID != "" {
		add(`t.board_id = $%d::uuid`, boardID)
	}
	if len(priorities) > 0 {
		add(`t.priority::text = ANY($%d::text[])`, priorities)
	}
	if len(tags) > 0 {
		add(`t.tags && $%d::text[]`, tags)
	}
	if len(assignees) > 0 {
		add(`EXISTS (SELECT 1 FROM app.task_assignees a2
		              WHERE a2.task_id = t.id AND a2.user_id = ANY($%d::uuid[]))`, assignees)
	}
	if dueFrom != "" {
		add(`t.due_date >= $%d::date`, dueFrom)
	}
	if dueTo != "" {
		add(`t.due_date <= $%d::date`, dueTo)
	}
	// Незавершённые задачи (completed_at IS NULL) не подходят под сравнение дат.
	if completedFrom != nil {
		add(`t.completed_at >= $%d::timestamptz`, *completedFrom)
	}
	if completedTo != nil {
		add(`t.completed_at < $%d::timestamptz`, *completedTo)
	}

	// Параметр hideMyDone=1 скрывает задачи, где сам пользователь (или тот, кого он замещает) уже поставил отметку
	// о выполнении своего этапа.
	if c.Query("hideMyDone") == "1" {
		where = append(where, `NOT EXISTS (SELECT 1 FROM app.task_assignees dm
		        WHERE dm.task_id = t.id AND dm.completed_at IS NOT NULL
		          AND dm.user_id IN (SELECT app.effective_users($1::uuid)))`)
	}

	// Параметр favorite=1 оставляет избранные задачи пользователя; favorite=0 — не избранные.
	// Параметр favoriteOpen=1 используется вкладкой «Избранные»: закрытые задачи в ней не показываются.
	switch c.Query("favorite") {
	case "1":
		where = append(where, `EXISTS (SELECT 1 FROM app.task_favorites fv WHERE fv.task_id = t.id AND fv.user_id = $1::uuid)`)
	case "0":
		where = append(where, `NOT EXISTS (SELECT 1 FROM app.task_favorites fv WHERE fv.task_id = t.id AND fv.user_id = $1::uuid)`)
	}

	switch status {
	case "active":
		where = append(where, "t.completed_at IS NULL")
	case "done":
		where = append(where, "t.completed_at IS NOT NULL")
	case "overdue":
		where = append(where,
			"t.completed_at IS NULL AND t.due_date IS NOT NULL AND t.due_date < current_date")
	case "ready":
		// Раздел «Готовы к сдаче»: завершённые задачи не включаются.
		where = append(where, "t.ready_at IS NOT NULL AND t.completed_at IS NULL")
	}

	if scope == "mine" {
		// Раздел «Мои»: автор, исполнитель или обладатель точечного доступа; замещение учитывается как в правах.
		where = append(where, `(
			t.created_by IN (SELECT app.effective_users($1))
			OR EXISTS (SELECT 1 FROM app.task_assignees a3
			            WHERE a3.task_id = t.id
			              AND a3.user_id IN (SELECT app.effective_users($1)))
			OR EXISTS (SELECT 1 FROM app.task_grants g3
			            WHERE g3.task_id = t.id
			              AND g3.user_id IN (SELECT app.effective_users($1)))
		)`)
	}

	// Направление сортировки выбирается из белого списка.
	dir := "DESC"
	if strings.EqualFold(c.Query("dir"), "asc") {
		dir = "ASC"
	}
	order := "t.updated_at " + dir
	switch c.Query("sort") {
	case "due":
		// Задачи без срока размещаются в конце.
		order = "t.due_date " + dir + " NULLS LAST"
	case "priority":
		order = `CASE t.priority::text
		           WHEN 'urgent' THEN 4 WHEN 'high' THEN 3
		           WHEN 'medium' THEN 2 ELSE 1 END ` + dir
	case "completed":
		// Незавершённые задачи размещаются в конце.
		order = "t.completed_at " + dir + " NULLS LAST"
	case "created":
		order = "t.created_at " + dir
	case "title":
		order = "t.title " + dir
	case "favorite":
		order = "(EXISTS (SELECT 1 FROM app.task_favorites fo WHERE fo.task_id = t.id AND fo.user_id = $1::uuid)) " + dir + ", t.updated_at DESC"
	case "board":
		order = "app.board_title(t.board_id) " + dir + ", t.updated_at DESC"
	}

	cond := strings.Join(where, " AND ")

	var tasks []models.Task
	var total int
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Общее число подсчитывается отдельным запросом без выборки полей.
		if e := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM app.tasks t
			  WHERE `+cond+` AND $1::uuid IS NOT NULL`, args...).Scan(&total); e != nil {
			return e
		}

		// Страница выбирается в два шага: сначала только идентификаторы с отбором и сортировкой, затем подробности
		// (исполнители, счётчики, отметки просмотра) только для задач страницы. Раньше подробности вычислялись для
		// всех подходящих задач до отсечения страницы.
		pageArgs := append(append([]any{}, args...), limit, offset)
		idRows, e := tx.Query(c.Context(), `
			SELECT t.id FROM app.tasks t
			 WHERE `+cond+` AND $1::uuid IS NOT NULL
			 ORDER BY `+order+`, t.id
			 LIMIT $`+strconv.Itoa(len(args)+1)+` OFFSET $`+strconv.Itoa(len(args)+2),
			pageArgs...)
		if e != nil {
			return e
		}
		ids, e := scanIDs(idRows)
		if e != nil {
			return e
		}
		if len(ids) == 0 {
			return nil
		}
		rows, e := tx.Query(c.Context(), taskSelect+`
			 WHERE t.id = ANY($2::uuid[])
			 GROUP BY t.id`, uid, ids)
		if e != nil {
			return e
		}
		tasks, e = scanTasks(rows)
		rows.Close()
		if e != nil {
			return e
		}
		pos := make(map[uuid.UUID]int, len(ids))
		for i, id := range ids {
			pos[id] = i
		}
		sort.SliceStable(tasks, func(i, j int) bool { return pos[tasks[i].ID] < pos[tasks[j].ID] })
		return attachSteps(c.Context(), tx, tasks)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if tasks == nil {
		tasks = []models.Task{}
	}
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{
		"items": tasks, "total": total, "limit": limit, "offset": offset,
	})
}

// Метод Inbox предназначен для получения задач из чужих проектов, где открыт точечный доступ или назначение.
// Участники проекта в выборку не входят.
func (s *Server) Inbox(c *fiber.Ctx) error {
	uid := s.uid(c)

	var tasks []models.Task
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT t.id, t.board_id, t.column_id, t.title, t.description, t.priority::text, t.color,
			       to_char(t.due_date, 'YYYY-MM-DD'),
			       t.incoming_number, to_char(t.incoming_date, 'YYYY-MM-DD'), t.position, t.tags, t.completed_at, t.created_by,
			       COALESCE(app.task_access(t.id, $1), 'read'),
			       COALESCE(array_agg(DISTINCT a.user_id) FILTER (WHERE a.user_id IS NOT NULL), '{}'),
	       COALESCE(array_agg(DISTINCT a.user_id) FILTER (WHERE a.completed_at IS NOT NULL), '{}'),
			       (SELECT count(*) FROM app.comments c    WHERE c.task_id = t.id),
			       (SELECT count(*) FROM app.attachments f WHERE f.task_id = t.id),
			       t.created_at, t.updated_at, app.board_title(t.board_id),
			       app.assignees_seen(t.id),
			       app.assignees_fresh(t.id),
			       app.task_activity_at(t.id, $1),
			       app.seen_at('task', t.id, $1),
			       t.ready_at, t.ready_by,
			       (SELECT h.user_id FROM app.task_assignees h WHERE h.task_id = t.id AND h.is_head)
			  FROM app.tasks t
			  LEFT JOIN app.task_assignees a ON a.task_id = t.id
			 WHERE app.board_role(t.board_id, $1) IS NULL
			   AND NOT t.archived
			 GROUP BY t.id
			 ORDER BY app.board_title(t.board_id), t.created_at DESC`, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		tasks = []models.Task{}
		for rows.Next() {
			var t models.Task
			if e := rows.Scan(&t.ID, &t.BoardID, &t.ColumnID, &t.Title, &t.Description,
				&t.Priority, &t.Color, &t.DueDate, &t.IncomingNumber, &t.IncomingDate, &t.Position, &t.Tags, &t.CompletedAt, &t.CreatedBy, &t.Access,
				&t.Assignees, &t.AssigneesDone, &t.CommentCnt, &t.AttachCnt, &t.CreatedAt, &t.UpdatedAt,
				&t.BoardTitle, &t.AssigneesSeen, &t.AssigneesFresh,
				&t.LastActivityAt, &t.SeenAt, &t.ReadyAt, &t.ReadyBy, &t.HeadAssignee); e != nil {
				return e
			}
			tasks = append(tasks, t)
		}
		if e := rows.Err(); e != nil {
			return e
		}
		return attachSteps(c.Context(), tx, tasks)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, tasks)
}

// Метод GetTask предназначен для получения задачи по идентификатору.
func (s *Server) GetTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	// Чтение задачи не отмечает её просмотренной.
	t, err := s.loadTaskView(c, taskID, false)
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, t)
}

// Метод loadTask предназначен для получения карточки в ответ на действие пользователя; задача отмечается просмотренной.
func (s *Server) loadTask(c *fiber.Ctx, taskID uuid.UUID) (models.Task, error) {
	return s.loadTaskView(c, taskID, true)
}

// Метод loadTaskView предназначен для получения карточки с необязательной отметкой просмотра.
func (s *Server) loadTaskView(c *fiber.Ctx, taskID uuid.UUID, markSeen bool) (models.Task, error) {
	uid := s.uid(c)
	var t models.Task

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Отметка ставится до выборки, чтобы ответ содержал актуальные отметки просмотра.
		if markSeen {
			if _, e := tx.Exec(c.Context(),
				`SELECT app.mark_seen('task', $1, $2)`, taskID, uid); e != nil {
				return e
			}
		}
		rows, e := tx.Query(c.Context(), taskSelect+` WHERE t.id = $2 GROUP BY t.id`, uid, taskID)
		if e != nil {
			return e
		}
		tasks, e := scanTasks(rows)
		rows.Close()
		if e != nil {
			return e
		}
		if len(tasks) == 0 {
			return pgx.ErrNoRows
		}
		if e := attachSteps(c.Context(), tx, tasks); e != nil {
			return e
		}
		t = tasks[0]
		return nil
	})
	return t, err
}

// Метод loadTasksByColumns предназначен для получения задач нескольких колонок после перемещения.
func (s *Server) loadTasksByColumns(c *fiber.Ctx, columnIDs []uuid.UUID) ([]models.Task, error) {
	uid := s.uid(c)
	var tasks []models.Task
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), taskSelect+`
			 WHERE t.column_id = ANY($2::uuid[])
			 GROUP BY t.id`, uid, columnIDs)
		if e != nil {
			return e
		}
		tasks, e = scanTasks(rows)
		rows.Close()
		if e != nil {
			return e
		}
		return attachSteps(c.Context(), tx, tasks)
	})
	return tasks, err
}

// Тип taskInput предназначен для разбора тела запроса создания задачи.
type taskInput struct {
	Title       string      `json:"title"`
	Description string      `json:"description"`
	Priority    string      `json:"priority"`
	Color       string      `json:"color"`
	IncomingNumber string   `json:"incomingNumber"`
	IncomingDate   *string  `json:"incomingDate"`
	ColumnID    uuid.UUID   `json:"columnId"`
	DueDate     *string     `json:"dueDate"`
	Tags        []string    `json:"tags"`
	Assignees   []uuid.UUID `json:"assignees"`
	// Периодичность; пустое значение или none означает отсутствие повторения.
	RecurFreq     string `json:"recurFreq"`
	RecurInterval int    `json:"recurInterval"`
	RecurWeekdays []int  `json:"recurWeekdays"`
	RecurMonthday *int   `json:"recurMonthday"`
	RecurUntil    *string `json:"recurUntil"`
	// Поле ClearRecur принимается формой, при создании не используется.
	ClearRecur bool `json:"clearRecur"`
	// Чек-лист, заполненный в форме создания; пункты создаются в одной транзакции с задачей.
	Steps []taskStepInput `json:"steps"`
}

// Тип taskStepInput предназначен для описания пункта чек-листа в форме создания задачи.
type taskStepInput struct {
	Body       string     `json:"body"`
	AssigneeID *uuid.UUID `json:"assigneeId"`
	DueDate    *string    `json:"dueDate"`
}

// Функция normalizeRecurrence предназначена для приведения правила повторения к согласованному виду;
// некорректные сочетания сбрасываются в «без повторения».
func normalizeRecurrence(freq string, interval int, weekdays []int, monthday *int) (string, int, []int, *int) {
	switch freq {
	case "daily", "weekly", "monthly":
	default:
		return "none", 1, []int{}, nil
	}
	if interval < 1 {
		interval = 1
	}
	if weekdays == nil {
		weekdays = []int{}
	}
	if freq != "weekly" {
		weekdays = []int{}
	}
	if freq != "monthly" {
		monthday = nil
	}
	return freq, interval, weekdays, monthday
}

// Метод CreateTask предназначен для создания задачи.
func (s *Server) CreateTask(c *fiber.Ctx) error {
	boardID, err := param(c, "boardID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in taskInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	in.Title = strings.TrimSpace(in.Title)
	if in.Title == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty_title", "Название задачи не может быть пустым"))
	}
	if in.Priority == "" {
		in.Priority = "medium"
	}
	if in.Color == "" {
		in.Color = "none"
	}
	if in.Tags == nil {
		in.Tags = []string{}
	}
	uid := s.uid(c)

	// Идентификатор формируется на сервере: политика tasks_select проверяет видимость через app.can_see_task,
	// а при RETURNING строка проверяется до появления связей доступа.
	taskID := uuid.New()
	rFreq, rInt, rWeek, rMonth := normalizeRecurrence(in.RecurFreq, in.RecurInterval, in.RecurWeekdays, in.RecurMonthday)
	var pending []pendingNotif
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(), `
			INSERT INTO app.tasks (id, board_id, column_id, title, description, priority, color,
			                       due_date, tags, incoming_number, incoming_date, position, created_by,
			                       recur_freq, recur_interval, recur_weekdays, recur_monthday, recur_until)
			-- incoming_number объявлен NOT NULL DEFAULT '': если поле в
			-- запросе не пришло вовсе, подставляем пустую строку, а не
			-- NULL, иначе вставка упадёт на ограничении.
			VALUES ($1, $2, $3, $4, $5, $6::app.task_priority, $7, $8::date, $9, COALESCE($10, ''), $11::date,
			        COALESCE((SELECT max(position) + 1 FROM app.tasks WHERE column_id = $3), 0), $12,
			        $13, $14, $15, $16, $17::date)`,
			taskID, boardID, in.ColumnID, in.Title, in.Description, in.Priority, in.Color,
			in.DueDate, in.Tags, in.IncomingNumber, in.IncomingDate, uid,
			rFreq, rInt, rWeek, rMonth, in.RecurUntil); e != nil {
			return e
		}
		var e error
		pending, _, e = s.replaceAssignees(c.Context(), tx, taskID, in.Assignees, uid, boardID)
		if e != nil {
			return e
		}
		// Чек-лист из формы создания; исполнитель пункта добавляется в исполнители задачи.
		pos := 0
		for _, st := range in.Steps {
			body := strings.TrimSpace(st.Body)
			if body == "" {
				continue
			}
			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.task_steps (task_id, body, position, assignee_id, due_date, created_by)
				VALUES ($1, $2, $3, $4, $5::date, $6)`,
				taskID, body, pos, st.AssigneeID, st.DueDate, uid); e != nil {
				return e
			}
			if st.AssigneeID != nil {
				if _, e := tx.Exec(c.Context(), `SELECT app.ensure_assignee($1, $2, $3)`,
					taskID, *st.AssigneeID, uid); e != nil {
					return e
				}
			}
			pos++
		}

		_, e = tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, 'Задача создана')`,
			taskID, uid)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.flushNotifs(pending)

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "created")
	return httpx.JSON(c, fiber.StatusCreated, t)
}

// Метод TransferTask предназначен для переноса задачи в другой проект вместе с исполнителями, комментариями,
// файлами, чек-листом, отчётом и историей.
func (s *Server) TransferTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in copyTaskInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.BoardID == uuid.Nil || in.ColumnID == uuid.Nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_target",
			"Выберите проект и колонку, куда переносить задачу"))
	}
	uid := s.uid(c)

	var oldBoardID uuid.UUID
	var pending []pendingNotif
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var title string
		if e := tx.QueryRow(c.Context(),
			`SELECT board_id, title FROM app.tasks WHERE id = $1`, taskID).
			Scan(&oldBoardID, &title); e != nil {
			return e
		}
		if oldBoardID == in.BoardID {
			return httpx.Err(fiber.StatusBadRequest, "same_board",
				"Задача уже находится в этом проекте")
		}

		var canEdit bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_edit_board($1, $2)`, in.BoardID, uid).Scan(&canEdit); e != nil {
			return e
		}
		if !canEdit {
			return httpx.Err(fiber.StatusForbidden, "not_editor",
				"Переносить задачи можно только в проект, где вы владелец или редактор")
		}

		var okCol bool
		if e := tx.QueryRow(c.Context(),
			`SELECT EXISTS (SELECT 1 FROM app.columns WHERE id = $1 AND board_id = $2)`,
			in.ColumnID, in.BoardID).Scan(&okCol); e != nil {
			return e
		}
		if !okCol {
			return httpx.Err(fiber.StatusBadRequest, "bad_column",
				"Колонка не принадлежит выбранному проекту")
		}

		tag, e := tx.Exec(c.Context(), `
			UPDATE app.tasks
			   SET board_id  = $2,
			       column_id = $3,
			       position  = COALESCE((SELECT max(position) + 1 FROM app.tasks WHERE column_id = $3), 0)
			 WHERE id = $1`, taskID, in.BoardID, in.ColumnID)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			// Политика tasks_update отклонила изменение: задача чужая.
			return httpx.ErrForbidden
		}

		// Исполнители сохраняются; доступ к задаче в новом проекте обеспечивается назначением.
		var boardTitle string
		if e := tx.QueryRow(c.Context(),
			`SELECT app.board_title($1)`, in.BoardID).Scan(&boardTitle); e != nil {
			return e
		}
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, "Задача перенесена в проект «"+boardTitle+"»"); e != nil {
			return e
		}

		// Порядок текста уведомления: кто, что, где (см. notifyPhrase).
		var actorName string
		if e := tx.QueryRow(c.Context(),
			`SELECT COALESCE(full_name, 'Пользователь') FROM app.users WHERE id = $1`,
			uid).Scan(&actorName); e != nil {
			return e
		}
		pending, e = s.notifyTaskWatchers(c.Context(), tx, taskID, in.BoardID, uid,
			notifyPhrase(actorName, "перенёс(ла) задачу «"+title+"» в проект «"+boardTitle+"»", "", ""))
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.flushNotifs(pending)

	// Задача сначала снимается с прежней доски, затем публикуется как новая.
	s.publishTaskDeletedTo(s.watchersOfBoard(c.Context(), oldBoardID), oldBoardID, taskID)

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "created")
	return httpx.JSON(c, fiber.StatusOK, t)
}

// Тип copyTaskInput предназначен для разбора тела запроса копирования задачи.
type copyTaskInput struct {
	BoardID  uuid.UUID `json:"boardId"`
	ColumnID uuid.UUID `json:"columnId"`
}

// Метод CopyTask предназначен для создания копии задачи в выбранном проекте и колонке: поля, чек-лист (обычный
// и расширенный) и теги. Исполнители и точечные права не копируются.
func (s *Server) CopyTask(c *fiber.Ctx) error {
	srcID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in copyTaskInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.BoardID == uuid.Nil || in.ColumnID == uuid.Nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_target",
			"Выберите проект и колонку для копии"))
	}
	uid := s.uid(c)
	newID := uuid.New()

	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Право создавать в целевом проекте имеет участник в любой роли; проверка выполняется явно для понятной ошибки.
		var role *string
		if e := tx.QueryRow(c.Context(),
			`SELECT app.board_role($1, $2)`, in.BoardID, uid).Scan(&role); e != nil {
			return e
		}
		if role == nil {
			return httpx.Err(fiber.StatusForbidden, "not_member",
				"Нет прав на создание задач в выбранном проекте")
		}

		// Целевая колонка должна принадлежать целевому проекту.
		var okCol bool
		if e := tx.QueryRow(c.Context(),
			`SELECT EXISTS (SELECT 1 FROM app.columns WHERE id = $1 AND board_id = $2)`,
			in.ColumnID, in.BoardID).Scan(&okCol); e != nil {
			return e
		}
		if !okCol {
			return httpx.Err(fiber.StatusBadRequest, "bad_column",
				"Колонка не принадлежит выбранному проекту")
		}

		// Копия вставляется выборкой из исходной задачи; видимость исходной задачи обеспечивает RLS.
		tag, e := tx.Exec(c.Context(), `
			INSERT INTO app.tasks (id, board_id, column_id, title, description, priority, color,
			                       due_date, tags, incoming_number, incoming_date, position, created_by)
			SELECT $1, $2, $3,
			       t.title, t.description, t.priority, t.color,
			       t.due_date, t.tags, t.incoming_number, t.incoming_date,
			       COALESCE((SELECT max(position) + 1 FROM app.tasks WHERE column_id = $3), 0), $4
			  FROM app.tasks t WHERE t.id = $5`,
			newID, in.BoardID, in.ColumnID, uid, srcID)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrNotFound
		}

		// Чек-лист копируется со сбросом отметок; исполнитель и срок пункта сохраняются.
		if _, e := tx.Exec(c.Context(), `
			INSERT INTO app.task_steps (task_id, body, done, position, assignee_id, due_date, created_by)
			SELECT $1, body, false, position, assignee_id, due_date, $2
			  FROM app.task_steps WHERE task_id = $3`, newID, uid, srcID); e != nil {
			return e
		}

		_, e = tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, 'Задача создана копированием')`,
			newID, uid)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	t, err := s.loadTask(c, newID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "created")
	return httpx.JSON(c, fiber.StatusCreated, t)
}

// Метод replaceAssignees предназначен для замены состава исполнителей; возвращает также список потерявших доступ
// к задаче для рассылки событий.
func (s *Server) replaceAssignees(ctx context.Context, tx pgx.Tx, taskID uuid.UUID,
	assignees []uuid.UUID, actor, boardID uuid.UUID) ([]pendingNotif, []uuid.UUID, error) {

	// Автор и название задачи для текста уведомления.
	var actorName, taskTitle string
	if e := tx.QueryRow(ctx, `
		SELECT COALESCE(u.full_name, 'Пользователь'), t.title
		  FROM app.tasks t LEFT JOIN app.users u ON u.id = $2
		 WHERE t.id = $1`, taskID, actor).Scan(&actorName, &taskTitle); e != nil {
		return nil, nil, e
	}

	// Прежний состав нужен для записи в историю добавленных и снятых исполнителей.
	oldRows, err := tx.Query(ctx, `SELECT user_id FROM app.task_assignees WHERE task_id = $1`, taskID)
	if err != nil {
		return nil, nil, err
	}
	oldSet := map[uuid.UUID]bool{}
	for oldRows.Next() {
		var id uuid.UUID
		if e := oldRows.Scan(&id); e != nil {
			oldRows.Close()
			return nil, nil, e
		}
		oldSet[id] = true
	}
	oldRows.Close()
	if e := oldRows.Err(); e != nil {
		return nil, nil, e
	}

	newSet := map[uuid.UUID]bool{}
	for _, a := range assignees {
		newSet[a] = true
	}

	// Головной исполнитель сохраняется, если остаётся в составе.
	var oldHead *uuid.UUID
	_ = tx.QueryRow(ctx, `SELECT user_id FROM app.task_assignees WHERE task_id = $1 AND is_head`, taskID).Scan(&oldHead)
	if _, err := tx.Exec(ctx, `DELETE FROM app.task_assignees WHERE task_id = $1`, taskID); err != nil {
		return nil, nil, err
	}
	defer func() {
		if oldHead != nil && newSet[*oldHead] {
			_, _ = tx.Exec(ctx, `UPDATE app.task_assignees SET is_head = true WHERE task_id = $1 AND user_id = $2`, taskID, *oldHead)
		}
	}()
	var pending []pendingNotif
	var added, removed []uuid.UUID
	for _, a := range assignees {
		if _, err := tx.Exec(ctx, `
			INSERT INTO app.task_assignees (task_id, user_id) VALUES ($1, $2)
			ON CONFLICT DO NOTHING`, taskID, a); err != nil {
			return nil, nil, err
		}
		if !oldSet[a] {
			added = append(added, a)
			// Уведомление получают только новые исполнители.
			if a != actor {
				n, err := notifyInsertCat(ctx, tx, a,
					notifyPhrase(actorName, "назначил(а) вас исполнителем задачи «"+taskTitle+"»", "", ""),
					"assigned", &boardID, &taskID)
				if err != nil {
					return nil, nil, err
				}
				if n.ID != uuid.Nil {
					pending = append(pending, pendingNotif{UserID: a, Notif: n})
				}
			}
		}
	}
	for id := range oldSet {
		if !newSet[id] {
			removed = append(removed, id)
		}
	}

	// В журнал записываются добавленные и удалённые исполнители.
	if len(added) > 0 {
		if names, e := userNames(ctx, tx, added); e == nil && names != "" {
			_, _ = tx.Exec(ctx, `INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1,$2,$3)`,
				taskID, actor, "Добавлены исполнители: "+names)
		}
	}
	if len(removed) > 0 {
		if names, e := userNames(ctx, tx, removed); e == nil && names != "" {
			_, _ = tx.Exec(ctx, `INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1,$2,$3)`,
				taskID, actor, "Удалены исполнители: "+names)
		}
	}
	// Потерявшие доступ получают событие об удалении карточки.
	var lost []uuid.UUID
	for _, id := range removed {
		var visible bool
		if e := tx.QueryRow(ctx,
			`SELECT app.can_see_task($1, $2)`, taskID, id).Scan(&visible); e != nil {
			return nil, nil, e
		}
		if !visible {
			lost = append(lost, id)
		}
	}

	return pending, lost, nil
}

// Функция userNames предназначена для получения ФИО пользователей через запятую для журнала.
func userNames(ctx context.Context, tx pgx.Tx, ids []uuid.UUID) (string, error) {
	if len(ids) == 0 {
		return "", nil
	}
	rows, err := tx.Query(ctx,
		`SELECT full_name FROM app.users WHERE id = ANY($1) ORDER BY full_name`, ids)
	if err != nil {
		return "", err
	}
	defer rows.Close()
	var names []string
	for rows.Next() {
		var n string
		if e := rows.Scan(&n); e != nil {
			return "", e
		}
		names = append(names, n)
	}
	return strings.Join(names, ", "), rows.Err()
}

// Тип taskPatch предназначен для разбора тела запроса изменения задачи.
type taskPatch struct {
	Title       *string      `json:"title"`
	Description *string      `json:"description"`
	Priority    *string      `json:"priority"`
	Color       *string      `json:"color"`
	IncomingNumber *string   `json:"incomingNumber"`
	IncomingDate   *string   `json:"incomingDate"`
	ColumnID    *uuid.UUID   `json:"columnId"`
	DueDate     *string      `json:"dueDate"`
	Tags        *[]string    `json:"tags"`
	Assignees   *[]uuid.UUID `json:"assignees"`
	RecurFreq     *string `json:"recurFreq"`
	RecurInterval *int    `json:"recurInterval"`
	RecurWeekdays *[]int  `json:"recurWeekdays"`
	RecurMonthday *int    `json:"recurMonthday"`
	RecurUntil    *string `json:"recurUntil"`
	// Поле ClearRecur — явный сброс периодичности; отсутствие поля означает «не менять».
	ClearRecur bool `json:"clearRecur"`
}

// Метод UpdateTask предназначен для изменения задачи с записью изменений в журнал.
func (s *Server) UpdateTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in taskPatch
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var pending []pendingNotif
	// Проект и список потерявших доступ используются после транзакции для рассылки событий.
	var boardID uuid.UUID
	var lostAccess []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Прежние значения нужны для записи в журнал конкретных изменений.
		var old struct {
			Title, Desc, Priority, Color, IncNum string
			DueDate, IncDate                     *string
			ColumnID                             uuid.UUID
			RecurFreq                            string
			Tags                                 []string
		}
		if e := tx.QueryRow(c.Context(), `
			SELECT board_id, title, description, priority::text, color, incoming_number,
			       to_char(due_date, 'YYYY-MM-DD'), to_char(incoming_date, 'YYYY-MM-DD'),
			       column_id, recur_freq, tags
			  FROM app.tasks WHERE id = $1`, taskID).
			Scan(&boardID, &old.Title, &old.Desc, &old.Priority, &old.Color, &old.IncNum,
				&old.DueDate, &old.IncDate, &old.ColumnID, &old.RecurFreq, &old.Tags); e != nil {
			return e
		}

		tag, e := tx.Exec(c.Context(), `
			UPDATE app.tasks SET
				title       = COALESCE($2, title),
				description = COALESCE($3, description),
				priority    = COALESCE($4::app.task_priority, priority),
				color       = COALESCE($5, color),
				column_id   = COALESCE($6, column_id),
				-- Пустая строка означает «снять значение», отсутствие
				-- поля — «не менять». Через COALESCE, как было раньше,
				-- снять срок было невозможно в принципе: и «не трогай»,
				-- и «убери» приходили как NULL, и обе команды
				-- превращались в «оставь как есть». Пользователь стирал
				-- дату в форме, сохранял — и она возвращалась.
				-- Приведение только через text: параметр всюду один и
				-- тот же, и если написать рядом $7::text и $7::date,
				-- Postgres выведет для него два разных типа и откажется
				-- выполнять запрос («inconsistent types deduced for
				-- parameter»). Отсюда двойное приведение text -> date.
				due_date    = CASE WHEN $7::text IS NULL THEN due_date
				                   WHEN $7::text = ''   THEN NULL
				                   ELSE $7::text::date END,
				tags        = COALESCE($8, tags),
				-- Входящий номер — text NOT NULL DEFAULT '': пустое
				-- значение здесь и есть пустая строка, а не NULL.
				-- Попытка «снять» его через NULL, как это делается с
				-- датами, упиралась в ограничение таблицы и роняла
				-- сохранение задачи целиком. Поэтому обычный COALESCE:
				-- нет поля — не трогаем, пришла пустая строка — она и
				-- записывается.
				incoming_number = COALESCE($9::text, incoming_number),
				incoming_date   = CASE WHEN $10::text IS NULL THEN incoming_date
				                       WHEN $10::text = ''   THEN NULL
				                       ELSE $10::text::date END
			WHERE id = $1`,
			taskID, in.Title, in.Description, in.Priority, in.Color, in.ColumnID, in.DueDate, in.Tags,
			in.IncomingNumber, in.IncomingDate)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}

		// Периодичность: сброс или установка нового правила.
		if in.ClearRecur {
			if _, e := tx.Exec(c.Context(), `
				UPDATE app.tasks SET recur_freq='none', recur_interval=1,
				       recur_weekdays='{}', recur_monthday=NULL, recur_until=NULL
				 WHERE id = $1`, taskID); e != nil {
				return e
			}
		} else if in.RecurFreq != nil {
			interval := 1
			if in.RecurInterval != nil {
				interval = *in.RecurInterval
			}
			var week []int
			if in.RecurWeekdays != nil {
				week = *in.RecurWeekdays
			}
			f, iv, wk, md := normalizeRecurrence(*in.RecurFreq, interval, week, in.RecurMonthday)
			if _, e := tx.Exec(c.Context(), `
				UPDATE app.tasks SET recur_freq=$2, recur_interval=$3, recur_weekdays=$4,
				       recur_monthday=$5, recur_until=$6::date WHERE id = $1`,
				taskID, f, iv, wk, md, in.RecurUntil); e != nil {
				return e
			}
		}

		if in.Assignees != nil {
			pending, lostAccess, e = s.replaceAssignees(c.Context(), tx, taskID, *in.Assignees, uid, boardID)
			if e != nil {
				return e
			}
		}

		// Перенос срока оповещается отдельным уведомлением.
		oldDueStr := ""
		if old.DueDate != nil {
			oldDueStr = *old.DueDate
		}
		if in.DueDate != nil && oldDueStr != *in.DueDate {
			title := old.Title
			if in.Title != nil {
				title = *in.Title
			}
			var actorName string
			if e := tx.QueryRow(c.Context(),
				`SELECT COALESCE(full_name, 'Пользователь') FROM app.users WHERE id = $1`,
				uid).Scan(&actorName); e != nil {
				return e
			}
			what := "перенёс(ла) срок на " + humanDate(*in.DueDate)
			if *in.DueDate == "" {
				what = "снял(а) срок исполнения"
			} else if old.DueDate != nil {
				what += " (было " + humanDate(*old.DueDate) + ")"
			}
			body := notifyPhrase(actorName, what, "задаче", title)
			more, e := s.notifyTaskWatchers(c.Context(), tx, taskID, boardID, uid, body)
			if e != nil {
				return e
			}
			pending = append(pending, more...)
		}

		// Список изменений для журнала.
		changes := describeTaskChanges(old.Title, old.Desc, old.Priority, old.Color, old.IncNum,
			old.DueDate, old.IncDate, old.Tags, old.RecurFreq, in)
		entry := "Задача отредактирована"
		if len(changes) > 0 {
			entry = "Изменено: " + strings.Join(changes, "; ")
		}
		_, e = tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, entry)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.flushNotifs(pending)

	// Исполнители, потерявшие доступ, получают событие об удалении карточки.
	if len(lostAccess) > 0 {
		s.publishTaskDeletedTo(lostAccess, boardID, taskID)
	}

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	return httpx.JSON(c, fiber.StatusOK, t)
}

// Функция humanDate предназначена для преобразования даты из формата YYYY-MM-DD в ДД.ММ.ГГГГ.
func humanDate(iso string) string {
	if len(iso) != 10 {
		return iso
	}
	return iso[8:10] + "." + iso[5:7] + "." + iso[0:4]
}

// Функция describeTaskChanges предназначена для сравнения прежних значений с изменением и формирования описаний
// для журнала; nil в изменении означает, что поле не менялось.
func describeTaskChanges(oldTitle, oldDesc, oldPriority, oldColor, oldIncNum string,
	oldDue, oldIncDate *string, oldTags []string, oldRecur string, in taskPatch) []string {
	var ch []string
	deref := func(p *string) string {
		if p == nil {
			return ""
		}
		return *p
	}
	// Пустое значение в журнале выводится словом.
	val := func(v string) string {
		if strings.TrimSpace(v) == "" {
			return "не указано"
		}
		return "«" + v + "»"
	}
	short := func(v string) string {
		v = strings.Join(strings.Fields(v), " ")
		r := []rune(v)
		if len(r) > 60 {
			return string(r[:60]) + "…"
		}
		return v
	}
	date := func(v string) string {
		if v == "" {
			return "не указан"
		}
		return humanDate(v)
	}

	if in.Title != nil && *in.Title != oldTitle {
		ch = append(ch, "название: "+val(oldTitle)+" → "+val(*in.Title))
	}
	if in.Description != nil && *in.Description != oldDesc {
		switch {
		case strings.TrimSpace(*in.Description) == "":
			ch = append(ch, "описание удалено (было: «"+short(oldDesc)+"»)")
		case strings.TrimSpace(oldDesc) == "":
			ch = append(ch, "добавлено описание: «"+short(*in.Description)+"»")
		default:
			ch = append(ch, "описание: «"+short(oldDesc)+"» → «"+short(*in.Description)+"»")
		}
	}
	if in.Priority != nil && *in.Priority != oldPriority {
		ch = append(ch, "приоритет: "+priorityLabel(oldPriority)+" → "+priorityLabel(*in.Priority))
	}
	if in.Color != nil && *in.Color != oldColor {
		ch = append(ch, "цвет карточки изменён")
	}
	if in.IncomingNumber != nil && *in.IncomingNumber != oldIncNum {
		ch = append(ch, "входящий №: "+val(oldIncNum)+" → "+val(*in.IncomingNumber))
	}
	if in.DueDate != nil && deref(in.DueDate) != deref(oldDue) {
		if *in.DueDate == "" {
			ch = append(ch, "срок снят (был "+date(deref(oldDue))+")")
		} else {
			ch = append(ch, "срок: "+date(deref(oldDue))+" → "+date(*in.DueDate))
		}
	}
	if in.IncomingDate != nil && deref(in.IncomingDate) != deref(oldIncDate) {
		ch = append(ch, "дата входящего: "+date(deref(oldIncDate))+" → "+date(deref(in.IncomingDate)))
	}
	// Форма присылает состав целиком, поэтому изменения определяются сравнением со старым значением.
	if in.Tags != nil && !sameStrings(oldTags, *in.Tags) {
		switch {
		case len(*in.Tags) == 0:
			ch = append(ch, "теги убраны (были #"+strings.Join(oldTags, " #")+")")
		case len(oldTags) == 0:
			ch = append(ch, "теги: #"+strings.Join(*in.Tags, " #"))
		default:
			ch = append(ch, "теги: #"+strings.Join(oldTags, " #")+" → #"+strings.Join(*in.Tags, " #"))
		}
	}
	// Изменения исполнителей и повторения записываются отдельно и здесь не дублируются.
	switch {
	case in.ClearRecur && oldRecur != "" && oldRecur != "none":
		ch = append(ch, "повторение отключено (было: "+recurLabel(oldRecur)+")")
	case !in.ClearRecur && in.RecurFreq != nil && *in.RecurFreq != oldRecur:
		ch = append(ch, "повторение: "+recurLabel(oldRecur)+" → "+recurLabel(*in.RecurFreq))
	}
	return ch
}

// Функция sameStrings предназначена для сравнения списков строк без учёта порядка.
func sameStrings(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

// Функция recurLabel предназначена для получения текстового названия периодичности.
func recurLabel(v string) string {
	switch v {
	case "", "none":
		return "без повторения"
	case "daily":
		return "ежедневно"
	case "weekly":
		return "еженедельно"
	case "monthly":
		return "ежемесячно"
	case "yearly":
		return "ежегодно"
	default:
		return v
	}
}

// Функция priorityLabel предназначена для получения текстового названия приоритета.
func priorityLabel(p string) string {
	switch p {
	case "low":
		return "низкий"
	case "medium":
		return "средний"
	case "high":
		return "высокий"
	case "urgent":
		return "срочный"
	}
	return p
}

// Тип reportInput предназначен для разбора тела запроса отчёта.
type reportInput struct {
	Report string `json:"report"`
}

// Метод SetReport предназначен для сохранения отчёта о выполнении; право имеют автор, редактор или владелец,
// исполнитель и обладатель права участия (can_contribute_task).
func (s *Server) SetReport(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in reportInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var canContribute bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_contribute_task($1, $2)`, taskID, uid).Scan(&canContribute); e != nil {
			return e
		}
		if !canContribute {
			return httpx.Err(fiber.StatusForbidden, "forbidden",
				"Отчёт может заполнить исполнитель, автор задачи или редактор проекта")
		}

		// Отчёт завершённой задачи не изменяется.
		var completed bool
		if e := tx.QueryRow(c.Context(),
			`SELECT completed_at IS NOT NULL FROM app.tasks WHERE id = $1`, taskID).
			Scan(&completed); e != nil {
			return e
		}
		if completed {
			return httpx.Err(fiber.StatusConflict, "task_completed",
				"Задача завершена — отчёт больше не редактируется. "+
					"Верните задачу в работу, если нужно его исправить")
		}
		// Отчёт изменяется SECURITY DEFINER-функцией, не зависящей от уровня доступа task_access.
		if _, e := tx.Exec(c.Context(),
			`SELECT app.set_task_report($1, $2, $3)`, taskID, in.Report, uid); e != nil {
			return e
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	return httpx.JSON(c, fiber.StatusOK, t)
}

// Тип moveInput предназначен для разбора тела запроса перемещения задачи.
type moveInput struct {
	ColumnID uuid.UUID `json:"columnId"`
	Position int       `json:"position"`
}

// Метод MoveTask предназначен для перемещения задачи между колонками и внутри колонки: соседи сдвигаются,
// нумерация уплотняется в обеих колонках одной транзакцией. Перенос в колонку «завершено» завершает задачу.
func (s *Server) MoveTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in moveInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Position < 0 {
		in.Position = 0
	}
	uid := s.uid(c)
	// Прежняя колонка используется после коммита для определения затронутых позиций.
	var oldColumn uuid.UUID

	// Перемещение выполняет SECURITY DEFINER-функция app.move_task, проверяющая право переноса.
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Перенос в колонку «Готово» завершает задачу; триггер использует часовой пояс клиента.
		if e := setClientTZ(c, tx); e != nil {
			return e
		}
		if e := tx.QueryRow(c.Context(),
			`SELECT app.move_task($1, $2, $3, $4)`,
			taskID, uid, in.ColumnID, in.Position).Scan(&oldColumn); e != nil {
			return e
		}
		// Перемещение между колонками записывается в журнал; перестановка внутри колонки не записывается.
		if oldColumn == in.ColumnID {
			return nil
		}
		_, e := tx.Exec(c.Context(), `
			INSERT INTO app.activity (task_id, actor_id, body)
			VALUES ($1, $2, 'Перемещена: ' || app.column_title($3) || ' → ' || app.column_title($4))`,
			taskID, uid, oldColumn, in.ColumnID)
		return e
	})
	if err != nil {
		// Отказ в доступе (SQLSTATE 42501) обрабатывается по тексту исключения.
		var pgErr *pgconn.PgError
		if errors.As(err, &pgErr) && pgErr.Code == "42501" {
			if pgErr.Message == "move_to_done_denied" {
				return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "move_to_done_denied",
					"Завершить задачу может автор задачи, редактор или владелец проекта"))
			}
			return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "move_denied",
				"Вы не являетесь автором задачи или у Вас отсутствуют права на перемещение"))
		}
		return httpx.Fail(c, err)
	}

	// Уплотнение нумерации изменяет позиции соседних задач обеих колонок.
	touched, err := s.loadTasksByColumns(c, []uuid.UUID{oldColumn, in.ColumnID})
	if err != nil {
		return httpx.Fail(c, err)
	}
	var moved models.Task
	for _, t := range touched {
		action := "updated"
		if t.ID == taskID {
			action = "moved"
			moved = t
		}
		go s.publishTask(t, action)
	}
	return httpx.JSON(c, fiber.StatusOK, moved)
}

// Переменная tzNamePattern задаёт допустимый формат имени часового пояса IANA из заголовка X-Timezone.
var tzNamePattern = regexp.MustCompile(`^(UTC|[A-Za-z]+(/[A-Za-z0-9_+\-]+){1,2})$`)

// Функция setClientTZ предназначена для передачи в транзакцию часового пояса клиента (настройка app.tz),
// используемого триггером отчёта о готовности (миграция 0019).
func setClientTZ(c *fiber.Ctx, tx pgx.Tx) error {
	tz := strings.TrimSpace(c.Get("X-Timezone"))
	if tz == "" || len(tz) > 64 || !tzNamePattern.MatchString(tz) {
		return nil
	}
	_, err := tx.Exec(c.Context(), `SELECT set_config('app.tz', $1, true)`, tz)
	return err
}

// Тип completeInput предназначен для разбора тела запроса завершения задачи.
type completeInput struct {
	Completed bool `json:"completed"`
}

// Метод CompleteTask предназначен для завершения задачи и возврата её в работу.
func (s *Server) CompleteTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in completeInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	// Идентификатор созданного экземпляра периодической задачи.
	var spawnedID *uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Завершить задачу может автор или владелец проекта; исполнитель использует отметку готовности.
		var canClose bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_close_task($1, $2)`, taskID, uid).Scan(&canClose); e != nil {
			return e
		}
		if !canClose {
			return httpx.Err(fiber.StatusForbidden, "not_author",
				"Завершить задачу может только её автор. Отметьте выполнение своей части — автор примет работу")
		}
		if e := setClientTZ(c, tx); e != nil {
			return e
		}

		// Задача с незакрытой блокирующей задачей не завершается.
		if in.Completed {
			var blocker string
			e := tx.QueryRow(c.Context(), `
				SELECT b.title
				  FROM app.task_links l
				  JOIN app.tasks b ON b.id = l.from_task
				 WHERE l.to_task = $1 AND l.kind = 'blocks'
				   AND b.completed_at IS NULL
				 LIMIT 1`, taskID).Scan(&blocker)
			if e == nil {
				return httpx.Err(fiber.StatusConflict, "blocked",
					"Задача заблокирована: сначала завершите «"+blocker+"»")
			}
			if !errors.Is(e, pgx.ErrNoRows) {
				return e
			}
		}

		var boardID uuid.UUID
		if e := tx.QueryRow(c.Context(),
			`SELECT board_id FROM app.tasks WHERE id = $1`, taskID).Scan(&boardID); e != nil {
			return e
		}

		// Целевая колонка: при завершении — колонка «Готово» (прежняя запоминается), при возврате — прежняя колонка.
		query := `SELECT id FROM app.columns WHERE board_id = $1 AND is_done ORDER BY position LIMIT 1`
		if !in.Completed {
			query = `
				SELECT COALESCE(
					(SELECT c.id FROM app.columns c
					   JOIN app.tasks t ON t.prev_column_id = c.id
					  WHERE t.id = $2 AND c.board_id = $1 AND NOT c.is_done),
					(SELECT id FROM app.columns
					  WHERE board_id = $1 AND NOT is_done ORDER BY position LIMIT 1))`
		}
		var targetCol *uuid.UUID
		var col *uuid.UUID
		var e error
		if in.Completed {
			e = tx.QueryRow(c.Context(), query, boardID).Scan(&col)
		} else {
			e = tx.QueryRow(c.Context(), query, boardID, taskID).Scan(&col)
		}
		switch {
		case e == nil:
			targetCol = col
		case errors.Is(e, pgx.ErrNoRows):
			targetCol = nil
		default:
			return e
		}

		tag, e := tx.Exec(c.Context(), `
			UPDATE app.tasks
			   SET completed_at = CASE WHEN $2 THEN now() ELSE NULL END,
			       -- Прежняя колонка запоминается в момент закрытия и
			       -- освобождается при возврате: хранить её дальше
			       -- незачем, а пустое значение честнее показывает,
			       -- что возвращать некуда.
			       prev_column_id = CASE WHEN $2 THEN column_id ELSE NULL END,
			       column_id    = COALESCE($3, column_id)
			 WHERE id = $1`, taskID, in.Completed, targetCol)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}

		body := "Задача завершена"
		if !in.Completed {
			body = "Задача возвращена в работу"
		}
		if _, e = tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`, taskID, uid, body); e != nil {
			return e
		}

		// При завершении периодической задачи создаётся следующий экземпляр; ошибка не скрывается.
		if in.Completed {
			if e = tx.QueryRow(c.Context(),
				`SELECT app.spawn_recurrence($1, $2)`, taskID, uid).Scan(&spawnedID); e != nil {
				return e
			}
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	// Новый экземпляр публикуется как созданный.
	if spawnedID != nil {
		if nt, e := s.loadTask(c, *spawnedID); e == nil {
			go s.publishTask(nt, "created")
		}
	}

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	return httpx.JSON(c, fiber.StatusOK, t)
}

// Метод DeleteTask предназначен для удаления задачи.
func (s *Server) DeleteTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var boardID uuid.UUID
	if e := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `SELECT board_id FROM app.tasks WHERE id = $1`, taskID).Scan(&boardID)
	}); e != nil {
		return httpx.Fail(c, httpx.ErrNotFound)
	}

	// Получатели определяются до удаления: каскад удаляет task_grants и task_assignees.
	watchCtx, cancelWatch := bgContext()
	watchers := s.watchersOfTaskForBoard(watchCtx, boardID, taskID)
	cancelWatch()

	var affected int64
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(), `DELETE FROM app.tasks WHERE id = $1`, taskID)
		affected = tag.RowsAffected()
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if affected == 0 {
		return httpx.Fail(c, httpx.ErrForbidden)
	}
	go s.publishTaskDeletedTo(watchers, boardID, taskID)
	return httpx.NoContent(c)
}

// Тип stepInput предназначен для разбора тела запросов пункта чек-листа. Отметка выполнения (POST .../toggle)
// и правка текста (PATCH .../:stepID) выполняются разными маршрутами.

type stepInput struct {
	Body       string     `json:"body"`
	AssigneeID *uuid.UUID `json:"assigneeId"`
	DueDate    *string    `json:"dueDate"`
}

// Метод CreateStep предназначен для создания пункта чек-листа.
func (s *Server) CreateStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in stepInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	body := strings.TrimSpace(in.Body)
	if body == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty_step", "Текст шага не может быть пустым"))
	}

	uid := s.uid(c)
	var st models.Step
	var watchers []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Состав чек-листа изменяют автор задачи, редактор и владелец проекта.
		var canManage bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_manage_steps($1, $2)`, taskID, uid).Scan(&canManage); e != nil {
			return e
		}
		if !canManage {
			return httpx.Err(fiber.StatusForbidden, "forbidden",
				"Изменять чек-лист может автор задачи, редактор или владелец проекта")
		}
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.task_steps (task_id, body, position, assignee_id, due_date, created_by)
			VALUES ($1, $2, COALESCE((SELECT max(position) + 1 FROM app.task_steps WHERE task_id = $1), 0),
			        $3, $4::date, $5)
			RETURNING id, body, done, position, assignee_id, to_char(due_date, 'YYYY-MM-DD'), done_by,
			          to_char(done_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`,
			taskID, body, in.AssigneeID, in.DueDate, uid).
			Scan(&st.ID, &st.Body, &st.Done, &st.Position, &st.AssigneeID, &st.DueDate, &st.DoneBy, &st.DoneAt); e != nil {
			return e
		}
		// Исполнитель пункта добавляется в исполнители задачи.
		if in.AssigneeID != nil {
			if _, e := tx.Exec(c.Context(), `SELECT app.ensure_assignee($1, $2, $3)`,
				taskID, *in.AssigneeID, uid); e != nil {
				return e
			}
		}
		entry := "Добавлен пункт чек-листа «" + st.Body + "»"
		// Текст уведомления формируется от лица автора действия.
		said := "добавил(а) пункт чек-листа «" + st.Body + "»"
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, entry); e != nil {
			return e
		}
		var e error
		watchers, e = s.notifyWatchersAbout(c.Context(), tx, taskID, uid, said)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishStep(taskID, st, "created")
	go s.pingNotifications(watchers)
	return httpx.JSON(c, fiber.StatusCreated, st)
}

// Метод RenameStep предназначен для изменения текста, исполнителя и срока пункта чек-листа.
func (s *Server) RenameStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	stepID, err := param(c, "stepID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in stepInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	body := strings.TrimSpace(in.Body)
	if body == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty_step", "Текст шага не может быть пустым"))
	}
	uid := s.uid(c)

	var st models.Step
	var watchers []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var canManage bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_manage_steps($1, $2)`, taskID, uid).Scan(&canManage); e != nil {
			return e
		}
		if !canManage {
			return httpx.Err(fiber.StatusForbidden, "forbidden",
				"Изменять чек-лист может автор задачи, редактор или владелец проекта")
		}
		var before string
		if e := tx.QueryRow(c.Context(),
			`SELECT body FROM app.task_steps WHERE id = $1 AND task_id = $2`,
			stepID, taskID).Scan(&before); e != nil {
			return e
		}
		if e := tx.QueryRow(c.Context(), `
			UPDATE app.task_steps
			   SET body = $3, assignee_id = $4, due_date = $5::date
			 WHERE id = $1 AND task_id = $2
			 RETURNING id, body, done, position, assignee_id, to_char(due_date, 'YYYY-MM-DD'), done_by,
			           to_char(done_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`,
			stepID, taskID, body, in.AssigneeID, in.DueDate).
			Scan(&st.ID, &st.Body, &st.Done, &st.Position, &st.AssigneeID, &st.DueDate, &st.DoneBy, &st.DoneAt); e != nil {
			return e
		}
		if in.AssigneeID != nil {
			if _, e := tx.Exec(c.Context(), `SELECT app.ensure_assignee($1, $2, $3)`,
				taskID, *in.AssigneeID, uid); e != nil {
				return e
			}
		}
		var entry, said string
		if before != st.Body {
			entry = "Пункт чек-листа «" + before + "» изменён на «" + st.Body + "»"
			said = "изменил(а) пункт чек-листа «" + before + "» на «" + st.Body + "»"
		} else {
			entry = "Изменён пункт чек-листа «" + st.Body + "»"
			said = "изменил(а) пункт чек-листа «" + st.Body + "»"
		}
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, entry); e != nil {
			return e
		}
		var e error
		watchers, e = s.notifyWatchersAbout(c.Context(), tx, taskID, uid, said)
		return e
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishStep(taskID, st, "updated")
	go s.pingNotifications(watchers)
	return httpx.JSON(c, fiber.StatusOK, st)
}

// Тип toggleInput предназначен для разбора тела запроса отметки пункта.
type toggleInput struct {
	Done bool `json:"done"`
}

// Метод ToggleStep предназначен для отметки пункта выполненным; доступен участникам с правом contribute.
func (s *Server) ToggleStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	stepID, err := param(c, "stepID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in toggleInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var st models.Step
	var watchers []uuid.UUID
	var denied bool
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Право отметки: исполнитель пункта (при его наличии) или ведущий чек-лист.
		var canCheck bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_check_step($1, $2)`, stepID, uid).Scan(&canCheck); e != nil {
			return e
		}
		if !canCheck {
			denied = true
			return nil
		}
		if e := tx.QueryRow(c.Context(), `
			UPDATE app.task_steps
			   SET done    = $3,
			       done_by = CASE WHEN $3 THEN $4::uuid ELSE NULL END,
			       done_at = CASE WHEN $3 THEN now() ELSE NULL END
			 WHERE id = $1 AND task_id = $2
			 RETURNING id, body, done, position, assignee_id, to_char(due_date, 'YYYY-MM-DD'), done_by,
			           to_char(done_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`,
			stepID, taskID, in.Done, uid).
			Scan(&st.ID, &st.Body, &st.Done, &st.Position, &st.AssigneeID, &st.DueDate, &st.DoneBy, &st.DoneAt); e != nil {
			return e
		}

		verb := "Отмечен пункт"
		saidVerb := "отметил(а) пункт чек-листа"
		if !in.Done {
			verb = "Снята отметка с пункта"
			saidVerb = "снял(а) отметку с пункта чек-листа"
		}
		body := verb + " «" + st.Body + "»"
		said := saidVerb + " «" + st.Body + "»"
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, body); e != nil {
			return e
		}
		var e error
		watchers, e = s.notifyWatchersAbout(c.Context(), tx, taskID, uid, said)
		return e
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	if denied {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_allowed",
			"Отметить этот пункт может только назначенный исполнитель"))
	}
	go s.publishStep(taskID, st, "updated")
	go s.pingNotifications(watchers)
	return httpx.JSON(c, fiber.StatusOK, st)
}

// Метод DeleteStep предназначен для удаления пункта чек-листа.
func (s *Server) DeleteStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	stepID, err := param(c, "stepID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var affected int64
	var watchers []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Текст пункта читается до удаления для записи в журнал.
		var body string
		if e := tx.QueryRow(c.Context(),
			`SELECT body FROM app.task_steps WHERE id = $1 AND task_id = $2`,
			stepID, taskID).Scan(&body); e != nil {
			if errors.Is(e, pgx.ErrNoRows) {
				return nil // строки нет — affected останется 0
			}
			return e
		}

		tag, e := tx.Exec(c.Context(),
			`DELETE FROM app.task_steps WHERE id = $1 AND task_id = $2`, stepID, taskID)
		if e != nil {
			return e
		}
		affected = tag.RowsAffected()
		if affected == 0 {
			return nil
		}

		entry := "Удалён пункт чек-листа «" + body + "»"
		said := "удалил(а) пункт чек-листа «" + body + "»"
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, entry); e != nil {
			return e
		}
		watchers, e = s.notifyWatchersAbout(c.Context(), tx, taskID, uid, said)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if affected == 0 {
		return httpx.Fail(c, httpx.ErrForbidden)
	}
	go s.publishStep(taskID, models.Step{ID: stepID}, "deleted")
	go s.pingNotifications(watchers)
	return httpx.NoContent(c)
}

// Тип grantInput предназначен для разбора элемента списка точечных прав.

type grantInput struct {
	UserID uuid.UUID `json:"userId"`
	Access string    `json:"access"`
}

// Метод SetGrants предназначен для замены списка точечных прав доступа к задаче.
func (s *Server) SetGrants(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in []grantInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var pending []pendingNotif
	var revoked []uuid.UUID
	var boardOfTask uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var canEdit bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_edit_task($1, $2)`, taskID, uid).Scan(&canEdit); e != nil {
			return e
		}
		if !canEdit {
			return httpx.ErrForbidden
		}

		var boardID uuid.UUID
		var taskTitle string
		if e := tx.QueryRow(c.Context(),
			`SELECT board_id, title FROM app.tasks WHERE id = $1`, taskID).Scan(&boardID, &taskTitle); e != nil {
			return e
		}
		boardOfTask = boardID
		var actorName string
		_ = tx.QueryRow(c.Context(),
			`SELECT full_name FROM app.users WHERE id = $1`, uid).Scan(&actorName)

		// Прежние права нужны для определения снятых; участники проекта не учитываются.
		beforeGrants := map[uuid.UUID]bool{}
		gr, e := tx.Query(c.Context(),
			`SELECT user_id FROM app.task_grants WHERE task_id = $1`, taskID)
		if e != nil {
			return e
		}
		for gr.Next() {
			var id uuid.UUID
			if e := gr.Scan(&id); e != nil {
				gr.Close()
				return e
			}
			beforeGrants[id] = true
		}
		gr.Close()
		if e := gr.Err(); e != nil {
			return e
		}

		staysGrant := map[uuid.UUID]bool{}
		for _, g := range in {
			if g.Access == "read" || g.Access == "contribute" {
				staysGrant[g.UserID] = true
			}
		}
		for id := range beforeGrants {
			if !staysGrant[id] {
				revoked = append(revoked, id)
			}
		}

		if _, e := tx.Exec(c.Context(), `DELETE FROM app.task_grants WHERE task_id = $1`, taskID); e != nil {
			return e
		}
		for _, g := range in {
			if g.Access != "read" && g.Access != "contribute" {
				continue
			}
			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.task_grants (task_id, user_id, access, granted_by)
				VALUES ($1, $2, $3::app.grant_access, $4)`, taskID, g.UserID, g.Access, uid); e != nil {
				return e
			}
			// Уведомление получают только те, кому доступ открыт впервые.
			if !beforeGrants[g.UserID] {
				// Порядок текста уведомления: кто, что, где.
				who := actorName
				if who == "" {
					who = "Пользователь"
				}
				msg := notifyPhrase(who, "открыл(а) вам доступ к задаче «"+taskTitle+"»", "", "")
				n, e := notifyInsertCat(c.Context(), tx, g.UserID, msg, "granted", &boardID, &taskID)
				if e != nil {
					return e
				}
				if n.ID != uuid.Nil {
					pending = append(pending, pendingNotif{UserID: g.UserID, Notif: n})
				}
			}
		}
		// Переменная e объявлена выше в этом блоке.
		_, e = tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, 'Изменён доступ к задаче')`,
			taskID, uid)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.flushNotifs(pending)
	// Лишённым права отправляется адресное событие.
	go s.publishTaskAccessRevoked(boardOfTask, taskID, revoked)

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	return httpx.JSON(c, fiber.StatusOK, t)
}

// Тип assignmentDoneInput предназначен для разбора тела запроса отметки исполнителя.
type assignmentDoneInput struct {
	Completed bool `json:"completed"`
}

// Метод CompleteAssignment предназначен для отметки исполнителем выполнения своей части. Права определяет политика
// task_assignees_self_update: изменяется только строка с собственным user_id.
func (s *Server) CompleteAssignment(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in assignmentDoneInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var affected int64
	var watchers []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(), `
			UPDATE app.task_assignees
			   SET completed_at = CASE WHEN $3 THEN now() ELSE NULL END
			 WHERE task_id = $1 AND user_id = $2`, taskID, uid, in.Completed)
		if e != nil {
			return e
		}
		affected = tag.RowsAffected()
		if affected == 0 {
			return nil
		}

		// Имя берётся из справочника для записи в журнал.
		var name string
		if e := tx.QueryRow(c.Context(),
			`SELECT full_name FROM app.users WHERE id = $1`, uid).Scan(&name); e != nil {
			return e
		}

		// Имя в тексте уведомления добавляет notifyWatchersAbout.
		body := "отметил(а) свою часть выполненной"
		if !in.Completed {
			body = "снял(а) отметку о выполнении"
		}
		// Имя в журнале указывается для самостоятельной читаемости записи.
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, name+" "+body); e != nil {
			return e
		}
		watchers, e = s.notifyWatchersAbout(c.Context(), tx, taskID, uid, body)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if affected == 0 {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_assignee",
			"Отметить выполнение может только исполнитель этой задачи"))
	}

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	go s.pingNotifications(watchers)
	return httpx.JSON(c, fiber.StatusOK, t)
}

// Тип readyInput предназначен для разбора тела запроса отметки готовности.
type readyInput struct {
	Ready bool `json:"ready"`
}

// Метод SetTaskReady предназначен для установки и снятия отметки «готова к сдаче»: исполнитель закончил работу
// и ожидает приёмки; завершает задачу автор или владелец.
func (s *Server) SetTaskReady(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in readyInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var ok bool
	// notifyWatchersAbout возвращает список получателей; записи уведомлений создаются внутри функции.
	var watchers []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(),
			`SELECT app.set_task_ready($1, $2, $3)`, taskID, uid, in.Ready).Scan(&ok); e != nil {
			return e
		}
		if !ok {
			return nil
		}

		what := "пометил(а) задачу готовой к сдаче"
		if !in.Ready {
			what = "снял(а) отметку о готовности к сдаче"
		}
		var name string
		if e := tx.QueryRow(c.Context(),
			`SELECT full_name FROM app.users WHERE id = $1`, uid).Scan(&name); e != nil {
			return e
		}
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, name+" "+what); e != nil {
			return e
		}
		var e error
		watchers, e = s.notifyWatchersAbout(c.Context(), tx, taskID, uid, what)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if !ok {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_assignee",
			"Отметить готовность к сдаче может исполнитель задачи, а снять — исполнитель или тот, кто ведёт задачу"))
	}
	go s.pingNotifications(watchers)

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	return httpx.JSON(c, fiber.StatusOK, t)
}

// Метод ToggleFavorite предназначен для обработки запроса POST /tasks/:taskID/favorite: ставит или снимает отметку
// «избранное» у текущего пользователя. Тело {"value": true|false} задаёт состояние явно; без тела состояние переключается.
func (s *Server) ToggleFavorite(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in struct {
		Value *bool `json:"value"`
	}
	_ = c.BodyParser(&in)
	uid := s.uid(c)
	var fav bool
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var exists bool
		if e := tx.QueryRow(c.Context(), `SELECT EXISTS (SELECT 1 FROM app.tasks WHERE id = $1)`, taskID).Scan(&exists); e != nil || !exists {
			return httpx.ErrNotFound
		}
		var cur bool
		if e := tx.QueryRow(c.Context(),
			`SELECT EXISTS (SELECT 1 FROM app.task_favorites WHERE task_id = $1 AND user_id = $2)`, taskID, uid).Scan(&cur); e != nil {
			return e
		}
		want := !cur
		if in.Value != nil {
			want = *in.Value
		}
		fav = want
		if want && !cur {
			_, e := tx.Exec(c.Context(), `INSERT INTO app.task_favorites (user_id, task_id) VALUES ($1, $2)
				ON CONFLICT DO NOTHING`, uid, taskID)
			return e
		}
		if !want && cur {
			_, e := tx.Exec(c.Context(), `DELETE FROM app.task_favorites WHERE task_id = $1 AND user_id = $2`, taskID, uid)
			return e
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"favorite": fav})
}

// Метод SetTaskHead предназначен для обработки запроса PUT /tasks/:taskID/head: назначает головного исполнителя
// (тело {"userId": "..."}) или снимает его ({"userId": null}).
func (s *Server) SetTaskHead(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in struct {
		UserID *uuid.UUID `json:"userId"`
	}
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var ok bool
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `SELECT app.set_task_head($1, $2, $3)`, taskID, uid, in.UserID).Scan(&ok)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if !ok {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "head_denied",
			"Назначить головного исполнителя может редактор задачи, и только из числа её исполнителей"))
	}
	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	return httpx.JSON(c, fiber.StatusOK, t)
}

// Метод TaskChat предназначен для обработки запроса POST /tasks/:taskID/chat: возвращает групповой чат задачи
// (название задачи, участники — исполнители, автор и пользователи с доступом), при отсутствии создаёт его.
func (s *Server) TaskChat(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var chatID uuid.UUID
	var created bool
	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `SELECT chat_id, created, members FROM app.task_chat($1, $2)`, taskID, uid).
			Scan(&chatID, &created, &members)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if created {
		go s.publishChat(members, chatID, "created")
	}
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"id": chatID, "created": created})
}
