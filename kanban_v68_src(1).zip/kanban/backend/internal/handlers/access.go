// Модуль предназначен для панели «Доступы»: просмотр доступов пользователя, выдача и снятие доступа к проектам
// и задачам, онбординг (копирование доступа коллеги) и офбординг. Права проверяют SQL-функции миграции 0027.

package handlers

import (
	"errors"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"github.com/example/kanban/internal/httpx"
)

// Тип accessRow предназначен для описания строки обзора доступов.

type accessRow struct {
	Kind       string     `json:"kind"`
	ObjectID   uuid.UUID  `json:"objectId"`
	Title      string     `json:"title"`
	BoardID    *uuid.UUID `json:"boardId,omitempty"`
	BoardTitle *string    `json:"boardTitle,omitempty"`
	Level      *string    `json:"level,omitempty"`
	Manageable bool       `json:"manageable"`
}

// Функция accessFail предназначена для преобразования отказов SQL-функций доступа в ответы с понятным текстом.
// Тексты не раскрывают структуру БД и возвращаются в production без изменений.
func accessFail(c *fiber.Ctx, err error) error {
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) {
		switch pgErr.Code {
		case "42501":
			return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "forbidden", pgErr.Message))
		case "22023":
			return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "invalid_input", pgErr.Message))
		case "P0002":
			return httpx.Fail(c, httpx.ErrNotFound)
		case "P0001":
			if n, ok := strings.CutPrefix(pgErr.Message, "need_successor:"); ok {
				owned, _ := strconv.Atoi(n)
				return httpx.JSON(c, fiber.StatusConflict, fiber.Map{
					"error": pgErr.Hint, "code": "need_successor", "owned": owned,
				})
			}
		}
	}
	return httpx.Fail(c, err)
}

// Функция actorName предназначена для получения имени пользователя, выполняющего действие, для текста уведомления.
func actorName(c *fiber.Ctx, tx pgx.Tx, uid uuid.UUID) (string, error) {
	var name string
	err := tx.QueryRow(c.Context(),
		`SELECT COALESCE((SELECT full_name FROM app.users WHERE id = $1), 'Пользователь')`, uid).Scan(&name)
	return name, err
}

// Метод AccessOverview предназначен для обработки запроса GET /access/users/:userID: доступы пользователя
// в пределах прав просматривающего (администратору — все).
func (s *Server) AccessOverview(c *fiber.Ctx) error {
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	rows := []accessRow{}
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		r, e := tx.Query(c.Context(), `
			SELECT kind, object_id, title, board_id, board_title, level, manageable
			  FROM app.access_overview($1)
			 ORDER BY kind, board_title NULLS FIRST, title`, target)
		if e != nil {
			return e
		}
		rows, e = pgx.CollectRows(r, func(row pgx.CollectableRow) (accessRow, error) {
			var a accessRow
			err := row.Scan(&a.Kind, &a.ObjectID, &a.Title, &a.BoardID, &a.BoardTitle, &a.Level, &a.Manageable)
			return a, err
		})
		return e
	})
	if err != nil {
		return accessFail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, rows)
}

// Тип idTitle предназначен для описания пары «идентификатор и название».
type idTitle struct {
	ID    uuid.UUID `json:"id"`
	Title string    `json:"title"`
}

// Метод AccessManageableBoards предназначен для обработки запроса GET /access/boards: проекты, где можно выдавать доступ.
func (s *Server) AccessManageableBoards(c *fiber.Ctx) error {
	out := []idTitle{}
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		r, e := tx.Query(c.Context(), `SELECT id, title FROM app.manageable_boards()`)
		if e != nil {
			return e
		}
		out, e = pgx.CollectRows(r, pgx.RowToStructByPos[idTitle])
		return e
	})
	if err != nil {
		return accessFail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

// Тип boardAccessInput предназначен для разбора тела запроса выдачи доступа к проекту.
type boardAccessInput struct {
	Role string `json:"role"`
}

// Метод SetBoardAccess предназначен для обработки запроса PUT /access/boards/:boardID/members/:userID: выдача или смена роли.
func (s *Server) SetBoardAccess(c *fiber.Ctx) error {
	boardID, err := param(c, "boardID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in boardAccessInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var pending []pendingNotif
	var added bool
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var prev *string
		if e := tx.QueryRow(c.Context(), `SELECT app.set_board_access($1, $2, $3)`,
			boardID, target, in.Role).Scan(&prev); e != nil {
			return e
		}
		added = prev == nil
		if !added || target == uid {
			return nil
		}
		// Текст уведомления совпадает с PUT /boards/:id/members.
		name, e := actorName(c, tx, uid)
		if e != nil {
			return e
		}
		var title string
		if e := tx.QueryRow(c.Context(), `SELECT app.board_title($1)`, boardID).Scan(&title); e != nil {
			return e
		}
		n, e := notifyInsert(c.Context(), tx, target,
			name+" открыл(а) вам доступ к проекту «"+title+"»", &boardID, nil)
		if e != nil {
			return e
		}
		if n.ID != uuid.Nil {
			pending = append(pending, pendingNotif{UserID: target, Notif: n})
		}
		return nil
	})
	if err != nil {
		return accessFail(c, err)
	}
	s.flushNotifs(pending)
	if added {
		go s.publishBoardMemberAdded(boardID, target)
	}
	s.publishBoardIfVisible(c, boardID)
	return httpx.NoContent(c)
}

// Метод RevokeBoardAccess предназначен для обработки запроса DELETE /access/boards/:boardID/members/:userID: снятие доступа.
func (s *Server) RevokeBoardAccess(c *fiber.Ctx) error {
	boardID, err := param(c, "boardID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var removed, stillSees bool
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `SELECT app.revoke_board_access($1, $2)`,
			boardID, target).Scan(&removed); e != nil {
			return e
		}
		return tx.QueryRow(c.Context(), `SELECT app.can_see_board($1, $2)`, boardID, target).Scan(&stillSees)
	})
	if err != nil {
		return accessFail(c, err)
	}
	if !removed {
		return httpx.NoContent(c)
	}
	// Событие «доступ закрыт» отправляется, только если проект пользователю больше не виден.
	if !stillSees {
		go s.publishAccessRevoked(boardID, []uuid.UUID{target}, "Доступ к проекту закрыт")
	}
	s.publishBoardIfVisible(c, boardID)
	return httpx.NoContent(c)
}

// Метод publishBoardIfVisible предназначен для рассылки обновлённого проекта наблюдателям; при невозможности собрать модель рассылка пропускается.
func (s *Server) publishBoardIfVisible(c *fiber.Ctx, boardID uuid.UUID) {
	if board, err := s.fetchBoard(c, boardID); err == nil {
		go s.publishBoard(board, "updated")
	}
}

// Тип taskAccessInput предназначен для разбора тела запроса выдачи доступа к задаче.
type taskAccessInput struct {
	Access string `json:"access"`
}

// Метод SetTaskAccess предназначен для обработки запроса PUT /access/tasks/:taskID/grants/:userID: точечный доступ к задаче.
func (s *Server) SetTaskAccess(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in taskAccessInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var pending []pendingNotif
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var prev *string
		if e := tx.QueryRow(c.Context(), `SELECT app.set_task_access($1, $2, $3)`,
			taskID, target, in.Access).Scan(&prev); e != nil {
			return e
		}
		if prev != nil || target == uid {
			return nil
		}
		var boardID uuid.UUID
		var title string
		if e := tx.QueryRow(c.Context(), `SELECT board_id, title FROM app.task_brief($1)`,
			taskID).Scan(&boardID, &title); e != nil {
			return e
		}
		name, e := actorName(c, tx, uid)
		if e != nil {
			return e
		}
		// Текст и категория уведомления совпадают с PUT /tasks/:id/grants.
		msg := notifyPhrase(name, "открыл(а) вам доступ к задаче «"+title+"»", "", "")
		n, e := notifyInsertCat(c.Context(), tx, target, msg, "granted", &boardID, &taskID)
		if e != nil {
			return e
		}
		if n.ID != uuid.Nil {
			pending = append(pending, pendingNotif{UserID: target, Notif: n})
		}
		return nil
	})
	if err != nil {
		return accessFail(c, err)
	}
	s.flushNotifs(pending)
	s.publishTaskIfVisible(c, taskID)
	return httpx.NoContent(c)
}

// Метод RevokeTaskAccess предназначен для обработки запроса DELETE /access/tasks/:taskID/grants/:userID: снятие точечного доступа.
func (s *Server) RevokeTaskAccess(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var removed, stillSees bool
	var boardID uuid.UUID
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `SELECT board_id FROM app.task_brief($1)`,
			taskID).Scan(&boardID); e != nil {
			if errors.Is(e, pgx.ErrNoRows) {
				return httpx.ErrNotFound
			}
			return e
		}
		if e := tx.QueryRow(c.Context(), `SELECT app.revoke_task_access($1, $2)`,
			taskID, target).Scan(&removed); e != nil {
			return e
		}
		return tx.QueryRow(c.Context(), `SELECT app.can_see_task($1, $2)`, taskID, target).Scan(&stillSees)
	})
	if err != nil {
		return accessFail(c, err)
	}
	if !removed {
		return httpx.NoContent(c)
	}
	// Задача может оставаться видимой через назначение или роль в проекте; в этом случае событие не отправляется.
	if !stillSees {
		go s.publishTaskAccessRevoked(boardID, taskID, []uuid.UUID{target})
	}
	s.publishTaskIfVisible(c, taskID)
	return httpx.NoContent(c)
}

// Метод publishTaskIfVisible предназначен для рассылки обновлённой задачи наблюдателям, включая нового получателя доступа.
func (s *Server) publishTaskIfVisible(c *fiber.Ctx, taskID uuid.UUID) {
	if t, err := s.loadTask(c, taskID); err == nil {
		go s.publishTask(t, "updated")
	}
}

// Тип copyAccessInput предназначен для разбора тела запроса копирования доступа.
type copyAccessInput struct {
	FromUserID uuid.UUID `json:"fromUserId"`
}

// Метод AdminCopyAccess предназначен для обработки запроса POST /admin/users/:userID/copy-access: выдача доступа как у коллеги.
func (s *Server) AdminCopyAccess(c *fiber.Ctx) error {
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in copyAccessInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	boards := []idTitle{}
	var pending []pendingNotif
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		r, e := tx.Query(c.Context(), `SELECT board_id, title FROM app.copy_access($1, $2)`,
			in.FromUserID, target)
		if e != nil {
			return e
		}
		if boards, e = pgx.CollectRows(r, pgx.RowToStructByPos[idTitle]); e != nil {
			return e
		}
		if len(boards) == 0 {
			return nil
		}
		// Отправляется одно уведомление на всю операцию.
		name, e := actorName(c, tx, uid)
		if e != nil {
			return e
		}
		titles := make([]string, len(boards))
		for i, b := range boards {
			titles[i] = "«" + b.Title + "»"
		}
		n, e := notifyInsert(c.Context(), tx, target,
			name+" открыл(а) вам доступ к проектам: "+strings.Join(titles, ", "), nil, nil)
		if e != nil {
			return e
		}
		if n.ID != uuid.Nil {
			pending = append(pending, pendingNotif{UserID: target, Notif: n})
		}
		return nil
	})
	if err != nil {
		return accessFail(c, err)
	}
	s.flushNotifs(pending)
	for _, b := range boards {
		go s.publishBoardMemberAdded(b.ID, target)
	}
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"boards": boards})
}

// Тип offboardInput предназначен для разбора тела запроса офбординга.
type offboardInput struct {
	SuccessorID *uuid.UUID `json:"successorId"`
}

// Метод offboard предназначен для удаления учётной записи со снятием доступа и передачей владения (app.offboard_user).
func (s *Server) offboard(c *fiber.Ctx, target uuid.UUID) error {
	var in offboardInput
	if len(c.Body()) > 0 {
		if err := httpx.Decode(c, &in); err != nil {
			return httpx.Fail(c, err)
		}
	}
	actor := s.uid(c)

	var pending []pendingNotif
	err := s.db.AsUser(c.Context(), actor, func(tx pgx.Tx) error {
		// Последний администратор не удаляется.
		var targetIsAdmin bool
		var others int
		if e := tx.QueryRow(c.Context(),
			`SELECT app.is_admin($1), app.other_admins_count($1)`, target).
			Scan(&targetIsAdmin, &others); e != nil {
			return e
		}
		if targetIsAdmin && others == 0 {
			return httpx.Err(fiber.StatusConflict, "last_admin",
				"Это последний администратор — сначала назначьте другого")
		}

		r, e := tx.Query(c.Context(), `
			SELECT notify_user, notification_id, created_at, body, board_id, task_id
			  FROM app.offboard_user($1, $2)`, target, in.SuccessorID)
		if e != nil {
			return e
		}
		defer r.Close()
		for r.Next() {
			var p pendingNotif
			var createdAt time.Time
			if e := r.Scan(&p.UserID, &p.Notif.ID, &createdAt, &p.Notif.Body,
				&p.Notif.BoardID, &p.Notif.TaskID); e != nil {
				return e
			}
			p.Notif.CreatedAt = createdAt
			pending = append(pending, p)
		}
		return r.Err()
	})
	if err != nil {
		return accessFail(c, err)
	}
	s.hub.Disconnect(target)
	s.flushNotifs(pending)
	return httpx.NoContent(c)
}

// Тип matrixRow предназначен для описания строки матрицы доступов: объект и уровень доступа выбранного пользователя.
type matrixRow struct {
	Kind       string    `json:"kind"`
	ObjectID   uuid.UUID `json:"objectId"`
	Title      string    `json:"title"`
	Level      *string   `json:"level"` // nil — доступа нет
	Manageable bool      `json:"manageable"`
	// Родительский проект (для kind = board): панель показывает проекты деревом и умеет менять доступ во вложенных.
	ParentID *uuid.UUID `json:"parentId,omitempty"`
}

// Метод AccessMatrix предназначен для обработки запроса GET /access/matrix/:userID: все проекты, диаграммы и доски,
// которыми управляет текущий пользователь, и статус доступа к каждому у выбранного пользователя.
func (s *Server) AccessMatrix(c *fiber.Ctx) error {
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	out := []matrixRow{}
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		r, e := tx.Query(c.Context(), `
			SELECT m.kind, m.object_id, m.title, m.level, m.manageable,
			       (SELECT b.parent_id FROM app.boards b WHERE m.kind = 'board' AND b.id = m.object_id)
			  FROM app.access_matrix($1) m`, target)
		if e != nil {
			return e
		}
		out, e = pgx.CollectRows(r, func(row pgx.CollectableRow) (matrixRow, error) {
			var m matrixRow
			err := row.Scan(&m.Kind, &m.ObjectID, &m.Title, &m.Level, &m.Manageable, &m.ParentID)
			return m, err
		})
		return e
	})
	if err != nil {
		return accessFail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

// Метод SetObjectAccess предназначен для обработки запроса PUT /access/:kind/:objectID/members/:userID,
// где kind — charts или whiteboards: выдача или смена роли в диаграмме или доске.
func (s *Server) SetObjectAccess(c *fiber.Ctx) error {
	kind, ok := objectKind(c.Params("kind"))
	if !ok {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	objectID, err := param(c, "objectID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in boardAccessInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var prev *string
		return tx.QueryRow(c.Context(), `SELECT app.set_object_access($1, $2, $3, $4)`,
			kind, objectID, target, in.Role).Scan(&prev)
	})
	if err != nil {
		return accessFail(c, err)
	}
	return httpx.NoContent(c)
}

// Метод RevokeObjectAccess предназначен для обработки запроса DELETE /access/:kind/:objectID/members/:userID.
func (s *Server) RevokeObjectAccess(c *fiber.Ctx) error {
	kind, ok := objectKind(c.Params("kind"))
	if !ok {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	objectID, err := param(c, "objectID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var done bool
		return tx.QueryRow(c.Context(), `SELECT app.revoke_object_access($1, $2, $3)`,
			kind, objectID, target).Scan(&done)
	})
	if err != nil {
		return accessFail(c, err)
	}
	return httpx.NoContent(c)
}

// Функция objectKind предназначена для преобразования сегмента маршрута в тип объекта SQL-функций.
func objectKind(seg string) (string, bool) {
	switch seg {
	case "charts":
		return "chart", true
	case "whiteboards":
		return "whiteboard", true
	}
	return "", false
}
