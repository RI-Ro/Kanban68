// Модуль предназначен для отметок о просмотре задач и проектов и для выдачи списка пользователей, находящихся в сети.

package handlers

import (
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// Тип viewInput предназначен для разбора тела запроса отметки о просмотре. Отдельный маршрут нужен, когда карточка
// открывается из уже загруженного списка и полная загрузка задачи не выполняется.

type viewInput struct {
	Kind string    `json:"kind"` // task | board
	ID   uuid.UUID `json:"id"`
}

// Тип viewResult предназначен для описания ответа на отметку о просмотре.
type viewResult struct {
	Kind     string     `json:"kind"`
	ID       uuid.UUID  `json:"id"`
	ViewedAt *time.Time `json:"viewedAt"`
}

// Тип seenEvent предназначен для описания события seen: поставленные отметки и число непрочитанных уведомлений.
type seenEvent struct {
	Items  []viewResult `json:"items"`
	Unread int          `json:"unread"`
}

// Метод MarkSeen предназначен для отметки задачи или проекта просмотренными.
func (s *Server) MarkSeen(c *fiber.Ctx) error {
	var in viewInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Kind != "task" && in.Kind != "board" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_kind",
			"Отметка о просмотре возможна только для задачи или проекта"))
	}
	if in.ID == uuid.Nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_id",
			"Не указан объект просмотра"))
	}
	uid := s.uid(c)

	var at *time.Time
	var unread int
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(),
			`SELECT app.mark_seen($1, $2, $3)`, in.Kind, in.ID, uid).Scan(&at); e != nil {
			return e
		}
		// Отметка задачи погашает её уведомления; возвращается новое число непрочитанных.
		return tx.QueryRow(c.Context(), `SELECT app.unread_notifications()`).Scan(&unread)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	// Значение NULL означает недоступный объект; ответ совпадает с ответом для несуществующего.
	if at == nil {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	res := viewResult{Kind: in.Kind, ID: in.ID, ViewedAt: at}
	s.publishSeen(uid, seenEvent{Items: []viewResult{res}, Unread: unread})
	return httpx.JSON(c, fiber.StatusOK, res)
}

// Метод Presence предназначен для получения списка пользователей в сети по живым соединениям WebSocket.
func (s *Server) Presence(c *fiber.Ctx) error {
	// Список доступен всем сотрудникам.
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"online": s.hub.Online()})
}
