// Модуль предназначен для конвертации офисных документов (doc, docx, odt, xls, xlsx, ppt и др.) в PDF
// программой soffice (LibreOffice) для предпросмотра в браузере.

package handlers

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/gofiber/fiber/v2"
)

// Переменная convertible задаёт расширения файлов, допускающих конвертацию в PDF.

var convertible = map[string]bool{
	".doc": true, ".docx": true, ".odt": true, ".rtf": true,
	".xls": true, ".xlsx": true, ".ods": true, ".csv": true,
	".ppt": true, ".pptx": true, ".odp": true,
}

// Функция convertibleName предназначена для проверки, что имя файла относится к конвертируемым типам.
func convertibleName(filename string) bool {
	return convertible[strings.ToLower(filepath.Ext(filename))]
}

var convertMu sync.Mutex

// Метод convertToPDF предназначен для получения содержимого PDF-версии файла. Файл результата удаляется до возврата
// в любом случае, в рабочей папке копии не остаются.
func (s *Server) convertToPDF(ctx context.Context, key, filename string) ([]byte, error) {
	if !convertibleName(filename) {
		return nil, errors.New("формат не конвертируется")
	}

	srcPath, err := s.files.Path(key)
	if err != nil {
		return nil, err
	}

	dir := s.cfg.ConvertDir
	if err := os.MkdirAll(dir, 0o750); err != nil {
		return nil, fmt.Errorf("рабочая папка конвертации недоступна: %w", err)
	}
	absDir, err := filepath.Abs(dir)
	if err != nil {
		return nil, err
	}
	profile := filepath.Join(absDir, "profile")

	convertMu.Lock()
	defer convertMu.Unlock()

	// Имя результата определяется LibreOffice: имя исходника с расширением .pdf; ключи хранилища уникальны.
	outPath := filepath.Join(absDir,
		strings.TrimSuffix(filepath.Base(srcPath), filepath.Ext(srcPath))+".pdf")

	// Удаление результата выполняется в defer и до запуска процесса.
	defer func() {
		if e := os.Remove(outPath); e != nil && !errors.Is(e, os.ErrNotExist) {
			slog.Warn("не удалось удалить переконвертированный файл",
				"error", e, "path", outPath)
		}
	}()

	// Предел времени конвертации — 60 секунд.
	runCtx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()

	cmd := exec.CommandContext(runCtx, "soffice",
		"--headless", "--norestore", "--nolockcheck",
		"-env:UserInstallation=file://"+profile,
		"--convert-to", "pdf", "--outdir", absDir, srcPath)

	out, err := cmd.CombinedOutput()
	if err != nil {
		slog.Error("конвертация документа не удалась",
			"error", err, "file", filename, "output", string(out))
		if errors.Is(runCtx.Err(), context.DeadlineExceeded) {
			return nil, errors.New("конвертация заняла слишком много времени")
		}
		if errors.Is(err, exec.ErrNotFound) {
			return nil, errors.New("на сервере не установлен LibreOffice — предпросмотр этого формата недоступен")
		}
		return nil, errors.New("не удалось подготовить предпросмотр")
	}

	data, err := os.ReadFile(outPath)
	if err != nil {
		return nil, errors.New("конвертер не создал файл")
	}
	return data, nil
}

// Функция sendConvertedPDF предназначена для отправки PDF из памяти, так как файл на диске уже удалён.
func sendConvertedPDF(c *fiber.Ctx, data []byte, filename string) error {
	c.Set(fiber.HeaderContentType, "application/pdf")
	c.Set(fiber.HeaderContentDisposition,
		`inline; filename="preview.pdf"; filename*=UTF-8''`+urlPathEscape(filename+".pdf"))
	// Кэширование отключено: ответ является копией документа.
	c.Set(fiber.HeaderCacheControl, "no-store")
	return c.Send(data)
}

// Функция urlPathEscape предназначена для экранирования имени файла в URL.
func urlPathEscape(s string) string {
	var b strings.Builder
	for _, r := range []byte(s) {
		switch {
		case r >= 'a' && r <= 'z', r >= 'A' && r <= 'Z', r >= '0' && r <= '9',
			r == '.', r == '-', r == '_':
			b.WriteByte(r)
		default:
			fmt.Fprintf(&b, "%%%02X", r)
		}
	}
	return b.String()
}
