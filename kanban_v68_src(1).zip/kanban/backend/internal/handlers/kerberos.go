// Модуль предназначен для входа по Kerberos (SPNEGO) и актуализации сведений о пользователе из LDAP при авторизации.
//
// Схема входа: браузер открывает /krb/login на отдельном порту Kerberos и проходит SPNEGO; сервер находит пользователя
// по логину (principal вида ii-ivanov@DOMAIN1.LOCAL, регистр не различается; домены различаются) и возвращает браузер
// в приложение с одноразовым кодом (подписанный JWT на 60 секунд). Приложение обменивает код на пару токенов запросом
// POST /api/auth/kerberos/exchange. Незнакомому пользователю показывается страница с ошибкой и текстом из config.yaml.

package handlers

import (
	"context"
	"errors"
	"fmt"
	"html"
	"log"
	"log/slog"
	"net"
	"net/http"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jcmturner/goidentity/v6"
	krbconfig "github.com/jcmturner/gokrb5/v8/config"
	"github.com/jcmturner/gokrb5/v8/keytab"
	"github.com/jcmturner/gokrb5/v8/service"
	"github.com/jcmturner/gokrb5/v8/spnego"

	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/ldapsync"
)

// Тип krbCodes предназначен для учёта погашенных одноразовых кодов: повторный обмен того же кода отклоняется.
type krbCodes struct {
	mu   sync.Mutex
	used map[string]time.Time
}

func (k *krbCodes) consume(id string, exp time.Time) bool {
	k.mu.Lock()
	defer k.mu.Unlock()
	if k.used == nil {
		k.used = map[string]time.Time{}
	}
	now := time.Now()
	for key, t := range k.used {
		if t.Before(now) {
			delete(k.used, key)
		}
	}
	if _, ok := k.used[id]; ok {
		return false
	}
	k.used[id] = exp.Add(time.Minute)
	return true
}

var krbUsed krbCodes

// Метод refreshFromLDAP предназначен для актуализации сведений пользователя из LDAP, если источник пользователя — LDAP-сервер.
// Недоступность LDAP не мешает входу (остаются прежние сведения); отказ возвращается только при включённом
// ldap.block_missing, когда пользователь в LDAP не найден.
func (s *Server) refreshFromLDAP(ctx context.Context, userID uuid.UUID) error {
	var login, source string
	if err := s.db.AsService(ctx, func(tx pgx.Tx) error {
		return tx.QueryRow(ctx, `SELECT login, source FROM app.user_source($1)`, userID).Scan(&login, &source)
	}); err != nil {
		return nil
	}
	if source == "" || source == "local" || login == "" {
		return nil
	}
	srv, ok := ldapsync.Find(s.cfg.LDAPServers, source)
	if !ok {
		slog.Warn("у пользователя указан неизвестный LDAP-сервер", "source", source, "user", userID)
		return nil
	}
	p, err := ldapsync.Lookup(ctx, srv, login)
	if err != nil {
		if errors.Is(err, ldapsync.ErrNotFound) && s.cfg.LDAPBlockMissing {
			return httpx.Err(fiber.StatusForbidden, "ldap_missing",
				"Учётная запись не найдена в каталоге LDAP — обратитесь к администратору")
		}
		slog.Warn("не удалось сверить сведения с LDAP", "server", srv.ID, "login", login, "error", err)
		return nil
	}
	return s.db.AsService(ctx, func(tx pgx.Tx) error {
		if _, e := tx.Exec(ctx, `SELECT app.sync_user_profile($1, $2, $3, $4, $5)`,
			userID, p.FullName, p.Position, p.Phone, p.Email); e != nil {
			return e
		}
		return s.syncLDAPPhoto(ctx, tx, userID, srv, p)
	})
}

// Метод krbCode предназначен для выпуска одноразового кода входа.
func (s *Server) krbCode(userID uuid.UUID) (string, error) {
	claims := jwt.RegisteredClaims{
		Subject: userID.String(), ID: uuid.NewString(), Audience: jwt.ClaimStrings{"kerberos-exchange"},
		ExpiresAt: jwt.NewNumericDate(time.Now().Add(60 * time.Second)), IssuedAt: jwt.NewNumericDate(time.Now()),
	}
	return jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString(s.cfg.JWTSecret)
}

// Метод KerberosExchange предназначен для обмена кода Kerberos-входа на пару токенов (POST /auth/kerberos/exchange).
func (s *Server) KerberosExchange(c *fiber.Ctx) error {
	var in struct {
		Code string `json:"code"`
	}
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	bad := httpx.Err(fiber.StatusUnauthorized, "bad_code", "Код входа недействителен или истёк — повторите вход")
	var claims jwt.RegisteredClaims
	tok, err := jwt.ParseWithClaims(in.Code, &claims, func(t *jwt.Token) (any, error) { return s.cfg.JWTSecret, nil },
		jwt.WithValidMethods([]string{"HS256"}), jwt.WithAudience("kerberos-exchange"))
	if err != nil || !tok.Valid {
		return httpx.Fail(c, bad)
	}
	uid, err := uuid.Parse(claims.Subject)
	if err != nil || !krbUsed.consume(claims.ID, claims.ExpiresAt.Time) {
		return httpx.Fail(c, bad)
	}
	var active bool
	if e := s.db.AsService(c.Context(), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `SELECT is_active AND NOT deleted FROM app.account_state($1)`, uid).Scan(&active)
	}); e != nil || !active {
		return httpx.Fail(c, bad)
	}
	return s.issue(c, uid)
}

// Метод KerberosHandler предназначен для создания обработчика порта Kerberos: /krb/login и страница ошибки.
func (s *Server) KerberosHandler() (http.Handler, error) {
	k := s.cfg.Kerberos
	if k.Keytab == "" {
		return nil, errors.New("kerberos.keytab не задан")
	}
	kt, err := keytab.Load(k.Keytab)
	if err != nil {
		return nil, fmt.Errorf("keytab %s: %w", k.Keytab, err)
	}
	// krb5.conf проверяется при запуске: ошибка в файле видна сразу, а не при первом входе.
	if _, err := krbconfig.Load(k.Krb5Conf); err != nil {
		return nil, fmt.Errorf("krb5.conf %s: %w", k.Krb5Conf, err)
	}
	// PAC не разбирается: нужен только principal клиента, а KDC без PAC (MIT) иначе давал бы отказ.
	opts := []func(*service.Settings){service.Logger(log.New(os.Stderr, "kerberos ", log.LstdFlags)), service.DecodePAC(false)}
	if k.ServicePrincipal != "" {
		opts = append(opts, service.KeytabPrincipal(k.ServicePrincipal))
	}

	inner := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ret := s.krbReturnURL(r)
		id := goidentity.FromHTTPRequestContext(r)
		if id == nil {
			s.krbErrorPage(w, ret, k.NotFoundTitle, k.NotFoundMessage, "")
			return
		}
		// Логин — полное имя principal: пользователь@ДОМЕН; ii-ivanov@DOMAIN1.LOCAL и ii-ivanov@DOMAIN2.LOCAL различаются.
		login := id.UserName() + "@" + id.Domain()
		var (
			uid    uuid.UUID
			active bool
			role   string
			source string
		)
		err := s.db.AsService(r.Context(), func(tx pgx.Tx) error {
			return tx.QueryRow(r.Context(), `SELECT id, is_active, role, source FROM app.user_by_login($1)`, login).
				Scan(&uid, &active, &role, &source)
		})
		if errors.Is(err, pgx.ErrNoRows) {
			slog.Info("вход по Kerberos: пользователь не найден", "login", login)
			s.krbErrorPage(w, ret, k.NotFoundTitle, k.NotFoundMessage, login)
			return
		}
		if err != nil {
			slog.Error("вход по Kerberos: ошибка базы", "error", err)
			s.krbErrorPage(w, ret, "Сервис временно недоступен", "Повторите попытку позже.", "")
			return
		}
		if !active {
			s.krbErrorPage(w, ret, k.NotFoundTitle, k.DisabledMessage, login)
			return
		}
		if err := s.refreshFromLDAP(r.Context(), uid); err != nil {
			s.krbErrorPage(w, ret, k.NotFoundTitle, k.NotFoundMessage, login)
			return
		}
		code, err := s.krbCode(uid)
		if err != nil {
			s.krbErrorPage(w, ret, "Ошибка входа", "Повторите попытку.", "")
			return
		}
		u, _ := url.Parse(ret)
		q := u.Query()
		q.Set("krb_code", code)
		u.RawQuery = q.Encode()
		http.Redirect(w, r, u.String(), http.StatusFound)
	})

	mux := http.NewServeMux()
	mux.Handle("/krb/login", spnego.SPNEGOKRB5Authenticate(inner, kt, opts...))
	mux.HandleFunc("/krb/health", func(w http.ResponseWriter, r *http.Request) { _, _ = w.Write([]byte("ok")) })
	return mux, nil
}

// Метод krbReturnURL предназначен для определения адреса возврата в приложение. Адрес берётся из конфигурации
// (kerberos.app_url) либо из параметра return, если его хост совпадает с хостом запроса (защита от открытого редиректа).
func (s *Server) krbReturnURL(r *http.Request) string {
	if s.cfg.Kerberos.AppURL != "" {
		return strings.TrimRight(s.cfg.Kerberos.AppURL, "/") + "/"
	}
	if ret := r.URL.Query().Get("return"); ret != "" {
		if u, err := url.Parse(ret); err == nil && (u.Scheme == "http" || u.Scheme == "https") {
			reqHost, _, e1 := net.SplitHostPort(r.Host)
			if e1 != nil {
				reqHost = r.Host
			}
			if strings.EqualFold(u.Hostname(), reqHost) {
				return u.Scheme + "://" + u.Host + "/"
			}
		}
	}
	return "/"
}

// Метод krbErrorPage предназначен для страницы с картинкой и текстом ошибки (тексты задаются в config.yaml).
func (s *Server) krbErrorPage(w http.ResponseWriter, back, title, message, login string) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(http.StatusForbidden)
	who := ""
	if login != "" {
		who = `<p class="who">Учётная запись: <b>` + html.EscapeString(login) + `</b></p>`
	}
	paras := ""
	for _, p := range strings.Split(message, "\n") {
		if strings.TrimSpace(p) != "" {
			paras += "<p>" + html.EscapeString(strings.TrimSpace(p)) + "</p>"
		}
	}
	fmt.Fprintf(w, krbErrorHTML, html.EscapeString(s.cfg.AppName), html.EscapeString(title), paras, who, html.EscapeString(back))
}

const krbErrorHTML = `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>%s</title><style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#eef2f9,#dfe7f5);font-family:system-ui,"Segoe UI",Arial,sans-serif;color:#1c2433}
.card{max-width:520px;margin:24px;background:#fff;border-radius:20px;padding:36px 34px;text-align:center;box-shadow:0 20px 60px -20px rgba(30,50,100,.35)}
h1{font-size:24px;margin:18px 0 10px}p{font-size:15px;line-height:1.55;color:#3c465a;margin:6px 0}.who{margin-top:16px;color:#6a7488;font-size:13px}
a{display:inline-block;margin-top:22px;padding:11px 22px;border-radius:12px;background:#2457d6;color:#fff;text-decoration:none;font-weight:600}
</style></head><body><div class="card">
<svg width="180" height="150" viewBox="0 0 180 150" aria-hidden="true"><ellipse cx="90" cy="136" rx="62" ry="8" fill="#dfe7f5"/>
<rect x="38" y="52" width="104" height="78" rx="14" fill="#2457d6"/><rect x="38" y="52" width="104" height="78" rx="14" fill="url(#g)" opacity=".25"/>
<path d="M60 52V40a30 30 0 0 1 60 0v12" fill="none" stroke="#8aa4e6" stroke-width="12" stroke-linecap="round"/>
<circle cx="90" cy="88" r="11" fill="#fff"/><rect x="85" y="92" width="10" height="22" rx="5" fill="#fff"/>
<circle cx="140" cy="36" r="20" fill="#e5484d"/><path d="M131 27l18 18M149 27l-18 18" stroke="#fff" stroke-width="5" stroke-linecap="round"/>
<defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#fff"/><stop offset="1" stop-color="#000"/></linearGradient></defs></svg>
<h1>%s</h1>%s%s<a href="%s">Вернуться на страницу входа</a></div></body></html>`

// Метод kerberosPublic предназначен для сведений о Kerberos-входе в публичной конфигурации: интерфейс строит ссылку на порт.
func (s *Server) kerberosPublic() any {
	k := s.cfg.Kerberos
	if !k.Enabled {
		return nil
	}
	_, port, err := net.SplitHostPort(k.Addr)
	if err != nil {
		port = strings.TrimPrefix(k.Addr, ":")
	}
	https := k.TLSCert != "" || s.cfg.TLSEnabled()
	text := k.ButtonText
	if text == "" {
		text = "Войти через Kerberos"
	}
	return fiber.Map{"port": port, "https": https, "buttonText": text}
}
