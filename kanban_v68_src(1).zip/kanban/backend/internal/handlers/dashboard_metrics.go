// Модуль предназначен для расчёта метрик сводки двух видов: «срез на сейчас» (состояние открытых задач без учёта периода)
// и «поток за период» (поставлено, завершено, по неделям, по людям), а также для списков задач под числами метрик.

package handlers

import (
	"context"
	"fmt"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)


const (
	// incomingDays — срок исполнения входящего документа в календарных днях от даты входящего.
	incomingDays = 30
	// incomingBurnDays — число дней до срока, при котором входящий считается горящим.
	incomingBurnDays = 5
	// staleDays — число дней без изменений, после которых открытая задача считается зависшей.
	staleDays = 14
	// maxWeeks — максимальное число недель на графике.
	maxWeeks = 80
)

// Константа metricScope задаёт условие области: $1 — проект (может быть NULL), $2 — исполнитель (может быть NULL).
const metricScope = `
	FROM dash_t t
	WHERE ($1::uuid IS NULL OR t.board_id = $1::uuid)
	  AND ($2::uuid IS NULL OR EXISTS (
	        SELECT 1 FROM dash_a sa
	         WHERE sa.task_id = t.id AND sa.user_id = $2::uuid))`

// Параметры периода: $3 — начало, $4 — конец (включительно).
const (
	periodCreated = `t.created_at >= $3::date AND t.created_at < $4::date + 1`
	periodDone    = `t.completed_at >= $3::date AND t.completed_at < $4::date + 1`
)

// Выражение staleExpr использует столбец touched временной таблицы dash_t: момент последнего изменения, активности или комментария.
var staleExpr = fmt.Sprintf(`(t.completed_at IS NULL AND t.touched < now() - interval '%d days')`, staleDays)

var (
	incomingDeadline = fmt.Sprintf(`(t.incoming_date + %d)`, incomingDays)
	incomingOpen     = `(t.completed_at IS NULL AND t.incoming_date IS NOT NULL)`
	incomingOverdue  = incomingOpen + ` AND ` + incomingDeadline + ` < current_date`
	incomingBurning  = fmt.Sprintf(`%s AND %s >= current_date AND %s - current_date <= %d`,
		incomingOpen, incomingDeadline, incomingDeadline, incomingBurnDays)
	incomingDone = `(t.incoming_date IS NOT NULL AND ` + periodDone + `)`
	incomingLate = incomingDone + ` AND t.completed_at::date > ` + incomingDeadline
)

// Тип weekPoint предназначен для описания точки графика по неделе.
type weekPoint struct {
	Week      string `json:"week"`
	Created   int    `json:"created"`
	Completed int    `json:"completed"`
}

// Тип priorityMedian предназначен для описания медианы срока по приоритету.
type priorityMedian struct {
	Priority   string   `json:"priority"`
	N          int      `json:"n"`
	MedianDays *float64 `json:"medianDays"`
}

// Тип flowStats предназначен для описания потока задач за период.
type flowStats struct {
	Created    int              `json:"created"`
	Completed  int              `json:"completed"`
	Open       int              `json:"open"`
	WithDue    int              `json:"withDue"`
	OnTime     int              `json:"onTime"`
	Late       int              `json:"late"`
	MedianDays *float64         `json:"medianDays"`
	ByPriority []priorityMedian `json:"byPriority"`
	Weeks      []weekPoint      `json:"weeks"`
}

// Тип overdueItem предназначен для описания просроченной задачи.
type overdueItem struct {
	ID       uuid.UUID `json:"id"`
	Title    string    `json:"title"`
	Board    string    `json:"board"`
	DueDate  string    `json:"dueDate"`
	DaysLate int       `json:"daysLate"`
}

// Тип columnCount предназначен для описания числа задач в колонке.
type columnCount struct {
	Title string `json:"title"`
	Count int    `json:"count"`
}

// Тип attentionStats предназначен для описания среза «на сейчас».
type attentionStats struct {
	Open          int           `json:"open"`
	Overdue       int           `json:"overdue"`
	Overdue1to3   int           `json:"overdue1to3"`
	Overdue4to7   int           `json:"overdue4to7"`
	Overdue8plus  int           `json:"overdue8plus"`
	OldestOverdue []overdueItem `json:"oldestOverdue"`
	Stale         int           `json:"stale"`
	StaleDays     int           `json:"staleDays"`
	WaitingReady  int           `json:"waitingReady"`
	ReadyAvgDays  *float64      `json:"readyAvgDays"`
	ReadyMaxDays  *int          `json:"readyMaxDays"`
	NoAssignee    int           `json:"noAssignee"`
	NoDue         int           `json:"noDue"`
	Urgent        int           `json:"urgent"`
	UrgentOverdue int           `json:"urgentOverdue"`
	ByColumn      []columnCount `json:"byColumn"`
}

// Тип incomingItem предназначен для описания входящего документа.
type incomingItem struct {
	ID       uuid.UUID `json:"id"`
	Title    string    `json:"title"`
	Number   string    `json:"incomingNumber"`
	Date     string    `json:"incomingDate"`
	Deadline string    `json:"deadline"`
	DaysLeft int       `json:"daysLeft"`
}

// Тип incomingStats предназначен для описания статистики входящих документов.
type incomingStats struct {
	Days      int            `json:"days"`
	BurnDays  int            `json:"burnDays"`
	Open      int            `json:"open"`
	Burning   int            `json:"burning"`
	Overdue   int            `json:"overdue"`
	Completed int            `json:"completed"`
	InTime    int            `json:"inTime"`
	AvgDays   *float64       `json:"avgDays"`
	Nearest   []incomingItem `json:"nearest"`
}

// Тип personStats предназначен для описания статистики по человеку.
type personStats struct {
	UserID  uuid.UUID `json:"userId"`
	Open    int       `json:"open"`
	Overdue int       `json:"overdue"`
	Done    int       `json:"done"`
	WithDue int       `json:"withDue"`
	OnTime  int       `json:"onTime"`
}

// Тип dashboardMetrics предназначен для описания всех метрик сводки.
type dashboardMetrics struct {
	Flow      flowStats      `json:"flow"`
	Attention attentionStats `json:"attention"`
	Incoming  incomingStats  `json:"incoming"`
	People    []personStats  `json:"people"`
}

// Функция loadDashboardMetrics предназначена для расчёта метрик сводки в транзакции.
func loadDashboardMetrics(ctx context.Context, tx pgx.Tx, f dashboardFilter) (dashboardMetrics, error) {
	var m dashboardMetrics
	scope := []any{f.BoardID, f.Assignee}
	period := []any{f.BoardID, f.Assignee, f.From, f.To}

	// Поток за период.
	if e := tx.QueryRow(ctx, `
		SELECT count(*) FILTER (WHERE `+periodCreated+`),
		       count(*) FILTER (WHERE `+periodDone+`),
		       count(*) FILTER (WHERE t.completed_at IS NULL),
		       count(*) FILTER (WHERE `+periodDone+` AND t.due_date IS NOT NULL),
		       count(*) FILTER (WHERE `+periodDone+` AND t.due_date IS NOT NULL
		                          AND t.completed_at::date <= t.due_date),
		       percentile_cont(0.5) WITHIN GROUP (
		         ORDER BY extract(epoch FROM (t.completed_at - t.created_at)) / 86400.0)
		         FILTER (WHERE `+periodDone+`)
		  `+metricScope, period...).
		Scan(&m.Flow.Created, &m.Flow.Completed, &m.Flow.Open, &m.Flow.WithDue,
			&m.Flow.OnTime, &m.Flow.MedianDays); e != nil {
		return m, e
	}
	m.Flow.Late = m.Flow.WithDue - m.Flow.OnTime

	m.Flow.ByPriority = []priorityMedian{}
	rows, e := tx.Query(ctx, `
		SELECT t.priority::text, count(*),
		       percentile_cont(0.5) WITHIN GROUP (
		         ORDER BY extract(epoch FROM (t.completed_at - t.created_at)) / 86400.0)
		  `+metricScope+` AND `+periodDone+`
		 GROUP BY t.priority ORDER BY min(CASE t.priority::text
		   WHEN 'very_urgent' THEN 0 WHEN 'urgent' THEN 1 WHEN 'prompt' THEN 2
		   WHEN 'dated' THEN 3 ELSE 4 END)`, period...)
	if e != nil {
		return m, e
	}
	for rows.Next() {
		var p priorityMedian
		if e := rows.Scan(&p.Priority, &p.N, &p.MedianDays); e != nil {
			rows.Close()
			return m, e
		}
		m.Flow.ByPriority = append(m.Flow.ByPriority, p)
	}
	rows.Close()

	// Недели считаются по дате постановки и по дате завершения раздельно; пустые недели добавляются позже.
	byWeek := map[string]*weekPoint{}
	rows, e = tx.Query(ctx, `
		SELECT to_char(date_trunc('week', x.d), 'YYYY-MM-DD'), sum(x.c)::int, sum(x.f)::int
		  FROM (
		    SELECT t.created_at AS d, 1 AS c, 0 AS f `+metricScope+` AND `+periodCreated+`
		    UNION ALL
		    SELECT t.completed_at, 0, 1 `+metricScope+` AND `+periodDone+`
		  ) x GROUP BY 1`, period...)
	if e != nil {
		return m, e
	}
	for rows.Next() {
		var wk weekPoint
		if e := rows.Scan(&wk.Week, &wk.Created, &wk.Completed); e != nil {
			rows.Close()
			return m, e
		}
		byWeek[wk.Week] = &wk
	}
	rows.Close()
	m.Flow.Weeks = fillWeeks(f.From, f.To, byWeek)

	// Срез на сейчас.
	a := &m.Attention
	a.StaleDays = staleDays
	if e := tx.QueryRow(ctx, `
		SELECT count(*) FILTER (WHERE t.completed_at IS NULL),
		       count(*) FILTER (WHERE t.completed_at IS NULL AND t.due_date < current_date),
		       count(*) FILTER (WHERE t.completed_at IS NULL
		                          AND current_date - t.due_date BETWEEN 1 AND 3),
		       count(*) FILTER (WHERE t.completed_at IS NULL
		                          AND current_date - t.due_date BETWEEN 4 AND 7),
		       count(*) FILTER (WHERE t.completed_at IS NULL
		                          AND current_date - t.due_date > 7),
		       count(*) FILTER (WHERE `+staleExpr+`),
		       count(*) FILTER (WHERE t.completed_at IS NULL AND t.ready_at IS NOT NULL),
		       (avg(current_date - t.ready_at::date)
		          FILTER (WHERE t.completed_at IS NULL AND t.ready_at IS NOT NULL))::float8,
		       max(current_date - t.ready_at::date)
		          FILTER (WHERE t.completed_at IS NULL AND t.ready_at IS NOT NULL),
		       count(*) FILTER (WHERE t.completed_at IS NULL AND NOT EXISTS (
		           SELECT 1 FROM dash_a x WHERE x.task_id = t.id)),
		       count(*) FILTER (WHERE t.completed_at IS NULL AND t.due_date IS NULL),
		       count(*) FILTER (WHERE t.completed_at IS NULL
		                          AND t.priority::text IN ('urgent','very_urgent')),
		       count(*) FILTER (WHERE t.completed_at IS NULL
		                          AND t.priority::text IN ('urgent','very_urgent')
		                          AND t.due_date < current_date)
		  `+metricScope, scope...).
		Scan(&a.Open, &a.Overdue, &a.Overdue1to3, &a.Overdue4to7, &a.Overdue8plus,
			&a.Stale, &a.WaitingReady, &a.ReadyAvgDays, &a.ReadyMaxDays,
			&a.NoAssignee, &a.NoDue, &a.Urgent, &a.UrgentOverdue); e != nil {
		return m, e
	}

	a.OldestOverdue = []overdueItem{}
	rows, e = tx.Query(ctx, `
		SELECT t.id, t.title, app.board_title(t.board_id),
		       to_char(t.due_date, 'YYYY-MM-DD'), current_date - t.due_date
		  `+metricScope+` AND t.completed_at IS NULL AND t.due_date < current_date
		 ORDER BY t.due_date, t.created_at LIMIT 5`, scope...)
	if e != nil {
		return m, e
	}
	for rows.Next() {
		var it overdueItem
		if e := rows.Scan(&it.ID, &it.Title, &it.Board, &it.DueDate, &it.DaysLate); e != nil {
			rows.Close()
			return m, e
		}
		a.OldestOverdue = append(a.OldestOverdue, it)
	}
	rows.Close()

	a.ByColumn = []columnCount{}
	rows, e = tx.Query(ctx, `
		SELECT app.column_title(t.column_id), count(*)
		  `+metricScope+` AND t.completed_at IS NULL
		 GROUP BY 1 ORDER BY 2 DESC, 1 LIMIT 12`, scope...)
	if e != nil {
		return m, e
	}
	for rows.Next() {
		var cc columnCount
		if e := rows.Scan(&cc.Title, &cc.Count); e != nil {
			rows.Close()
			return m, e
		}
		a.ByColumn = append(a.ByColumn, cc)
	}
	rows.Close()

	// Входящие документы: срок 30 дней от даты входящего.
	in := &m.Incoming
	in.Days, in.BurnDays = incomingDays, incomingBurnDays
	if e := tx.QueryRow(ctx, `
		SELECT count(*) FILTER (WHERE `+incomingOpen+`),
		       count(*) FILTER (WHERE `+incomingBurning+`),
		       count(*) FILTER (WHERE `+incomingOverdue+`),
		       count(*) FILTER (WHERE `+incomingDone+`),
		       count(*) FILTER (WHERE `+incomingDone+` AND t.completed_at::date <= `+incomingDeadline+`),
		       (avg(t.completed_at::date - t.incoming_date) FILTER (WHERE `+incomingDone+`))::float8
		  `+metricScope, period...).
		Scan(&in.Open, &in.Burning, &in.Overdue, &in.Completed, &in.InTime, &in.AvgDays); e != nil {
		return m, e
	}
	// Сначала непросроченные по ближайшему сроку, затем просроченные.
	in.Nearest = []incomingItem{}
	rows, e = tx.Query(ctx, `
		SELECT t.id, t.title, t.incoming_number, to_char(t.incoming_date, 'YYYY-MM-DD'),
		       to_char(`+incomingDeadline+`, 'YYYY-MM-DD'), `+incomingDeadline+` - current_date
		  `+metricScope+` AND `+incomingOpen+`
		 ORDER BY (`+incomingDeadline+` < current_date), t.incoming_date, t.created_at
		 LIMIT 5`, scope...)
	if e != nil {
		return m, e
	}
	for rows.Next() {
		var it incomingItem
		if e := rows.Scan(&it.ID, &it.Title, &it.Number, &it.Date, &it.Deadline, &it.DaysLeft); e != nil {
			rows.Close()
			return m, e
		}
		in.Nearest = append(in.Nearest, it)
	}
	rows.Close()

	// Срез по людям: время завершения части — собственная отметка либо закрытие задачи целиком.
	m.People = []personStats{}
	rows, e = tx.Query(ctx, `
		SELECT ta.user_id,
		       count(*) FILTER (WHERE p.at IS NULL),
		       count(*) FILTER (WHERE p.at IS NULL AND t.due_date < current_date),
		       count(*) FILTER (WHERE p.at >= $3::date AND p.at < $4::date + 1),
		       count(*) FILTER (WHERE p.at >= $3::date AND p.at < $4::date + 1
		                          AND t.due_date IS NOT NULL),
		       count(*) FILTER (WHERE p.at >= $3::date AND p.at < $4::date + 1
		                          AND t.due_date IS NOT NULL AND p.at::date <= t.due_date)
		  FROM dash_t t
		  JOIN dash_a ta ON ta.task_id = t.id
		  CROSS JOIN LATERAL (SELECT COALESCE(ta.completed_at, t.completed_at) AS at) p
		 WHERE ($1::uuid IS NULL OR t.board_id = $1::uuid)
		   AND ($2::uuid IS NULL OR EXISTS (
		         SELECT 1 FROM dash_a sa
		          WHERE sa.task_id = t.id AND sa.user_id = $2::uuid))
		 GROUP BY ta.user_id
		 ORDER BY 2 DESC, 4 DESC LIMIT 30`, period...)
	if e != nil {
		return m, e
	}
	for rows.Next() {
		var p personStats
		if e := rows.Scan(&p.UserID, &p.Open, &p.Overdue, &p.Done, &p.WithDue, &p.OnTime); e != nil {
			rows.Close()
			return m, e
		}
		m.People = append(m.People, p)
	}
	rows.Close()
	return m, rows.Err()
}

// Функция fillWeeks предназначена для заполнения точек по неделям от начала до конца периода, включая пустые недели.
func fillWeeks(from, to string, have map[string]*weekPoint) []weekPoint {
	out := []weekPoint{}
	start, err1 := time.Parse("2006-01-02", from)
	end, err2 := time.Parse("2006-01-02", to)
	if err1 != nil || err2 != nil {
		return out
	}
	monday := func(d time.Time) time.Time {
		off := (int(d.Weekday()) + 6) % 7
		return d.AddDate(0, 0, -off)
	}
	for d, n := monday(start), 0; !d.After(end) && n < maxWeeks; d, n = d.AddDate(0, 0, 7), n+1 {
		key := d.Format("2006-01-02")
		if p, ok := have[key]; ok {
			out = append(out, *p)
		} else {
			out = append(out, weekPoint{Week: key})
		}
	}
	return out
}

// Метод DashboardTasks предназначен для получения списка задач под числом метрики; условия совпадают с расчётом метрик.
// Параметры: kind, boardId, assignee, from, to.
func (s *Server) DashboardTasks(c *fiber.Ctx) error {
	f := readDashboardFilter(c)
	kind := c.Query("kind")
	uid := s.uid(c)

	args := []any{f.BoardID, f.Assignee, f.From, f.To}
	var cond, order string
	order = `t.due_date NULLS LAST, t.created_at DESC`
	switch kind {
	case "created":
		cond = periodCreated
	case "completed":
		cond = periodDone
		order = `t.completed_at DESC`
	case "ontime":
		cond = periodDone + ` AND t.due_date IS NOT NULL AND t.completed_at::date <= t.due_date`
		order = `t.completed_at DESC`
	case "late":
		cond = periodDone + ` AND t.due_date IS NOT NULL AND t.completed_at::date > t.due_date`
		order = `t.completed_at DESC`
	case "open":
		cond = `t.completed_at IS NULL`
	case "overdue":
		cond = `t.completed_at IS NULL AND t.due_date < current_date`
	case "overdue_1_3":
		cond = `t.completed_at IS NULL AND current_date - t.due_date BETWEEN 1 AND 3`
	case "overdue_4_7":
		cond = `t.completed_at IS NULL AND current_date - t.due_date BETWEEN 4 AND 7`
	case "overdue_8":
		cond = `t.completed_at IS NULL AND current_date - t.due_date > 7`
		order = `t.due_date`
	case "stale":
		cond = staleExpr
		order = `t.updated_at`
	case "ready":
		cond = `t.completed_at IS NULL AND t.ready_at IS NOT NULL`
		order = `t.ready_at`
	case "no_assignee":
		cond = `t.completed_at IS NULL AND NOT EXISTS (
		          SELECT 1 FROM dash_a x WHERE x.task_id = t.id)`
	case "no_due":
		cond = `t.completed_at IS NULL AND t.due_date IS NULL`
		order = `t.created_at DESC`
	case "urgent":
		cond = `t.completed_at IS NULL AND t.priority::text IN ('urgent','very_urgent')`
	case "urgent_overdue":
		cond = `t.completed_at IS NULL AND t.priority::text IN ('urgent','very_urgent')
		        AND t.due_date < current_date`
	case "column":
		title := c.Query("column")
		if title == "" {
			return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_column", "Не указана колонка"))
		}
		args = append(args, title)
		cond = `t.completed_at IS NULL AND app.column_title(t.column_id) = $5::text`
	case "incoming_open":
		cond = incomingOpen
		order = `t.incoming_date`
	case "incoming_burning":
		cond = incomingBurning
		order = `t.incoming_date`
	case "incoming_overdue":
		cond = incomingOverdue
		order = `t.incoming_date`
	case "incoming_done":
		cond = incomingDone
		order = `t.completed_at DESC`
	case "incoming_late":
		cond = incomingLate
		order = `t.completed_at DESC`
	case "person_open", "person_done":
		pid, err := uuid.Parse(c.Query("userId"))
		if err != nil {
			return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_user", "Не указан сотрудник"))
		}
		args = append(args, pid)
		// Момент завершения своей части совпадает с метриками по людям.
		done := `COALESCE((SELECT ta.completed_at FROM dash_a ta
		                    WHERE ta.task_id = t.id AND ta.user_id = $5::uuid), t.completed_at)`
		cond = `EXISTS (SELECT 1 FROM dash_a ta
		                 WHERE ta.task_id = t.id AND ta.user_id = $5::uuid) AND `
		if kind == "person_open" {
			cond += done + ` IS NULL`
		} else {
			cond += done + ` >= $3::date AND ` + done + ` < $4::date + 1`
			order = done + ` DESC`
		}
	default:
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_kind", "Неизвестный вид списка"))
	}

	var tasks []taskBrief
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if e := prepareDashboardData(c.Context(), tx, uid, f.BoardID); e != nil {
			return e
		}
		// Параметры $3 и $4 присутствуют в каждом запросе для вывода типов PostgreSQL. Сначала выбираются
		// идентификаторы страницы, затем подробности только для них.
		rows, e := tx.Query(c.Context(), `
			SELECT t.id
			  FROM dash_t t
			 WHERE ($1::uuid IS NULL OR t.board_id = $1::uuid)
			   AND ($2::uuid IS NULL OR EXISTS (
			         SELECT 1 FROM dash_a sa
			          WHERE sa.task_id = t.id AND sa.user_id = $2::uuid))
			   AND ($3::date IS NOT NULL AND $4::date IS NOT NULL)
			   AND (`+cond+`)
			 ORDER BY `+order+`
			 LIMIT 200`, args...)
		if e != nil {
			return e
		}
		ids, e := scanIDs(rows)
		if e != nil {
			return e
		}
		tasks, e = loadBriefs(c.Context(), tx, ids)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, tasks)
}
