// Модуль предназначен для сбора метрик PostgreSQL собственным опросом pg_stat_* раз в 15 секунд:
// размер БД, соединения, фиксации, блокировки, таблицы, прикладные объёмы.

package metrics

import (
	"context"
	"fmt"
	"log/slog"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Тип PGCollector предназначен для снятия метрик БД без внешнего экспортёра и их выдачи в формате Prometheus.
type PGCollector struct {
	pool *pgxpool.Pool
	reg  *Registry

	mu   sync.RWMutex
	text string    // готовый текст метрик, обновляется опросом
	at   time.Time // когда он снят
}

// Функция NewPGCollector предназначена для создания сборщика метрик БД.
func NewPGCollector(pool *pgxpool.Pool, reg *Registry) *PGCollector {
	return &PGCollector{pool: pool, reg: reg}
}

// Метод Start предназначен для запуска опроса БД с интервалом 15 секунд.
func (c *PGCollector) Start(ctx context.Context) {
	go func() {
		c.collect(ctx) // первый снимок сразу, чтобы /metrics не был пустым
		t := time.NewTicker(15 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				c.collect(ctx)
			}
		}
	}()
}

// Метод Text предназначен для получения последнего снимка метрик БД.
func (c *PGCollector) Text() string {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.text
}

// Метод At предназначен для получения времени последнего опроса БД.
func (c *PGCollector) At() time.Time {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.at
}

// Метод collect предназначен для выполнения запросов статистики БД и формирования текста метрик.
func (c *PGCollector) collect(ctx context.Context) {
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	var b strings.Builder

	// Размер БД.
	var dbName string
	var dbSize int64
	if err := c.pool.QueryRow(ctx,
		`SELECT current_database(), pg_database_size(current_database())`).
		Scan(&dbName, &dbSize); err == nil {
		b.WriteString("# HELP pg_database_size_bytes Размер базы данных\n# TYPE pg_database_size_bytes gauge\n")
		fmt.Fprintf(&b, "pg_database_size_bytes{datname=\"%s\"} %d\n", esc(dbName), dbSize)
	} else {
		slog.Debug("метрики базы: размер", "error", err)
	}

	// Соединения по состояниям.
	if rows, err := c.pool.Query(ctx, `
		SELECT COALESCE(state, 'unknown'), count(*)
		  FROM pg_stat_activity
		 WHERE datname = current_database()
		 GROUP BY 1`); err == nil {
		b.WriteString("# HELP pg_connections Соединения с базой по состояниям\n# TYPE pg_connections gauge\n")
		for rows.Next() {
			var state string
			var n int64
			if rows.Scan(&state, &n) == nil {
				fmt.Fprintf(&b, "pg_connections{state=\"%s\"} %d\n", esc(state), n)
			}
		}
		rows.Close()
	}

	// Предел соединений.
	var maxConn int64
	if err := c.pool.QueryRow(ctx,
		`SELECT setting::bigint FROM pg_settings WHERE name = 'max_connections'`).
		Scan(&maxConn); err == nil {
		b.WriteString("# HELP pg_max_connections Предел соединений\n# TYPE pg_max_connections gauge\n")
		fmt.Fprintf(&b, "pg_max_connections %d\n", maxConn)
	}

	// Фиксации, откаты, кэш, блокировки.
	var commits, rollbacks, blksRead, blksHit, deadlocks, tupReturned, tupFetched int64
	if err := c.pool.QueryRow(ctx, `
		SELECT xact_commit, xact_rollback, blks_read, blks_hit,
		       deadlocks, tup_returned, tup_fetched
		  FROM pg_stat_database WHERE datname = current_database()`).
		Scan(&commits, &rollbacks, &blksRead, &blksHit, &deadlocks,
			&tupReturned, &tupFetched); err == nil {

		b.WriteString("# HELP pg_xact_commit_total Зафиксированных транзакций\n# TYPE pg_xact_commit_total counter\n")
		fmt.Fprintf(&b, "pg_xact_commit_total %d\n", commits)
		b.WriteString("# HELP pg_xact_rollback_total Откатов транзакций\n# TYPE pg_xact_rollback_total counter\n")
		fmt.Fprintf(&b, "pg_xact_rollback_total %d\n", rollbacks)
		b.WriteString("# HELP pg_blks_read_total Блоков прочитано с диска\n# TYPE pg_blks_read_total counter\n")
		fmt.Fprintf(&b, "pg_blks_read_total %d\n", blksRead)
		b.WriteString("# HELP pg_blks_hit_total Блоков прочитано из кэша\n# TYPE pg_blks_hit_total counter\n")
		fmt.Fprintf(&b, "pg_blks_hit_total %d\n", blksHit)
		b.WriteString("# HELP pg_deadlocks_total Взаимных блокировок\n# TYPE pg_deadlocks_total counter\n")
		fmt.Fprintf(&b, "pg_deadlocks_total %d\n", deadlocks)
		b.WriteString("# HELP pg_tup_returned_total Строк просмотрено\n# TYPE pg_tup_returned_total counter\n")
		fmt.Fprintf(&b, "pg_tup_returned_total %d\n", tupReturned)
		b.WriteString("# HELP pg_tup_fetched_total Строк выбрано\n# TYPE pg_tup_fetched_total counter\n")
		fmt.Fprintf(&b, "pg_tup_fetched_total %d\n", tupFetched)
	}

	// Самые долгие запрос и транзакция.
	var longestQuery, longestXact, idleInTx float64
	if err := c.pool.QueryRow(ctx, `
		SELECT COALESCE(max(EXTRACT(epoch FROM now() - query_start))
		         FILTER (WHERE state = 'active'), 0),
		       COALESCE(max(EXTRACT(epoch FROM now() - xact_start)), 0),
		       COALESCE(max(EXTRACT(epoch FROM now() - state_change))
		         FILTER (WHERE state = 'idle in transaction'), 0)
		  FROM pg_stat_activity
		 WHERE datname = current_database() AND pid <> pg_backend_pid()`).
		Scan(&longestQuery, &longestXact, &idleInTx); err == nil {

		b.WriteString("# HELP pg_longest_query_seconds Самый долгий активный запрос\n# TYPE pg_longest_query_seconds gauge\n")
		fmt.Fprintf(&b, "pg_longest_query_seconds %g\n", longestQuery)
		b.WriteString("# HELP pg_longest_transaction_seconds Самая долгая транзакция\n# TYPE pg_longest_transaction_seconds gauge\n")
		fmt.Fprintf(&b, "pg_longest_transaction_seconds %g\n", longestXact)
		b.WriteString("# HELP pg_idle_in_transaction_seconds Самая долгая простаивающая транзакция\n# TYPE pg_idle_in_transaction_seconds gauge\n")
		fmt.Fprintf(&b, "pg_idle_in_transaction_seconds %g\n", idleInTx)
	}

	// Блокировки в ожидании.
	var waiting int64
	if err := c.pool.QueryRow(ctx,
		`SELECT count(*) FROM pg_locks WHERE NOT granted`).Scan(&waiting); err == nil {
		b.WriteString("# HELP pg_locks_waiting Запросов, ждущих блокировку\n# TYPE pg_locks_waiting gauge\n")
		fmt.Fprintf(&b, "pg_locks_waiting %d\n", waiting)
	}

	// Таблицы схемы приложения (20 крупнейших): размер, строки, мёртвые строки, автоочистка.
	if rows, err := c.pool.Query(ctx, `
		SELECT relname,
		       pg_total_relation_size(relid),
		       COALESCE(n_live_tup, 0), COALESCE(n_dead_tup, 0),
		       COALESCE(seq_scan, 0), COALESCE(idx_scan, 0),
		       COALESCE(EXTRACT(epoch FROM now() - GREATEST(last_autovacuum, last_vacuum)), -1)
		  FROM pg_stat_user_tables
		 WHERE schemaname = 'app'
		 ORDER BY pg_total_relation_size(relid) DESC
		 LIMIT 20`); err == nil {

		b.WriteString("# HELP pg_table_size_bytes Размер таблицы с индексами\n# TYPE pg_table_size_bytes gauge\n")
		var sizes, live, dead, seqs, idxs, vac strings.Builder
		for rows.Next() {
			var name string
			var size, l, dd, sc, ic int64
			var since float64
			if rows.Scan(&name, &size, &l, &dd, &sc, &ic, &since) != nil {
				continue
			}
			fmt.Fprintf(&sizes, "pg_table_size_bytes{table=\"%s\"} %d\n", esc(name), size)
			fmt.Fprintf(&live, "pg_table_live_rows{table=\"%s\"} %d\n", esc(name), l)
			fmt.Fprintf(&dead, "pg_table_dead_rows{table=\"%s\"} %d\n", esc(name), dd)
			fmt.Fprintf(&seqs, "pg_table_seq_scan_total{table=\"%s\"} %d\n", esc(name), sc)
			fmt.Fprintf(&idxs, "pg_table_idx_scan_total{table=\"%s\"} %d\n", esc(name), ic)
			if since >= 0 {
				fmt.Fprintf(&vac, "pg_table_vacuum_age_seconds{table=\"%s\"} %g\n", esc(name), since)
			}
		}
		rows.Close()
		b.WriteString(sizes.String())
		b.WriteString("# HELP pg_table_live_rows Живых строк в таблице\n# TYPE pg_table_live_rows gauge\n")
		b.WriteString(live.String())
		b.WriteString("# HELP pg_table_dead_rows Мёртвых строк (отставание автоочистки)\n# TYPE pg_table_dead_rows gauge\n")
		b.WriteString(dead.String())
		b.WriteString("# HELP pg_table_seq_scan_total Полных просмотров таблицы\n# TYPE pg_table_seq_scan_total counter\n")
		b.WriteString(seqs.String())
		b.WriteString("# HELP pg_table_idx_scan_total Просмотров по индексу\n# TYPE pg_table_idx_scan_total counter\n")
		b.WriteString(idxs.String())
		b.WriteString("# HELP pg_table_vacuum_age_seconds Сколько прошло с последней очистки\n# TYPE pg_table_vacuum_age_seconds gauge\n")
		b.WriteString(vac.String())
	}

	// Прикладные объёмы (app.system_counts): проекты, задачи, доски.
	if rows, err := c.pool.Query(ctx, `SELECT kind, n FROM app.system_counts()`); err == nil {
		b.WriteString("# HELP kanban_entities Количество объектов в системе\n# TYPE kanban_entities gauge\n")
		for rows.Next() {
			var kind string
			var n int64
			if rows.Scan(&kind, &n) == nil {
				fmt.Fprintf(&b, "kanban_entities{kind=\"%s\"} %d\n", esc(kind), n)
			}
		}
		rows.Close()
	} else {
		slog.Warn("не удалось снять объёмы системы", "err", err)
	}

	c.mu.Lock()
	c.text = b.String()
	c.at = time.Now()
	c.mu.Unlock()
}
