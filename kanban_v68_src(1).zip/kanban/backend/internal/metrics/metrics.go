// Модуль предназначен для сбора метрик приложения и выдачи их в текстовом формате Prometheus
// без внешних библиотек: счётчики, гистограммы, датчики и журнал медленных запросов.

package metrics

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// Переменная durationBuckets задаёт границы гистограммы длительности запросов в секундах.
var durationBuckets = []float64{
	0.001, 0.0025, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10,
}

// Переменная durationBucketIndex сопоставляет подпись ступени гистограммы её позиции в массиве.
var durationBucketIndex = func() map[string]int {
	m := make(map[string]int, len(durationBuckets))
	for i, b := range durationBuckets {
		m[fmtFloat(b)] = i
	}
	return m
}()

// Переменная sizeBuckets задаёт границы гистограммы размера ответа в байтах.
var sizeBuckets = []float64{
	256, 1024, 4096, 16384, 65536, 262144, 1048576, 4194304, 16777216,
}

// Тип labels предназначен для набора меток запроса: метод, маршрут, статус.
type labels struct {
	method string
	route  string
	status string
}

// Метод key предназначен для получения строкового ключа набора меток.
func (l labels) key() string { return l.method + "\x00" + l.route + "\x00" + l.status }

// Тип histogram предназначен для хранения счётчиков ступеней, суммы и общего числа наблюдений
// в целых числах с атомарным обновлением.
type histogram struct {
	counts []uint64 // по ступеням, без последней «+Inf»
	total  uint64
	sumNs  uint64 // сумма в наносекундах либо байтах
}

// Функция newHistogram предназначена для создания гистограммы с заданным числом ступеней.
func newHistogram(n int) *histogram {
	return &histogram{counts: make([]uint64, n)}
}

// Метод observe предназначен для учёта наблюдения в гистограмме.
func (h *histogram) observe(v float64, bounds []float64, scale float64) {
	atomic.AddUint64(&h.total, 1)
	atomic.AddUint64(&h.sumNs, uint64(v*scale))
	// Линейный поиск ступени.
	for i, b := range bounds {
		if v <= b {
			atomic.AddUint64(&h.counts[i], 1)
			return
		}
	}
	// Значение выше последней границы учитывается только в «+Inf» через total.
}

// Тип Registry предназначен для хранения всех метрик приложения.
type Registry struct {
	mu sync.RWMutex

	// Запросы.
	reqTotal    map[string]*uint64    // method|route|status → число
	reqDuration map[string]*histogram // method|route → длительность
	reqSize     map[string]*histogram // method|route → размер ответа
	reqInFlight int64                 // сейчас в обработке

	// База данных.
	dbQueries  map[string]*uint64    // операция → число
	dbDuration map[string]*histogram // операция → длительность
	dbErrors   uint64

	// WebSocket и прикладные события.
	wsEvents   map[string]*uint64 // тип события → число
	appCounter map[string]*uint64 // произвольные прикладные счётчики

	// Датчики: значения считываются в момент выдачи метрик.
	gaugeFn map[string]func() float64

	// Журнал медленных запросов: кольцевой буфер на SlowKeep записей.
	slowMu   sync.Mutex
	slow     []SlowRequest
	slowNext int
	// Счётчик медленных запросов за всё время работы.
	slowTotal uint64

	started time.Time
}

// Тип SlowRequest предназначен для описания медленного запроса.
type SlowRequest struct {
	At      time.Time `json:"at"`
	Method  string    `json:"method"`
	Route   string    `json:"route"`
	Status  int       `json:"status"`
	Seconds float64   `json:"seconds"`
}

const (
	// SlowThreshold — порог длительности, с которого запрос считается медленным.
	SlowThreshold = 500 * time.Millisecond
	// SlowKeep — число записей журнала медленных запросов.
	SlowKeep = 200
)

// Функция New предназначена для создания реестра метрик.
func New() *Registry {
	return &Registry{
		reqTotal:    map[string]*uint64{},
		reqDuration: map[string]*histogram{},
		reqSize:     map[string]*histogram{},
		dbQueries:   map[string]*uint64{},
		dbDuration:  map[string]*histogram{},
		wsEvents:    map[string]*uint64{},
		appCounter:  map[string]*uint64{},
		gaugeFn:     map[string]func() float64{},
		slow:        make([]SlowRequest, 0, SlowKeep),
		started:     time.Now(),
	}
}

// Метод Gauge предназначен для регистрации датчика, значение которого считывается при выдаче метрик.
func (r *Registry) Gauge(name string, fn func() float64) {
	r.mu.Lock()
	r.gaugeFn[name] = fn
	r.mu.Unlock()
}

// Метод counter предназначен для получения счётчика по ключу с созданием при отсутствии.
func (r *Registry) counter(m map[string]*uint64, key string) *uint64 {
	r.mu.RLock()
	c, ok := m[key]
	r.mu.RUnlock()
	if ok {
		return c
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if c, ok = m[key]; ok {
		return c
	}
	c = new(uint64)
	m[key] = c
	return c
}

// Метод hist предназначен для получения гистограммы по ключу с созданием при отсутствии.
func (r *Registry) hist(m map[string]*histogram, key string, n int) *histogram {
	r.mu.RLock()
	h, ok := m[key]
	r.mu.RUnlock()
	if ok {
		return h
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if h, ok = m[key]; ok {
		return h
	}
	h = newHistogram(n)
	m[key] = h
	return h
}

// Метод RequestStarted предназначен для учёта начала обработки запроса.

func (r *Registry) RequestStarted() { atomic.AddInt64(&r.reqInFlight, 1) }
// Метод RequestEnded предназначен для учёта завершения обработки запроса.
func (r *Registry) RequestEnded()   { atomic.AddInt64(&r.reqInFlight, -1) }

// Метод Request предназначен для записи завершённого запроса: счётчик, длительность, размер ответа.
func (r *Registry) Request(method, route string, status int, d time.Duration, size int) {
	l := labels{method: method, route: route, status: strconv.Itoa(status)}
	atomic.AddUint64(r.counter(r.reqTotal, l.key()), 1)

	mr := method + "\x00" + route
	r.hist(r.reqDuration, mr, len(durationBuckets)).
		observe(d.Seconds(), durationBuckets, float64(time.Second))
	if size > 0 {
		r.hist(r.reqSize, mr, len(sizeBuckets)).
			observe(float64(size), sizeBuckets, 1)
	}
	if d >= SlowThreshold {
		atomic.AddUint64(&r.slowTotal, 1)
		r.recordSlow(SlowRequest{
			At: time.Now(), Method: method, Route: route,
			Status: status, Seconds: d.Seconds(),
		})
	}
}

// Метод recordSlow предназначен для записи медленного запроса в кольцо с вытеснением самой старой записи.
func (r *Registry) recordSlow(rec SlowRequest) {
	r.slowMu.Lock()
	defer r.slowMu.Unlock()
	if len(r.slow) < SlowKeep {
		r.slow = append(r.slow, rec)
		return
	}
	r.slow[r.slowNext] = rec
	r.slowNext = (r.slowNext + 1) % SlowKeep
}

// Метод Slow предназначен для получения журнала медленных запросов, свежие записи первыми.
func (r *Registry) Slow() []SlowRequest {
	r.slowMu.Lock()
	defer r.slowMu.Unlock()
	out := make([]SlowRequest, len(r.slow))
	copy(out, r.slow)
	sort.Slice(out, func(i, j int) bool { return out[i].At.After(out[j].At) })
	return out
}


// Метод DBQuery предназначен для записи обращения к БД; op — тип операции (tx, service_tx), не текст запроса.
func (r *Registry) DBQuery(op string, d time.Duration, err bool) {
	atomic.AddUint64(r.counter(r.dbQueries, op), 1)
	r.hist(r.dbDuration, op, len(durationBuckets)).
		observe(d.Seconds(), durationBuckets, float64(time.Second))
	if err {
		atomic.AddUint64(&r.dbErrors, 1)
	}
}

// Метод WSEvent предназначен для учёта события WebSocket по его типу.

func (r *Registry) WSEvent(kind string) {
	atomic.AddUint64(r.counter(r.wsEvents, kind), 1)
}

// Метод Inc предназначен для увеличения прикладного счётчика (уведомления, входы, загрузки).
func (r *Registry) Inc(name string) {
	atomic.AddUint64(r.counter(r.appCounter, name), 1)
}

// Функция esc предназначена для экранирования значения метки.

func esc(v string) string {
	v = strings.ReplaceAll(v, `\`, `\\`)
	v = strings.ReplaceAll(v, `"`, `\"`)
	v = strings.ReplaceAll(v, "\n", `\n`)
	return v
}

// Метод Render предназначен для получения всех метрик в текстовом формате Prometheus.
func (r *Registry) Render() string {
	locked := true
	r.mu.RLock()
	defer func() {
		if locked {
			r.mu.RUnlock()
		}
	}()

	var b strings.Builder

	// Раздел: число запросов.
	b.WriteString("# HELP kanban_http_requests_total Обработано HTTP-запросов\n")
	b.WriteString("# TYPE kanban_http_requests_total counter\n")
	for _, k := range sortedKeys(r.reqTotal) {
		p := strings.Split(k, "\x00")
		fmt.Fprintf(&b, "kanban_http_requests_total{method=\"%s\",route=\"%s\",status=\"%s\"} %d\n",
			esc(p[0]), esc(p[1]), esc(p[2]), atomic.LoadUint64(r.reqTotal[k]))
	}

	// Раздел: длительность запросов.
	b.WriteString("# HELP kanban_http_request_duration_seconds Время обработки запроса\n")
	b.WriteString("# TYPE kanban_http_request_duration_seconds histogram\n")
	for _, k := range sortedHistKeys(r.reqDuration) {
		p := strings.Split(k, "\x00")
		lbl := fmt.Sprintf("method=\"%s\",route=\"%s\"", esc(p[0]), esc(p[1]))
		writeHistogram(&b, "kanban_http_request_duration_seconds", lbl,
			r.reqDuration[k], durationBuckets, float64(time.Second))
	}

	// Раздел: размер ответов.
	b.WriteString("# HELP kanban_http_response_bytes Размер ответа\n")
	b.WriteString("# TYPE kanban_http_response_bytes histogram\n")
	for _, k := range sortedHistKeys(r.reqSize) {
		p := strings.Split(k, "\x00")
		lbl := fmt.Sprintf("method=\"%s\",route=\"%s\"", esc(p[0]), esc(p[1]))
		writeHistogram(&b, "kanban_http_response_bytes", lbl, r.reqSize[k], sizeBuckets, 1)
	}

	b.WriteString("# HELP kanban_slow_requests_total Запросов дольше порога\n")
	b.WriteString("# TYPE kanban_slow_requests_total counter\n")
	fmt.Fprintf(&b, "kanban_slow_requests_total %d\n", atomic.LoadUint64(&r.slowTotal))

	b.WriteString("# HELP kanban_http_requests_in_flight Запросов в обработке сейчас\n")
	b.WriteString("# TYPE kanban_http_requests_in_flight gauge\n")
	fmt.Fprintf(&b, "kanban_http_requests_in_flight %d\n", atomic.LoadInt64(&r.reqInFlight))

	// Раздел: БД.
	b.WriteString("# HELP kanban_db_queries_total Транзакций к базе\n")
	b.WriteString("# TYPE kanban_db_queries_total counter\n")
	for _, k := range sortedKeys(r.dbQueries) {
		fmt.Fprintf(&b, "kanban_db_queries_total{op=\"%s\"} %d\n",
			esc(k), atomic.LoadUint64(r.dbQueries[k]))
	}
	b.WriteString("# HELP kanban_db_query_duration_seconds Время транзакции к базе\n")
	b.WriteString("# TYPE kanban_db_query_duration_seconds histogram\n")
	for _, k := range sortedHistKeys(r.dbDuration) {
		writeHistogram(&b, "kanban_db_query_duration_seconds",
			fmt.Sprintf("op=\"%s\"", esc(k)), r.dbDuration[k],
			durationBuckets, float64(time.Second))
	}
	b.WriteString("# HELP kanban_db_errors_total Ошибок при работе с базой\n")
	b.WriteString("# TYPE kanban_db_errors_total counter\n")
	fmt.Fprintf(&b, "kanban_db_errors_total %d\n", atomic.LoadUint64(&r.dbErrors))

	// Раздел: события WebSocket.
	b.WriteString("# HELP kanban_ws_events_total Отправлено событий по WebSocket\n")
	b.WriteString("# TYPE kanban_ws_events_total counter\n")
	for _, k := range sortedKeys(r.wsEvents) {
		fmt.Fprintf(&b, "kanban_ws_events_total{type=\"%s\"} %d\n",
			esc(k), atomic.LoadUint64(r.wsEvents[k]))
	}

	// Раздел: прикладные счётчики.
	b.WriteString("# HELP kanban_app_events_total Прикладные события\n")
	b.WriteString("# TYPE kanban_app_events_total counter\n")
	for _, k := range sortedKeys(r.appCounter) {
		fmt.Fprintf(&b, "kanban_app_events_total{event=\"%s\"} %d\n",
			esc(k), atomic.LoadUint64(r.appCounter[k]))
	}

	// Датчики вызываются без блокировки реестра, чтобы исключить взаимную блокировку.
	gauges := make([]string, 0, len(r.gaugeFn))
	gaugeFns := make([]func() float64, 0, len(r.gaugeFn))
	for _, name := range sortedGauges(r.gaugeFn) {
		gauges = append(gauges, name)
		gaugeFns = append(gaugeFns, r.gaugeFn[name])
	}

	b.WriteString("# HELP kanban_uptime_seconds Время работы процесса\n")
	b.WriteString("# TYPE kanban_uptime_seconds gauge\n")
	fmt.Fprintf(&b, "kanban_uptime_seconds %.0f\n", time.Since(r.started).Seconds())

	head := b.String()
	r.mu.RUnlock()
	locked = false

	var g strings.Builder
	for i, name := range gauges {
		fmt.Fprintf(&g, "# TYPE %s gauge\n%s %g\n", name, name, gaugeFns[i]())
	}
	return head + g.String()
}

// Функция writeHistogram предназначена для вывода ступеней (кумулятивно), суммы и числа наблюдений.
func writeHistogram(b *strings.Builder, name, lbl string, h *histogram,
	bounds []float64, scale float64) {

	// Значение total читается первым и ограничивает ступени сверху.
	total := atomic.LoadUint64(&h.total)
	var acc uint64
	for i, bound := range bounds {
		acc += atomic.LoadUint64(&h.counts[i])
		if acc > total {
			acc = total
		}
		fmt.Fprintf(b, "%s_bucket{%s,le=\"%s\"} %d\n", name, lbl, fmtFloat(bound), acc)
	}
	fmt.Fprintf(b, "%s_bucket{%s,le=\"+Inf\"} %d\n", name, lbl, total)
	fmt.Fprintf(b, "%s_sum{%s} %g\n", name, lbl, float64(atomic.LoadUint64(&h.sumNs))/scale)
	fmt.Fprintf(b, "%s_count{%s} %d\n", name, lbl, total)
}

// Функция fmtFloat предназначена для форматирования числа в тексте метрик.
func fmtFloat(v float64) string {
	return strconv.FormatFloat(v, 'g', -1, 64)
}

// Функция sortedKeys предназначена для получения отсортированных ключей карты счётчиков.
func sortedKeys(m map[string]*uint64) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

// Функция sortedHistKeys предназначена для получения отсортированных ключей карты гистограмм.
func sortedHistKeys(m map[string]*histogram) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

// Функция sortedGauges предназначена для получения отсортированных имён датчиков.
func sortedGauges(m map[string]func() float64) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
