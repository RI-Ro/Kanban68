// Модуль предназначен для хранения истории показаний метрик в памяти приложения: периодическое снятие,
// сокращение снимков и расчёт скоростей и перцентилей.

package metrics

import (
	"context"
	"math"
	"sort"
	"strings"
	"sync"
	"time"
)

// Константы Sampler: шаг снятия показаний, объём истории и параметры хранения разбивки по маршрутам.
const (
	// SampleStep — шаг снятия показаний.
	SampleStep = 10 * time.Second
	// SampleKeep — число точек подробного кольца (1 час при шаге 10 секунд).
	SampleKeep = 360
	// CoarseEvery и CoarseKeep задают крупное кольцо: каждая 6-я точка (раз в минуту), 24 часа. Всего хранится
	// не более 24 часов истории, поэтому память под статистику ограничена и не растёт со временем работы.
	CoarseEvery = 6
	CoarseKeep  = 1440
	// RouteEvery — периодичность сохранения разбивки по маршрутам (в точках, раз в минуту).
	RouteEvery = 6 // то есть раз в минуту
	// RouteKeepTop — число маршрутов в точке; значение выше числа маршрутов приложения.
	RouteKeepTop = 250
)

// Тип routeFrame предназначен для хранения накопленных счётчиков и ступеней маршрута на момент снимка.
type routeFrame struct {
	count   float64
	sumSec  float64
	errors  float64
	buckets []float64 // по durationBuckets, кумулятивно
}

// Тип frame предназначен для хранения сокращённого снимка показаний для дашборда.
type frame struct {
	at time.Time
	// Время опроса БД: метрики pg_* снимаются реже остальных.
	pgAt time.Time

	reqTotal         float64
	req2xx, req3xx   float64
	req4xx, req5xx   float64
	durCount, durSum float64
	durBuckets       map[float64]float64
	sizeSum          float64
	inFlight         float64
	slowTotal        float64
	wsEvents         float64
	wsConns, wsUsers float64
	dbTx, dbTxSum    float64
	dbTxBuckets      map[float64]float64
	dbErrors         float64
	poolTotal        float64
	poolAcquired     float64
	poolIdle         float64
	poolMax          float64
	poolEmpty        float64
	pgCommits        float64
	pgRollbacks      float64
	pgHit, pgRead    float64
	pgDeadlocks      float64
	pgConnsActive    float64
	pgConnsIdle      float64
	pgConnsIdleTx    float64
	pgSize           float64
	pgLongestQuery   float64
	pgLongestTx      float64
	pgIdleInTx       float64
	pgLocksWaiting   float64
	pgTupReturned    float64
	pgTupFetched     float64

	routes map[string]routeFrame // не в каждой точке, см. RouteEvery
	// Список маршрутов подрезан по RouteKeepTop.
	routesCapped bool
}

// Тип Sampler предназначен для снятия и хранения показаний.
type Sampler struct {
	reg *Registry
	pg  *PGCollector

	mu    sync.RWMutex
	ring  []frame
	next  int
	count int
	// Крупное кольцо: точки раз в минуту за 24 часа.
	coarse []frame
	cnext  int
	ccount int
	n      int64 // сколько снимков сделано — для шага маршрутов
	last   *Scrape
}

// Функция NewSampler предназначена для создания Sampler.
func NewSampler(reg *Registry, pg *PGCollector) *Sampler {
	return &Sampler{reg: reg, pg: pg, ring: make([]frame, SampleKeep), coarse: make([]frame, CoarseKeep)}
}

// Метод Start предназначен для запуска периодического снятия показаний.
func (s *Sampler) Start(ctx context.Context) {
	go func() {
		s.sample() // первая точка сразу: дашборд не должен быть пустым
		t := time.NewTicker(SampleStep)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				s.sample()
			}
		}
	}()
}

// Метод text предназначен для получения текста метрик, идентичного выдаче /metrics.
func (s *Sampler) text() string {
	out := s.reg.Render()
	if s.pg != nil {
		out += s.pg.Text()
	}
	return out
}

// Метод sample предназначен для снятия одного показания и добавления его в кольцо.
func (s *Sampler) sample() {
	now := time.Now()
	sc := ParseScrape(s.text(), now)

	s.mu.Lock()
	// Разбивка по маршрутам собирается только в каждой RouteEvery-й точке.
	withRoutes := s.n%RouteEvery == 0
	s.n++
	s.mu.Unlock()

	f := reduce(sc, withRoutes)
	if s.pg != nil {
		f.pgAt = s.pg.At()
	} else {
		f.pgAt = now
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	s.last = sc
	s.ring[s.next] = f
	s.next = (s.next + 1) % len(s.ring)
	if s.count < len(s.ring) {
		s.count++
	}
	// Каждая CoarseEvery-я точка копируется в крупное кольцо. Разбивка по маршрутам в нём хранится раз в 5 минут:
	// она самая тяжёлая часть точки.
	if (s.n-1)%CoarseEvery == 0 {
		cf := f
		if cf.at.Unix()/60%5 != 0 {
			cf.routes = nil
		}
		s.coarse[s.cnext] = cf
		s.cnext = (s.cnext + 1) % len(s.coarse)
		if s.ccount < len(s.coarse) {
			s.ccount++
		}
	}
}

// Функция reduce предназначена для сокращения полного разбора до нужных чисел.
func reduce(sc *Scrape, withRoutes bool) frame {
	conns := sc.By("pg_connections", "state")
	f := frame{
		at:       sc.At,
		reqTotal: sc.Sum("kanban_http_requests_total"),
		req2xx:   sc.Sum("kanban_http_requests_total", "status", "~2"),
		req3xx:   sc.Sum("kanban_http_requests_total", "status", "~3"),
		req4xx:   sc.Sum("kanban_http_requests_total", "status", "~4"),
		req5xx:   sc.Sum("kanban_http_requests_total", "status", "~5"),

		durCount:   sc.Sum("kanban_http_request_duration_seconds_count"),
		durSum:     sc.Sum("kanban_http_request_duration_seconds_sum"),
		durBuckets: sc.Buckets("kanban_http_request_duration_seconds_bucket"),
		sizeSum:    sc.Sum("kanban_http_response_bytes_sum"),
		inFlight:   sc.One("kanban_http_requests_in_flight"),
		slowTotal:  sc.Sum("kanban_slow_requests_total"),

		wsEvents: sc.Sum("kanban_ws_events_total"),
		wsConns:  sc.One("kanban_ws_connections"),
		wsUsers:  sc.One("kanban_ws_users"),

		dbTx:        sc.Sum("kanban_db_queries_total"),
		dbTxSum:     sc.Sum("kanban_db_query_duration_seconds_sum"),
		dbTxBuckets: sc.Buckets("kanban_db_query_duration_seconds_bucket"),
		dbErrors:    sc.Sum("kanban_db_errors_total"),

		poolTotal:    sc.One("kanban_db_pool_total"),
		poolAcquired: sc.One("kanban_db_pool_acquired"),
		poolIdle:     sc.One("kanban_db_pool_idle"),
		poolMax:      sc.One("kanban_db_pool_max"),
		poolEmpty:    sc.One("kanban_db_pool_empty_acquires"),

		pgCommits:      sc.Sum("pg_xact_commit_total"),
		pgRollbacks:    sc.Sum("pg_xact_rollback_total"),
		pgHit:          sc.Sum("pg_blks_hit_total"),
		pgRead:         sc.Sum("pg_blks_read_total"),
		pgDeadlocks:    sc.Sum("pg_deadlocks_total"),
		pgConnsActive:  conns["active"],
		pgConnsIdle:    conns["idle"],
		pgConnsIdleTx:  conns["idle in transaction"],
		pgSize:         sc.Sum("pg_database_size_bytes"),
		pgLongestQuery: sc.One("pg_longest_query_seconds"),
		pgLongestTx:    sc.One("pg_longest_transaction_seconds"),
		pgIdleInTx:     sc.One("pg_idle_in_transaction_seconds"),
		pgLocksWaiting: sc.One("pg_locks_waiting"),
		pgTupReturned:  sc.Sum("pg_tup_returned_total"),
		pgTupFetched:   sc.Sum("pg_tup_fetched_total"),
	}

	if withRoutes {
		f.routes, f.routesCapped = routesOf(sc)
	}
	return f
}

// Функция routesOf предназначена для получения разбивки по маршрутам из снимка; ключ — «МЕТОД маршрут».
func routesOf(sc *Scrape) (map[string]routeFrame, bool) {
	routes := map[string]routeFrame{}
	for _, lv := range sc.Series["kanban_http_request_duration_seconds_count"] {
		k := lv.Labels["method"] + " " + lv.Labels["route"]
		rf := routes[k]
		rf.count += lv.Value
		routes[k] = rf
	}
	for _, lv := range sc.Series["kanban_http_request_duration_seconds_sum"] {
		k := lv.Labels["method"] + " " + lv.Labels["route"]
		rf := routes[k]
		rf.sumSec += lv.Value
		routes[k] = rf
	}
	for _, lv := range sc.Series["kanban_http_request_duration_seconds_bucket"] {
		i, ok := durationBucketIndex[lv.Labels["le"]]
		if !ok {
			continue // «+Inf»: его роль играет count
		}
		k := lv.Labels["method"] + " " + lv.Labels["route"]
		rf := routes[k]
		if rf.buckets == nil {
			rf.buckets = make([]float64, len(durationBuckets))
		}
		rf.buckets[i] += lv.Value
		routes[k] = rf
	}
	for _, lv := range sc.Series["kanban_http_requests_total"] {
		st := lv.Labels["status"]
		if !strings.HasPrefix(st, "4") && !strings.HasPrefix(st, "5") {
			continue
		}
		k := lv.Labels["method"] + " " + lv.Labels["route"]
		rf := routes[k]
		rf.errors += lv.Value
		routes[k] = rf
	}
	capped := len(routes) > RouteKeepTop
	return topRoutes(routes, RouteKeepTop), capped
}

// Функция topRoutes предназначена для отбора самых нагруженных маршрутов.
func topRoutes(in map[string]routeFrame, limit int) map[string]routeFrame {
	if len(in) <= limit {
		return in
	}
	keys := make([]string, 0, len(in))
	for k := range in {
		keys = append(keys, k)
	}
	sort.Slice(keys, func(i, j int) bool { return in[keys[i]].count > in[keys[j]].count })
	out := make(map[string]routeFrame, limit)
	for _, k := range keys[:limit] {
		out[k] = in[k]
	}
	return out
}

// Метод framesLocked предназначен для получения точек в хронологическом порядке за период; вызывается при взятом s.mu.
// Период до часа берётся из подробного кольца (шаг 10 секунд), длиннее — из крупного (шаг минута) с самой свежей точкой.
func (s *Sampler) framesLocked(window time.Duration) []frame {
	cut := time.Now().Add(-window)
	if window <= time.Duration(SampleKeep)*SampleStep {
		return collect(s.ring, s.next, s.count, cut)
	}
	out := collect(s.coarse, s.cnext, s.ccount, cut)
	if s.count > 0 {
		newest := s.ring[(s.next-1+len(s.ring))%len(s.ring)]
		if len(out) == 0 || newest.at.After(out[len(out)-1].at) {
			out = append(out, newest)
		}
	}
	return out
}

// Функция collect предназначена для выбора из кольца точек не старше границы cut в хронологическом порядке.
func collect(ring []frame, next, count int, cut time.Time) []frame {
	out := make([]frame, 0, count)
	start := 0
	if count == len(ring) {
		start = next
	}
	for i := 0; i < count; i++ {
		f := ring[(start+i)%len(ring)]
		if f.at.IsZero() || f.at.Before(cut) {
			continue
		}
		out = append(out, f)
	}
	return out
}

// Функция rate предназначена для расчёта прироста счётчика в секунду; отрицательный прирост (сброс счётчика) отбрасывается.
func rate(cur, prev float64, dt float64) float64 {
	if dt <= 0 || cur < prev {
		return 0
	}
	return (cur - prev) / dt
}

// Функция quantile предназначена для расчёта перцентиля по кумулятивной гистограмме с линейной интерполяцией внутри ступени.
func quantile(buckets map[float64]float64, total, q float64) float64 {
	if total <= 0 || len(buckets) == 0 {
		return 0
	}
	bounds := make([]float64, 0, len(buckets))
	for b := range buckets {
		bounds = append(bounds, b)
	}
	sort.Float64s(bounds)

	want := q * total
	prevBound, prevCount := 0.0, 0.0
	for _, b := range bounds {
		c := buckets[b]
		if c >= want {
			if c == prevCount {
				return b
			}
			// Линейная интерполяция внутри ступени.
			return prevBound + (b-prevBound)*(want-prevCount)/(c-prevCount)
		}
		prevBound, prevCount = b, c
	}
	// Выше последней границы возвращается последняя граница.
	if len(bounds) > 0 {
		return bounds[len(bounds)-1]
	}
	return 0
}

// Функция diffBuckets предназначена для расчёта прироста ступеней гистограммы между точками.
func diffBuckets(cur, prev map[float64]float64) (map[float64]float64, float64) {
	out := make(map[float64]float64, len(cur))
	var top float64
	for b, v := range cur {
		d := v - prev[b]
		if d < 0 {
			d = 0
		}
		out[b] = d
		if d > top {
			top = d
		}
	}
	return out, top
}

// Функция safeDiv предназначена для деления с нулевым результатом при нулевом делителе.
func safeDiv(a, b float64) float64 {
	if b == 0 || math.IsNaN(b) {
		return 0
	}
	return a / b
}
