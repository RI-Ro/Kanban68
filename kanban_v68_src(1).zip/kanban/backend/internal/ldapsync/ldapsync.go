// Модуль предназначен для обращения к LDAP-серверам: поиск пользователя по логину и сопоставление атрибутов LDAP
// с атрибутами приложения по шаблонам вида "{surname} {name} {patronymic}". Запросы анонимные, без авторизации
// (аналог ldapsearch -x без -D и -w), поэтому сервер должен разрешать анонимное чтение нужных атрибутов.

package ldapsync

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"net"
	"regexp"
	"strings"

	"github.com/go-ldap/ldap/v3"

	"github.com/example/kanban/internal/config"
)

// Ошибки поиска: пользователь не найден или найдено несколько записей.
var (
	ErrNotFound  = errors.New("пользователь не найден в LDAP")
	ErrAmbiguous = errors.New("по логину найдено несколько записей LDAP")
)

// Тип Profile предназначен для описания сведений о пользователе, полученных из LDAP.
type Profile struct {
	DN       string            `json:"dn"`
	FullName string            `json:"fullName"`
	Position string            `json:"position"`
	Phone    string            `json:"phone"`
	Email    string            `json:"email"`
	Raw      map[string]string `json:"raw,omitempty"`
	// Фото из атрибута, указанного в сопоставлении как photo (обычно jpegPhoto); nil — атрибута нет или он пуст.
	Photo    []byte `json:"-"`
	HasPhoto bool   `json:"hasPhoto"`
}

var placeholder = regexp.MustCompile(`\{([A-Za-z0-9_;.-]+)\}`)

// Функция Find предназначена для поиска сервера в списке по идентификатору.
func Find(servers []config.LDAPServer, id string) (config.LDAPServer, bool) {
	for _, s := range servers {
		if s.ID == id {
			return s, true
		}
	}
	return config.LDAPServer{}, false
}

// Функция defaultFilter предназначена для фильтра по умолчанию, если в конфигурации он не задан.
const defaultFilter = "(|(userPrincipalName={login})(sAMAccountName={user})(uid={user}))"

// Функция buildFilter предназначена для подстановки логина в фильтр: {login} — полностью, {user} — часть до «@»,
// {realm} — часть после «@». Значения экранируются по правилам LDAP, внедрение в фильтр невозможно.
func buildFilter(tpl, login string) string {
	if tpl == "" {
		tpl = defaultFilter
	}
	user, realm := login, ""
	if i := strings.LastIndex(login, "@"); i >= 0 {
		user, realm = login[:i], login[i+1:]
	}
	r := strings.NewReplacer("{login}", ldap.EscapeFilter(login), "{user}", ldap.EscapeFilter(user), "{realm}", ldap.EscapeFilter(realm))
	return r.Replace(tpl)
}

// Функция wanted предназначена для перечня атрибутов LDAP, которые нужны шаблонам сопоставления.
func wanted(attrs map[string]string) []string {
	seen := map[string]bool{}
	var out []string
	for _, tpl := range attrs {
		if tpl == attrs["photo"] {
			continue
		}
		for _, m := range placeholder.FindAllStringSubmatch(tpl, -1) {
			k := strings.ToLower(m[1])
			if !seen[k] {
				seen[k] = true
				out = append(out, m[1])
			}
		}
	}
	// Атрибут фото запрашивается отдельно: в сопоставлении он задан именем без фигурных скобок.
	if ph := strings.Trim(strings.TrimSpace(attrs["photo"]), "{}"); ph != "" && !seen[strings.ToLower(ph)] {
		out = append(out, ph)
	}
	if len(out) == 0 {
		return []string{"*"}
	}
	return out
}

// Функция render предназначена для подстановки значений атрибутов в шаблон; отсутствующий атрибут даёт пустую строку,
// лишние пробелы схлопываются.
func render(tpl string, entry *ldap.Entry) string {
	if tpl == "" {
		return ""
	}
	out := placeholder.ReplaceAllStringFunc(tpl, func(m string) string {
		name := m[1 : len(m)-1]
		for _, a := range entry.Attributes {
			if strings.EqualFold(a.Name, name) && len(a.Values) > 0 {
				return a.Values[0]
			}
		}
		return ""
	})
	return strings.Join(strings.Fields(out), " ")
}

// Функция Lookup предназначена для анонимного поиска пользователя по логину на сервере и сопоставления атрибутов.
func Lookup(ctx context.Context, srv config.LDAPServer, login string) (*Profile, error) {
	login = strings.TrimSpace(login)
	if login == "" {
		return nil, errors.New("не указан логин")
	}
	dialer := &net.Dialer{Timeout: srv.Timeout}
	opts := []ldap.DialOpt{ldap.DialWithDialer(dialer)}
	tlsCfg := &tls.Config{InsecureSkipVerify: srv.SkipVerify} //nolint:gosec // параметр tls_skip_verify задаёт администратор
	if strings.HasPrefix(strings.ToLower(srv.URL), "ldaps://") {
		opts = append(opts, ldap.DialWithTLSConfig(tlsCfg))
	}
	conn, err := ldap.DialURL(srv.URL, opts...)
	if err != nil {
		return nil, fmt.Errorf("нет связи с LDAP-сервером %s: %w", srv.URL, err)
	}
	defer conn.Close()
	conn.SetTimeout(srv.Timeout)
	if srv.StartTLS {
		if err := conn.StartTLS(tlsCfg); err != nil {
			return nil, fmt.Errorf("STARTTLS: %w", err)
		}
	}
	// Анонимная привязка: пустое имя и пустой пароль.
	if err := conn.UnauthenticatedBind(""); err != nil {
		return nil, fmt.Errorf("анонимный доступ к LDAP не разрешён: %w", err)
	}

	req := ldap.NewSearchRequest(srv.BaseDN, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases, 2,
		int(srv.Timeout.Seconds())+1, false, buildFilter(srv.Filter, login), wanted(srv.Attributes), nil)
	res, err := conn.Search(req)
	if err != nil {
		return nil, fmt.Errorf("поиск в LDAP: %w", err)
	}
	switch len(res.Entries) {
	case 0:
		return nil, ErrNotFound
	case 1:
	default:
		return nil, ErrAmbiguous
	}
	e := res.Entries[0]
	p := &Profile{DN: e.DN, Raw: map[string]string{}}
	for _, a := range e.Attributes {
		if len(a.Values) > 0 && len(a.Values[0]) < 200 {
			p.Raw[a.Name] = a.Values[0]
		}
	}
	p.FullName = render(srv.Attributes["fullName"], e)
	p.Position = render(srv.Attributes["position"], e)
	p.Phone = render(srv.Attributes["phone"], e)
	p.Email = strings.ToLower(render(srv.Attributes["email"], e))
	if ph := strings.Trim(strings.TrimSpace(srv.Attributes["photo"]), "{}"); ph != "" {
		if raw := e.GetRawAttributeValue(ph); len(raw) > 0 {
			p.Photo, p.HasPhoto = raw, true
		}
	}
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	default:
	}
	return p, nil
}
