// Модуль предназначен для проверки access-токена в REST-запросах и получения идентификатора пользователя.

package middleware

import (
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"

	"github.com/example/kanban/internal/auth"
	"github.com/example/kanban/internal/httpx"
)

const localsUserID = "userID"

// Функция Auth предназначена для создания middleware: проверяет подпись токена и сохраняет идентификатор
// пользователя в fiber.Locals. Права доступа далее определяются политиками RLS.
func Auth(m *auth.Manager) fiber.Handler {
	return func(c *fiber.Ctx) error {
		token := bearerToken(c)
		if token == "" {
			// Токен принимается и из параметра access_token: для скачивания файлов и WebSocket заголовок Authorization недоступен.
			token = c.Query("access_token")
		}
		if token == "" {
			return httpx.Fail(c, httpx.ErrUnauthorized)
		}

		userID, err := m.ParseAccess(token)
		if err != nil {
			code := "unauthorized"
			if err == auth.ErrExpired {
				code = "token_expired"
			}
			return httpx.JSON(c, fiber.StatusUnauthorized,
				httpx.ErrorBody{Error: "Требуется вход в систему", Code: code})
		}
		c.Locals(localsUserID, userID)
		return c.Next()
	}
}

// Функция bearerToken предназначена для извлечения токена из заголовка Authorization.
func bearerToken(c *fiber.Ctx) string {
	header := c.Get("Authorization")
	token, ok := strings.CutPrefix(header, "Bearer ")
	if !ok {
		return ""
	}
	return token
}

// Функция UserID предназначена для получения идентификатора пользователя из контекста запроса.
func UserID(c *fiber.Ctx) uuid.UUID {
	id, _ := c.Locals(localsUserID).(uuid.UUID)
	return id
}
