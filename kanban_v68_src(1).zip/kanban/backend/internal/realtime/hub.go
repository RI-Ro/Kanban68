// Модуль предназначен для учёта WebSocket-соединений и рассылки событий их владельцам, включая
// присутствие пользователей и обмен через общую шину между экземплярами.

package realtime

import (
	"encoding/json"
	"log/slog"
	"sync"
	"time"

	"github.com/gofiber/websocket/v2"
	"github.com/google/uuid"
)

const (
	pingInterval = 25 * time.Second
	writeWait    = 10 * time.Second
	// Размер очереди отправки одного соединения.
	sendBuffer = 64
)

// Тип Hub предназначен для хранения соединений и доставки событий.
type Hub struct {
	mu    sync.RWMutex
	conns map[uuid.UUID]map[*Conn]struct{}

	// Общая шина между экземплярами; nil означает работу одного процесса.
	bus *Bus

	// Присутствие, переданное соседними экземплярами; отдельная блокировка не задерживает рассылку событий.
	peerMu sync.Mutex
	peers  map[string]peerPresence

	// Необязательный наблюдатель отправленных событий для метрик.
	observe func(kind string)
}

// Метод SetObserver предназначен для подключения подсчёта событий; nil отключает его.
func (h *Hub) SetObserver(fn func(kind string)) { h.observe = fn }

// Тип Conn предназначен для соединения с собственной очередью отправки. Запись в сокет выполняет
// отдельная горутина; SendTo только помещает кадр в очередь. Переполнение очереди закрывает
// соединение: клиент переподключается и загружает состояние заново.
type Conn struct {
	ws     *websocket.Conn
	send   chan []byte
	closeC chan struct{}
	once   sync.Once
}

// Функция NewHub предназначена для создания хаба.
func NewHub() *Hub {
	return &Hub{
		conns: make(map[uuid.UUID]map[*Conn]struct{}),
		peers: make(map[string]peerPresence),
	}
}

// Метод Register предназначен для регистрации соединения и запуска его писателя; результат передаётся в Unregister.
func (h *Hub) Register(userID uuid.UUID, ws *websocket.Conn) *Conn {
	c := &Conn{
		ws:     ws,
		send:   make(chan []byte, sendBuffer),
		closeC: make(chan struct{}),
	}

	h.mu.Lock()
	if h.conns[userID] == nil {
		h.conns[userID] = make(map[*Conn]struct{})
	}
	h.conns[userID][c] = struct{}{}
	// Присутствие объявляется соседним экземплярам сразу.
	go h.announcePresence()
	h.mu.Unlock()

	go c.writeLoop()
	return c
}

// Метод Unregister предназначен для удаления соединения.
func (h *Hub) Unregister(userID uuid.UUID, c *Conn) {
	defer func() { go h.announcePresence() }()
	c.close()

	h.mu.Lock()
	defer h.mu.Unlock()
	if set, ok := h.conns[userID]; ok {
		delete(set, c)
		if len(set) == 0 {
			delete(h.conns, userID)
		}
	}
}

// Метод Disconnect предназначен для разрыва всех соединений пользователя при блокировке или удалении
// учётной записи: права проверяются только при рукопожатии.
func (h *Hub) Disconnect(userID uuid.UUID) {
	h.mu.RLock()
	targets := make([]*Conn, 0, len(h.conns[userID]))
	for c := range h.conns[userID] {
		targets = append(targets, c)
	}
	h.mu.RUnlock()

	for _, c := range targets {
		c.close()
	}
}

// Метод ConnectedUsers предназначен для подсчёта пользователей с живым соединением (используется в /healthz).
func (h *Hub) ConnectedUsers() int {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return len(h.conns)
}

// Метод Connections предназначен для подсчёта всех соединений.
func (h *Hub) Connections() int {
	h.mu.RLock()
	defer h.mu.RUnlock()
	n := 0
	for _, set := range h.conns {
		n += len(set)
	}
	return n
}

// Тип Event предназначен для описания события, отправляемого клиентам.
type Event struct {
	Type    string `json:"type"`
	Action  string `json:"action,omitempty"`
	Payload any    `json:"payload,omitempty"`
}

// Метод SendTo предназначен для рассылки события указанным пользователям без блокировки:
// сериализация выполняется один раз, доставка идёт через очереди соединений.
func (h *Hub) SendTo(userIDs []uuid.UUID, event Event) {
	if len(userIDs) == 0 {
		return
	}
	if h.observe != nil {
		h.observe(event.Type)
	}
	data, err := json.Marshal(event)
	if err != nil {
		slog.Error("не удалось сериализовать событие", "error", err, "type", event.Type)
		return
	}

	// Событие публикуется в общую шину вместе со списком получателей, вычисленным по правам доступа.
	h.publish(userIDs, data)


	// Получатели выбираются под блокировкой чтения; отправка выполняется вне блокировки.
	h.mu.RLock()
	targets := make([]*Conn, 0, len(userIDs))
	for _, uid := range userIDs {
		for c := range h.conns[uid] {
			targets = append(targets, c)
		}
	}
	h.mu.RUnlock()

	for _, c := range targets {
		c.enqueue(data)
	}
}

// Метод enqueue предназначен для помещения кадра в очередь соединения; при переполнении соединение закрывается.
func (c *Conn) enqueue(data []byte) {
	select {
	case <-c.closeC:
		return
	default:
	}

	select {
	case c.send <- data:
	default:
		slog.Warn("очередь соединения переполнена, закрываем — клиент не успевает читать")
		c.close()
	}
}

// Метод writeLoop предназначен для записи кадров в сокет: единственное место записи, так как конкурентная запись не допускается.
func (c *Conn) writeLoop() {
	ticker := time.NewTicker(pingInterval)
	defer func() {
		ticker.Stop()
		_ = c.ws.Close()
	}()

	for {
		select {
		case <-c.closeC:
			// Прощальный кадр отправляется без ожидания.
			_ = c.ws.SetWriteDeadline(time.Now().Add(time.Second))
			_ = c.ws.WriteMessage(websocket.CloseMessage,
				websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""))
			return

		case data := <-c.send:
			// Срок записи ограничен, чтобы запись в оборванное соединение не блокировалась до таймаута ОС.
			if err := c.ws.SetWriteDeadline(time.Now().Add(writeWait)); err != nil {
				return
			}
			if err := c.ws.WriteMessage(websocket.TextMessage, data); err != nil {
				slog.Debug("запись в сокет не удалась, закрываем", "error", err)
				return
			}

		case <-ticker.C:
			if err := c.ws.SetWriteDeadline(time.Now().Add(writeWait)); err != nil {
				return
			}
			if err := c.ws.WriteMessage(websocket.PingMessage, nil); err != nil {
				// Соединение закрывается, чтобы ReadMessage вернул ошибку и обработчик освободил горутину.
				return
			}
		}
	}
}

// Метод close предназначен для закрытия сокета соединения.
func (c *Conn) close() {
	c.once.Do(func() { close(c.closeC) })
}

// Метод Online предназначен для получения списка пользователей с живым соединением (локальным и у соседних экземпляров).
// Присутствие определяется по соединениям, а не по отметке активности в БД.
func (h *Hub) Online() []uuid.UUID {
	h.mu.RLock()
	seen := make(map[uuid.UUID]bool, len(h.conns))
	for id, set := range h.conns {
		if len(set) > 0 {
			seen[id] = true
		}
	}
	h.mu.RUnlock()

	// К локальным соединениям добавляются сведения соседних экземпляров.
	h.peerMu.Lock()
	now := time.Now()
	for inst, p := range h.peers {
		// Список экземпляра, молчавшего дольше presenceTTL, считается устаревшим.
		if now.Sub(p.at) > presenceTTL {
			delete(h.peers, inst)
			continue
		}
		for _, id := range p.users {
			seen[id] = true
		}
	}
	h.peerMu.Unlock()

	out := make([]uuid.UUID, 0, len(seen))
	for id := range seen {
		out = append(out, id)
	}
	return out
}

// Константы присутствия между экземплярами.

const (
	// Периодичность объявления своих подключённых.
	presenceEvery = 10 * time.Second
	// Время жизни чужого списка без обновления.
	presenceTTL = 25 * time.Second
)

// Тип peerPresence предназначен для хранения списка подключённых соседнего экземпляра и времени получения.
type peerPresence struct {
	users []uuid.UUID
	at    time.Time
}

// Метод announcePresence предназначен для публикации списка своих подключённых. Рассылка периодическая:
// состояние восстанавливается после сбоя шины.
func (h *Hub) announcePresence() {
	if h.bus == nil {
		return
	}
	payload, err := json.Marshal(presenceMessage{
		Kind:  "presence",
		Users: h.localOnline(),
	})
	if err != nil {
		return
	}
	h.bus.Publish(payload)
}

// Метод localOnline предназначен для получения списка локально подключённых пользователей.
func (h *Hub) localOnline() []uuid.UUID {
	h.mu.RLock()
	defer h.mu.RUnlock()
	out := make([]uuid.UUID, 0, len(h.conns))
	for id, set := range h.conns {
		if len(set) > 0 {
			out = append(out, id)
		}
	}
	return out
}

// Тип presenceMessage предназначен для описания сообщения о присутствии в шине.
type presenceMessage struct {
	Kind  string      `json:"kind"`
	Users []uuid.UUID `json:"users"`
}


// Тип busEnvelope предназначен для описания сообщения шины: получатели и событие.
type busEnvelope struct {
	Users []uuid.UUID     `json:"users"`
	Event json.RawMessage `json:"event"`
}

// Метод AttachBus предназначен для подключения хаба к общей шине. Без шины события видят только соединения процесса.
func (h *Hub) AttachBus(bus *Bus) {
	h.bus = bus
	bus.Start(func(instance string, payload []byte) {
		// В канале два вида сообщений (событие и присутствие), различаются полем kind.
		var probe struct {
			Kind string `json:"kind"`
		}
		if err := json.Unmarshal(payload, &probe); err == nil && probe.Kind == "presence" {
			var pm presenceMessage
			if err := json.Unmarshal(payload, &pm); err != nil {
				return
			}
			h.peerMu.Lock()
			h.peers[instance] = peerPresence{users: pm.Users, at: time.Now()}
			h.peerMu.Unlock()
			return
		}

		var env busEnvelope
		if err := json.Unmarshal(payload, &env); err != nil {
			slog.Warn("шина событий: непонятное сообщение", "error", err)
			return
		}
		// Доставка выполняется без повторной публикации.
		h.deliverLocal(env.Users, env.Event)
	})

	// Первое объявление присутствия отправляется сразу.
	h.announcePresence()
	go func() {
		t := time.NewTicker(presenceEvery)
		defer t.Stop()
		for range t.C {
			h.announcePresence()
		}
	}()
}

// Метод publish предназначен для отправки события в общую шину.
func (h *Hub) publish(userIDs []uuid.UUID, data []byte) {
	if h.bus == nil {
		return
	}
	payload, err := json.Marshal(busEnvelope{Users: userIDs, Event: data})
	if err != nil {
		return
	}
	h.bus.Publish(payload)
}

// Метод deliverLocal предназначен для рассылки готового события локальным соединениям.
func (h *Hub) deliverLocal(userIDs []uuid.UUID, data []byte) {
	h.mu.RLock()
	targets := make([]*Conn, 0, len(userIDs))
	for _, uid := range userIDs {
		for c := range h.conns[uid] {
			targets = append(targets, c)
		}
	}
	h.mu.RUnlock()

	for _, c := range targets {
		c.enqueue(data)
	}
}
