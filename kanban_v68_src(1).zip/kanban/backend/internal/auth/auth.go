// Модуль предназначен для выпуска и проверки access-токенов JWT, генерации refresh-токенов
// и хеширования паролей.

package auth

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
)

var (
	ErrInvalidToken = errors.New("недействительный токен")
	ErrExpired      = errors.New("срок действия токена истёк")
)

// Тип Claims предназначен для хранения утверждений access-токена.
type Claims struct {
	jwt.RegisteredClaims
	UserID uuid.UUID `json:"uid"`
}

// Тип Manager предназначен для выпуска и проверки токенов с общим секретом и сроками жизни.
type Manager struct {
	secret     []byte
	accessTTL  time.Duration
	refreshTTL time.Duration
}

// Функция NewManager предназначена для создания Manager.
func NewManager(secret []byte, accessTTL, refreshTTL time.Duration) *Manager {
	return &Manager{secret: secret, accessTTL: accessTTL, refreshTTL: refreshTTL}
}

// Метод AccessTTL предназначен для получения срока жизни access-токена.
func (m *Manager) AccessTTL() time.Duration  { return m.accessTTL }
// Метод RefreshTTL предназначен для получения срока жизни refresh-токена.
func (m *Manager) RefreshTTL() time.Duration { return m.refreshTTL }

// Метод IssueAccess предназначен для выпуска access-токена пользователя.
func (m *Manager) IssueAccess(userID uuid.UUID) (string, error) {
	now := time.Now()
	claims := Claims{
		RegisteredClaims: jwt.RegisteredClaims{
			Subject:   userID.String(),
			IssuedAt:  jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(m.accessTTL)),
			NotBefore: jwt.NewNumericDate(now),
			ID:        uuid.NewString(),
			Issuer:    "kanban",
		},
		UserID: userID,
	}
	return jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString(m.secret)
}

// Метод ParseAccess предназначен для проверки токена и получения идентификатора пользователя.
// Используется и middleware REST, и обработчиком WebSocket.
func (m *Manager) ParseAccess(token string) (uuid.UUID, error) {
	parsed, err := jwt.ParseWithClaims(token, &Claims{}, func(t *jwt.Token) (any, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("неожиданный алгоритм подписи: %v", t.Header["alg"])
		}
		return m.secret, nil
	}, jwt.WithIssuer("kanban"), jwt.WithValidMethods([]string{"HS256"}))

	if err != nil {
		if errors.Is(err, jwt.ErrTokenExpired) {
			return uuid.Nil, ErrExpired
		}
		return uuid.Nil, ErrInvalidToken
	}
	claims, ok := parsed.Claims.(*Claims)
	if !ok || !parsed.Valid || claims.UserID == uuid.Nil {
		return uuid.Nil, ErrInvalidToken
	}
	return claims.UserID, nil
}

// Функция NewRefreshToken предназначена для генерации refresh-токена и его хеша.
func NewRefreshToken() (raw string, hash []byte, err error) {
	buf := make([]byte, 32)
	if _, err = rand.Read(buf); err != nil {
		return "", nil, err
	}
	raw = base64.RawURLEncoding.EncodeToString(buf)
	return raw, HashRefresh(raw), nil
}

// Функция HashRefresh предназначена для вычисления хеша refresh-токена.
func HashRefresh(raw string) []byte {
	sum := sha256.Sum256([]byte(raw))
	return sum[:]
}

// Функция HashPassword предназначена для получения bcrypt-хеша пароля.
func HashPassword(plain string) (string, error) {
	h, err := bcrypt.GenerateFromPassword([]byte(plain), 12)
	return string(h), err
}

// Функция CheckPassword предназначена для сверки пароля с bcrypt-хешем.
func CheckPassword(hash, plain string) bool {
	return bcrypt.CompareHashAndPassword([]byte(hash), []byte(plain)) == nil
}
