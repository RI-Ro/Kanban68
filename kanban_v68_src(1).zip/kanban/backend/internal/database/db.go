// Модуль предназначен для работы с пулом соединений PostgreSQL: транзакции с идентификатором
// пользователя для политик RLS, сервисные транзакции и проверка роли подключения.

package database

import (
	"context"
	"log/slog"
	"errors"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// Тип DB предназначен для выполнения запросов только в транзакциях с выставленным app.user_id;
// без него RLS-политики не возвращают строк.
type DB struct {
	Pool *pgxpool.Pool
	// Необязательный наблюдатель транзакций для метрик; задаётся до первых запросов.
	observe func(op string, d time.Duration, failed bool)
}

// Метод SetObserver предназначен для подключения измерения транзакций; nil отключает его.
func (d *DB) SetObserver(fn func(op string, d time.Duration, failed bool)) {
	d.observe = fn
}

// Метод track предназначен для передачи длительности и результата транзакции наблюдателю.
func (d *DB) track(op string, start time.Time, err error) {
	if d.observe != nil {
		d.observe(op, time.Since(start), err != nil)
	}
}

var ErrNoAccess = errors.New("нет доступа")

// Функция New предназначена для создания пула соединений заданного размера и проверки подключения.
func New(ctx context.Context, url string, poolSize, minIdle int, statementCache bool) (*DB, error) {
	cfg, err := pgxpool.ParseConfig(url)
	if err != nil {
		return nil, fmt.Errorf("разбор DATABASE_URL: %w", err)
	}

	if poolSize <= 0 {
		poolSize = 40
	}
	if minIdle <= 0 {
		minIdle = poolSize / 5
	}

	if !statementCache {
		// Без кэша подготовленных запросов; требуется за pgbouncer в режиме transaction.
		cfg.ConnConfig.DefaultQueryExecMode = pgx.QueryExecModeExec
	}

	cfg.MaxConns = int32(poolSize)
	cfg.MinConns = int32(minIdle)
	cfg.MaxConnLifetime = time.Hour
	cfg.MaxConnLifetimeJitter = 5 * time.Minute
	cfg.MaxConnIdleTime = 15 * time.Minute
	cfg.HealthCheckPeriod = 30 * time.Second
	// Таймаут подключения 10 секунд; нехватку соединений в пуле нужно устранять увеличением DB_POOL_SIZE.
	cfg.ConnConfig.ConnectTimeout = 10 * time.Second

	pool, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		return nil, fmt.Errorf("подключение к базе: %w", err)
	}
	if err := pool.Ping(ctx); err != nil {
		return nil, fmt.Errorf("база не отвечает: %w", err)
	}

	// Проверка роли подключения: суперпользователь и роль с BYPASSRLS обходят политики RLS,
	// поэтому запуск с такой ролью отклоняется.
	var (
		roleName   string
		isSuper    bool
		bypassRLS  bool
	)
	if err := pool.QueryRow(ctx, `
		SELECT current_user, rolsuper, rolbypassrls
		  FROM pg_roles WHERE rolname = current_user`).
		Scan(&roleName, &isSuper, &bypassRLS); err != nil {
		return nil, fmt.Errorf("не удалось проверить роль подключения: %w", err)
	}
	if isSuper || bypassRLS {
		pool.Close()
		return nil, fmt.Errorf(
			"подключение выполнено ролью %q, которая обходит политики доступа "+
				"(superuser=%v, bypassrls=%v). В этом режиме разграничение прав не работает: "+
				"каждый пользователь увидит чужие проекты и задачи. "+
				"Укажите в DATABASE_URL роль app_user — она создаётся миграцией 0000_roles.sql "+
				"и намеренно лишена этих привилегий",
			roleName, isSuper, bypassRLS)
	}
	slog.Info("подключение к базе", "role", roleName)
	return &DB{Pool: pool}, nil
}

// Метод Close предназначен для закрытия пула.
func (d *DB) Close() { d.Pool.Close() }

// Метод Stats предназначен для получения статистики пула.
func (d *DB) Stats() *pgxpool.Stat { return d.Pool.Stat() }

// Метод AsUser предназначен для выполнения fn в транзакции с локальным параметром app.user_id.
// Параметр сбрасывается при COMMIT и ROLLBACK и не переходит на следующий запрос через пул.
func (d *DB) AsUser(ctx context.Context, userID uuid.UUID, fn func(pgx.Tx) error) (err error) {
	start := time.Now()
	defer func() { d.track("user_tx", start, err) }()

	tx, err := d.Pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("начало транзакции: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	if _, err := tx.Exec(ctx, `SELECT set_config('app.user_id', $1, true)`, userID.String()); err != nil {
		return fmt.Errorf("установка контекста пользователя: %w", err)
	}
	if err := fn(tx); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

// Метод AsService предназначен для выполнения fn в транзакции без пользовательского контекста:
// вход, обновление токена, регистрация, вызов SECURITY DEFINER-функций. Не эквивалентен BYPASSRLS.
func (d *DB) AsService(ctx context.Context, fn func(pgx.Tx) error) (err error) {
	start := time.Now()
	defer func() { d.track("service_tx", start, err) }()

	tx, err := d.Pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("начало транзакции: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	if err := fn(tx); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

// Функция IsNoRows предназначена для проверки, что ошибка означает отсутствие строки.
func IsNoRows(err error) bool { return errors.Is(err, pgx.ErrNoRows) }
