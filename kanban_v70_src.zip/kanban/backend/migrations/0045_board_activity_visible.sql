-- Миграция 0045: активность проекта учитывает только задачи, видимые текущему пользователю.
-- Раньше функция (SECURITY DEFINER) учитывала все задачи проекта, поэтому проект помечался изменившимся
-- из-за правки задачи, к которой у пользователя нет доступа.

CREATE OR REPLACE FUNCTION app.board_activity_at(p_board uuid, p_except uuid)
RETURNS timestamptz LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH vis AS (
        -- Задачи проекта, которые пользователь вправе видеть (та же логика, что в политике tasks_select).
        SELECT t.id, t.updated_at FROM app.tasks t
         WHERE t.board_id = p_board AND NOT t.archived
           AND (t.board_id IN (SELECT app.my_edit_boards())
                OR t.created_by IN (SELECT app.my_ids())
                OR t.id IN (SELECT app.my_task_ids()))
    )
    SELECT GREATEST(
               b.updated_at,
               COALESCE((SELECT max(v.updated_at) FROM vis v), b.updated_at),
               COALESCE((SELECT max(x.at)
                           FROM vis v
                           CROSS JOIN LATERAL (
                                SELECT a.created_at AS at FROM app.activity a
                                 WHERE a.task_id = v.id
                                   AND (p_except IS NULL OR a.actor_id IS DISTINCT FROM p_except)
                                 ORDER BY a.created_at DESC LIMIT 1) x),
                        b.updated_at))
      FROM app.boards b WHERE b.id = p_board
$$;
