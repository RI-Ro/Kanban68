// Модуль предназначен для фотографий пользователей: загрузка себе и администратором, выдача, удаление и приведение
// изображения к единому виду (квадрат, не более 400 px, JPEG). Фото из LDAP сохраняется той же функцией.

package handlers

import (
	"context"
	"log/slog"
	"strings"

	"bytes"
	"crypto/sha1"
	"encoding/hex"
	"errors"
	"github.com/example/kanban/internal/config"
	"github.com/example/kanban/internal/ldapsync"
	"github.com/google/uuid"
	"image"
	"image/color"
	"image/jpeg"
	_ "image/png" // декодер PNG для normalizePhoto
	"io"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"github.com/example/kanban/internal/httpx"
)

// Константы фото: предельный размер исходного файла и сторона итогового квадрата.
const (
	photoMaxSource = 8 << 20
	photoSide      = 400
)

// Функция normalizePhoto предназначена для приведения изображения (JPEG или PNG) к квадрату со стороной не более
// photoSide: кадрирование по центру, уменьшение усреднением, сохранение в JPEG. Возвращает данные и контрольную сумму.
func normalizePhoto(src []byte) ([]byte, string, error) {
	img, _, err := image.Decode(bytes.NewReader(src))
	if err != nil {
		return nil, "", errors.New("файл не является изображением JPEG или PNG")
	}
	b := img.Bounds()
	side := b.Dx()
	if b.Dy() < side {
		side = b.Dy()
	}
	if side < 16 {
		return nil, "", errors.New("изображение слишком маленькое")
	}
	// У портретов лицо обычно выше середины кадра: при кадрировании по высоте берётся верхняя часть (отступ 15 %), а не центр.
	x0, y0 := b.Min.X+(b.Dx()-side)/2, b.Min.Y+(b.Dy()-side)*15/100
	out := side
	if out > photoSide {
		out = photoSide
	}
	dst := image.NewRGBA(image.Rect(0, 0, out, out))
	// Усреднение по площади: каждый пиксель результата — среднее блока исходного изображения.
	ratio := float64(side) / float64(out)
	for y := 0; y < out; y++ {
		sy0, sy1 := int(float64(y)*ratio), int(float64(y+1)*ratio)
		if sy1 <= sy0 {
			sy1 = sy0 + 1
		}
		for x := 0; x < out; x++ {
			sx0, sx1 := int(float64(x)*ratio), int(float64(x+1)*ratio)
			if sx1 <= sx0 {
				sx1 = sx0 + 1
			}
			var r, g, bl, n uint64
			for yy := sy0; yy < sy1 && yy < side; yy++ {
				for xx := sx0; xx < sx1 && xx < side; xx++ {
					cr, cg, cb, ca := img.At(x0+xx, y0+yy).RGBA()
					// Прозрачные области заливаются белым.
					r += uint64((cr*ca + 0xffff*(0xffff-ca)) / 0xffff)
					g += uint64((cg*ca + 0xffff*(0xffff-ca)) / 0xffff)
					bl += uint64((cb*ca + 0xffff*(0xffff-ca)) / 0xffff)
					n++
				}
			}
			if n == 0 {
				n = 1
			}
			dst.Set(x, y, color.RGBA{uint8(r / n >> 8), uint8(g / n >> 8), uint8(bl / n >> 8), 255})
		}
	}
	var buf bytes.Buffer
	if err := jpeg.Encode(&buf, dst, &jpeg.Options{Quality: 86}); err != nil {
		return nil, "", err
	}
	sum := sha1.Sum(buf.Bytes())
	return buf.Bytes(), hex.EncodeToString(sum[:]), nil
}

// Метод savePhoto предназначен для сохранения фото пользователя из сырых данных изображения.
func (s *Server) savePhoto(c *fiber.Ctx, target interface{ String() string }, raw []byte) error {
	data, sum, err := normalizePhoto(raw)
	if err != nil {
		return httpx.Err(fiber.StatusBadRequest, "bad_photo", "Не удалось обработать фото: "+err.Error())
	}
	return s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		var changed bool
		return tx.QueryRow(c.Context(), `SELECT app.set_user_photo($1::uuid, 'image/jpeg', $2, $3, 'manual')`,
			target.String(), data, sum).Scan(&changed)
	})
}

// Метод uploadPhoto предназначен для чтения файла из запроса и сохранения фото выбранного пользователя.
func (s *Server) uploadPhoto(c *fiber.Ctx, target interface{ String() string }) error {
	header, err := c.FormFile("file")
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_file", "Файл не передан"))
	}
	if header.Size > photoMaxSource {
		return httpx.Fail(c, httpx.Err(fiber.StatusRequestEntityTooLarge, "too_big", "Фото больше 8 МБ"))
	}
	f, err := header.Open()
	if err != nil {
		return httpx.Fail(c, err)
	}
	defer f.Close()
	raw, err := io.ReadAll(io.LimitReader(f, photoMaxSource))
	if err != nil {
		return httpx.Fail(c, err)
	}
	if err := s.savePhoto(c, target, raw); err != nil {
		return accessOrFail(c, err)
	}
	return httpx.NoContent(c)
}

// Функция accessOrFail предназначена для отказа в правах как 403 и прочих ошибок в обычном виде.
func accessOrFail(c *fiber.Ctx, err error) error {
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && pgErr.Code == "42501" {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "forbidden", "Недостаточно прав для изменения фото"))
	}
	return httpx.Fail(c, err)
}

// Метод UploadMyPhoto предназначен для обработки запроса POST /me/photo.
func (s *Server) UploadMyPhoto(c *fiber.Ctx) error { return s.uploadPhoto(c, s.uid(c)) }

// Метод UploadUserPhoto предназначен для обработки запроса POST /admin/users/:userID/photo (администратор).
func (s *Server) UploadUserPhoto(c *fiber.Ctx) error {
	id, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.uploadPhoto(c, id)
}

// Метод deletePhoto предназначен для удаления фото выбранного пользователя.
func (s *Server) deletePhoto(c *fiber.Ctx, target interface{ String() string }) error {
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		var gone bool
		return tx.QueryRow(c.Context(), `SELECT app.delete_user_photo($1::uuid, false)`, target.String()).Scan(&gone)
	})
	if err != nil {
		return accessOrFail(c, err)
	}
	return httpx.NoContent(c)
}

// Метод DeleteMyPhoto предназначен для обработки запроса DELETE /me/photo.
func (s *Server) DeleteMyPhoto(c *fiber.Ctx) error { return s.deletePhoto(c, s.uid(c)) }

// Метод DeleteUserPhoto предназначен для обработки запроса DELETE /admin/users/:userID/photo (администратор).
func (s *Server) DeleteUserPhoto(c *fiber.Ctx) error {
	id, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.deletePhoto(c, id)
}

// Метод GetUserPhoto предназначен для обработки запроса GET /users/:userID/photo: выдача фото с проверкой ETag.
func (s *Server) GetUserPhoto(c *fiber.Ctx) error {
	id, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var data []byte
	var mime, sum string
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT data, mime_type, checksum FROM app.user_photos WHERE user_id = $1`, id).Scan(&data, &mime, &sum)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	etag := `"` + sum + `"`
	c.Set(fiber.HeaderETag, etag)
	// Адрес содержит версию (?v=), поэтому кэш браузера может быть долгим; изменение фото меняет версию.
	c.Set(fiber.HeaderCacheControl, "private, max-age=86400")
	if c.Get(fiber.HeaderIfNoneMatch) == etag {
		return c.SendStatus(fiber.StatusNotModified)
	}
	c.Set(fiber.HeaderContentType, mime)
	return c.Send(data)
}

// Метод syncLDAPPhoto предназначен для синхронизации фото из LDAP при входе: если в каталоге фото есть, оно сохраняется
// (неизменённое не перезаписывается, фото, заданное вручную, не затрагивается); если в каталоге фото убрали, а сохранённое
// получено из LDAP, оно удаляется. Сопоставление включается указанием атрибута фото в ldap.servers[].attributes.photo.
func (s *Server) syncLDAPPhoto(ctx context.Context, tx pgx.Tx, userID uuid.UUID, srv config.LDAPServer, p *ldapsync.Profile) error {
	if strings.TrimSpace(srv.Attributes["photo"]) == "" {
		return nil
	}
	if !p.HasPhoto {
		_, e := tx.Exec(ctx, `SELECT app.delete_user_photo($1, true)`, userID)
		return e
	}
	data, sum, err := normalizePhoto(p.Photo)
	if err != nil {
		slog.Warn("фото из LDAP не обработано", "user", userID, "error", err)
		return nil
	}
	_, e := tx.Exec(ctx, `SELECT app.set_user_photo($1, 'image/jpeg', $2, $3, 'ldap')`, userID, data, sum)
	return e
}
