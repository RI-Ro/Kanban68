// Модуль предназначен для статистики по задачам одного пользователя: сводка по статусам, разрезы по приоритетам и
// проектам, динамика по неделям, сроки и ближайшие задачи. Учитываются только задачи, видимые смотрящему (RLS).

package handlers

import (
	"context"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// Константа userTaskState задаёт состояние задачи для пользователя $1 (исполнитель): done — его часть или вся задача
// выполнена; ready — сдана на проверку; overdue — срок истёк; progress — в работе (остальное).
const userTaskBase = `
	FROM dash_t t
	JOIN dash_a ta ON ta.task_id = t.id AND ta.user_id = $1
	CROSS JOIN LATERAL (SELECT (t.completed_at IS NOT NULL OR ta.completed_at IS NOT NULL) AS done) s`

// Функция loadUserStats предназначена для расчёта статистики пользователя userID; boardID (необязательно) ограничивает проект.
// Требует подготовленных временных таблиц (prepareDashboardData).
func loadUserStats(ctx context.Context, tx pgx.Tx, userID uuid.UUID, boardID *uuid.UUID) (fiber.Map, error) {
	out := fiber.Map{}

	// Поручено пользователю.
	var total, progress, ready, done, overdue, soon, noDue int
	if err := tx.QueryRow(ctx, `
		SELECT count(*),
		       count(*) FILTER (WHERE NOT s.done AND t.ready_at IS NULL),
		       count(*) FILTER (WHERE NOT s.done AND t.ready_at IS NOT NULL),
		       count(*) FILTER (WHERE s.done),
		       count(*) FILTER (WHERE NOT s.done AND t.due_date IS NOT NULL AND t.due_date < current_date),
		       count(*) FILTER (WHERE NOT s.done AND t.due_date >= current_date AND t.due_date < current_date + 7),
		       count(*) FILTER (WHERE NOT s.done AND t.due_date IS NULL)`+userTaskBase+`
		 WHERE ($2::uuid IS NULL OR t.board_id = $2::uuid)`, userID, boardID).
		Scan(&total, &progress, &ready, &done, &overdue, &soon, &noDue); err != nil {
		return nil, err
	}
	out["assigned"] = fiber.Map{"total": total, "inProgress": progress, "ready": ready, "done": done,
		"overdue": overdue, "dueSoon": soon, "noDue": noDue}

	// Поставлено пользователем.
	var cTotal, cOpen, cDone, cOverdue int
	if err := tx.QueryRow(ctx, `
		SELECT count(*), count(*) FILTER (WHERE t.completed_at IS NULL), count(*) FILTER (WHERE t.completed_at IS NOT NULL),
		       count(*) FILTER (WHERE t.completed_at IS NULL AND t.due_date IS NOT NULL AND t.due_date < current_date)
		  FROM dash_t t WHERE t.created_by = $1 AND ($2::uuid IS NULL OR t.board_id = $2::uuid)`, userID, boardID).
		Scan(&cTotal, &cOpen, &cDone, &cOverdue); err != nil {
		return nil, err
	}
	out["created"] = fiber.Map{"total": cTotal, "open": cOpen, "done": cDone, "overdue": cOverdue}

	// Качество исполнения: в срок / с опозданием, среднее время выполнения.
	var withDue, onTime int
	var avgDays *float64
	if err := tx.QueryRow(ctx, `
		SELECT count(*) FILTER (WHERE t.due_date IS NOT NULL),
		       count(*) FILTER (WHERE t.due_date IS NOT NULL AND COALESCE(ta.completed_at, t.completed_at)::date <= t.due_date),
		       avg(EXTRACT(EPOCH FROM (COALESCE(ta.completed_at, t.completed_at) - t.created_at)) / 86400.0)`+userTaskBase+`
		 WHERE s.done AND ($2::uuid IS NULL OR t.board_id = $2::uuid)`, userID, boardID).
		Scan(&withDue, &onTime, &avgDays); err != nil {
		return nil, err
	}
	out["quality"] = fiber.Map{"withDue": withDue, "onTime": onTime, "late": withDue - onTime, "avgDays": avgDays}

	// Разрез по приоритетам.
	byPriority := []fiber.Map{}
	rows, err := tx.Query(ctx, `
		SELECT t.priority, count(*), count(*) FILTER (WHERE s.done), count(*) FILTER (WHERE NOT s.done),
		       count(*) FILTER (WHERE NOT s.done AND t.due_date IS NOT NULL AND t.due_date < current_date)`+userTaskBase+`
		 WHERE ($2::uuid IS NULL OR t.board_id = $2::uuid) GROUP BY t.priority ORDER BY count(*) DESC`, userID, boardID)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var p string
		var a, b, c2, d int
		if err := rows.Scan(&p, &a, &b, &c2, &d); err != nil {
			rows.Close()
			return nil, err
		}
		byPriority = append(byPriority, fiber.Map{"priority": p, "total": a, "done": b, "open": c2, "overdue": d})
	}
	rows.Close()
	out["byPriority"] = byPriority

	// Разрез по проектам.
	byBoard := []fiber.Map{}
	rows, err = tx.Query(ctx, `
		SELECT b.id, b.title, count(*), count(*) FILTER (WHERE s.done),
		       count(*) FILTER (WHERE NOT s.done AND t.ready_at IS NULL), count(*) FILTER (WHERE NOT s.done AND t.ready_at IS NOT NULL),
		       count(*) FILTER (WHERE NOT s.done AND t.due_date IS NOT NULL AND t.due_date < current_date)`+userTaskBase+`
		  JOIN app.boards b ON b.id = t.board_id
		 WHERE ($2::uuid IS NULL OR t.board_id = $2::uuid)
		 GROUP BY b.id, b.title ORDER BY count(*) DESC LIMIT 30`, userID, boardID)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var id uuid.UUID
		var title string
		var a, b2, c2, d, e int
		if err := rows.Scan(&id, &title, &a, &b2, &c2, &d, &e); err != nil {
			rows.Close()
			return nil, err
		}
		byBoard = append(byBoard, fiber.Map{"boardId": id, "title": title, "total": a, "done": b2,
			"inProgress": c2, "ready": d, "overdue": e})
	}
	rows.Close()
	out["byBoard"] = byBoard

	// Динамика: последние 12 недель — сколько поручено и сколько выполнено.
	weekly := []fiber.Map{}
	rows, err = tx.Query(ctx, `
		WITH w AS (SELECT generate_series(date_trunc('week', current_date) - interval '11 weeks', date_trunc('week', current_date), '1 week')::date AS d)
		SELECT w.d::text,
		       (SELECT count(*) FROM dash_t t JOIN dash_a ta ON ta.task_id = t.id AND ta.user_id = $1
		         WHERE t.created_at >= w.d AND t.created_at < w.d + 7 AND ($2::uuid IS NULL OR t.board_id = $2::uuid)),
		       (SELECT count(*) FROM dash_t t JOIN dash_a ta ON ta.task_id = t.id AND ta.user_id = $1
		         WHERE COALESCE(ta.completed_at, t.completed_at) >= w.d AND COALESCE(ta.completed_at, t.completed_at) < w.d + 7
		           AND ($2::uuid IS NULL OR t.board_id = $2::uuid))
		  FROM w ORDER BY w.d`, userID, boardID)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var d string
		var a, b int
		if err := rows.Scan(&d, &a, &b); err != nil {
			rows.Close()
			return nil, err
		}
		weekly = append(weekly, fiber.Map{"week": d, "assigned": a, "done": b})
	}
	rows.Close()
	out["weekly"] = weekly

	// Открытые задачи: просроченные и ближайшие по сроку.
	rows, err = tx.Query(ctx, `
		SELECT t.id`+userTaskBase+`
		 WHERE NOT s.done AND ($2::uuid IS NULL OR t.board_id = $2::uuid)
		 ORDER BY t.due_date NULLS LAST, t.created_at DESC LIMIT 15`, userID, boardID)
	if err != nil {
		return nil, err
	}
	ids, err := scanIDs(rows)
	if err != nil {
		return nil, err
	}
	open, err := loadBriefs(ctx, tx, ids)
	if err != nil {
		return nil, err
	}
	out["openTasks"] = open

	// Активность: комментарии пользователя к видимым задачам.
	var comments, comments30 int
	if err := tx.QueryRow(ctx, `
		SELECT count(*), count(*) FILTER (WHERE c.created_at >= now() - interval '30 days')
		  FROM app.comments c WHERE c.author_id = $1 AND c.task_id IN (SELECT id FROM dash_t)`, userID).
		Scan(&comments, &comments30); err != nil {
		return nil, err
	}
	out["activity"] = fiber.Map{"comments": comments, "comments30": comments30}
	return out, nil
}

// Метод UserStats предназначен для получения статистики пользователя (GET /dashboard/users/:userID/stats).
func (s *Server) UserStats(c *fiber.Ctx) error {
	userID, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var boardID *uuid.UUID
	if v := c.Query("boardId"); v != "" {
		if id, e := uuid.Parse(v); e == nil {
			boardID = &id
		}
	}
	uid := s.uid(c)
	var out fiber.Map
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if e := prepareDashboardData(c.Context(), tx, uid, boardID); e != nil {
			return e
		}
		var e error
		out, e = loadUserStats(c.Context(), tx, userID, boardID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}
