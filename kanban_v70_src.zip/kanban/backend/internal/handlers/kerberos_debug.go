// Модуль предназначен для подробного журнала входа по Kerberos: что пришло от браузера, какой билет предъявлен,
// есть ли для него ключ в keytab и что именно вернул сервер. Включается параметром logging.kerberos_debug.

package handlers

import (
	"encoding/base64"
	"fmt"
	"log/slog"
	"net/http"
	"strings"
	"time"

	"github.com/jcmturner/gokrb5/v8/iana/etypeID"
	"github.com/jcmturner/gokrb5/v8/keytab"
	"github.com/jcmturner/gokrb5/v8/spnego"

	"github.com/example/kanban/internal/applog"
)

// Тип krbRecorder предназначен для перехвата кода, заголовков и начала тела ответа SPNEGO-слоя.
type krbRecorder struct {
	http.ResponseWriter
	status int
	body   strings.Builder
}

func (r *krbRecorder) WriteHeader(code int) { r.status = code; r.ResponseWriter.WriteHeader(code) }

func (r *krbRecorder) Write(b []byte) (int, error) {
	if r.status == 0 {
		r.status = http.StatusOK
	}
	if r.body.Len() < 512 {
		r.body.Write(b)
	}
	return r.ResponseWriter.Write(b)
}

// Функция krbLogKeytab предназначена для вывода содержимого keytab при запуске: principal, kvno и тип шифрования каждой записи.
func krbLogKeytab(path string, kt *keytab.Keytab) {
	if !applog.KerberosDebug() {
		return
	}
	for _, e := range kt.Entries {
		slog.Debug("kerberos: запись keytab", "file", path,
			"principal", strings.Join(e.Principal.Components, "/")+"@"+e.Principal.Realm,
			"kvno", e.KVNO, "etype", e.Key.KeyType, "etype_name", etypeName(e.Key.KeyType))
	}
	if len(kt.Entries) == 0 {
		slog.Warn("kerberos: keytab пуст", "file", path)
	}
}

// Функция etypeName предназначена для названия типа шифрования по номеру.
func etypeName(id int32) string {
	switch id {
	case etypeID.AES256_CTS_HMAC_SHA1_96:
		return "aes256-cts-hmac-sha1-96"
	case etypeID.AES128_CTS_HMAC_SHA1_96:
		return "aes128-cts-hmac-sha1-96"
	case etypeID.AES256_CTS_HMAC_SHA384_192:
		return "aes256-cts-hmac-sha384-192"
	case etypeID.AES128_CTS_HMAC_SHA256_128:
		return "aes128-cts-hmac-sha256-128"
	case etypeID.RC4_HMAC:
		return "arcfour-hmac"
	}
	return fmt.Sprintf("etype-%d", id)
}

// Функция krbDescribeToken предназначена для разбора SPNEGO-токена из заголовка Authorization и сверки билета с keytab.
// Возвращает строки для журнала.
func krbDescribeToken(auth string, kt *keytab.Keytab) []any {
	fields := []any{}
	parts := strings.SplitN(auth, " ", 2)
	if len(parts) != 2 {
		return append(fields, "token_error", "заголовок Authorization без значения")
	}
	raw, err := base64.StdEncoding.DecodeString(strings.TrimSpace(parts[1]))
	if err != nil {
		return append(fields, "token_error", "не base64: "+err.Error())
	}
	fields = append(fields, "token_bytes", len(raw))
	var st spnego.SPNEGOToken
	if err := st.Unmarshal(raw); err != nil {
		// Некоторые клиенты шлют голый KRB5-токен без обёртки SPNEGO.
		var kt5 spnego.KRB5Token
		if e2 := kt5.Unmarshal(raw); e2 != nil {
			return append(fields, "token_error", "не SPNEGO ("+err.Error()+") и не KRB5 ("+e2.Error()+")")
		}
		return append(fields, krbDescribeAP(&kt5, kt)...)
	}
	if st.Init {
		fields = append(fields, "spnego", "NegTokenInit")
		var mt spnego.KRB5Token
		if err := mt.Unmarshal(st.NegTokenInit.MechTokenBytes); err != nil {
			// Типичная причина: клиент выбрал NTLM, а не Kerberos (нет билета, неверное имя сервиса в URL).
			return append(fields, "token_error", "механизм не Kerberos (возможно NTLM): "+err.Error(),
				"mech_types", fmt.Sprint(st.NegTokenInit.MechTypes))
		}
		return append(fields, krbDescribeAP(&mt, kt)...)
	}
	if st.Resp {
		fields = append(fields, "spnego", "NegTokenResp")
	}
	return fields
}

// Функция krbDescribeAP предназначена для описания AP-REQ: сервис, область, шифрование билета и наличие подходящего ключа.
func krbDescribeAP(t *spnego.KRB5Token, kt *keytab.Keytab) []any {
	if !t.IsAPReq() {
		return []any{"token_error", "в токене нет AP-REQ"}
	}
	tk := t.APReq.Ticket
	spn := strings.Join(tk.SName.NameString, "/")
	f := []any{
		"ticket_service", spn + "@" + tk.Realm,
		"ticket_etype", etypeName(tk.EncPart.EType), "ticket_kvno", tk.EncPart.KVNO,
	}
	match := "нет"
	var avail []string
	for _, e := range kt.Entries {
		p := strings.Join(e.Principal.Components, "/") + "@" + e.Principal.Realm
		avail = append(avail, fmt.Sprintf("%s kvno=%d %s", p, e.KVNO, etypeName(e.Key.KeyType)))
		if strings.EqualFold(p, spn+"@"+tk.Realm) && e.Key.KeyType == tk.EncPart.EType && int(e.KVNO) == tk.EncPart.KVNO {
			match = "да"
		}
	}
	f = append(f, "keytab_match", match)
	if match != "да" {
		f = append(f, "keytab_entries", strings.Join(avail, "; "),
			"hint", "в keytab нет записи с тем же principal, kvno и типом шифрования, что в билете: пересоздайте keytab (ktpass/ipa-getkeytab/kadmin ktadd) после смены пароля учётной записи сервиса")
	}
	return f
}

// Функция krbDebugWrap предназначена для оборачивания SPNEGO-обработчика подробным журналом: входящий запрос,
// разбор токена и итог (код, WWW-Authenticate, начало тела ответа). Без kerberos_debug возвращает обработчик без изменений.
func krbDebugWrap(next http.Handler, kt *keytab.Keytab) http.Handler {
	if !applog.KerberosDebug() {
		return next
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		auth := r.Header.Get("Authorization")
		fields := []any{
			"remote", r.RemoteAddr, "method", r.Method, "host", r.Host, "uri", r.URL.RequestURI(),
			"proto", r.Proto, "tls", r.TLS != nil, "user_agent", r.UserAgent(),
			"has_authorization", auth != "", "x_forwarded_for", r.Header.Get("X-Forwarded-For"),
		}
		if auth == "" {
			fields = append(fields, "hint", "ответ 401 Negotiate — штатный вызов; если следом нет запроса с Authorization, браузер не отправил билет: "+
				"адрес не в списке доверенных (Chrome: AuthServerAllowlist, Firefox: network.negotiate-auth.trusted-uris), "+
				"у клиента нет билета HTTP/<имя-хоста> (klist) или в адресе IP вместо имени")
			slog.Debug("kerberos: запрос без Authorization — будет отправлен вызов 401 Negotiate", fields...)
		} else {
			scheme := strings.SplitN(auth, " ", 2)[0]
			fields = append(fields, "auth_scheme", scheme)
			fields = append(fields, krbDescribeToken(auth, kt)...)
			slog.Debug("kerberos: запрос с Authorization", fields...)
		}
		rec := &krbRecorder{ResponseWriter: w}
		next.ServeHTTP(rec, r)
		if rec.status == 0 {
			rec.status = http.StatusOK
		}
		slog.Debug("kerberos: ответ", "status", rec.status, "www_authenticate", truncStr(rec.Header().Get("WWW-Authenticate"), 80),
			"location", rec.Header().Get("Location"), "body", truncStr(strings.TrimSpace(rec.body.String()), 300),
			"took_ms", time.Since(start).Milliseconds())
		if rec.status == http.StatusUnauthorized && auth != "" {
			slog.Warn("kerberos: билет предъявлен, но проверка не пройдена (причина — в строках «kerberos SPNEGO» выше от gokrb5)",
				"remote", r.RemoteAddr, "host", r.Host)
		}
	})
}

// Функция truncStr предназначена для усечения строки журнала.
func truncStr(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "…"
}
