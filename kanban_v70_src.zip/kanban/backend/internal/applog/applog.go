// Модуль applog предназначен для журналов приложения по аналогии с apache2: журнал доступа (access log, формат combined)
// и журнал ошибок (error log) в файлах, пути к которым задаются в конфигурации. Вывод в консоль включается отдельно.
package applog

import (
	"fmt"
	"io"
	"log"
	"log/slog"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// Тип Config предназначен для настроек журналов.
type Config struct {
	AccessLog     string // путь к журналу доступа; пусто — журнал доступа в файл не пишется
	ErrorLog      string // путь к журналу ошибок и служебных сообщений; пусто — только консоль
	Console       bool   // дублировать сообщения в консоль (stdout/stderr)
	Debug         bool   // уровень debug (иначе info)
	KerberosDebug bool   // подробный журнал входа по Kerberos
}

var (
	mu       sync.Mutex
	cfg      Config
	access   io.Writer
	errFile  *os.File
	accFile  *os.File
	kerbDbg  bool
	kerbOnce sync.Once
)

// Функция openAppend предназначена для открытия файла журнала на дозапись с созданием каталога.
func openAppend(path string) (*os.File, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0o750); err != nil {
		return nil, err
	}
	return os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o640)
}

// Функция Setup предназначена для настройки журналов: slog по умолчанию пишет в файл ошибок и/или консоль.
// Возвращаемая функция закрывает файлы. Повторное открытие файлов по сигналу SIGHUP выполняет Reopen (для logrotate).
func Setup(c Config) (func(), error) {
	mu.Lock()
	defer mu.Unlock()
	cfg = c
	kerbDbg = c.KerberosDebug

	var w []io.Writer
	if c.Console || c.ErrorLog == "" {
		w = append(w, os.Stdout)
	}
	if c.ErrorLog != "" {
		f, err := openAppend(c.ErrorLog)
		if err != nil {
			return nil, fmt.Errorf("журнал ошибок %s: %w", c.ErrorLog, err)
		}
		errFile = f
		w = append(w, f)
	}
	if c.AccessLog != "" {
		f, err := openAppend(c.AccessLog)
		if err != nil {
			return nil, fmt.Errorf("журнал доступа %s: %w", c.AccessLog, err)
		}
		accFile = f
		access = f
	}
	level := slog.LevelInfo
	if c.Debug || c.KerberosDebug {
		level = slog.LevelDebug
	}
	slog.SetDefault(slog.New(slog.NewTextHandler(io.MultiWriter(w...), &slog.HandlerOptions{Level: level})))
	log.SetOutput(io.MultiWriter(w...))
	return Close, nil
}

// Функция Close предназначена для закрытия файлов журналов.
func Close() {
	mu.Lock()
	defer mu.Unlock()
	if errFile != nil {
		_ = errFile.Close()
		errFile = nil
	}
	if accFile != nil {
		_ = accFile.Close()
		accFile = nil
	}
}

// Функция KerberosDebug предназначена для проверки, включён ли подробный журнал Kerberos.
func KerberosDebug() bool { mu.Lock(); defer mu.Unlock(); return kerbDbg }

// Функция Writer предназначена для получения writer'а журнала ошибок (для библиотек со своим логгером).
func Writer() io.Writer {
	mu.Lock()
	defer mu.Unlock()
	var w []io.Writer
	if cfg.Console || cfg.ErrorLog == "" {
		w = append(w, os.Stderr)
	}
	if errFile != nil {
		w = append(w, errFile)
	}
	if len(w) == 0 {
		return io.Discard
	}
	return io.MultiWriter(w...)
}

// Функция Access предназначена для записи строки журнала доступа в формате Apache combined:
// host ident user [time] "METHOD path PROTO" status bytes "referer" "user-agent" latency.
func Access(remote, user, method, uri, proto string, status, bytes int, referer, ua string, took time.Duration) {
	mu.Lock()
	w, console := access, cfg.Console
	mu.Unlock()
	if w == nil && !console {
		return
	}
	if user == "" {
		user = "-"
	}
	if referer == "" {
		referer = "-"
	}
	if ua == "" {
		ua = "-"
	}
	line := fmt.Sprintf("%s - %s [%s] \"%s %s %s\" %d %d \"%s\" \"%s\" %dus\n",
		remote, user, time.Now().Format("02/Jan/2006:15:04:05 -0700"), method, uri, proto, status, bytes, referer, ua, took.Microseconds())
	mu.Lock()
	defer mu.Unlock()
	if access != nil {
		_, _ = io.WriteString(access, line)
	}
	if cfg.Console && access == nil {
		_, _ = io.WriteString(os.Stdout, line)
	}
}

// Функция Reopen предназначена для повторного открытия файлов (после ротации logrotate по SIGHUP).
func Reopen() {
	mu.Lock()
	c := cfg
	mu.Unlock()
	Close()
	_, _ = Setup(c)
}
