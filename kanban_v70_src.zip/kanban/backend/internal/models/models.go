// Модуль предназначен для описания структур данных, передаваемых клиенту в JSON.

package models

import (
	"time"

	"github.com/google/uuid"
)

// Тип User предназначен для описания пользователя.
type User struct {
	ID          uuid.UUID `json:"id"`
	Email       string    `json:"email"`
	FullName    string    `json:"fullName"`
	Position    string    `json:"position"`
	Phone       string    `json:"phone"`
	AvatarColor string    `json:"avatarColor"`
	// Версия фото (unix-время изменения); nil — фото не задано, показываются инициалы.
	PhotoVersion *int64 `json:"photoVersion,omitempty"`
	IsActive    bool      `json:"isActive"`
	Deleted     bool      `json:"deleted"`
	// Роль в системе: member или admin (не путать с ролью в проекте).
	Role string `json:"role"`
	// Логин для входа по Kerberos (principal вида ii-ivanov@DOMAIN1.LOCAL) и источник сведений: local или id LDAP-сервера.
	// Заполняются только в панели администратора.
	Login  string `json:"login,omitempty"`
	Source string `json:"source,omitempty"`
	// Заполняется только в панели администратора.
	CreatedAt *time.Time `json:"createdAt,omitempty"`
	Sessions  int        `json:"sessions,omitempty"`
}

// Тип BoardMember предназначен для описания участника проекта и его роли.
type BoardMember struct {
	UserID uuid.UUID `json:"userId"`
	Role   string    `json:"role"`
}

// Тип Board предназначен для описания проекта (доски).
type Board struct {
	ID          uuid.UUID     `json:"id"`
	Title       string        `json:"title"`
	Description string        `json:"description"`
	BgPreset    string        `json:"bgPreset"`
	BgFileID    *uuid.UUID    `json:"bgFileId"`
	BgBlur      bool          `json:"bgBlur"`
	Archived    bool          `json:"archived"`
	MyRole      string        `json:"myRole"`
	// Роль получена по замещению; заполняется только в списке проектов.
	ViaDelegation bool        `json:"viaDelegation,omitempty"`
	// Родительский проект; сервер возвращает значение без изменений, недоступный родитель обрабатывается клиентом.
	ParentID    *uuid.UUID    `json:"parentId"`
	Position    int           `json:"position"`
	CreatedBy   uuid.UUID     `json:"createdBy"`
	Members     []BoardMember `json:"members,omitempty"`
	UpdatedAt   time.Time     `json:"updatedAt"`
	// LastActivityAt — последнее изменение проекта или его задач, кроме действий самого пользователя;
	// SeenAt — последнее открытие проекта пользователем.
	LastActivityAt time.Time  `json:"lastActivityAt"`
	SeenAt         *time.Time `json:"seenAt"`
}

// Тип Column предназначен для описания колонки доски.
type Column struct {
	ID       uuid.UUID `json:"id"`
	BoardID  uuid.UUID `json:"boardId"`
	Title    string    `json:"title"`
	Color    string    `json:"color"`
	Position int       `json:"position"`
	WipLimit int       `json:"wipLimit"`
	IsDone   bool      `json:"isDone"`
}

// Тип Step предназначен для описания пункта чек-листа.
type Step struct {
	ID         uuid.UUID  `json:"id"`
	Body       string     `json:"body"`
	Done       bool       `json:"done"`
	Position   int        `json:"position"`
	AssigneeID *uuid.UUID `json:"assigneeId"`
	DueDate    *string    `json:"dueDate"`
	DoneBy     *uuid.UUID `json:"doneBy"`
	DoneAt     *string    `json:"doneAt"`
}

// Тип Grant предназначен для описания права доступа к задаче.
type Grant struct {
	UserID uuid.UUID `json:"userId"`
	Access string    `json:"access"`
}

// Тип ExtStep предназначен для описания пункта расширенного чек-листа: исполнитель, срок,
// отметка о выполнении, фактический срок и автор отметки.
type ExtStep struct {
	ID         uuid.UUID  `json:"id"`
	TaskID     uuid.UUID  `json:"taskId"`
	Body       string     `json:"body"`
	AssigneeID *uuid.UUID `json:"assigneeId"`
	DueDate    *string    `json:"dueDate"`
	Done       bool       `json:"done"`
	DoneDate   *string    `json:"doneDate"`
	DoneBy     *uuid.UUID `json:"doneBy"`
	Position   int        `json:"position"`
	CreatedBy  uuid.UUID  `json:"createdBy"`
}

// Тип Comment предназначен для описания комментария к задаче.
type Comment struct {
	ID        uuid.UUID  `json:"id"`
	TaskID    uuid.UUID  `json:"taskId"`
	AuthorID  uuid.UUID  `json:"authorId"`
	Body      string     `json:"body"`
	CreatedAt time.Time  `json:"createdAt"`
	EditedAt  *time.Time `json:"editedAt"`
	CanEdit   bool       `json:"canEdit"`
}

// Тип Attachment предназначен для описания вложения.
type Attachment struct {
	ID          uuid.UUID  `json:"id"`
	TaskID      uuid.UUID  `json:"taskId"`
	AuthorID    uuid.UUID  `json:"authorId"`
	Filename    string     `json:"filename"`
	Title       string     `json:"title"`
	MIME        string     `json:"mime"`
	Size        int64      `json:"size"`
	CreatedAt   time.Time  `json:"createdAt"`
	EditedAt    *time.Time `json:"editedAt"`
	CanEdit     bool       `json:"canEdit"`
	Previewable bool       `json:"previewable"`
}

// Тип Activity предназначен для описания записи журнала изменений.
type Activity struct {
	ID        uuid.UUID  `json:"id"`
	ActorID   *uuid.UUID `json:"actorId"`
	Body      string     `json:"body"`
	CreatedAt time.Time  `json:"createdAt"`
}

// Тип Task предназначен для описания задачи. CreatedBy — автор задачи.
type Task struct {
	ID          uuid.UUID   `json:"id"`
	BoardID     uuid.UUID   `json:"boardId"`
	BoardTitle  string      `json:"boardTitle,omitempty"`
	ColumnID    uuid.UUID   `json:"columnId"`
	// Название колонки; заполняется в списках задач вне доски.
	ColumnTitle string      `json:"columnTitle,omitempty"`
	Title       string      `json:"title"`
	Description string      `json:"description"`
	Report      string      `json:"report"`
	Priority    string      `json:"priority"`
	// Идентификатор цвета из палитры; оттенок определяется темой на клиенте.
	Color       string      `json:"color"`
	DueDate     *string     `json:"dueDate"`
	// Реквизиты входящего документа, по которому заведена задача.
	IncomingNumber string  `json:"incomingNumber"`
	IncomingDate   *string `json:"incomingDate"`
	Position    int         `json:"position"`
	Tags        []string    `json:"tags"`
	CompletedAt *time.Time  `json:"completedAt"`
	CreatedBy   uuid.UUID   `json:"createdBy"`
	Assignees   []uuid.UUID `json:"assignees"`
	// Исполнители, отметившие свою часть выполненной.
	AssigneesDone []uuid.UUID `json:"assigneesDone"`
	// Исполнители, открывавшие задачу.
	AssigneesSeen []uuid.UUID `json:"assigneesSeen"`
	// Исполнители, чей просмотр новее последнего изменения задачи (см. app.assignees_fresh).
	AssigneesFresh []uuid.UUID `json:"assigneesFresh"`
	Grants      []Grant     `json:"grants"`
	Steps       []Step      `json:"steps"`
	// Favorite — отметка «избранная» текущего пользователя.
	Favorite    bool        `json:"favorite"`
	CommentCnt  int         `json:"commentCount"`
	AttachCnt   int         `json:"attachmentCount"`
	// Агрегаты расширенного чек-листа для карточки.
	ExtStepCnt  int         `json:"extStepCount"`
	ExtStepDone int         `json:"extStepDone"`
	Access      string      `json:"access"`
	// Периодичность: none, daily, weekly или monthly.
	RecurFreq     string  `json:"recurFreq"`
	RecurInterval int     `json:"recurInterval"`
	RecurWeekdays []int32 `json:"recurWeekdays"`
	RecurMonthday *int    `json:"recurMonthday"`
	RecurUntil    *string `json:"recurUntil"`
	CreatedAt   time.Time   `json:"createdAt"`
	UpdatedAt   time.Time   `json:"updatedAt"`
	// LastActivityAt — последнее изменение задачи (включая комментарии, файлы, чек-лист);
	// SeenAt — момент последнего открытия задачи пользователем.
	LastActivityAt time.Time  `json:"lastActivityAt"`
	SeenAt         *time.Time `json:"seenAt"`
	// Время перевода задачи в состояние «готова к сдаче».
	ReadyAt *time.Time `json:"readyAt"`
	ReadyBy *uuid.UUID `json:"readyBy"`
	// Ответственный (один из исполнителей, отвечающий за результат).
	HeadAssignee *uuid.UUID `json:"headAssignee"`
}

// Тип Notification предназначен для описания уведомления.
type Notification struct {
	ID        uuid.UUID  `json:"id"`
	Body      string     `json:"body"`
	BoardID   *uuid.UUID `json:"boardId"`
	TaskID    *uuid.UUID `json:"taskId"`
	// Идентификатор диаграммы или доски, на которую указывает уведомление.
	ChartID      *uuid.UUID `json:"chartId"`
	WhiteboardID *uuid.UUID `json:"whiteboardId"`
	Category  string     `json:"category,omitempty"`
	Read      bool       `json:"read"`
	CreatedAt time.Time  `json:"createdAt"`
}

// Тип Delegation предназначен для описания передачи прав заместителю на время отсутствия.
type Delegation struct {
	ID        uuid.UUID `json:"id"`
	GrantorID uuid.UUID `json:"grantorId"`
	DeputyID  uuid.UUID `json:"deputyId"`
	StartsAt  string    `json:"startsAt"`
	EndsAt    string    `json:"endsAt"`
	Note      string    `json:"note"`
	Active    bool      `json:"active"`
}

// Тип TaskLink предназначен для описания связи между задачами: blocks, relates или subtask.
type TaskLink struct {
	ID        uuid.UUID `json:"id"`
	FromTask  uuid.UUID `json:"fromTask"`
	ToTask    uuid.UUID `json:"toTask"`
	Kind      string    `json:"kind"`
	// Заголовок и состояние связанной задачи.
	Title     string    `json:"title"`
	Completed bool      `json:"completed"`
	BoardID   uuid.UUID `json:"boardId"`
}

// Тип TaskTemplate предназначен для описания шаблона задачи.
type TaskTemplate struct {
	ID          uuid.UUID   `json:"id"`
	BoardID     *uuid.UUID  `json:"boardId"`
	OwnerID     uuid.UUID   `json:"ownerId"`
	Name        string      `json:"name"`
	Title       string      `json:"title"`
	Description string      `json:"description"`
	Priority    string      `json:"priority"`
	Color       string      `json:"color"`
	Tags        []string    `json:"tags"`
	DueInDays   *int        `json:"dueInDays"`
	Steps       []string    `json:"steps"`
	Assignees   []uuid.UUID `json:"assignees"`
}
