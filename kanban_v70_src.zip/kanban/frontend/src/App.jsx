// Модуль предназначен для корневого компонента приложения: сессия и вход, маршрутизация по разделам, загрузка проектов и задач,
// обработка событий реального времени, фильтры, операции с задачами, боковое меню, шапка, окна и уведомления.

import PageBgPicker from "./components/PageBgPicker.jsx";
import ServerClock from "./components/ServerClock.jsx";
import { AboutModal, GuideModal } from "./components/InfoModals.jsx";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  LayoutGrid, Search, Filter, Bell, Plus, ChevronDown, Palette, Settings, Eye, EyeOff,
  Inbox, UserPlus, LogOut, Check, Link2, ShieldCheck, FileSpreadsheet, UserCheck, Volume2, VolumeX, Zap, UsersRound, KeyRound, Activity,
  PanelLeftClose, PanelLeftOpen, ChevronsUpDown, Ellipsis, Play, BookOpen, Info,
  Camera,
} from "lucide-react";

import { api, hasSession, onAuthLost } from "./lib/api.js";
import { realtimeConnect, realtimeDisconnect, onRealtimeMessage, onRealtimeStatus } from "./lib/realtime.js";
import { subscribePresence } from "./lib/presence.js";
import { playEventSound, primeAudio, loadSoundSettings, saveSoundSettings, SOUND_EVENT_LABELS } from "./lib/sound.js";
import { exportTasksToExcel } from "./lib/excel.js";
import { appConfig } from "./lib/appConfig.js";
import { THEMES, DESIGNS, DESIGN_ORDER, DESIGN_THEMES, DESIGN_DEFAULT_THEME, designOfTheme, ALL_BACKGROUNDS, bgById, PRIORITIES, ROLE_LABEL, isOverdue, resolveUser, bgImageUrl, bgThumbUrl, fmtDate, plural } from "./lib/theme.js";
import { Avatar, ChatToast, Chip, ConfirmDialog, Field, Modal, ModalHeader, Toggle, Toast, Spinner, UserCard, RealtimeDot, inputStyle } from "./lib/ui.jsx";
import { countFilters, emptyFilters, loadFilters, matchesFilters, saveFilters, savedFilterScope } from "./lib/filters.js";

import { FONT_LIST } from "./lib/fontList.js";
import { DEFAULT_SCALE, UI_MIN, UI_MAX, FS_MIN, FS_MAX, STEP, clampScale, readLocal, applyScale, saveLocal, saveRemote, loadRemote, isScaleKey } from "./lib/uiScale.js";
import { NavIcon } from "./lib/navIcons.jsx";
import { lazyView, idlePrefetch } from "./lib/lazy-routes.jsx";
import Login, { safeSession } from "./components/Login.jsx";
import { BoardView, InboxView } from "./components/Board.jsx";
import TaskModal from "./components/TaskModal.jsx";
import PhotoEditor from "./components/PhotoEditor.jsx";
import TaskDetail from "./components/TaskDetail.jsx";
import Notifications from "./components/Notifications.jsx";
import PasswordModal from "./components/PasswordModal.jsx";
import ProjectTree from "./components/ProjectTree.jsx";
import ColumnView from "./components/ColumnView.jsx";
import CopyTaskModal from "./components/CopyTaskModal.jsx";
import TaskFilters, { FilterGroup } from "./components/TaskFilters.jsx";
import TaskReminderModal from "./components/TaskReminderModal.jsx";
import AlarmModal from "./components/AlarmModal.jsx";

const INBOX = "inbox";
const DASHBOARD = "dashboard";
const CALENDAR = "calendar";
const ALLTASKS = "alltasks";
const REMINDERS = "reminders";
const CHATS = "chats";
const READY = "ready";
const FAVORITES = "favorites";
const CHARTS = "charts";
const WHITEBOARDS = "whiteboards";
const SYSTEM = "system";
// Крупные разделы загружаются отдельными чанками (lib/lazy-routes.jsx).
const Dashboard = lazyView("dashboard");
const Calendar = lazyView("calendar");
const AllTasks = lazyView("allTasks");
const Charts = lazyView("charts");
const Whiteboards = lazyView("whiteboards");
const Chats = lazyView("chats");
const Reminders = lazyView("reminders");
const System = lazyView("system");
const Admin = lazyView("admin");
const Access = lazyView("access");
const Delegation = lazyView("delegation");
const Team = lazyView("team");
const Templates = lazyView("templates");
const BoardSettings = lazyView("boardSettings");

const THEME_KEY = "kanban.theme";
const DESIGN_KEY = "kanban.design";
const DESIGN_THEME_KEY = "kanban.themeByDesign";
const THEME_MIGRATED_KEY = "kanban.theme.glass";
const HIDE_DONE_KEY = "kanban.hideCompleted";
const HIDE_MYDONE_KEY = "kanban.hideMyDone";
const FILTERS_KEY = "kanban.filters";
const SORT_KEY = "kanban.boardSort";

// Функция readTaskLink предназначена для чтения ссылки вида /tasks/<id>; раздел из неё не определяется, так как задача может находиться в любом проекте.
export function readTaskLink() {
  const m = window.location.pathname.match(/^\/tasks\/([0-9a-f-]{36})/i);
  return m ? m[1] : null;
}

// Функция readRoute предназначена для определения текущего раздела по адресу страницы.
function readRoute() {
  const match = window.location.pathname.match(/^\/b\/([0-9a-f-]{36})/i);
  if (match) return { view: "board", boardId: match[1] };
  if (window.location.pathname.startsWith("/inbox")) return { view: INBOX, boardId: null };
  if (window.location.pathname.startsWith("/dashboard")) return { view: DASHBOARD, boardId: null };
  if (window.location.pathname.startsWith("/calendar")) return { view: CALENDAR, boardId: null };
  if (window.location.pathname.startsWith("/all-tasks")) return { view: ALLTASKS, boardId: null };
  if (window.location.pathname.startsWith("/reminders")) return { view: REMINDERS, boardId: null };
  if (window.location.pathname.startsWith("/chats")) return { view: CHATS, boardId: null };
  if (window.location.pathname.startsWith("/ready")) return { view: READY, boardId: null };
  if (window.location.pathname.startsWith("/favorites")) return { view: FAVORITES, boardId: null };
  // Диаграммы и доски имеют адрес с идентификатором: по ссылке открывается соответствующая диаграмма (доска).
  const chart = window.location.pathname.match(/^\/charts\/([0-9a-f-]{36})/i);
  if (chart) return { view: CHARTS, boardId: null, objectId: chart[1] };
  const wb = window.location.pathname.match(/^\/whiteboards\/([0-9a-f-]{36})/i);
  if (wb) return { view: WHITEBOARDS, boardId: null, objectId: wb[1] };
  if (window.location.pathname.startsWith("/charts")) return { view: CHARTS, boardId: null };
  if (window.location.pathname.startsWith("/whiteboards")) return { view: WHITEBOARDS, boardId: null };
  if (window.location.pathname.startsWith("/system")) return { view: SYSTEM, boardId: null };
  return { view: "none", boardId: null };
}

// Функция pathForRoute предназначена для получения адреса раздела; используется и для адресной строки, и для кнопки «ссылка».
function pathForRoute(route) {
  return route.view === INBOX ? "/inbox"
    : route.view === DASHBOARD ? "/dashboard"
    : route.view === CALENDAR ? "/calendar"
    : route.view === ALLTASKS ? "/all-tasks"
    : route.view === REMINDERS ? "/reminders"
    : route.view === CHATS ? "/chats"
    : route.view === READY ? "/ready"
    : route.view === FAVORITES ? "/favorites"
    : route.view === SYSTEM ? "/system"
    : route.view === CHARTS ? (route.objectId ? `/charts/${route.objectId}` : "/charts")
    : route.view === WHITEBOARDS ? (route.objectId ? `/whiteboards/${route.objectId}` : "/whiteboards")
    : route.view === "board" ? `/b/${route.boardId}` : "/";
}

// Функция pushRoute предназначена для изменения адреса страницы при переходе между разделами.
function pushRoute(route, replace = false) {
  const path = pathForRoute(route);
  if (window.location.pathname === path) return;
  window.history[replace ? "replaceState" : "pushState"]({}, "", path);
}

// Компонент App предназначен для корневого компонента приложения.
// Хук useBlobUrl предназначен для загрузки закрытого файла в object URL. Прежнее изображение остаётся на экране, пока
// не загрузится новое; адрес меняется только при смене ключа (файл или версия), а не при обновлении токена.
function useBlobUrl(spec, enabled) {
  const [url, setUrl] = useState(null);
  const key = spec?.key || null;
  const path = spec?.path || null;
  useEffect(() => {
    if (!enabled || !key) { setUrl(null); return undefined; }
    let alive = true;
    let made = null;
    api.fileBlob(path).then((blob) => {
      if (!alive) return;
      made = URL.createObjectURL(blob);
      setUrl(made);
    }).catch(() => {});
    return () => {
      alive = false;
      // Освобождение откладывается: старый адрес ещё используется до отрисовки нового.
      if (made) setTimeout(() => URL.revokeObjectURL(made), 2000);
    };
  }, [key, enabled]); // eslint-disable-line react-hooks/exhaustive-deps
  return url;
}

export default function App() {
  const [themeId, setThemeId] = useState(() => {
    // Тема по умолчанию — «Стекло»; выбор сохраняется только после явного изменения пользователем.
    const saved = localStorage.getItem(THEME_KEY);
    if (!localStorage.getItem(THEME_MIGRATED_KEY)) {
      localStorage.setItem(THEME_MIGRATED_KEY, "1");
      if (!saved || saved === "balun") return "glass";
    }
    // Удалённые темы (например, прежние «Ретро» и «Терминал») заменяются основной.
    return THEMES[saved] ? saved : "glass";
  });
  const theme = THEMES[themeId] || THEMES.glass;
  // Дизайн хранится отдельно от цвета; у каждого дизайна запоминается свой цвет.
  const [design, setDesignState] = useState(() => {
    const saved = localStorage.getItem(DESIGN_KEY);
    return DESIGNS[saved] ? saved : designOfTheme(localStorage.getItem(THEME_KEY) || "glass");
  });
  // Функция setDesign предназначена для переключения дизайна: применяется последний цвет, выбранный в этом дизайне.
  const setDesign = (d) => {
    let map = {};
    try { map = JSON.parse(localStorage.getItem(DESIGN_THEME_KEY) || "{}"); } catch { /* повреждённое значение игнорируется */ }
    const id = DESIGN_THEMES[d].includes(map[d]) ? map[d] : DESIGN_DEFAULT_THEME[d];
    setDesignState(d);
    setThemeId(id);
  };
  // Функция pickTheme предназначена для выбора цвета в текущем дизайне и его запоминания.
  const pickTheme = (id) => {
    let map = {};
    try { map = JSON.parse(localStorage.getItem(DESIGN_THEME_KEY) || "{}"); } catch { /* см. выше */ }
    map[design] = id;
    localStorage.setItem(DESIGN_THEME_KEY, JSON.stringify(map));
    setThemeId(id);
  };

  const [user, setUser] = useState(null);
  const [booting, setBooting] = useState(true);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);

  // Масштаб интерфейса пользователя: «масштаб элементов» и «размер шрифта» (в процентах). Хранится на сервере и в
  // localStorage, применяется во всех открытых вкладках (событие storage).
  const [scale, setScaleState] = useState(() => readLocal(null));
  const designK = 1;
  useEffect(() => { applyScale(scale, designK); }, [scale, designK]);
  const setScale = (next) => {
    const v = clampScale(next);
    setScaleState(v);
    saveLocal(user?.id, v);
    saveRemote(v);
  };
  useEffect(() => {
    const onStorage = (e) => {
      if (!isScaleKey(e.key) || !e.newValue) return;
      try { setScaleState(clampScale(JSON.parse(e.newValue))); } catch { /* повреждённое значение игнорируется */ }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);
  // Общий фон всех страниц (настройка ui.pagebg на сервере; кэш в localStorage — чтобы фон был с первого кадра).
  const [pageBg, setPageBgState] = useState(() => {
    try { return { preset: "none", blur: false, fileId: "", stamp: 1, ...JSON.parse(localStorage.getItem("kanban.pagebg") || "{}") }; }
    catch { return { preset: "none", blur: false, fileId: "", stamp: 1 }; }
  });
  const setPageBg = (v) => {
    setPageBgState(v);
    try { localStorage.setItem("kanban.pagebg", JSON.stringify(v)); } catch { /* кэш недоступен */ }
    const { stamp, ...stored } = v;
    api.setPreference("ui.pagebg", stored).catch(() => {});
  };
  useEffect(() => {
    if (!user) return;
    api.getPreference("ui.pagebg").then((v) => {
      if (v && typeof v === "object") setPageBgState((cur) => ({ ...cur, preset: v.preset || "none", blur: !!v.blur, fileId: v.fileId || "" }));
    }).catch(() => {});
  }, [user?.id]);
  // После входа подтягивается масштаб пользователя с сервера (источник истины); локальный кэш обновляется.
  useEffect(() => {
    if (!user) return;
    let alive = true;
    loadRemote().then((v) => {
      if (!alive) return;
      if (v) { setScaleState(v); saveLocal(user.id, v); }
      else { setScaleState(readLocal(user.id)); }
    }).catch(() => {});
    return () => { alive = false; };
  }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const [directory, setDirectory] = useState([]);
  const [team, setTeam] = useState([]);
  const [boards, setBoards] = useState([]);

  const [route, setRoute] = useState(readRoute);
  const [board, setBoard] = useState(null);
  const [columns, setColumns] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loadingBoard, setLoadingBoard] = useState(false);

  const [search, setSearch] = useState("");
  // Текст в поле поиска хранится отдельно и попадает в `search` с задержкой 250 мс: быстрый набор не перерисовывает
  // весь интерфейс и не отправляет запрос на каждый символ (раньше из-за этого ввод «залипал»).
  const [searchDraft, setSearchDraft] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchDraft), 250);
    return () => clearTimeout(t);
  }, [searchDraft]);
  const [filtersOpen, setFiltersOpen] = useState(false);
  // Фильтры сохраняются между перезагрузками.
  const [filters, setFilters] = useState(() => loadFilters(FILTERS_KEY));

  // Порядок сортировки внутри проекта хранится отдельно от фильтров: это настройка вида.
  const [boardSort, setBoardSort] = useState(() => localStorage.getItem(SORT_KEY) || "position");
  useEffect(() => { localStorage.setItem(SORT_KEY, boardSort); }, [boardSort]);

  // Условия фильтра сохраняются вместе с разделом, к которому они относятся.
  useEffect(() => {
    if (route.view === "none") return;
    saveFilters(FILTERS_KEY, filters, `${route.view}:${route.boardId || ""}`);
  }, [filters, route.view, route.boardId]);
  const [hideCompleted, setHideCompleted] = useState(() => localStorage.getItem(HIDE_DONE_KEY) === "true");
  // Скрытие задач, где пользователь сам поставил отметку о выполнении своего этапа (задача при этом не завершена).
  const [hideMyDone, setHideMyDone] = useState(() => localStorage.getItem(HIDE_MYDONE_KEY) === "true");

  const [menu, setMenu] = useState(null);
  // Левое меню проектов сворачивается и сохраняет состояние между сеансами.
  const [sidebarCollapsed, setSidebarCollapsed] = useState(
    () => localStorage.getItem("kanban.sidebarCollapsed") === "true");
  useEffect(() => {
    localStorage.setItem("kanban.sidebarCollapsed", String(sidebarCollapsed));
  }, [sidebarCollapsed]);
  // Ширина левого меню изменяется мышью и сохраняется локально.
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const v = parseInt(localStorage.getItem("kanban.sidebarWidth") || "", 10);
    return Number.isFinite(v) && v >= 200 && v <= 560 ? v : 264;
  });
  useEffect(() => {
    localStorage.setItem("kanban.sidebarWidth", String(sidebarWidth));
  }, [sidebarWidth]);
  // Признак активного перетаскивания границы бокового меню.
  const sidebarResizing = useRef(false);
  useEffect(() => {
    const onMove = (e) => {
      if (!sidebarResizing.current) return;
      const w = Math.min(560, Math.max(200, e.clientX));
      setSidebarWidth(w);
    };
    const onUp = () => {
      if (sidebarResizing.current) {
        sidebarResizing.current = false;
        document.body.style.userSelect = "";
        document.body.style.cursor = "";
      }
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
  }, []);
  const [unread, setUnread] = useState(0);
  const [wsStatus, setWsStatus] = useState("disconnected");
  const [toast, setToast] = useState(null);

  const [taskModal, setTaskModal] = useState(null);
  // Колонки и участники проекта задачи, открытой на правку из раздела, где проект не загружен («Все задачи», календарь, «Входящие» и т. п.).
  const [modalCtx, setModalCtx] = useState(null);
  const [detailId, setDetailId] = useState(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [newBoardOpen, setNewBoardOpen] = useState(false);
  const [teamOpen, setTeamOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [delegationOpen, setDelegationOpen] = useState(false);
  const [accessOpen, setAccessOpen] = useState(false);
  const [soundOpen, setSoundOpen] = useState(false);
  const [photoOpen, setPhotoOpen] = useState(false);
  const [passwordOpen, setPasswordOpen] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [openColumn, setOpenColumn] = useState(null);
  // Задача, для которой открыто окно копирования или переноса (одно окно в двух режимах).
  const [transfer, setTransfer] = useState(null);
  // Задача, для которой создаётся напоминание из карточки.
  const [reminderFor, setReminderFor] = useState(null);
  // Очередь сработавших напоминаний: после перерыва пользователь разбирает их по очереди.
  const [alarms, setAlarms] = useState([]);
  // Число непрочитанных сообщений рядом с разделом «Сообщения»; значение приходит из вкладки переписки.
  const [chatUnread, setChatUnread] = useState(0);
  // Пользователи в сети (список общий для приложения).
  const [onlineUsers, setOnlineUsers] = useState(new Set());
  // Группы личной команды для выбора исполнителей.
  const [teamGroups, setTeamGroups] = useState([]);
  // Число задач, ожидающих приёмки; вычисляется сервером (запрос страницы из одной записи).
  const [readyCount, setReadyCount] = useState(0);
  // Всплывающее сообщение о сданной задаче.
  const [readyToast, setReadyToast] = useState(null);
  useEffect(() => subscribePresence(setOnlineUsers), []);
  // Всплывающее сообщение о новом сообщении переписки: { chatId, author, chatTitle }; хранится в App, а не во вкладке чатов.
  const [chatToast, setChatToast] = useState(null);
  // Чат, который нужно открыть при переходе во вкладку переписки.
  const [openChatId, setOpenChatId] = useState(null);
  // Задача, форму которой нужно открыть после загрузки её проекта: { boardId, taskId } (используется после копирования).
  const [pendingEdit, setPendingEdit] = useState(null);
  // Задача для подробного вида, загруженная отдельно (в сводке и календаре список задач доски не загружен).
  const [fetchedTask, setFetchedTask] = useState(null);
  // Действующие замещения всех сотрудников для карточки пользователя.
  const [activeDelegations, setActiveDelegations] = useState([]);
  // Настройки звука хранятся в состоянии, а не читаются из localStorage на каждое событие.
  const [sound, setSound] = useState(loadSoundSettings);

  // Подсветка изменившихся карточек: id → { color }; снимается через несколько секунд и при открытии задачи.
  const [highlights, setHighlights] = useState({});
  const highlightTimers = React.useRef({});

  // Ссылка на flashTask: upsertTask объявлена выше по файлу и не может обращаться к ней напрямую.
  const flashTaskRef = React.useRef(null);

  const flashTask = useCallback((taskId, color) => {
    setHighlights((prev) => ({ ...prev, [taskId]: { color } }));
    clearTimeout(highlightTimers.current[taskId]);
    highlightTimers.current[taskId] = setTimeout(() => {
      setHighlights((prev) => {
        const next = { ...prev };
        delete next[taskId];
        return next;
      });
      delete highlightTimers.current[taskId];
    }, 6000);
  }, []);

  useEffect(() => { flashTaskRef.current = flashTask; }, [flashTask]);

  // Таймеры очищаются при размонтировании.
  useEffect(() => () => {
    Object.values(highlightTimers.current).forEach(clearTimeout);
  }, []);

  // Недавно изменившиеся задачи (taskId → тип изменения): спокойная подсветка тонкой полосой слева, гаснет сама.
  const [recent, setRecent] = useState({});   // taskId -> тип изменения

  // Отметка живёт 12 секунд.
  const markRecent = useCallback((taskId, kind) => {
    if (!taskId) return;
    setRecent((prev) => ({ ...prev, [taskId]: kind }));
    setTimeout(() => {
      setRecent((prev) => {
        if (prev[taskId] !== kind) return prev;   // успело смениться на другое
        const next = { ...prev };
        delete next[taskId];
        return next;
      });
    }, 12000);
  }, []);

  useEffect(() => { saveSoundSettings(sound); }, [sound]);

  // Разблокировка звука на первом действии пользователя: события приходят по сети, а не из клика.
  useEffect(() => { primeAudio(); }, []);
  const [userCard, setUserCard] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [bgStamp, setBgStamp] = useState(Date.now());

  const showError = useCallback((message) => setToast({ message, kind: "error" }), []);
  const showInfo = useCallback((message) => setToast({ message, kind: "ok" }), []);

  /* Раздел: сессия. */

  useEffect(() => {
    let alive = true;
    (async () => {
      if (!hasSession()) { setBooting(false); return; }
      try {
        const restored = await api.restore();
        if (alive) setUser(restored);
      } catch {
        // сессия истекла: отображается экран входа
      } finally {
        if (alive) setBooting(false);
      }
    })();
    return () => { alive = false; };
  }, []);

  useEffect(() => onAuthLost(() => setUser(null)), []);
  // После входа частые разделы подгружаются в простое браузера.
  useEffect(() => { if (user) idlePrefetch(); }, [user]);
  useEffect(() => { localStorage.setItem(THEME_KEY, themeId); }, [themeId]);
  useEffect(() => { localStorage.setItem(DESIGN_KEY, design); }, [design]);

  // Цвета темы дублируются CSS-переменными, признаки — атрибутами body, чтобы общие классы из styles.css работали с темой.
  useEffect(() => {
    const root = document.documentElement.style;
    for (const [k, v] of Object.entries(theme)) {
      if (typeof v === "string" && k !== "name") root.setProperty(`--t-${k}`, v);
    }
    // data-design переключает концептуальное оформление; data-brand сохраняется для стеклянных градиентов.
    document.body.dataset.design = design;
    document.documentElement.dataset.design = design;
    document.body.dataset.brand = design === "glass" ? "glass" : "";
    document.body.dataset.themeId = themeId;
    document.body.dataset.dark = theme.dark ? "1" : "0";
  }, [theme, design]);
  useEffect(() => { localStorage.setItem(HIDE_DONE_KEY, String(hideCompleted)); }, [hideCompleted]);
  useEffect(() => { localStorage.setItem(HIDE_MYDONE_KEY, String(hideMyDone)); }, [hideMyDone]);

  useEffect(() => {
    const onPop = () => setRoute(readRoute());
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  // WebSocket открыт весь сеанс, пока пользователь вошёл: уведомления не привязаны к открытой доске.
  useEffect(() => {
    if (!user) { realtimeDisconnect(); return; }
    realtimeConnect();
    return () => realtimeDisconnect();
  }, [user]);

  useEffect(() => onRealtimeStatus(setWsStatus), []);

  /* Раздел: справочники и доски. */

  const reloadBoards = useCallback(async () => {
    const list = await api.boards();
    setBoards(list);
    return list;
  }, []);

  useEffect(() => {
    if (!user) return;
    let alive = true;
    (async () => {
      try {
        const [dir, teamIds, boardList] = await Promise.all([api.directory(), api.team(), api.boards()]);
        if (!alive) return;
        setDirectory(dir);
        setTeam(teamIds);
        // Группы загружаются отдельно и не блокируют вход: без них выбор исполнителей работает плоским списком.
        api.teamGroups().then(setTeamGroups).catch(() => {});
        setBoards(boardList);

        const current = readRoute();
        // Прямая ссылка на раздел или существующий проект открывается на нём, а не на первом проекте списка.
        const keepAsIs = current.view === "board"
          ? boardList.some((b) => b.id === current.boardId)
          : current.view !== "none";
        if (keepAsIs) {
          setRoute(current);
        } else if (boardList.length > 0) {
          const next = { view: "board", boardId: boardList[0].id };
          setRoute(next);
          pushRoute(next, true);
        } else {
          setRoute({ view: INBOX, boardId: null });
          pushRoute({ view: INBOX }, true);
        }
      } catch (e) {
        showError(e.message);
      }
    })();
    return () => { alive = false; };
  }, [user, showError]);

  // Счётчик непрочитанных загружается один раз при входе, затем обновляется событиями WebSocket.
  useEffect(() => {
    if (!user) return;
    api.notifications({ limit: 1, includeRead: false }).then((d) => setUnread(d.unread)).catch(() => {});
    api.activeDelegations().then(setActiveDelegations).catch(() => {});
  }, [user]);

  /* Раздел: загрузка содержимого. */

  const loadBoardData = useCallback(async () => {
    if (!user) return;

    if (route.view === INBOX) {
      setLoadingBoard(true);
      try {
        const list = await api.inbox();
        setBoard(null);
        setColumns([]);
        setTasks(list);
      } catch (e) {
        showError(e.message);
      } finally {
        setLoadingBoard(false);
      }
      return;
    }
    if (route.view === DASHBOARD || route.view === CALENDAR || route.view === ALLTASKS
        || route.view === REMINDERS || route.view === CHATS || route.view === READY || route.view === FAVORITES
        || route.view === CHARTS || route.view === WHITEBOARDS || route.view === SYSTEM) {
      // Сводка, календарь и «Все задачи» загружают данные самостоятельно: им нужны данные по всем проектам.
      setBoard(null);
      setColumns([]);
      setTasks([]);
      setLoadingBoard(false);
      return;
    }
    if (route.view !== "board" || !route.boardId) return;

    setLoadingBoard(true);
    try {
      const [b, cols, list] = await Promise.all([api.board(route.boardId), api.columns(route.boardId), api.tasks(route.boardId)]);
      setBoard(b);
      setColumns(cols);
      setTasks(list);
    } catch (e) {
      if (e.status === 404 || e.status === 403) {
        // Причина отказа берётся из ответа сервера («не допущены к проекту», «проект удалён»).
        showError(e.message || "Проект недоступен или удалён");
        const list = await reloadBoards();
        const next = list.length ? { view: "board", boardId: list[0].id } : { view: INBOX, boardId: null };
        setRoute(next);
        pushRoute(next, true);
      } else {
        showError(e.message);
      }
    } finally {
      setLoadingBoard(false);
    }
  }, [user, route, showError, reloadBoards]);

  useEffect(() => { loadBoardData(); }, [loadBoardData]);

  // Задача из ссылки открывается один раз после входа, затем адрес не изменяется.
  const taskLinkDone = React.useRef(false);
  const refreshReady = useCallback(() => {
    api.allTasks("status=ready&scope=all&limit=1")
      .then((res) => setReadyCount(res.total || 0))
      .catch(() => {});
  }, []);
  // При возврате на вкладку браузера перечитываются данные, которые могли измениться.
  useEffect(() => {
    if (!user) return undefined;
    const onFocus = () => {
      reloadBoards();
      refreshReady();
      api.notifications({ limit: 1 })
        .then((data) => setUnread(data.unread))
        .catch(() => {});
      api.chats()
        .then((list) => setChatUnread(list.reduce((n, c) => n + (c.unread || 0), 0)))
        .catch(() => {});
    };
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [user, reloadBoards, refreshReady]);

  useEffect(() => { if (user) refreshReady(); }, [user, refreshReady]);

  // Счётчик готовых к сдаче пересчитывается при переходе между разделами.
  useEffect(() => { if (user) refreshReady(); }, [user, route.view, refreshReady]);

  // Счётчик непрочитанных сообщений загружается при входе.
  useEffect(() => {
    if (!user) return;
    api.chats()
      .then((list) => setChatUnread(list.reduce((n, c) => n + (c.unread || 0), 0)))
      .catch(() => {});
  }, [user]);

  useEffect(() => {
    if (!user || taskLinkDone.current) return;
    const id = readTaskLink();
    if (!id) return;
    taskLinkDone.current = true;
    setDetailId(id);
    window.history.replaceState({}, "", "/");
  }, [user]);

  // Просмотр проекта: открытая доска считается просмотренной со всем, что в ней изменилось.
  useEffect(() => {
    if (!user || route.view !== "board" || !route.boardId) return;
    const boardId = route.boardId;
    const seenAt = new Date().toISOString();
    setBoards((prev) => prev.map((b) => (b.id === boardId ? { ...b, seenAt } : b)));
    api.markSeen("board", boardId).catch(() => {});
  }, [user, route.view, route.boardId]);

  const goto = (next) => { setRoute(next); pushRoute(next); setMenu(null); };

  // Панель отбора закрывается при переходе в раздел, где она не нужна.
  useEffect(() => {
    if (route.view === REMINDERS || route.view === DASHBOARD || route.view === CHATS
        || route.view === SYSTEM) {
      setFiltersOpen(false);
    }
  }, [route.view]);

  // Фильтр относится к конкретному списку (раздел и проект) и не переносится на другую вкладку.
  const filterScope = `${route.view}:${route.boardId || ""}`;
  const prevFilterScope = useRef(null);
  useEffect(() => {
    if (route.view === "none") return;
    const prev = prevFilterScope.current;
    prevFilterScope.current = filterScope;
    const settling = prev === null;
    if (settling ? savedFilterScope(FILTERS_KEY) === filterScope : prev === filterScope) {
      return;
    }
    setFilters(emptyFilters());
    setSearch("");
    setSearchDraft("");
  }, [filterScope, route.view]);

  // Функция openBoard предназначена для перехода в проект по ссылке из списка задач, календаря или уведомления.
  const openBoard = useCallback((boardId) => {
    if (!boardId) return;
    if (!boards.some((b) => b.id === boardId)) {
      showError("Вы не допущены к этому проекту — доступны только отдельные задачи, открытые вам лично");
      return;
    }
    goto({ view: "board", boardId });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [boards, showError]);

  /* Раздел: события реального времени. Единая точка входа: любое изменение, своё или чужое, обрабатывается здесь. */

  // Поле task.access — уровень доступа (edit, contribute, read) для конкретного зрителя, а не свойство задачи; сервер вычисляет его при рассылке.
  // Функция hasVisibleChange предназначена для проверки содержательности изменения задачи.
  const hasVisibleChange = useCallback((prev, next) => {
    if (!prev) return false;
    if (Boolean(prev.completedAt) !== Boolean(next.completedAt)) return true;
    if ((prev.assigneesDone || []).length !== (next.assigneesDone || []).length) return true;
    if (prev.commentCount !== next.commentCount) return true;
    if (prev.attachmentCount !== next.attachmentCount) return true;
    if (prev.columnId !== next.columnId) return true;
    if ((prev.assignees || []).join() !== (next.assignees || []).join()) return true;
    const steps = (x) => (x.steps || []).filter((s) => s.done).length;
    if (steps(prev) !== steps(next)) return true;
    return prev.title !== next.title || prev.dueDate !== next.dueDate
        || prev.priority !== next.priority || prev.description !== next.description;
  }, []);

  // Функция touchBoard предназначена для пометки проекта изменившимся в списке слева (событие не содержит пересчитанных отметок).
  const touchBoard = useCallback((boardId) => {
    if (!boardId || (route.view === "board" && boardId === route.boardId)) return;
    const at = new Date().toISOString();
    setBoards((prev) => prev.map((b) => (b.id === boardId ? { ...b, lastActivityAt: at } : b)));
  }, [route]);

  // Функция touchTask предназначена для пометки задачи изменившейся (комментарий, файл или отметка чек-листа приходят отдельными событиями).
  const touchTask = useCallback((taskId) => {
    const at = new Date().toISOString();
    setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, lastActivityAt: at } : t)));
  }, []);

  // Функция applySeen предназначена для применения отметок просмотра с сервера: прочтение уведомления снимает выделение задачи
  // и проекта (если в нём нет других непросмотренных задач).
  const applySeen = useCallback((ev) => {
    const items = ev?.items || [];
    const tasksSeen = new Map(items.filter((i) => i.kind === "task").map((i) => [i.id, i.viewedAt]));
    const boardsSeen = new Map(items.filter((i) => i.kind === "board").map((i) => [i.id, i.viewedAt]));
    if (tasksSeen.size) {
      setTasks((prev) => prev.map((t) => (tasksSeen.has(t.id) ? { ...t, seenAt: tasksSeen.get(t.id) } : t)));
      setFetchedTask((prev) => (prev && tasksSeen.has(prev.id) ? { ...prev, seenAt: tasksSeen.get(prev.id) } : prev));
    }
    if (boardsSeen.size) {
      setBoards((prev) => prev.map((b) => (boardsSeen.has(b.id) ? { ...b, seenAt: boardsSeen.get(b.id) } : b)));
    }
    if (typeof ev?.unread === "number") setUnread(ev.unread);
  }, []);

  const upsertTask = useCallback((t) => {
    // Догруженная карточка (сводка, календарь) обновляется отдельно от списка задач доски.
    setFetchedTask((prev) => (prev && prev.id === t.id
      ? { ...t, access: prev.access, seenAt: prev.seenAt }
      : prev));
    setTasks((prev) => {
      const i = prev.findIndex((x) => x.id === t.id);
      if (i === -1) {
        if (route.view === "board" && t.boardId !== route.boardId) return prev;
        return [...prev, t];
      }
      if (hasVisibleChange(prev[i], t)) flashTaskRef.current?.(t.id, theme.accent);
      const next = [...prev];
      // Поля seenAt и access вычислены для пользователя, чьё действие вызвало рассылку, поэтому сохраняются прежние значения получателя.
      next[i] = { ...t, access: prev[i].access, seenAt: prev[i].seenAt };
      return next;
    });
  }, [route, hasVisibleChange, theme]);


  // Функция fetchOwnTaskView предназначена для загрузки представления задачи, которой не было в локальном состоянии.
  const fetchOwnTaskView = useCallback(async (taskId) => {
    try {
      const t = await api.task(taskId);
      setTasks((prev) => (prev.some((x) => x.id === t.id) ? prev : [...prev, t]));
    } catch {
      // Задача могла стать недоступной или удалиться: она не добавляется в список.
    }
  }, []);

  // Актуальный список задач в ref: обработчик события должен знать, видела ли приложение задачу ранее.
  const tasksRef = React.useRef(tasks);
  useEffect(() => { tasksRef.current = tasks; }, [tasks]);

  // Список проектов в ref: обработчику событий нужно знать, состоит ли пользователь в проекте.
  const boardsRef = React.useRef(boards);
  useEffect(() => { boardsRef.current = boards; }, [boards]);

  useEffect(() => {
    if (!user) return;

    const offTask = onRealtimeMessage("task", (e) => {
      if (e.action === "deleted") {
        setTasks((prev) => prev.filter((t) => t.id !== e.payload.id));
        if (detailId === e.payload.id) setDetailId(null);
        return;
      }
      // Звук зависит от события: новая задача, перенос между колонками, закрытие.
      if (route.view === INBOX && e.payload.boardId
          && boardsRef.current.some((b) => b.id === e.payload.boardId)) {
        setTasks((prev) => prev.filter((t) => t.id !== e.payload.id));
        return;
      }

      // Звук различается по событию; подсветка одна для всех видов изменений.
      refreshReady();

      // Сданная задача: отдельный сигнал и всплывающее сообщение; сравнивается со старым состоянием.
      const prevTask = tasksRef.current.find((t) => t.id === e.payload.id);
      if (e.payload.readyAt && !e.payload.completedAt
          && (!prevTask || !prevTask.readyAt)
          && e.payload.readyBy !== user.id) {
        if ((e.payload.assignees || []).includes(user.id) || e.payload.createdBy === user.id) playEventSound("ready", sound);
        setReadyToast({
          taskId: e.payload.id,
          title: e.payload.title,
          author: e.payload.readyBy
            ? resolveUser(directory, e.payload.readyBy).fullName
            : "Исполнитель",
        });
        refreshReady();
      } else if (prevTask && prevTask.readyAt && !e.payload.readyAt) {
        refreshReady();
      }

      const known = tasksRef.current.find((t) => t.id === e.payload.id);
      // Звук только по задачам, где пользователь исполнитель: редактору проекта чужие задачи не озвучиваются.
      const mine = (e.payload.assignees || []).includes(user.id);
      const playTask = (kind) => { if (mine) playEventSound(kind, sound); };
      if (e.action === "created" && !known) {
        playTask("taskCreated");
        flashTask(e.payload.id, theme.accent);
      } else if (e.action === "moved" && known && known.columnId !== e.payload.columnId) {
        playTask("taskMoved");
      } else if (known && !known.completedAt && e.payload.completedAt) {
        playTask("taskDone");
      } else if (known && (known.assigneesDone || []).length <
                 (e.payload.assigneesDone || []).length) {
        // Исполнитель сдал свою часть: сигнал «готово».
        playTask("taskDone");
      }

      // Проект помечается изменившимся только при содержательной правке (перетаскивание рассылает карточку целиком).
      if (!known || hasVisibleChange(known, e.payload)) {
        touchBoard(e.payload.boardId);
      }

      const isNew = !tasksRef.current.some((t) => t.id === e.payload.id);
      const belongsHere = route.view === INBOX || e.payload.boardId === route.boardId;
      // Во «Входящих» карточки группируются по названию проекта; без названия задача попала бы в группу «Без проекта».
      if (route.view === INBOX && !e.payload.boardTitle) {
        fetchOwnTaskView(e.payload.id);
        return;
      }
      if (isNew && belongsHere) {
        fetchOwnTaskView(e.payload.id);
      } else {
        upsertTask(e.payload);
      }
    });

    const offStep = onRealtimeMessage("step", (e) => {
      const { taskId, step } = e.payload;
      setTasks((prev) => prev.map((t) => {
        if (t.id !== taskId) return t;
        if (e.action === "deleted") return { ...t, steps: t.steps.filter((s) => s.id !== step.id) };
        const i = t.steps.findIndex((s) => s.id === step.id);
        const steps = i === -1 ? [...t.steps, step] : t.steps.map((s) => (s.id === step.id ? step : s));
        return { ...t, steps };
      }));
    });

    const offComment = onRealtimeMessage("comment", (e) => {
      const taskId = e.payload.taskId;
      // Сигнал только на чужие сообщения.
      if (e.action === "created" && e.payload.authorId !== user.id) {
        // Звук комментария — только в задачах, где пользователь исполнитель.
        if ((tasksRef.current.find((t) => t.id === taskId)?.assignees || []).includes(user.id)) playEventSound("comment", sound);
        flashTask(taskId, theme.accent);
        // Собственное сообщение непрочитанным не помечается.
        touchTask(taskId);
        touchBoard(tasksRef.current.find((t) => t.id === taskId)?.boardId);
      }
      setTasks((prev) => prev.map((t) => {
        if (t.id !== taskId) return t;
        if (e.action === "created") return { ...t, commentCount: t.commentCount + 1 };
        if (e.action === "deleted") return { ...t, commentCount: Math.max(0, t.commentCount - 1) };
        return t;
      }));
    });

    const offAttachment = onRealtimeMessage("attachment", (e) => {
      const taskId = e.payload.taskId;
      if (e.action === "created" && e.payload.authorId !== user.id) {
        flashTask(taskId, theme.accent);
        touchTask(taskId);
        touchBoard(tasksRef.current.find((t) => t.id === taskId)?.boardId);
      }
      setTasks((prev) => prev.map((t) => {
        if (t.id !== taskId) return t;
        if (e.action === "created") return { ...t, attachmentCount: t.attachmentCount + 1 };
        if (e.action === "deleted") return { ...t, attachmentCount: Math.max(0, t.attachmentCount - 1) };
        return t;
      }));
    });

    const offColumns = onRealtimeMessage("columns", (e) => {
      if (route.view === "board" && e.payload.boardId === route.boardId) setColumns(e.payload.columns);
    });

    const offBoard = onRealtimeMessage("board", (e) => {
      if (e.action === "deleted") {
        setBoards((prev) => prev.filter((b) => b.id !== e.payload.id));
        if (route.view === "board" && route.boardId === e.payload.id) {
          showError("Проект удалён владельцем");
          goto({ view: INBOX, boardId: null });
        }
        return;
      }
      if (e.action === "member_added") {
        reloadBoards();
        return;
      }
      reloadBoards();
      if (route.view === "board" && route.boardId === e.payload.id) {
        // Поле myRole в payload вычислено для пользователя, вызвавшего рассылку, поэтому роль получателя сохраняется.
        setBoard((prev) => (prev ? { ...e.payload, myRole: prev.myRole } : e.payload));
        setBgStamp(Date.now());
      }
    });

    // Новое уведомление обновляет счётчик и воспроизводит звук независимо от состояния панели.
    const offAccess = onRealtimeMessage("access", (e) => {
      // Отозван точечный доступ к одной задаче: закрывается только эта задача.
      if (e.action === "task_revoked") {
        const lostTaskId = e.payload.taskId;
        setTasks((prev) => prev.filter((t) => t.id !== lostTaskId));
        if (detailId === lostTaskId) setDetailId(null);
        setTaskModal((m) => (m?.task?.id === lostTaskId ? null : m));
        showError(e.payload.reason || "Доступ к задаче отозван");
        return;
      }

      if (e.action !== "revoked") return;
      const lostBoardId = e.payload.boardId;

      // Проект удаляется из списка, его задачи удаляются из памяти.
      setBoards((prev) => prev.filter((b) => b.id !== lostBoardId));
      setTasks((prev) => prev.filter((t) => t.boardId !== lostBoardId));

      const lookingAtIt = route.view === "board" && route.boardId === lostBoardId;
      const detailFromIt = detailId && tasksRef.current.some(
        (t) => t.id === detailId && t.boardId === lostBoardId
      );

      if (lookingAtIt || detailFromIt) {
        // Закрываются все окна, открытые поверх проекта: карточка задачи, форма, настройки.
        setDetailId(null);
        setTaskModal(null);
        setSettingsOpen(false);
        setConfirm(null);
      }

      if (lookingAtIt) {
        setBoard(null);
        setColumns([]);
        goto({ view: INBOX, boardId: null });
      }

      showError(e.payload.reason || "Доступ к проекту закрыт");
    });

    // Сработавшее напоминание открывает окно будильника; дубли отсеиваются по идентификатору.
    const offReminder = onRealtimeMessage("reminder", (e) => {
      const { id, reminderId, title, taskId, dueAt } = e.payload || {};
      if (!id) return;
      setAlarms((prev) => (prev.some((a) => a.id === id) ? prev : [...prev, { id, reminderId, title, taskId, dueAt }]));
    });

    // При входе (и при возврате на вкладку после неактивности) подтягиваются неподтверждённые напоминания,
    // сработавшие в отсутствие пользователя: окно закрывается только явным действием.
    const loadAlerts = () => {
      api.reminderAlerts().then((list) => {
        if (!Array.isArray(list) || !list.length) return;
        setAlarms((prev) => {
          const have = new Set(prev.map((a) => a.id));
          const add = list.filter((a) => !have.has(a.id))
            .map((a) => ({ id: a.id, reminderId: a.reminderId, title: a.title, taskId: a.taskId, dueAt: a.dueAt, missed: true }));
          return add.length ? [...prev, ...add] : prev;
        });
      }).catch(() => {});
    };
    loadAlerts();
    const onVisible = () => { if (!document.hidden) loadAlerts(); };
    document.addEventListener("visibilitychange", onVisible);

    // Сообщение могло прийти при закрытой вкладке переписки: счётчик пересчитывается здесь.
    const offChatMsg = onRealtimeMessage("message", (e) => {
      // Собственное сообщение не озвучивается.
      if (e.payload?.authorId === user.id) return;
      // Правки и удаления чужих сообщений звуком не сопровождаются.
      if (e.action === "created") playEventSound("message", sound);

      // Пересчёт счётчика нужен только при закрытой вкладке переписки.
      if (route.view === CHATS) return;

      if (e.action === "created") {
        const who = e.payload?.authorId
          ? resolveUser(directory, e.payload.authorId).fullName
          : "Сотрудник";
        // В уведомлении отображается текст сообщения.
        const body = e.payload?.body
          ? (e.payload.body.length > 120 ? `${e.payload.body.slice(0, 120)}…` : e.payload.body)
          : (e.payload?.fileId ? "Файл: " + (e.payload.filename || "вложение") : "");
        setChatToast({ chatId: e.payload?.chatId, author: who, body });
      }
      api.chats()
        .then((list) => setChatUnread(list.reduce((n, c) => n + (c.unread || 0), 0)))
        .catch(() => {});
    });

    const offSeen = onRealtimeMessage("seen", (e) => applySeen(e.payload));

    const offNotif = onRealtimeMessage("notification", () => {
      setUnread((n) => n + 1);
      playEventSound("notification", sound);
    });

    return () => {
      offTask(); offStep(); offComment(); offAttachment();
      document.removeEventListener("visibilitychange", onVisible);
      offColumns(); offBoard(); offAccess(); offNotif(); offSeen(); offReminder(); offChatMsg();
    };
  }, [user, route, detailId, upsertTask, fetchOwnTaskView, reloadBoards, showError, showInfo,
      sound, flashTask, theme, touchBoard, touchTask, hasVisibleChange, directory]);

  /* Раздел: фильтрация. */

  const allTags = useMemo(() => [...new Set(tasks.flatMap((t) => t.tags || []))].sort(), [tasks]);

  // Набор тегов для панели отбора: на доске и во «Входящих» берётся из загруженных задач, остальные вкладки передают свои теги (viewTags).
  const [viewTags, setViewTags] = useState([]);
  const filterTags = (route.view === "board" || route.view === INBOX) ? allTags : viewTags;

  // Поиск по комментариям и отчёту выполняется на сервере (тексты комментариев в списке задач не передаются).
  const [searchExtra, setSearchExtra] = useState(null);
  useEffect(() => {
    const q = (search || "").trim();
    if (q.length < 2) { setSearchExtra(null); return undefined; }
    let dead = false;
    const h = setTimeout(() => {
      api.searchTaskIds(q).then((ids) => { if (!dead) setSearchExtra(new Set(ids)); }).catch(() => {});
    }, 300);
    return () => { dead = true; clearTimeout(h); };
  }, [search]);

  const visibleTasks = useMemo(
    () => tasks.filter((t) => matchesFilters(t, filters, search, searchExtra)
      && !(hideMyDone && user && (t.assigneesDone || []).includes(user.id))),
    [tasks, search, searchExtra, filters, hideMyDone, user]);

  // Отбор по дате завершения означает запрос завершённых: «скрыть завершённые» в этом случае не применяется.
  const hideDone = hideCompleted && !(filters.doneFrom || filters.doneTo);

  // Отсортированный список передаётся доске; порядок внутри колонки определяется выбранной сортировкой.
  const sortedTasks = useMemo(() => {
    const list = [...visibleTasks];
    switch (boardSort) {
      case "due":
        return list.sort((a, b) => {
          if (!a.dueDate && !b.dueDate) return 0;
          if (!a.dueDate) return 1;   // без срока — в конец
          if (!b.dueDate) return -1;
          return a.dueDate.localeCompare(b.dueDate);
        });
      case "created":
        return list.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
      case "priority":
        return list.sort((a, b) =>
          (PRIORITIES[b.priority]?.order || 0) - (PRIORITIES[a.priority]?.order || 0));
      case "title":
        return list.sort((a, b) => a.title.localeCompare(b.title, "ru"));
      default:
        return list.sort((a, b) => a.position - b.position);
    }
  }, [visibleTasks, boardSort]);

  const activeSortLabel = {
    position: "как на доске", due: "по сроку",
    created: "по дате", priority: "по приоритету", title: "по названию",
  }[boardSort];

  const toggleFilter = (kind, value) => setFilters((f) => {
    const next = new Set(f[kind]);
    next.has(value) ? next.delete(value) : next.add(value);
    return { ...f, [kind]: next };
  });

  const activeFilters = countFilters(filters);

  /* Раздел: операции с задачами. */

  const myRole = board?.myRole || "";
  const canEdit = ["owner", "editor"].includes(myRole);
  // Настройки проекта (участники, колонки, оформление) доступны и редактору; удаление проекта — только владельцу.
  const canManage = canEdit;
  const isOwner = myRole === "owner";
  // Создавать задачи может любой участник проекта, включая читателя (reader); перемещать задачу вправе автор и редактор.
  const canCreate = Boolean(myRole);
  const canMoveTask = useCallback(
    (t) => t && (t.createdBy === user?.id || canEdit || (t.assignees || []).includes(user?.id)),
    [canEdit, user],
  );
  const isInbox = route.view === INBOX;

  // Функция moveTask предназначена для переноса задачи: перетаскивание отображается сразу (оптимистично), итоговое состояние приходит событием.
  const moveTask = async (taskId, columnId, position) => {
    setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, columnId, position } : t)));
    try {
      await api.moveTask(taskId, columnId, position);
    } catch (e) {
      showError(e.message);
      loadBoardData();
    }
  };

  const saveTask = async (form) => {
    try {
      const payload = {
        title: form.title, description: form.description, priority: form.priority,
        // Поле color обязательно в списке: выбор цвета иначе терялся бы при сохранении.
        color: form.color || "none",
        // Реквизиты документа передаются обратно в сервер при правке.
        incomingNumber: form.incomingNumber || "",
        // При правке пустая дата означает «убрать реквизит», при создании — «нет значения».
        incomingDate: form.id ? (form.incomingDate || "") : (form.incomingDate || null),
        columnId: form.columnId,
        // При создании пустой срок — null («поля нет»), при правке — пустая строка («снять срок»).
        dueDate: form.id ? (form.dueDate || "") : (form.dueDate || null),
        tags: form.tags, assignees: form.assignees,
        // Периодичность: при «Без повторения» на правке явно передаётся сброс правила (clearRecur).
        recurFreq: form.recurFreq || "none",
        recurInterval: form.recurInterval || 1,
        recurWeekdays: form.recurWeekdays || [],
        recurMonthday: form.recurMonthday ?? null,
        recurUntil: form.recurUntil || null,
        clearRecur: form.id ? (form.recurFreq === "none" || !form.recurFreq) : false,
      };
      // Чек-лист принимается только при создании задачи.
      if (!form.id) {
        payload.steps = (form.steps || [])
          .filter((s) => (s.body || "").trim())
          .map((s) => ({
            body: s.body.trim(),
            assigneeId: s.assigneeId || null,
            dueDate: s.dueDate || null,
          }));
      }
      const saved = form.id ? await api.updateTask(form.id, payload) : await api.createTask(route.boardId, payload);
      upsertTask(saved);
      setTaskModal(null);

      // Напоминание из формы создаётся отдельным запросом после сохранения задачи.
      if (form.reminderAt) {
        try {
          await api.createReminder({
            title: saved.title,
            remindAt: new Date(form.reminderAt).toISOString(),
            recurFreq: "none",
            recurInterval: 1,
            recurWeekdays: [],
            taskId: saved.id,
          });
          showInfo("Задача сохранена, напоминание создано");
        } catch {
          showError("Задача сохранена, но напоминание создать не удалось");
        }
      }
    } catch (e) {
      showError(e.message);
    }
  };

  const requestDeleteTask = (taskId) => {
    const t = tasks.find((x) => x.id === taskId);
    setConfirm({
      title: "Удалить задачу?",
      message: `Задача «${t?.title}» будет удалена вместе с комментариями, файлами и историей. Отменить это действие нельзя.`,
      confirmLabel: "Удалить задачу",
      onConfirm: async () => {
        setConfirm(null);
        setTaskModal(null);
        setDetailId(null);
        try {
          await api.deleteTask(taskId);
          setTasks((prev) => prev.filter((x) => x.id !== taskId));
        } catch (e) {
          showError(e.message);
        }
      },
    });
  };

  const requestDeleteBoard = () => {
    setConfirm({
      title: "Удалить проект?",
      message: `Проект «${board.title}» будет удалён вместе с колонками, задачами, файлами и историей. Участники потеряют доступ. Действие необратимо.`,
      confirmLabel: "Удалить проект",
      onConfirm: async () => {
        setConfirm(null);
        setSettingsOpen(false);
        try {
          await api.deleteBoard(board.id);
          const list = await reloadBoards();
          const next = list.length ? { view: "board", boardId: list[0].id } : { view: INBOX, boardId: null };
          setRoute(next);
          pushRoute(next, true);
        } catch (e) {
          showError(e.message);
        }
      },
    });
  };

  // Функция moveBoard предназначена для перетаскивания проекта (вложение и порядок на уровне); parentId передаётся всегда, в том числе null.
  const moveBoard = async (boardId, target) => {
    try {
      await api.updateBoard(boardId, {
        parentId: target.parentId ?? null,
        ...(target.position !== undefined ? { position: target.position } : {}),
      });
      await reloadBoards();
    } catch (e) {
      showError(e.message);
    }
  };

  const createBoard = async (payload) => {
    try {
      const { id } = await api.createBoard(payload);
      await reloadBoards();
      setNewBoardOpen(false);
      goto({ view: "board", boardId: id });
    } catch (e) {
      showError(e.message);
    }
  };

  // Открытая диаграмма или доска (сообщают сами разделы): ссылка в шапке ведёт на неё, а не на список.
  const [activeObject, setActiveObject] = useState(null);
  const copyLink = async () => {
    // Ссылка на текущее представление строится тем же правилом, что и адресная строка: любой раздел ведёт на себя, а не в корень.
    const viewPath = pathForRoute(activeObject && (route.view === CHARTS || route.view === WHITEBOARDS) ? { ...route, objectId: activeObject } : route);
    const url = `${window.location.origin}${viewPath}`;
    try {
      // navigator.clipboard доступен только в защищённом контексте (HTTPS или localhost).
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(url);
      } else {
        const ta = document.createElement("textarea");
        ta.value = url;
        ta.style.position = "fixed";
        ta.style.top = "-1000px";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        const ok = document.execCommand("copy");
        document.body.removeChild(ta);
        if (!ok) throw new Error("copy_unsupported");
      }
      showInfo("Ссылка скопирована");
    } catch {
      showError("Не удалось скопировать ссылку");
    }
  };

  // Открытие задачи отмечает её просмотренной: это единственное место отметки на сервере (GET задачи просмотр не отмечает).
  useEffect(() => {
    if (!detailId) return;
    const seenAt = new Date().toISOString();
    setTasks((prev) => prev.map((t) => (t.id === detailId ? { ...t, seenAt } : t)));
    setFetchedTask((prev) => (prev && prev.id === detailId ? { ...prev, seenAt } : prev));
    api.markSeen("task", detailId).catch(() => {});
  }, [detailId]);

  // При открытии задачи подсветка снимается.
  useEffect(() => {
    if (!detailId) return;
    setHighlights((prev) => {
      if (!prev[detailId]) return prev;
      const next = { ...prev };
      delete next[detailId];
      return next;
    });
  }, [detailId]);

  useEffect(() => {
    if (!detailId) { setFetchedTask(null); return; }
    if (tasksRef.current.some((t) => t.id === detailId)) return;
    let alive = true;
    api.task(detailId)
      // seenAt из ответа может быть старше отметки, поставленной параллельно, поэтому используется текущее время.
      .then((t) => alive && setFetchedTask({ ...t, seenAt: new Date().toISOString() }))
      .catch((e) => { showError(e.message); setDetailId(null); });
    return () => { alive = false; };
  }, [detailId, showError]);

  const editBoardId = taskModal?.mode === "edit" ? taskModal.task.boardId : null;
  const modalOwnBoard = !editBoardId || (route.view === "board" && route.boardId === editBoardId && columns.length > 0);
  useEffect(() => {
    if (modalOwnBoard) { setModalCtx(null); return undefined; }
    let alive = true;
    Promise.all([api.board(editBoardId), api.columns(editBoardId)])
      .then(([b, cols]) => { if (alive) setModalCtx({ boardId: editBoardId, board: b, columns: cols }); })
      .catch((e) => { if (alive) { showError(e.message); setTaskModal(null); } });
    return () => { alive = false; };
  }, [editBoardId, modalOwnBoard, showError]);

  // Отложенное открытие формы задачи после перехода в другой проект (копирование): ожидаются колонки и задача.
  useEffect(() => {
    if (!pendingEdit) return;
    if (route.view !== "board" || route.boardId !== pendingEdit.boardId) return;
    if (loadingBoard || columns.length === 0) return;
    const t = tasks.find((x) => x.id === pendingEdit.taskId);
    if (!t) return;
    setTaskModal({ mode: "edit", task: t });
    setPendingEdit(null);
  }, [pendingEdit, route, loadingBoard, columns, tasks]);

  // Если переход не состоялся (проект закрыт, задача удалена), отложенное открытие сбрасывается.
  useEffect(() => {
    if (!pendingEdit) return;
    const t = setTimeout(() => setPendingEdit(null), 15000);
    return () => clearTimeout(t);
  }, [pendingEdit]);

  const detailTask = tasks.find((t) => t.id === detailId)
    || (fetchedTask?.id === detailId ? fetchedTask : null);

  // Свои фоны (страницы и проекта) загружаются как blob и показываются по object URL. Прямой адрес содержал access_token,
  // который меняется при каждом обновлении токена: адрес фона менялся, картинка перезагружалась и страница мигала.
  const customBoardBg = board?.bgPreset === "custom" && board?.bgFileId ? { path: `/boards/${board.id}/background?v=${bgStamp}`, key: `b:${board.id}:${bgStamp}` } : null;
  const customPageBg = pageBg.preset === "custom" && pageBg.fileId ? { path: `/me/background?v=${pageBg.stamp || 0}`, key: `p:${pageBg.fileId}:${pageBg.stamp || 0}` } : null;
  const boardBgUrl = useBlobUrl(customBoardBg, Boolean(user));
  const pageBgUrl = useBlobUrl(customPageBg, Boolean(user));

  /* Раздел: отрисовка. */

  if (booting) {
    return <div style={{ background: theme.bg, minHeight: "100vh" }} className="flex items-center justify-center"><Spinner theme={theme} label="Загружаем…" /></div>;
  }
  if (!user) {
    return <Login theme={theme} onSuccess={setUser} />;
  }

  const preset = bgById(board?.bgPreset);
  const isCustom = board?.bgPreset === "custom" && board?.bgFileId;
  // Готовые изображения находятся в статике сервера и одинаковы у всех, в отличие от «custom» (загружается пользователем).
  const readyImage = bgImageUrl(board?.bgPreset);
  const bgImage = isCustom
    ? (boardBgUrl ? `url(${boardBgUrl})` : null)
    : readyImage
    ? `url(${readyImage})`
    : preset?.css || null;
  // Узорные фоны повторяются плиткой, а не растягиваются.
  const bgSize = isCustom || readyImage ? "cover" : preset?.size || "cover";
  // Общий фон страниц действует, пока у открытого проекта нет собственного фона.
  const pagePreset = bgById(pageBg.preset);
  const pageReady = bgImageUrl(pageBg.preset);
  const pageImage = pageBg.preset === "custom" && pageBg.fileId
    ? (pageBgUrl ? `url(${pageBgUrl})` : null)
    : pageReady ? `url(${pageReady})` : pagePreset?.css || null;
  const pageSize = pageBg.preset === "custom" || pageReady ? "cover" : pagePreset?.size || "cover";
  const effImage = bgImage || pageImage;
  const effSize = bgImage ? bgSize : pageSize;
  const effBlur = bgImage ? board?.bgBlur : pageBg.blur;

  // Шапка экрана: заголовок и краткая сводка; отрисовывается компонентом App для всех разделов.
  const ownerMember = (board?.members || []).find((m) => m.role === "owner");
  const owner = ownerMember ? resolveUser(directory, ownerMember.userId) : null;
  const pageTitle =
    route.view === CALENDAR ? "Календарь"
    : route.view === DASHBOARD ? "Сводка"
    : route.view === ALLTASKS ? "Все задачи"
    : route.view === READY ? "Готовы к сдаче"
    : route.view === FAVORITES ? "Избранные"
    : route.view === REMINDERS ? "Напоминания"
    : route.view === CHATS ? "Сообщения"
    : route.view === CHARTS ? "Диаграммы"
    : route.view === WHITEBOARDS ? "Совместные доски"
    : route.view === SYSTEM ? "Состояние системы"
    : isInbox ? "Входящие"
    : route.view === "board" ? (board?.title || "Проект")
    : "";
  const todayLabel = new Date().toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" });
  const projectsLabel = plural(boards.length, "проект", "проекта", "проектов");
  const pageSubtitle =
    route.view === DASHBOARD ? `${todayLabel[0].toUpperCase()}${todayLabel.slice(1)} · ${projectsLabel}`
    : route.view === ALLTASKS || route.view === CALENDAR ? `Задачи из ${plural(boards.length, "проекта", "проектов", "проектов")}`
    : route.view === READY ? (readyCount ? `${plural(readyCount, "задача ждёт", "задачи ждут", "задач ждут")} приёмки` : "Нет задач, ожидающих приёмки")
    : route.view === FAVORITES ? "Ваши отмеченные открытые задачи"
    : route.view === CHATS ? (chatUnread ? plural(chatUnread, "непрочитанное", "непрочитанных", "непрочитанных") : "Переписка с коллегами")
    : route.view === REMINDERS ? "Личные напоминания с будильником"
    : route.view === CHARTS ? "Этапы работ на шкале времени"
    : route.view === WHITEBOARDS ? "Общие холсты для обсуждения"
    : isInbox && !loadingBoard ? `${plural(tasks.length, "задача открыта", "задачи открыты", "задач открыто")} вам лично`
    : route.view === "board" && board ? [
        ROLE_LABEL[myRole] ? `Вы — ${ROLE_LABEL[myRole].toLowerCase()}` : null,
        owner && ownerMember.userId !== user.id && !owner.deleted ? `владелец ${owner.fullName}` : null,
        plural(tasks.length, "задача", "задачи", "задач"),
      ].filter(Boolean).join(" · ")
    : "";

  // Плитки-счётчики под заголовком доски и «Входящих» считаются по всем загруженным задачам без учёта фильтров.
  const showStats = (route.view === "board" && board) || isInbox;
  const stats = (() => {
    if (!showStats) return null;
    const today = new Date(new Date().toDateString());
    const weekEnd = new Date(today);
    weekEnd.setDate(today.getDate() + ((7 - today.getDay()) % 7) + 1); // начало следующего понедельника
    let open = 0, week = 0, overdue = 0, done = 0;
    for (const t of tasks) {
      if (t.completedAt) { done += 1; continue; }
      open += 1;
      if (isOverdue(t.dueDate, false)) overdue += 1;
      else if (t.dueDate && new Date(t.dueDate) < weekEnd) week += 1;
    }
    return [
      ["Открыто", open, null],
      ["Срок на этой неделе", week, null],
      ["Просрочено", overdue, overdue ? theme.danger : null],
      ["Завершено", done, null],
    ];
  })();

  const showSearch = !(route.view === DASHBOARD || route.view === REMINDERS
    || route.view === CHATS || route.view === CHARTS
    || route.view === WHITEBOARDS || route.view === SYSTEM || route.view === "none");
  const showFiltersBtn = route.view !== DASHBOARD && route.view !== REMINDERS && route.view !== SYSTEM && route.view !== "none"
    && route.view !== CHATS && route.view !== CHARTS && route.view !== WHITEBOARDS; // панель отбора там не открывается
  const showDoneBtn = route.view !== "none" && route.view !== DASHBOARD && route.view !== REMINDERS
    && route.view !== CHATS && route.view !== SYSTEM;
  const showCreate = canCreate && !isInbox && route.view !== DASHBOARD && route.view !== CALENDAR
    && route.view !== ALLTASKS && route.view !== REMINDERS && route.view !== CHATS;

  // Цвет активной капсулы-переключателя: тон акцента.
  const toggleOn = { background: `${theme.accent}26`, color: theme.accent, borderColor: "transparent" };
  const menuItem = "w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13.5px] text-left transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]";
  const popover = "glass-pane absolute z-30 p-1.5 shadow-[0_24px_48px_-20px_rgba(0,0,0,.45)]";

  return (
    <div style={{ background: theme.bg, height: "100vh" }} className="relative overflow-hidden">
      {/* Фон проекта (настройка владельца) занимает окно, поверх него — ровная вуаль цвета темы. */}
      {effImage && (
        <>
          <div aria-hidden style={{
            backgroundImage: effImage, backgroundSize: effSize, backgroundPosition: "center",
            filter: effBlur ? "blur(22px)" : "none", transform: effBlur ? "scale(1.12)" : "none",
          }} className="absolute inset-0 pointer-events-none" />
          <div aria-hidden style={{ background: theme.bg, opacity: theme.dark ? 0.72 : 0.62 }}
            className="absolute inset-0 pointer-events-none" />
        </>
      )}

      {/* Нажатие вне открытого меню (уведомления, оформление, профиль, действия проекта) закрывает его. */}
      {menu && (
        <div onClick={() => setMenu(null)} className="fixed inset-0 z-[45]"
          style={{ background: menu === "notif" ? (theme.dark ? "rgba(0,0,0,.28)" : "rgba(20,20,40,.10)") : "transparent" }} aria-hidden />
      )}

      <div className="app-shell relative h-full flex p-[14px] gap-[14px]">
        {/* Левое меню: плавающая панель, сворачивается кнопкой в шапке; на узких экранах в развёрнутом виде накладывается на содержимое. */}
        {!sidebarCollapsed && (
          <>
            <aside
              // Ширина хранится по положению курсора от края окна; отступ панели от края (14 px) вычитается.
              style={{ width: sidebarWidth - 14, zIndex: menu === "user" ? 50 : undefined }}
              className="app-aside glass-pane shrink-0 flex flex-col z-30 absolute top-[14px] bottom-[14px] left-[14px] lg:relative lg:top-auto lg:bottom-auto lg:left-auto shadow-2xl lg:shadow-none">
              <div className="flex items-center gap-2.5 px-4 pt-4 pb-3">
                <button onClick={() => goto({ view: ALLTASKS, boardId: null })}
                  className="flex items-center gap-2.5 min-w-0 flex-1 rounded-full" title="Все задачи">
                  {/* Логотип: webp 96×96 (для экранов с плотностью 2×), отображается 36 px. */}
                  <img src="/logo-96.webp" width="36" height="36" alt="" decoding="async"
                    className="app-logo w-9 h-9 shrink-0" />
                  <span style={{ color: theme.text }} className="text-[18px] font-bold tracking-[-0.01em] truncate">{appConfig.appName}</span>
                </button>
                <button onClick={() => setSidebarCollapsed(true)} className="btn-icon shrink-0"
                  title="Скрыть меню" aria-label="Скрыть меню">
                  <PanelLeftClose size={18} />
                </button>
              </div>

              <div className="flex-1 min-h-0 overflow-y-auto">
                <ProjectTree
                  theme={theme} design={design} boards={boards} directory={directory}
                  activeId={route.boardId}
                  isInbox={isInbox} isDashboard={route.view === DASHBOARD}
                  isCalendar={route.view === CALENDAR} isAllTasks={route.view === ALLTASKS}
                  isReminders={route.view === REMINDERS}
                  isChats={route.view === CHATS} chatUnread={chatUnread}
                  isFavorites={route.view === FAVORITES}
                  onSelectFavorites={() => goto({ view: FAVORITES, boardId: null })}
                  isReady={route.view === READY} readyCount={readyCount}
                  onSelectReady={() => goto({ view: READY, boardId: null })}
                  onSelect={(id) => goto({ view: "board", boardId: id })}
                  onSelectInbox={() => goto({ view: INBOX, boardId: null })}
                  onSelectDashboard={() => goto({ view: DASHBOARD, boardId: null })}
                  onSelectCalendar={() => goto({ view: CALENDAR, boardId: null })}
                  onSelectAllTasks={() => goto({ view: ALLTASKS, boardId: null })}
                  onSelectReminders={() => goto({ view: REMINDERS, boardId: null })}
                  onSelectChats={() => goto({ view: CHATS, boardId: null })}
                  isCharts={route.view === CHARTS}
                  onSelectCharts={() => goto({ view: CHARTS, boardId: null })}
                  isWhiteboards={route.view === WHITEBOARDS}
                  onSelectWhiteboards={() => goto({ view: WHITEBOARDS, boardId: null })}
                  onCreate={() => { setNewBoardOpen(true); }}
                  onMove={moveBoard}
                  canReorder />
                <div className="px-2.5 pb-3">
                  <button onClick={() => { setTeamOpen(true); }} style={{ color: theme.textMuted }}
                    className="nav-item w-full flex items-center gap-3 px-3 min-h-[40px] text-[14px] transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]"
                    title="Редактировать состав команды">
                    <NavIcon design={design} name="team" />
                    <span style={{ color: theme.text }} className="flex-1 text-left font-medium">Моя команда</span>
                    <span style={{ background: theme.dark ? "rgba(255,255,255,.09)" : "rgba(0,0,0,.06)" }}
                      className="text-[11.5px] font-semibold tabular-nums min-w-[22px] h-[20px] px-1.5 rounded-full inline-flex items-center justify-center">
                      {team.length}
                    </span>
                  </button>
                </div>
              </div>

              {/* Профиль внизу панели: текущий пользователь и личные настройки. */}
              <div className="relative p-2.5 pt-1.5">
                <button onClick={() => setMenu(menu === "user" ? null : "user")}
                  aria-expanded={menu === "user"} aria-haspopup="menu"
                  className="w-full flex items-center gap-3 p-2 rounded-[18px] text-left transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]"
                  title="Профиль и настройки">
                  <Avatar user={user} size={34} theme={theme} />
                  <span className="flex-1 min-w-0">
                    <span style={{ color: theme.text }} className="block text-[14px] font-semibold truncate">{user.fullName}</span>
                    <span style={{ color: theme.textMuted }} className="block text-[12px] truncate">
                      {user.position || (user.role === "admin" ? "Администратор" : user.email)}
                    </span>
                  </span>
                  <ChevronsUpDown size={15} style={{ color: theme.textMuted }} className="shrink-0" />
                </button>
                {menu === "user" && (
                  <div role="menu" className={`${popover} bottom-full mb-1 left-2.5 right-2.5`}>
                    {appConfig.userGuide && (
                      <button onClick={() => { setGuideOpen(true); setMenu(null); }} style={{ color: theme.text }} className={menuItem}>
                        <BookOpen size={15} style={{ color: theme.textMuted }} /> Руководство пользователя
                      </button>
                    )}
                    <button onClick={() => { setPhotoOpen(true); setMenu(null); }} style={{ color: theme.text }} className={menuItem}>
                      <Camera size={15} style={{ color: theme.textMuted }} /> Моя фотография
                    </button>
                    <button onClick={() => { setSoundOpen(true); setMenu(null); }} style={{ color: theme.text }} className={menuItem}>
                      {sound.enabled
                        ? <Volume2 size={15} style={{ color: theme.accent }} />
                        : <VolumeX size={15} style={{ color: theme.textMuted }} />}
                      Звуковые уведомления
                    </button>
                    <button onClick={() => { setDelegationOpen(true); setMenu(null); }} style={{ color: theme.text }} className={menuItem}>
                      <UserCheck size={15} style={{ color: theme.textMuted }} /> Замещение
                    </button>
                    <button onClick={() => { setAccessOpen(true); setMenu(null); }} style={{ color: theme.text }} className={menuItem}>
                      <ShieldCheck size={15} style={{ color: theme.textMuted }} /> Доступы
                    </button>
                    <button onClick={() => { setPasswordOpen(true); setMenu(null); }} style={{ color: theme.text }} className={menuItem}>
                      <KeyRound size={15} style={{ color: theme.textMuted }} /> Сменить пароль
                    </button>
                    {appConfig.about && (
                      <button onClick={() => { setAboutOpen(true); setMenu(null); }} style={{ color: theme.text }} className={menuItem}>
                        <Info size={15} style={{ color: theme.textMuted }} /> О системе
                      </button>
                    )}
                    {user.role === "admin" && (
                      <>
                        <div style={{ background: theme.border }} className="h-px mx-2 my-1" />
                        <button onClick={() => { setAdminOpen(true); setMenu(null); }} style={{ color: theme.text }} className={menuItem}>
                          <ShieldCheck size={15} style={{ color: theme.textMuted }} /> Пользователи
                        </button>
                        <button onClick={() => { goto({ view: SYSTEM, boardId: null }); }} style={{ color: theme.text }} className={menuItem}>
                          <Activity size={15} style={{ color: theme.textMuted }} /> Состояние системы
                        </button>
                      </>
                    )}
                    <div style={{ background: theme.border }} className="h-px mx-2 my-1" />
                    <button onClick={async () => { await api.logout(); safeSession("set", "krb_off", "1"); setUser(null); setMenu(null); }} style={{ color: theme.danger }} className={`${menuItem} font-medium`}>
                      <LogOut size={15} /> Выйти
                    </button>
                  </div>
                )}
              </div>

              {/* Маркер изменения ширины меню мышью (на десктопе); ширина сохраняется в localStorage. */}
              <div
                onMouseDown={() => {
                  sidebarResizing.current = true;
                  document.body.style.userSelect = "none";
                  document.body.style.cursor = "col-resize";
                }}
                onDoubleClick={() => setSidebarWidth(264)}
                title="Потяните, чтобы изменить ширину (двойной клик — сброс)"
                className="hidden lg:block absolute top-6 bottom-6 -right-[10px] w-[6px] rounded-full cursor-col-resize transition-colors duration-150 hover:bg-[var(--t-border)] active:bg-[var(--t-accent)]" />
            </aside>
            {/* Подложка для закрытия меню нажатием вне его (мобильные экраны). */}
            <div onClick={() => setSidebarCollapsed(true)}
              className="fixed inset-0 z-20 lg:hidden" style={{ background: "rgba(0,0,0,0.35)" }} />
          </>
        )}

        <div className="app-main flex-1 min-w-0 flex flex-col">
          {/* Шапка экрана: заголовок слева, инструменты справа. */}
          <header className="relative flex items-start gap-4" style={{ zIndex: menu && menu !== "user" ? 50 : 40 }}>
            {sidebarCollapsed && (
              <button onClick={() => setSidebarCollapsed(false)}
                className="btn-icon glass-pane shrink-0 mt-[3px]" style={{ width: 40, height: 40, borderRadius: 999 }}
                title="Показать меню" aria-label="Показать меню">
                <PanelLeftOpen size={18} />
              </button>
            )}
            <div className="flex-1 min-w-0 pt-0.5">
              <h1 className="page-title truncate" title={pageTitle}>{pageTitle}</h1>
              <div className="flex items-center gap-2 min-w-0 mt-0.5">
                {pageSubtitle && <p className="page-subtitle truncate">{pageSubtitle}</p>}
                {route.view === "board" && board && !canEdit && myRole === "reader" && (
                  <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="pill shrink-0"
                    title="Исполнитель: можно создавать задачи и двигать свои; чужие задачи перемещает автор или редактор">
                    <Eye size={12} /> Исполнитель
                  </span>
                )}
              </div>
            </div>

            <div className="glass-pane shrink-0 flex items-center gap-1 p-1.5" style={{ borderRadius: 999 }}>
              <ServerClock theme={theme} />
              {/* Поиск по задачам отображается только в разделах, где он применяется. */}
              {showSearch && (
                <div className="relative w-[180px] xl:w-[240px]">
                  <Search size={15} style={{ color: theme.textMuted }} className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input value={searchDraft} onChange={(e) => setSearchDraft(e.target.value)}
                    placeholder="Поиск задач"
                    title="Поиск: название, описание, вх. номер, тег"
                    aria-label="Поиск: название, описание, вх. номер, тег"
                    style={{ ...inputStyle(theme), border: "1px solid transparent", borderRadius: 999 }}
                    className="w-full h-9 pl-9 pr-3 text-[13.5px] outline-none" />
                </div>
              )}
              {showCreate && (
                <button onClick={() => setTaskModal({ mode: "create", columnId: columns[0]?.id })}
                  className="btn-icon" title="Новая задача" aria-label="Новая задача">
                  <Plus size={19} />
                </button>
              )}
              {/* Ссылка на раздел; в проекте находится в меню «⋯» вместе с действиями проекта. */}
              {route.view !== "none" && !(route.view === "board" && board) && (
                <button onClick={copyLink} className="btn-icon" title="Скопировать ссылку на текущий раздел" aria-label="Скопировать ссылку на текущий раздел">
                  <Link2 size={18} />
                </button>
              )}
              <div className="relative">
                <button onClick={() => setMenu(menu === "theme" ? null : "theme")} className="btn-icon"
                  title="Оформление" aria-label="Оформление" aria-expanded={menu === "theme"}>
                  <Palette size={18} />
                </button>
                {menu === "theme" && (
                  <div role="menu" className={`${popover} top-full mt-2.5 right-0 w-72 max-h-[70vh] overflow-y-auto`}>
                    <div className="px-3 pt-1.5 pb-1 text-[12px] font-medium" style={{ color: theme.textMuted }}>
                      Оформление
                    </div>
                    {/* Размер: масштаб элементов и шрифта хранятся у пользователя и действуют во всех вкладках. */}
                    <div className="px-3 pb-2 space-y-1.5">
                      {[["ui", "Масштаб элементов", UI_MIN, UI_MAX], ["fs", "Размер шрифта", FS_MIN, FS_MAX]].map(([k, label, lo, hi]) => (
                        <div key={k} className="flex items-center gap-1.5">
                          <span className="flex-1 text-[12px]" style={{ color: theme.textMuted }}>{label}</span>
                          <button onClick={() => setScale({ ...scale, [k]: scale[k] - STEP })} disabled={scale[k] <= lo}
                            aria-label={`${label}: меньше`} className="btn-icon !w-7 !h-7 disabled:opacity-30">−</button>
                          <span className="w-11 text-center text-[12px] tabular-nums" style={{ color: theme.text }}>{scale[k]}%</span>
                          <button onClick={() => setScale({ ...scale, [k]: scale[k] + STEP })} disabled={scale[k] >= hi}
                            aria-label={`${label}: больше`} className="btn-icon !w-7 !h-7 disabled:opacity-30">+</button>
                        </div>
                      ))}
                      {/* Шрифт и начертание: хранятся у пользователя; Tinos — аналог Times New Roman. */}
                      <div className="flex items-center gap-1.5 pt-0.5">
                        <select value={scale.font} onChange={(e) => setScale({ ...scale, font: e.target.value })}
                          aria-label="Шрифт" style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
                          className="flex-1 min-w-0 rounded-lg px-2 py-1 text-[12px] outline-none">
                          <option value="">Шрифт дизайна</option>
                          {FONT_LIST.map((f) => <option key={f.id} value={f.id}>{f.label}</option>)}
                        </select>
                        <button onClick={() => setScale({ ...scale, bold: !scale.bold })} aria-pressed={scale.bold}
                          title="Жирный" aria-label="Жирный"
                          style={scale.bold ? { background: theme.accent, color: theme.accentText } : { background: theme.surfaceAlt, color: theme.text }}
                          className="w-7 h-7 rounded-lg text-[13px] font-bold shrink-0">Ж</button>
                        <button onClick={() => setScale({ ...scale, italic: !scale.italic })} aria-pressed={scale.italic}
                          title="Курсив" aria-label="Курсив"
                          style={scale.italic ? { background: theme.accent, color: theme.accentText } : { background: theme.surfaceAlt, color: theme.text }}
                          className="w-7 h-7 rounded-lg text-[13px] italic shrink-0">К</button>
                      </div>
                      {(scale.ui !== 100 || scale.fs !== 100 || scale.font || scale.bold || scale.italic) && (
                        <button onClick={() => setScale(DEFAULT_SCALE)} className="text-[12px] underline underline-offset-2"
                          style={{ color: theme.accent }}>Сбросить размеры</button>
                      )}
                    </div>
                    <div className="h-px mx-2 mb-2" style={{ background: theme.border }} />
                    {/* Дизайн: концептуально разное оформление; ниже — цвета выбранного дизайна. */}
                    <div className="grid grid-cols-2 gap-1 px-2 pb-2">
                      {DESIGN_ORDER.map((d) => (
                        <button key={d} onClick={() => setDesign(d)} title={DESIGNS[d].hint}
                          aria-pressed={d === design}
                          style={d === design
                            ? { background: theme.accent, color: theme.accentText }
                            : { background: theme.surfaceAlt, color: theme.text }}
                          className="rounded-lg px-2 py-1.5 text-[12px] font-medium leading-tight min-w-0 truncate text-left">
                          {DESIGNS[d].name}
                        </button>
                      ))}
                    </div>
                    <div className="px-3 pb-1 text-[12px] font-medium" style={{ color: theme.textMuted }}>Цвет</div>
                    {DESIGN_THEMES[design].map((id) => {
                      const t = THEMES[id];
                      if (!t) return null;
                      return (
                        <button key={id} onClick={() => { pickTheme(id); setMenu(null); }}
                          style={{ color: theme.text, background: id === themeId ? theme.surfaceAlt : undefined }}
                          className={menuItem}>
                          {/* Образец темы показывает фон и оба акцента. */}
                          <span style={{ background: t.bg, border: `1px solid ${theme.border}` }}
                            className="w-8 h-6 rounded-full flex items-center justify-center gap-0.5 shrink-0">
                            <span style={{ background: t.accent }} className="w-2 h-2 rounded-full" />
                            <span style={{ background: t.accent2 }} className="w-2 h-2 rounded-full" />
                          </span>
                          <span className="flex-1 text-left">{t.name}</span>
                          <span className="text-[11.5px]" style={{ color: theme.textMuted }}>
                            {t.dark ? "тёмная" : "светлая"}
                          </span>
                          <Check size={14} style={{ color: theme.accent, visibility: id === themeId ? "visible" : "hidden" }} />
                        </button>
                      );
                    })}
                    <div className="h-px mx-2 my-2" style={{ background: theme.border }} />
                    <PageBgPicker theme={theme} value={pageBg} onChange={setPageBg} />
                  </div>
                )}
              </div>

              <div className="relative">
                <button onClick={() => setMenu(menu === "notif" ? null : "notif")} className="btn-icon relative"
                  title="Уведомления" aria-label={unread > 0 ? `Уведомления, непрочитанных: ${unread}` : "Уведомления"}
                  aria-expanded={menu === "notif"}>
                  <Bell size={18} />
                  {unread > 0 && (
                    <span style={{ background: theme.danger, boxShadow: `0 0 0 2px ${theme.surface}` }}
                      className="absolute top-0.5 right-0 min-w-[17px] h-[17px] px-1 rounded-full text-white text-[10px] tabular-nums flex items-center justify-center font-bold">
                      {unread > 99 ? "99+" : unread}
                    </span>
                  )}
                </button>
                {menu === "notif" && (
                  <Notifications theme={theme} onCountChange={setUnread} onSeen={applySeen} onOpenTask={async (n) => {
                    setMenu(null);

                    // Уведомление об открытии доступа может прийти раньше обновления списка проектов; переход выполняется с учётом этого.
                    if (n.chartId) {
                      goto({ view: CHARTS, boardId: null, objectId: n.chartId });
                      return;
                    }
                    if (n.whiteboardId) {
                      goto({ view: WHITEBOARDS, boardId: null, objectId: n.whiteboardId });
                      return;
                    }

                    let known = n.boardId ? boards.some((b) => b.id === n.boardId) : false;
                    if (n.boardId && !known) {
                      const list = await reloadBoards();
                      known = (list || []).some((b) => b.id === n.boardId);
                    }

                    if (known) {
                      goto({ view: "board", boardId: n.boardId });
                    } else if (n.taskId) {
                      // Доступ точечный: проекта в дереве нет, задача находится во «Входящих».
                      goto({ view: INBOX, boardId: null });
                    }
                    if (n.taskId) setDetailId(n.taskId);
                  }} />
                )}
              </div>

              <span className="w-7 h-9 flex items-center justify-center"
                title={wsStatus === "connected" ? "Обновления в реальном времени включены" : "Переподключение к серверу…"}>
                <RealtimeDot theme={theme} status={wsStatus} />
              </span>
            </div>
          </header>

          {/* Второй ряд шапки: счётчики слева, переключатели и действия справа. */}
          {(showStats || showFiltersBtn || showDoneBtn) && (
            <div className="relative flex items-end gap-3 flex-wrap mt-4" style={{ zIndex: menu === "board" ? 50 : 30 }}>
              {stats && (
                <div className="flex items-stretch gap-2.5 flex-wrap">
                  {stats.map(([label, value, color]) => (
                    <div key={label} className="stat-pill glass">
                      <span className="stat-label">{label}</span>
                      <span className="stat-value" style={color ? { color } : undefined}>{value}</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="ml-auto flex items-center gap-2 flex-wrap justify-end">
                {/* Кнопка отбора доступна на всех вкладках со списками задач: доска, «Входящие», «Все задачи», календарь. */}
                {showFiltersBtn && (
                  <button onClick={() => setFiltersOpen((v) => !v)} className="btn-pill"
                    aria-pressed={filtersOpen}
                    style={activeFilters ? toggleOn : filtersOpen ? { background: theme.surface } : undefined}>
                    <Filter size={14} /> Фильтры{activeFilters > 0 && <span className="tabular-nums">· {activeFilters}</span>}
                  </button>
                )}

                {/* Скрытие завершённых доступно там, где есть задачи. */}
                {showDoneBtn && (
                  <button onClick={() => setHideCompleted((v) => !v)} className="btn-pill"
                    aria-pressed={hideCompleted}
                    style={hideCompleted ? toggleOn : undefined}
                    title={hideCompleted ? "Показать завершённые" : "Скрыть завершённые"}
                    aria-label={hideCompleted ? "Показать завершённые" : "Скрыть завершённые"}>
                    {hideCompleted ? <EyeOff size={14} /> : <Eye size={14} />}
                    <span className="hidden xl:inline">{hideCompleted ? "Завершённые скрыты" : "Завершённые"}</span>
                  </button>
                )}
                {/* Второй переключатель: скрывает задачи с моей отметкой о выполнении своего этапа. */}
                {showDoneBtn && (
                  <button onClick={() => setHideMyDone((v) => !v)} className="btn-pill"
                    aria-pressed={hideMyDone}
                    style={hideMyDone ? toggleOn : undefined}
                    title={hideMyDone ? "Показать задачи с моей отметкой о выполнении" : "Скрыть задачи, где я отметил(а) выполнение"}
                    aria-label={hideMyDone ? "Показать задачи с моей отметкой о выполнении" : "Скрыть задачи, где я отметил(а) выполнение"}>
                    {hideMyDone ? <EyeOff size={14} /> : <Eye size={14} />}
                    <span className="hidden xl:inline">{hideMyDone ? "Скрыты с отметкой о выполнении" : "Не отмечено выполнение"}</span>
                  </button>
                )}

                {/* Действия проекта собраны в меню с подписями. */}
                {route.view === "board" && board ? (
                  <div className="relative">
                    <button onClick={() => setMenu(menu === "board" ? null : "board")}
                      className="btn-pill" style={{ paddingLeft: 10, paddingRight: 10 }}
                      title="Действия с проектом" aria-label="Действия с проектом" aria-expanded={menu === "board"}>
                      <Ellipsis size={18} />
                    </button>
                    {menu === "board" && (
                      <div role="menu" className={`${popover} top-full mt-2 right-0 w-64`} style={{ zIndex: 50 }}>
                        <button onClick={() => { setMenu(null); copyLink(); }} style={{ color: theme.text }} className={menuItem}>
                          <Link2 size={15} style={{ color: theme.textMuted }} /> Скопировать ссылку
                        </button>
                        <button
                          onClick={async () => {
                            setMenu(null);
                            // Выгружается отфильтрованный список (то, что отображается на экране).
                            try {
                              const n = await exportTasksToExcel(sortedTasks, {
                                directory, columns, boardTitle: board?.title,
                              });
                              showInfo(`Выгружено задач: ${n}`);
                            } catch (e) { showError(e.message); }
                          }}
                          style={{ color: theme.text }} className={menuItem}
                          title="Выгрузить задачи в Excel (с учётом фильтров)">
                          <FileSpreadsheet size={15} style={{ color: theme.textMuted }} /> Выгрузить в Excel
                        </button>
                        {canEdit && (
                          <button onClick={() => { setMenu(null); setTemplatesOpen(true); }} style={{ color: theme.text }} className={menuItem}>
                            <Zap size={15} style={{ color: theme.textMuted }} /> Шаблоны задач
                          </button>
                        )}
                        {canManage && (
                          <button onClick={() => { setMenu(null); setSettingsOpen(true); }} style={{ color: theme.text }} className={menuItem}>
                            <Settings size={15} style={{ color: theme.textMuted }} /> Настройки проекта
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                ) : null}

                {showCreate && (
                  <button onClick={() => setTaskModal({ mode: "create", columnId: columns[0]?.id })} className="btn-primary">
                    <Plus size={16} strokeWidth={2.4} /> Новая задача
                  </button>
                )}
              </div>
            </div>
          )}

      {/* Панель отбора общая для всех вкладок со списками задач; в сводке, переписке и состоянии системы не отображается. */}
      {filtersOpen && route.view !== DASHBOARD && route.view !== CHATS && route.view !== SYSTEM
        && route.view !== CHARTS && route.view !== WHITEBOARDS && (
        <div className="relative z-20 mt-3">
        <TaskFilters theme={theme} filters={filters} setFilters={setFilters}
          directory={directory} people={team} tags={filterTags}
          boards={route.view === "board" ? null : boards}
          extra={route.view === "board" ? (
            <FilterGroup theme={theme} label={`Сортировка · ${activeSortLabel}`}>
              {[["position", "Как на доске"], ["due", "По сроку"], ["priority", "По приоритету"],
                ["created", "По дате"], ["title", "По названию"]].map(([id, label]) => (
                <Chip key={id} theme={theme} active={boardSort === id} onClick={() => setBoardSort(id)}>
                  {label}
                </Chip>
              ))}
            </FilterGroup>
          ) : null} />
        </div>
      )}

      <main className="flex-1 min-h-0 relative overflow-hidden mt-4">
        <div className="relative h-full overflow-auto">
          {loadingBoard ? (
            <Spinner theme={theme} label="Загружаем данные…" />
          ) : route.view === CALENDAR ? (
            <Calendar theme={theme} directory={directory} boards={boards} currentUser={user}
              hideCompleted={hideDone} hideMyDone={hideMyDone} filters={filters} search={search} onTags={setViewTags}
              onError={showError} onInfo={showInfo} onOpenTask={setDetailId}
              onTaskCreated={upsertTask} />
          ) : route.view === DASHBOARD ? (
            <Dashboard theme={theme} directory={directory} boards={boards} currentUser={user}
              hideCompleted={hideDone}
              onError={showError} onOpenTask={setDetailId} />
          ) : route.view === ALLTASKS ? (
            <AllTasks theme={theme} directory={directory} boards={boards} currentUser={user}
              hideCompleted={hideDone} hideMyDone={hideMyDone} filters={filters} search={search} onTags={setViewTags}
              onError={showError} onInfo={showInfo} onOpenTask={setDetailId}
              onOpenBoard={openBoard} />
          ) : route.view === READY ? (
            // Раздел «Готовы к сдаче» — тот же список «Всех задач» с условием готовности к сдаче.
            <AllTasks theme={theme} directory={directory} boards={boards} currentUser={user}
              hideCompleted={hideDone} hideMyDone={hideMyDone} filters={filters} search={search} onTags={setViewTags}
              readyOnly
              onError={showError} onInfo={showInfo} onOpenTask={setDetailId}
              onOpenBoard={openBoard} />
          ) : route.view === FAVORITES ? (
            // Вкладка «Избранные» — список «Всех задач» с отметкой пользователя; закрытые задачи не показываются.
            <AllTasks theme={theme} directory={directory} boards={boards} currentUser={user}
              hideCompleted={hideDone} hideMyDone={hideMyDone} filters={filters} search={search} onTags={setViewTags}
              favoritesOnly
              onError={showError} onInfo={showInfo} onOpenTask={setDetailId}
              onOpenBoard={openBoard} />
          ) : route.view === CHARTS ? (
            <Charts theme={theme} directory={directory} team={team} currentUser={user}
              onError={showError} onOpenTask={setDetailId}
              openId={route.objectId} onActive={setActiveObject}
              onOpened={() => setRoute((r) => ({ ...r, objectId: null }))} />
          ) : route.view === WHITEBOARDS ? (
            <Whiteboards theme={theme} directory={directory} team={team} currentUser={user}
              onError={showError}
              openId={route.objectId} onActive={setActiveObject}
              onOpened={() => setRoute((r) => ({ ...r, objectId: null }))} />
          ) : route.view === CHATS ? (
            <Chats theme={theme} directory={directory} currentUser={user}
              onError={showError} onUnread={setChatUnread}
              openChatId={openChatId} onOpened={() => setOpenChatId(null)} />
          ) : route.view === REMINDERS ? (
            <Reminders theme={theme} onError={showError} onOpenTask={(id) => setDetailId(id)} />
          ) : route.view === SYSTEM ? (
            // Раздел только для администратора: сервер проверяет права самостоятельно (группа /admin).
            user.role === "admin"
              ? <System theme={theme} onError={showError} />
              : <p style={{ color: theme.textMuted }} className="text-[13px]">
                  Раздел доступен только администратору.
                </p>
          ) : isInbox ? (
            <InboxView tasks={sortedTasks} theme={theme} directory={directory}
              hideCompleted={hideDone} onOpenTask={setDetailId}
              highlights={highlights} currentUserId={user.id} onOpenUser={setUserCard} />
          ) : board ? (
            <BoardView columns={columns} tasks={sortedTasks} theme={theme} directory={directory} canEdit={canEdit} canManage={canManage}
              canCreate={canCreate} canMoveTask={canMoveTask}
              hideCompleted={hideDone} onOpenTask={setDetailId} onMove={moveTask}
              onQuickAdd={(columnId) => setTaskModal({ mode: "create", columnId })} onSettings={() => setSettingsOpen(true)}
              onExpandColumn={(col) => setOpenColumn(col)}
              currentUserId={user.id} onOpenUser={setUserCard}
              highlights={highlights}
              onShowCompleted={() => setHideCompleted(false)} />
          ) : (
            <div className="glass-pane max-w-md mx-auto text-center px-8 py-12 mt-10">
              <span style={{ background: theme.surfaceAlt, color: theme.textMuted }}
                className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <LayoutGrid size={22} />
              </span>
              <h3 style={{ color: theme.text }} className="font-semibold text-[19px] mb-1.5">Проектов пока нет</h3>
              <p style={{ color: theme.textMuted }} className="text-[14px] mb-5">Создайте первый проект — колонки и доска появятся сразу.</p>
              <button onClick={() => setNewBoardOpen(true)} className="btn-primary">
                <Plus size={16} strokeWidth={2.4} /> Создать проект
              </button>
            </div>
          )}
        </div>
      </main>
        </div>
      </div>

      {taskModal && (modalOwnBoard || modalCtx?.boardId === editBoardId) && (
        <TaskModal theme={theme} directory={directory} team={team} teamGroups={teamGroups}
          boardMemberIds={((modalOwnBoard ? board : modalCtx.board)?.members || []).map((m) => m.userId)} currentUser={user}
          columns={modalOwnBoard ? columns : modalCtx.columns}
          initial={taskModal.mode === "edit" ? taskModal.task : { columnId: taskModal.columnId }}
          onClose={() => setTaskModal(null)} onSave={saveTask} onRequestDelete={requestDeleteTask} />
      )}

      {detailTask && (
        <TaskDetail theme={theme} task={detailTask} directory={directory} team={team} currentUser={user}
          teamGroups={teamGroups}
          onClose={() => setDetailId(null)}
          onEdit={(t) => { setDetailId(null); setTaskModal({ mode: "edit", task: t }); }}
          onTaskPatched={upsertTask}
          onRequestDelete={requestDeleteTask}
          onRequestCopy={(t) => setTransfer({ task: t, mode: "copy" })}
          onRequestMove={(t) => setTransfer({ task: t, mode: "move" })}
          onRequestReminder={(t) => setReminderFor(t)}
          onOpenBoard={(id) => { setDetailId(null); openBoard(id); }}
          onError={showError} onOpenUser={setUserCard}
          onOpenTask={setDetailId}
          onOpenTaskChat={async (t) => {
            // Групповой чат задачи: сервер создаёт его с названием задачи и участниками или возвращает существующий.
            try {
              const res = await api.taskChat(t.id);
              setDetailId(null);
              setOpenChatId(res.id);
              goto({ view: CHATS, boardId: null });
            } catch (e) {
              showError(e.message);
            }
          }} />
      )}

      {settingsOpen && board && (
        <BoardSettings theme={theme} board={board} columns={columns} tasks={tasks} directory={directory} isOwner={isOwner}
          team={team} currentUser={user}
          onClose={() => setSettingsOpen(false)}
          onSaved={() => { setBgStamp(Date.now()); reloadBoards(); loadBoardData(); }}
          onRequestDeleteBoard={requestDeleteBoard} onError={showError} />
      )}

      {newBoardOpen && <NewBoardModal theme={theme} onClose={() => setNewBoardOpen(false)} onCreate={createBoard} />}

      {teamOpen && (
        <Team theme={theme} directory={directory} team={team} groups={teamGroups} currentUser={user} onClose={() => setTeamOpen(false)} onOpenUser={setUserCard}
          onSave={async (ids, groups) => {
            try {
              // Сначала сохраняется состав команды, затем группы: группа ссылается на участников команды.
              await api.saveTeam(ids);
              setTeam(ids);
              if (groups) {
                // Из групп удаляются пользователи, только что убранные из команды (сервер делает то же каскадом).
                const keep = new Set(ids);
                const cleaned = groups.map((g) => ({
                  ...g, members: g.members.filter((id) => keep.has(id)),
                }));
                setTeamGroups(await api.saveTeamGroups(cleaned));
              }
              setTeamOpen(false);
            } catch (e) { showError(e.message); }
          }} />
      )}

      {adminOpen && (
        <Admin theme={theme} currentUser={user} onClose={() => setAdminOpen(false)}
          onError={showError} onInfo={showInfo}
          onDirectoryChanged={() => api.directory().then(setDirectory).catch(() => {})} />
      )}

      {delegationOpen && (
        <Delegation theme={theme} directory={directory} currentUser={user}
          onClose={() => setDelegationOpen(false)}
          onError={showError} onInfo={showInfo} />
      )}

      {accessOpen && (
        <Access theme={theme} directory={directory} currentUser={user}
          onClose={() => setAccessOpen(false)}
          onError={showError} onInfo={showInfo}
          onOpenTask={(taskId, boardId) => {
            // Как переход из уведомления: проект из дерева — на доску, иначе задача находится во «Входящих».
            setAccessOpen(false);
            if (boardId && boards.some((b) => b.id === boardId)) {
              goto({ view: "board", boardId });
            } else {
              goto({ view: INBOX, boardId: null });
            }
            setDetailId(taskId);
          }} />
      )}

      {passwordOpen && (
        <PasswordModal theme={theme} onClose={() => setPasswordOpen(false)}
          onError={showError} onDone={showInfo} />
      )}

      {openColumn && (
        <ColumnView theme={theme} column={openColumn} directory={directory}
          tasks={sortedTasks.filter((t) => t.columnId === openColumn.id)}
          onClose={() => setOpenColumn(null)}
          onOpenTask={(id) => { setOpenColumn(null); setDetailId(id); }} />
      )}

      {reminderFor && (
        <TaskReminderModal theme={theme} task={reminderFor}
          onClose={() => setReminderFor(null)}
          onSaved={() => { setReminderFor(null); showInfo("Напоминание создано"); }}
          onError={showError} />
      )}

      {transfer && (
        // Список boards содержит только проекты, где пользователь состоит участником (в них можно создавать задачи).
        <CopyTaskModal theme={theme} task={transfer.task} mode={transfer.mode} boards={boards}
          onClose={() => setTransfer(null)}
          onError={showError}
          onCopied={(copy, targetBoardId, mode) => {
            setTransfer(null);

            if (mode === "move") {
              // При переносе задача та же, форму открывать не требуется: изменился только проект.
              showInfo("Задача перенесена");
              setTasks((prev) => prev.filter((t) => t.id !== copy.id));
              setFetchedTask(copy);
              openBoard(targetBoardId);
              setDetailId(copy.id);
              return;
            }

            showInfo("Задача скопирована");
            // Закрывается всё, что относилось к исходной задаче: работа продолжается в копии.
            setDetailId(null);
            setFetchedTask(null);

            if (route.view === "board" && targetBoardId === route.boardId) {
              // Копия в открытом проекте отображается сразу, её форма открывается.
              upsertTask(copy);
              setTaskModal({ mode: "edit", task: copy });
              return;
            }

            // Копия в другом проекте: выполняется переход, форма редактирования открывается после загрузки доски.
            openBoard(targetBoardId);
            setPendingEdit({ boardId: targetBoardId, taskId: copy.id });
          }} />
      )}

      {templatesOpen && (
        <Templates theme={theme} directory={directory} team={team}
          boardId={route.boardId} boardTitle={board?.title} columns={columns}
          onClose={() => setTemplatesOpen(false)}
          onError={showError} onInfo={showInfo}
          onCreated={(task) => upsertTask(task)} />
      )}

      {aboutOpen && <AboutModal theme={theme} onClose={() => setAboutOpen(false)} />}
      {guideOpen && <GuideModal theme={theme} onClose={() => setGuideOpen(false)} onError={showError} />}

      {photoOpen && (
        <Modal theme={theme} onClose={() => setPhotoOpen(false)} width="max-w-sm" geometryKey="my-photo">
          <ModalHeader theme={theme} title="Моя фотография" onClose={() => setPhotoOpen(false)} />
          <PhotoEditor theme={theme} user={directory.find((x) => x.id === user.id) || user}
            onChanged={() => api.directory().then(setDirectory)} onError={showError} onInfo={showInfo} />
        </Modal>
      )}

      {soundOpen && (
        <Modal theme={theme} onClose={() => setSoundOpen(false)} width="max-w-sm" geometryKey="sound-settings">
          <ModalHeader theme={theme} title="Звуковые уведомления"
            subtitle="Разные события звучат по-разному, чтобы понимать их не глядя на экран"
            onClose={() => setSoundOpen(false)} />

          <button onClick={() => setSound((s) => ({ ...s, enabled: !s.enabled }))}
            aria-pressed={sound.enabled}
            className={`${sound.enabled ? "btn-primary" : "btn-pill"} w-full h-11 mb-4`}>
            {sound.enabled ? <Volume2 size={15} /> : <VolumeX size={15} />}
            {sound.enabled ? "Звук включён" : "Звук выключен"}
          </button>

          <div style={{ opacity: sound.enabled ? 1 : 0.45 }}>
            <div className="text-[12.5px] font-medium mb-1.5"
              style={{ color: theme.textMuted }}>Громкость</div>
            <input type="range" min="0.02" max="0.5" step="0.02" value={sound.volume}
              disabled={!sound.enabled}
              onChange={(e) => {
                const v = Number(e.target.value);
                setSound((s) => ({ ...s, volume: v }));
                // Звук воспроизводится сразу при изменении громкости.
                playEventSound("notification", { ...sound, volume: v, enabled: true });
              }}
              className="w-full mb-4" style={{ accentColor: theme.accent }} />

            <div className="text-[12.5px] font-medium mb-2"
              style={{ color: theme.textMuted }}>Какие события</div>
            {Object.entries(SOUND_EVENT_LABELS).map(([key, label]) => (
              <div key={key} className="flex items-center justify-between gap-2 mb-1.5">
                <Toggle theme={theme} checked={sound.events[key] !== false}
                  label={label}
                  onChange={(next) => setSound((s) => ({
                    ...s, events: { ...s.events, [key]: next },
                  }))} />
                <button
                  onClick={() => playEventSound(key, { ...sound, enabled: true, events: { [key]: true } })}
                  className="btn-icon shrink-0" style={{ width: 30, height: 30 }}
                  title={`Прослушать: ${label}`} aria-label={`Прослушать: ${label}`}>
                  <Play size={13} />
                </button>
              </div>
            ))}

            <p style={{ color: theme.textMuted }} className="text-[11.5px] mt-3 leading-relaxed">
              Перемещение задач выключено по умолчанию: на активной доске карточки
              двигаются постоянно, и звук на каждое перетаскивание быстро надоедает.
            </p>
          </div>
        </Modal>
      )}

      {userCard && (
        <UserCard theme={theme} user={userCard} directory={directory}
          online={onlineUsers.has(userCard.id)}
          onWriteChat={async (u) => {
            // Закрывается всё, что было открыто поверх: карточка пользователя и окна, из которых она открыта.
            setUserCard(null);
            setTeamOpen(false);
            setDelegationOpen(false);
            setMenu(null);
            try {
              // Сервер находит существующую переписку с пользователем и создаёт новую, только если её нет.
              const res = await api.createChat({ kind: "direct", userId: u.id });
              setOpenChatId(res.id);
              goto({ view: CHATS, boardId: null });
            } catch (e) {
              showError(e.message);
            }
          }}
          onClose={() => setUserCard(null)}
          delegation={(() => {
            const d = activeDelegations.find((x) => x.grantorId === userCard.id);
            if (!d) return null;
            return {
              deputyName: resolveUser(directory, d.deputyId).fullName,
              note: d.note,
              endsAtLabel: fmtDate(d.endsAt),
            };
          })()} />
      )}
      {alarms.length > 0 && (
        <AlarmModal theme={theme} alarms={alarms} onError={showError}
          onOpenTask={(taskId) => setDetailId(taskId)}
          onDismiss={(id, info) => {
            api.ackReminderAlert(id).catch(() => {});
            setAlarms((prev) => prev.filter((a) => a.id !== id));
            if (info) showInfo(info);
          }} />
      )}

      {/* Сданная задача: то же всплывающее окно, что у сообщений, но со своим цветом и звуком. */}
      <ChatToast theme={theme} toast={readyToast && {
          author: readyToast.author,
          body: `Готова к сдаче: ${readyToast.title}`,
        }}
        accent={theme.success}
        label="задача готова к сдаче"
        action="Открыть задачу →"
        onDismiss={() => setReadyToast(null)}
        onOpen={() => {
          const id = readyToast?.taskId;
          setReadyToast(null);
          if (id) setDetailId(id);
        }} />

      <ChatToast theme={theme} toast={chatToast}
        onDismiss={() => setChatToast(null)}
        onOpen={() => {
          const id = chatToast?.chatId;
          setChatToast(null);
          if (id) setOpenChatId(id);
          goto({ view: CHATS, boardId: null });
        }} />

      {confirm && <ConfirmDialog theme={theme} {...confirm} onCancel={() => setConfirm(null)} />}
      {toast && <Toast theme={theme} message={toast.message} kind={toast.kind} onDismiss={() => setToast(null)} />}
    </div>
  );
}

// Компонент NewBoardModal предназначен для окна создания проекта.
function NewBoardModal({ theme, onClose, onCreate }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [bgPreset, setBgPreset] = useState("none");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!title.trim()) return;
    setBusy(true);
    await onCreate({ title: title.trim(), description, bgPreset, bgBlur: true });
    setBusy(false);
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-3xl" geometryKey="board-new">
      <ModalHeader theme={theme} title="Новый проект" onClose={onClose} />
      <Field label="Название" theme={theme}>
        <input value={title} onChange={(e) => setTitle(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} autoFocus
          placeholder="Например, «Инфраструктура API»" style={inputStyle(theme)} className="w-full rounded-xl px-3.5 h-10 text-[14px] outline-none" />
      </Field>
      <Field label="Описание" theme={theme}>
        <input value={description} onChange={(e) => setDescription(e.target.value)} style={inputStyle(theme)} className="w-full rounded-xl px-3.5 h-10 text-[14px] outline-none" />
      </Field>
      <Field label="Фон" theme={theme} hint="Своё изображение можно загрузить в настройках проекта">
        <div className="grid grid-cols-6 gap-2">
          {ALL_BACKGROUNDS.map((p) => {
            // Для пресетов-изображений (города, природа) используется миниатюра из /backgrounds.
            const thumb = bgThumbUrl(p.id);
            return (
              <button key={p.id} onClick={() => setBgPreset(p.id)}
                style={{
                  background: thumb ? `url(${thumb}) center/cover` : (p.css || theme.surfaceAlt),
                  backgroundSize: thumb ? "cover" : (p.size || "cover"),
                  border: `2px solid ${bgPreset === p.id ? theme.accent : theme.border}`,
                }}
                className="h-11 rounded-xl transition-transform duration-150 hover:scale-[1.03]" title={p.label} aria-label={p.label} aria-pressed={bgPreset === p.id} />
            );
          })}
        </div>
      </Field>
      <button onClick={submit} disabled={!title.trim() || busy} className="btn-primary w-full h-11 mt-2 disabled:opacity-40 disabled:cursor-not-allowed">
        {busy ? "Создаём…" : "Создать проект"}
      </button>
      <p style={{ color: theme.textMuted }} className="text-[12px] mt-3">Проект создаётся со стандартным набором колонок — их можно изменить в настройках.</p>
    </Modal>
  );
}
