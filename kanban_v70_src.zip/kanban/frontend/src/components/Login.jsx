// Модуль предназначен для формы входа и регистрации.

import React, { useEffect, useState } from "react";
import { appConfig } from "../lib/appConfig.js";
import { api } from "../lib/api.js";
import { Field, PasswordInput, PasswordRules, inputStyle } from "../lib/ui.jsx";
import { checkPassword } from "../lib/password.js";

// Функция safeSession предназначена для работы с sessionStorage без исключений (приватный режим, запрет хранилища).
export function safeSession(op, key, value) {
  try {
    if (op === "get") return sessionStorage.getItem(key);
    if (op === "set") sessionStorage.setItem(key, value);
    if (op === "remove") sessionStorage.removeItem(key);
  } catch { /* хранилище недоступно */ }
  return null;
}

// Компонент Login предназначен для входа и регистрации пользователя; при успехе вызывает onSuccess.
export default function Login({ theme, onSuccess }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ email: "", password: "", fullName: "", position: "", phone: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const krb = appConfig.kerberos;
  const passwordLogin = appConfig.passwordLogin;

  // Возврат со страницы входа Kerberos: код в адресе меняется на сессию, адрес очищается.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("krb_code");
    if (code) {
      window.history.replaceState(null, "", window.location.pathname + window.location.hash);
      setBusy(true);
      api.kerberosExchange(code)
        .then((u) => { safeSession("remove", "krb_tried"); onSuccess(u); })
        .catch((e) => setError(e.message)).finally(() => setBusy(false));
      return;
    }
    // Прозрачный вход: страница входа сразу отправляет браузер на порт Kerberos. Одна попытка за сеанс вкладки;
    // после выхода пользователя (krb_off), при ?nokrb=1 и после неудачной попытки показывается обычная форма.
    if (krb && !params.has("nokrb") && !safeSession("get", "krb_off") && !safeSession("get", "krb_tried")) {
      safeSession("set", "krb_tried", "1");
      setBusy(true);
      goKerberos();
    }
  }, []);

  // Переход на порт Kerberos того же сервера: браузер проходит SPNEGO и возвращается с одноразовым кодом.
  const goKerberos = () => {
    safeSession("remove", "krb_off");
    const proto = krb.https ? "https:" : "http:";
    const back = encodeURIComponent(window.location.origin + "/");
    window.location.href = `${proto}//${window.location.hostname}:${krb.port}/krb/login?return=${back}`;
  };

  const submit = async () => {
    setError("");
    // При регистрации требования к паролю проверяются до отправки формы.
    if (mode === "register") {
      const check = checkPassword(form.password);
      if (!check.valid) {
        setError(check.error || "Пароль не соответствует требованиям");
        return;
      }
    }
    setBusy(true);
    try {
      const user = mode === "login"
        ? await api.login(form.email.trim(), form.password)
        : await api.register({ email: form.email.trim(), password: form.password, fullName: form.fullName.trim(), position: form.position.trim(), phone: form.phone.trim() });
      onSuccess(user);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ background: theme.bg }} className="min-h-screen flex items-center justify-center p-4">
      <div style={{ borderRadius: 28, boxShadow: theme.dark ? "0 32px 80px -28px rgba(0,0,0,.7)" : "0 32px 80px -32px rgba(30,30,60,.35)" }}
        className="glass-pane w-full max-w-[400px] p-8">
        <img src="/logo-96.webp" width="56" height="56" alt="" decoding="async" className="app-logo w-14 h-14 mb-5" />
        <h1 style={{ color: theme.text, fontFamily: "var(--font-ui)" }} className="font-bold text-[26px] leading-tight tracking-[-0.02em]">{appConfig.appName}</h1>
        <p style={{ color: theme.textMuted }} className="text-[14px] mt-1 mb-6">{!passwordLogin ? "Вход выполняется через Kerberos" : mode === "login" ? "Вход в систему планирования задач" : "Создание учётной записи"}</p>

        {passwordLogin && (
          <>
        {mode === "register" && (
          <>
            <Field label="ФИО" theme={theme}><input value={form.fullName} onChange={(e) => set("fullName", e.target.value)} style={inputStyle(theme)} className="w-full rounded-xl px-3.5 h-11 text-[14px] outline-none" placeholder="Иванов Иван" /></Field>
            <Field label="Должность" theme={theme}><input value={form.position} onChange={(e) => set("position", e.target.value)} style={inputStyle(theme)} className="w-full rounded-xl px-3.5 h-11 text-[14px] outline-none" placeholder="Frontend-разработчик" /></Field>
            <Field label="Телефон" theme={theme}><input value={form.phone} onChange={(e) => set("phone", e.target.value)} style={inputStyle(theme)} className="w-full rounded-xl px-3.5 h-11 text-[14px] outline-none" placeholder="+7 900 000-00-00" /></Field>
          </>
        )}

        <Field label="Электронная почта" theme={theme}>
          <input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} autoFocus style={inputStyle(theme)} className="w-full rounded-xl px-3.5 h-11 text-[14px] outline-none" placeholder="name@team.dev" />
        </Field>
        <Field label="Пароль" theme={theme}>
          <PasswordInput theme={theme} value={form.password} onChange={(e) => set("password", e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} className="w-full rounded-xl px-3.5 h-11 text-[14px] outline-none" />
          {/* При входе требования к паролю не отображаются. */}
          {mode === "register" && (
            <div className="mt-2"><PasswordRules theme={theme} value={form.password} /></div>
          )}
        </Field>

        {error && <p style={{ color: theme.danger }} className="text-[13px] mb-3" role="alert">{error}</p>}

        <button onClick={submit} disabled={busy} className="btn-primary w-full h-11 mt-2 text-[15px] disabled:opacity-50">
          {busy ? "Подождите…" : mode === "login" ? "Войти" : "Зарегистрироваться"}
        </button>
        <button onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }} style={{ color: theme.textMuted }} className="w-full text-[13px] mt-4 py-1 rounded-full transition-colors hover:text-[var(--t-text)]">
          {mode === "login" ? "Нет учётной записи? Зарегистрироваться" : "Уже есть учётная запись? Войти"}
        </button>

          </>
        )}

        {krb && (
          <button onClick={goKerberos} disabled={busy}
            className={`${passwordLogin ? "btn-pill mt-3" : "btn-primary mt-2"} w-full h-11 text-[15px] disabled:opacity-50`}>
            {krb.buttonText || "Войти через Kerberos"}
          </button>
        )}
        {!passwordLogin && error && <p style={{ color: theme.danger }} className="text-[13px] mt-3" role="alert">{error}</p>}

        {/* Регистрация по умолчанию закрыта: учётные записи создаёт администратор. Форма остаётся доступной, так как */}
        {/* на пустой базе через неё создаётся первый администратор. */}
        {passwordLogin && mode === "register" && (
          <p style={{ color: theme.textMuted }} className="text-[12px] mt-3 leading-relaxed text-center">
            Если регистрация закрыта, учётную запись создаст администратор.
            На пустой системе первая созданная запись получает права администратора.
          </p>
        )}
      </div>
    </div>
  );
}
