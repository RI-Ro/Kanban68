import React, { useEffect, useMemo, useRef, useState } from "react";
import { Camera, Trash2 } from "lucide-react";
import { api } from "../lib/api.js";
import { Avatar, Modal, ModalHeader } from "../lib/ui.jsx";

// Модуль предназначен для выбора фотографии пользователя: себе или (для администратора) выбранному пользователю.
// Изображение перед отправкой приводится в браузере к квадрату 512 px (JPEG): так принимаются и WebP, и снимки с телефона.

const VIEW = 260; // сторона области кадрирования, px
const OUT = 512;  // сторона итогового фото, px

// Компонент CropDialog предназначен для выбора области фото: изображение перетаскивается и масштабируется ползунком,
// чтобы лицо оказалось в кадре (по центру обрезалось бы только по середине кадра). Результат — квадратный JPEG.
function CropDialog({ theme, file, onCancel, onDone }) {
  const [img, setImg] = useState(null);
  const [zoom, setZoom] = useState(1);
  const [pos, setPos] = useState({ x: 0, y: 0 });   // смещение изображения относительно кадра, px
  const drag = useRef(null);

  useEffect(() => {
    let alive = true;
    createImageBitmap(file).then((bmp) => {
      if (!alive) return;
      setImg(bmp);
      // Начальное положение: по ширине по центру, по высоте выше середины, где у портретов обычно лицо.
      const base = VIEW / Math.min(bmp.width, bmp.height);
      setPos({ x: (VIEW - bmp.width * base) / 2, y: (VIEW - bmp.height * base) * 0.2 });
    }).catch(() => alive && onDone(file));
    return () => { alive = false; };
  }, [file]); // eslint-disable-line react-hooks/exhaustive-deps

  const preview = useMemo(() => URL.createObjectURL(file), [file]);
  useEffect(() => () => URL.revokeObjectURL(preview), [preview]);
  if (!img) return null;

  const base = VIEW / Math.min(img.width, img.height);
  const w = img.width * base * zoom;
  const h = img.height * base * zoom;
  // Изображение не должно оставлять пустых полей в кадре.
  const clamp = (p, nw, nh) => ({
    x: Math.min(0, Math.max(VIEW - nw, p.x)),
    y: Math.min(0, Math.max(VIEW - nh, p.y)),
  });
  const cur = clamp(pos, w, h);

  const changeZoom = (z) => {
    // Масштабирование вокруг центра кадра.
    const k = z / zoom;
    const cx = VIEW / 2, cy = VIEW / 2;
    const nw = img.width * base * z, nh = img.height * base * z;
    setZoom(z);
    setPos(clamp({ x: cx - (cx - cur.x) * k, y: cy - (cy - cur.y) * k }, nw, nh));
  };

  const down = (e) => { drag.current = { sx: e.clientX, sy: e.clientY, ox: cur.x, oy: cur.y }; e.currentTarget.setPointerCapture(e.pointerId); };
  const move = (e) => {
    if (!drag.current) return;
    setPos(clamp({ x: drag.current.ox + e.clientX - drag.current.sx, y: drag.current.oy + e.clientY - drag.current.sy }, w, h));
  };
  const up = () => { drag.current = null; };

  const save = async () => {
    const canvas = document.createElement("canvas");
    canvas.width = OUT; canvas.height = OUT;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, OUT, OUT);
    // Видимая область кадра в координатах исходного изображения.
    const k = (img.width * base * zoom) / img.width;
    ctx.drawImage(img, -cur.x / k, -cur.y / k, VIEW / k, VIEW / k, 0, 0, OUT, OUT);
    const blob = await new Promise((res) => canvas.toBlob(res, "image/jpeg", 0.9));
    onDone(blob ? new File([blob], "photo.jpg", { type: "image/jpeg" }) : file);
  };

  return (
    <Modal theme={theme} onClose={onCancel} width="max-w-sm" geometryKey="photo-crop">
      <ModalHeader theme={theme} title="Область фото" onClose={onCancel} />
      <p style={{ color: theme.textMuted }} className="text-[13px] mb-3">
        Перетащите фото, чтобы лицо оказалось в круге, и подберите масштаб.
      </p>
      <div className="flex justify-center">
        <div onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}
          style={{ width: VIEW, height: VIEW, position: "relative", overflow: "hidden", borderRadius: 16, touchAction: "none",
            cursor: "grab", background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}>
          <img src={preview} alt="" draggable={false}
            style={{ position: "absolute", left: cur.x, top: cur.y, width: w, height: h, maxWidth: "none", userSelect: "none", pointerEvents: "none" }} />
          {/* Круг показывает, как фото будет выглядеть в аватаре; вне круга — затемнение. */}
          <div style={{ position: "absolute", inset: 0, borderRadius: "50%", boxShadow: "0 0 0 999px rgba(0,0,0,.45)", pointerEvents: "none",
            border: "2px solid rgba(255,255,255,.9)" }} />
        </div>
      </div>
      <input type="range" min="1" max="3" step="0.01" value={zoom} onChange={(e) => changeZoom(Number(e.target.value))}
        aria-label="Масштаб" className="w-full mt-4" />
      <div className="flex justify-end gap-2 mt-4">
        <button onClick={onCancel} className="btn-pill">Отмена</button>
        <button onClick={save} className="btn-primary">Сохранить фото</button>
      </div>
    </Modal>
  );
}

// Компонент PhotoEditor предназначен для показа текущего фото и кнопок «Выбрать фото» и «Убрать».
// userId задаётся для администратора; без него меняется фото текущего пользователя.
export default function PhotoEditor({ theme, user, userId, onChanged, onError, onInfo }) {
  const input = useRef(null);
  const [busy, setBusy] = useState(false);
  const has = Boolean(user?.photoVersion);

  const [pending, setPending] = useState(null);   // выбранный файл до кадрирования
  const pick = (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (file) setPending(file);
  };

  const upload = async (ready) => {
    setPending(null);
    setBusy(true);
    try {
      await (userId ? api.adminUploadPhoto(userId, ready) : api.uploadMyPhoto(ready));
      onInfo?.("Фото сохранено");
      await onChanged?.();
    } catch (err) {
      onError?.(err.message);
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await (userId ? api.adminDeletePhoto(userId) : api.deleteMyPhoto());
      onInfo?.("Фото убрано");
      await onChanged?.();
    } catch (err) {
      onError?.(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex items-center gap-4">
      {pending && <CropDialog theme={theme} file={pending} onCancel={() => setPending(null)} onDone={upload} />}
      <Avatar user={user} size={84} theme={theme} />
      <div className="flex flex-col gap-2 items-start">
        <input ref={input} type="file" accept="image/*" className="hidden" onChange={pick} />
        <button onClick={() => input.current?.click()} disabled={busy} className="btn-pill">
          <Camera size={14} style={{ color: theme.accent }} /> {has ? "Заменить фото" : "Выбрать фото"}
        </button>
        {has && (
          <button onClick={remove} disabled={busy} className="btn-pill" style={{ color: theme.danger }}>
            <Trash2 size={14} /> Убрать фото
          </button>
        )}
        <span style={{ color: theme.textMuted }} className="text-[12px] max-w-[240px]">
          Без фото показываются инициалы. Фото из LDAP обновляется при входе, но не заменяет загруженное вручную.
        </span>
      </div>
    </div>
  );
}
