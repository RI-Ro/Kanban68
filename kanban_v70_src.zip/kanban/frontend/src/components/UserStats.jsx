// Модуль предназначен для статистики по задачам пользователя: плитки, распределение по статусам, динамика по неделям,
// разрезы по приоритетам и проектам, ближайшие задачи. Используется в карточке пользователя и в общей статистике.

import React, { useEffect, useState } from "react";
import { api } from "../lib/api.js";
import { Modal, ModalHeader } from "../lib/ui.jsx";
import { PRIORITIES, fmtDate } from "../lib/theme.js";

// Функция pctOf предназначена для расчёта доли в процентах (целое число).
const pctOf = (n, of) => (of > 0 ? Math.round((n / of) * 100) : 0);

// Компонент Tile предназначен для плитки с числом и подписью.
function Tile({ theme, label, value, sub, color }) {
  return (
    <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }} className="rounded-2xl px-3.5 py-3 min-w-[110px] flex-1">
      <div style={{ color: theme.textMuted }} className="text-[11.5px] font-medium">{label}</div>
      <div style={{ color: color || theme.text }} className="text-[24px] font-semibold tabular-nums leading-tight mt-0.5">{value}</div>
      {sub && <div style={{ color: theme.textMuted }} className="text-[11.5px] mt-0.5">{sub}</div>}
    </div>
  );
}

// Компонент Section предназначен для блока с заголовком.
function Section({ theme, title, children }) {
  return (
    <section className="mt-5">
      <h4 style={{ color: theme.text }} className="text-[13.5px] font-semibold mb-2">{title}</h4>
      {children}
    </section>
  );
}

// Компонент StackBar предназначен для горизонтальной полосы из сегментов {value,color,label}.
function StackBar({ theme, parts }) {
  const total = parts.reduce((s, p) => s + p.value, 0);
  return (
    <div>
      <div style={{ background: theme.surfaceAlt }} className="flex h-3.5 rounded-full overflow-hidden">
        {total > 0 && parts.filter((p) => p.value > 0).map((p) => (
          <div key={p.label} title={`${p.label}: ${p.value}`} style={{ width: `${(p.value / total) * 100}%`, background: p.color }} />
        ))}
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2">
        {parts.map((p) => (
          <span key={p.label} style={{ color: theme.textMuted }} className="text-[12px] flex items-center gap-1.5">
            <i style={{ background: p.color, width: 9, height: 9, borderRadius: 3, display: "inline-block" }} />
            {p.label}: <b style={{ color: theme.text }} className="tabular-nums">{p.value}</b>
            {total > 0 && <span className="tabular-nums">({pctOf(p.value, total)}%)</span>}
          </span>
        ))}
      </div>
    </div>
  );
}

// Компонент WeeklyChart предназначен для сгруппированных столбцов «поручено / выполнено» по неделям.
function WeeklyChart({ theme, weekly }) {
  const max = Math.max(1, ...weekly.flatMap((w) => [w.assigned, w.done]));
  const H = 110;
  return (
    <div>
      <div className="flex items-end gap-1.5" style={{ height: H + 18 }}>
        {weekly.map((w) => (
          <div key={w.week} className="flex-1 min-w-0 flex flex-col items-center justify-end h-full" title={`Неделя с ${fmtDate(w.week)}: поручено ${w.assigned}, выполнено ${w.done}`}>
            <div className="flex items-end gap-[2px] w-full justify-center" style={{ height: H }}>
              <div style={{ height: Math.max(2, (w.assigned / max) * H), background: theme.accent, opacity: w.assigned ? 1 : 0.25 }} className="w-1/2 max-w-[14px] rounded-t" />
              <div style={{ height: Math.max(2, (w.done / max) * H), background: theme.success, opacity: w.done ? 1 : 0.25 }} className="w-1/2 max-w-[14px] rounded-t" />
            </div>
            <div style={{ color: theme.textMuted }} className="text-[10px] mt-1 tabular-nums">{fmtDate(w.week).slice(0, 5)}</div>
          </div>
        ))}
      </div>
      <div className="flex gap-4 mt-1">
        <span style={{ color: theme.textMuted }} className="text-[12px] flex items-center gap-1.5"><i style={{ background: theme.accent, width: 9, height: 9, borderRadius: 3, display: "inline-block" }} />Поручено</span>
        <span style={{ color: theme.textMuted }} className="text-[12px] flex items-center gap-1.5"><i style={{ background: theme.success, width: 9, height: 9, borderRadius: 3, display: "inline-block" }} />Выполнено</span>
      </div>
    </div>
  );
}

// Компонент MiniTable предназначен для таблицы с долей выполненных в строке.
function MiniTable({ theme, head, rows }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-[12.5px]" style={{ color: theme.text }}>
        <thead>
          <tr style={{ color: theme.textMuted }} className="text-left">
            {head.map((h, i) => <th key={h} className={`font-medium py-1.5 pr-3 ${i ? "text-right" : ""}`}>{h}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.key} style={{ borderTop: `1px solid ${theme.border}` }}>
              {r.cells.map((c, i) => <td key={i} className={`py-1.5 pr-3 tabular-nums ${i ? "text-right" : "max-w-[220px] truncate"}`}
                style={i && r.alertCol === i && c > 0 ? { color: theme.danger } : undefined}>{c}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Компонент StatsView предназначен для отображения готовой статистики (ответ /dashboard/users/:id/stats или myStats).
export function StatsView({ theme, stats }) {
  if (!stats) return null;
  const a = stats.assigned || {}, c = stats.created || {}, q = stats.quality || {}, act = stats.activity || {};
  const weekly = stats.weekly || [];
  const onTime = pctOf(q.onTime || 0, q.withDue || 0);
  const avg = q.avgDays == null ? "—" : `${q.avgDays < 10 ? Number(q.avgDays).toFixed(1).replace(".", ",") : Math.round(q.avgDays)} дн.`;
  const dayFmt = (d) => (d ? fmtDate(d) : "без срока");

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        <Tile theme={theme} label="Всего поручено" value={a.total || 0} sub={`выполнено ${pctOf(a.done || 0, a.total || 0)}%`} />
        <Tile theme={theme} label="В работе" value={a.inProgress || 0} color={theme.accent} />
        <Tile theme={theme} label="Сдано" value={a.ready || 0} color={theme.warning} sub="ожидают проверки" />
        <Tile theme={theme} label="Выполнено" value={a.done || 0} color={theme.success} />
        <Tile theme={theme} label="Просрочено" value={a.overdue || 0} color={(a.overdue || 0) > 0 ? theme.danger : undefined} />
      </div>

      <Section theme={theme} title="Поручено пользователю: распределение">
        <StackBar theme={theme} parts={[
          { label: "В работе", value: a.inProgress || 0, color: theme.accent },
          { label: "Сдано", value: a.ready || 0, color: theme.warning },
          { label: "Выполнено", value: a.done || 0, color: theme.success },
        ]} />
        <div className="flex flex-wrap gap-x-5 gap-y-1 mt-2 text-[12px]" style={{ color: theme.textMuted }}>
          <span>Срок в ближайшие 7 дней: <b style={{ color: theme.text }}>{a.dueSoon || 0}</b></span>
          <span>Открытых без срока: <b style={{ color: theme.text }}>{a.noDue || 0}</b></span>
        </div>
      </Section>

      <Section theme={theme} title="Динамика за 12 недель">
        <WeeklyChart theme={theme} weekly={weekly} />
      </Section>

      <Section theme={theme} title="Исполнительская дисциплина">
        <div className="flex flex-wrap gap-2">
          <Tile theme={theme} label="В срок" value={q.withDue ? `${onTime}%` : "—"} sub={q.withDue ? `${q.onTime} из ${q.withDue} со сроком` : "нет задач со сроком"}
            color={q.withDue ? (onTime >= 80 ? theme.success : onTime >= 50 ? theme.warning : theme.danger) : undefined} />
          <Tile theme={theme} label="С опозданием" value={q.late || 0} />
          <Tile theme={theme} label="Среднее время выполнения" value={avg} sub="от создания до сдачи" />
          <Tile theme={theme} label="Комментарии" value={act.comments || 0} sub={`за 30 дней: ${act.comments30 || 0}`} />
        </div>
      </Section>

      <Section theme={theme} title="Поставлено пользователем">
        <StackBar theme={theme} parts={[
          { label: "Открыто", value: c.open || 0, color: theme.accent },
          { label: "Выполнено", value: c.done || 0, color: theme.success },
        ]} />
        <div style={{ color: theme.textMuted }} className="text-[12px] mt-2">
          Всего поставлено: <b style={{ color: theme.text }}>{c.total || 0}</b>, просрочено открытых: <b style={{ color: theme.text }}>{c.overdue || 0}</b>
        </div>
      </Section>

      {(stats.byPriority || []).length > 0 && (
        <Section theme={theme} title="По приоритетам">
          <MiniTable theme={theme} head={["Приоритет", "Всего", "В работе", "Выполнено", "Просрочено"]}
            rows={stats.byPriority.map((p) => ({ key: p.priority, alertCol: 4,
              cells: [PRIORITIES[p.priority]?.label || p.priority, p.total, p.open, p.done, p.overdue] }))} />
        </Section>
      )}

      {(stats.byBoard || []).length > 0 && (
        <Section theme={theme} title="По проектам">
          <MiniTable theme={theme} head={["Проект", "Всего", "В работе", "Сдано", "Выполнено", "Просрочено"]}
            rows={stats.byBoard.map((b) => ({ key: b.boardId, alertCol: 5,
              cells: [b.title, b.total, b.inProgress, b.ready, b.done, b.overdue] }))} />
        </Section>
      )}

      {(stats.openTasks || []).length > 0 && (
        <Section theme={theme} title="Открытые задачи (по сроку)">
          <MiniTable theme={theme} head={["Задача", "Проект", "Срок"]}
            rows={stats.openTasks.map((t) => ({ key: t.id, cells: [t.title, t.boardTitle, dayFmt(t.dueDate)] }))} />
        </Section>
      )}
    </div>
  );
}

// Компонент UserStatsModal предназначен для окна статистики пользователя.
export default function UserStatsModal({ theme, user, onClose }) {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    let alive = true;
    api.userStats(user.id).then((s) => alive && setStats(s)).catch((e) => alive && setError(e.message));
    return () => { alive = false; };
  }, [user.id]);

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-3xl" geometryKey="user-stats">
      <ModalHeader theme={theme} title={`Статистика: ${user.fullName}`}
        subtitle="Учитываются только задачи, доступные вам" onClose={onClose} />
      {error && <p style={{ color: theme.danger }} className="text-[13px]">{error}</p>}
      {!stats && !error && <p style={{ color: theme.textMuted }} className="text-[13px]">Загрузка…</p>}
      <StatsView theme={theme} stats={stats} />
    </Modal>
  );
}
